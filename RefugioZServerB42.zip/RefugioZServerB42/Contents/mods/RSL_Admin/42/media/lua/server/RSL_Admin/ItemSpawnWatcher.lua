-- RSL_Admin/ItemSpawnWatcher.lua (server)
-- Non-invasive (Power-ADM style): detect staff "spawn/give item" actions via OnClientCommand,
-- then confirm by diffing the player's inventory on the SERVER and writing to Spawn_Itens log.
--
-- Why this works in MP:
--  - The server is source-of-truth for the inventory.
--  - We do NOT patch UI/client functions (no ISItemsListTable monkeypatch).
--
-- This is best-effort because vanilla command names can vary by minor patch/mods.
-- We match by keywords and/or args, then verify by inventory diff.

if not isServer() then return end

require "RSL_Admin/Config"
require "RSL_Admin/Paths"
require "RSL_Admin/LogWriter"

RSL_Admin = RSL_Admin or {}
RSL_Admin.Server = RSL_Admin.Server or {}

if not (RSL_Admin.Config and RSL_Admin.Config.LogStaffItemSpawns) then return end

local pending = {} -- pending[onlineIdStr] = { before=set, at=sec, hint=str, player=player }
local lastAt = {}  -- per onlineID, anti-spam

local function nowSec()
    -- Return seconds (float). getTimestamp() is usually milliseconds in B42.
    local t
    if _G.getTimestamp then
        local ok, v = pcall(_G.getTimestamp)
        if ok and type(v) == "number" then t = v end
    end
    if not t then t = (os and os.time and os.time()) or 0 end
    if t > 1000000000000 then t = t / 1000 end -- ms -> s
    return t
end

local function onlineIdStr(player)
    if player and player.getOnlineID then
        local ok, v = pcall(player.getOnlineID, player)
        if ok and v ~= nil then return tostring(v) end
    end
    return tostring(player or "nil")
end

local function allowRate(player)
    local secs = (RSL_Admin.Config and RSL_Admin.Config.RateLimitSeconds) or 0.15
    if secs <= 0 then return true end
    local id = onlineIdStr(player)
    local t = nowSec()
    local prev = lastAt[id] or 0
    if (t - prev) < secs then return false end
    lastAt[id] = t
    return true
end

local function accessLevelOf(player)
    -- Avoid pcall inside frequent command hooks; getAccessLevel exists on server player objects.
    if not player or not player.getAccessLevel then return "None" end
    local v = player:getAccessLevel()
    if v and tostring(v) ~= "" then return tostring(v) end
    return "None"
end

local function isStaff(player)
    local lvl = accessLevelOf(player)
    return lvl ~= "None"
end

local function safeCall(obj, fn, ...)
    if obj and obj[fn] then
        local ok, v = pcall(obj[fn], obj, ...)
        if ok then return v end
    end
    return nil
end

local function snapshotInventory(player)
    local set, byId = {}, {}
    local inv = safeCall(player, "getInventory")
    if not inv then return set, byId end
    local items = safeCall(inv, "getItems")
    if not items or not items.size then return set, byId end
    local okSize, size = pcall(items.size, items)
    if not okSize or not size then return set, byId end

    for i = 0, size - 1 do
        local it = items:get(i)
        if it then
            local id = safeCall(it, "getID")
            if id ~= nil then
                id = tostring(id)
                set[id] = true
                byId[id] = it
            end
        end
    end
    return set, byId
end

local function itemDesc(it)
    local ft = safeCall(it, "getFullType")
    if ft then ft = tostring(ft) else ft = "unknown" end
    local dn = safeCall(it, "getDisplayName")
    if dn and tostring(dn) ~= "" then
        dn = tostring(dn)
    else
        dn = ft
    end
    return dn, ft
end

local function norm(s) return tostring(s or ""):lower() end

local spawnCmdKW = {
    "additem","spawn","give","createitem","addtoinv","addinventory","add_to_inv","add_to_inventory",
    "itemspawn","spawnitem","giveitem","addone","additems","additemstoinventory",
}

local spawnModKW = {
    "admin","debug","item","items","inventory","player","cheat",
}

local function argsHasItemHint(args)
    if type(args) ~= "table" then return false end
    for k,v in pairs(args) do
        local ks = norm(k)
        if ks == "item" or ks == "fulltype" or ks == "type" or ks == "id" or ks:find("item") then
            if type(v) == "string" and v:find("%.") then return true end
        end
    end
    return false
end

local function extractHint(args)
    if type(args) ~= "table" then return nil end
    -- common keys
    local keys = { "fullType","fulltype","item","type","itemType","itemtype","name","itemName","itemname" }
    for _,k in ipairs(keys) do
        local v = args[k]
        if type(v) == "string" and v ~= "" then return v end
    end
    -- any string that looks like Module.Item
    for _,v in pairs(args) do
        if type(v) == "string" and v:find("%.") then return v end
    end
    return nil
end

local function looksLikeSpawn(module, command, args)
    module = norm(module)
    command = norm(command)
    local modOk = false
    for _,kw in ipairs(spawnModKW) do
        if module == kw then modOk = true break end
    end

    local cmdOk = false
    for _,kw in ipairs(spawnCmdKW) do
        if command:find(kw, 1, true) then cmdOk = true break end
    end

    -- Accept: (admin/debug) + any item-hint args, OR command keywords.
    if cmdOk then return true end
    if modOk and argsHasItemHint(args) then return true end

    -- Also accept: module has "admin" and command has "item"
    if module:find("admin", 1, true) and command:find("item", 1, true) then return true end
    return false
end

local function writeSpawnLine(player, reason)
    if not player then return end
    if module == "BurdJournals" then return end -- compat: never touch BurdJournals commands
    local sid, user, _access = RSL_Admin.LogWriter:prefix(player)
    local line = string.format("%s [%s] %s", tostring(sid), tostring(user), tostring(reason))
    RSL_Admin.LogWriter:write(RSL_Admin.Paths.ItemSpawn, line)
end

local function flush()
    local t = nowSec()
    for id, rec in pairs(pending) do
        if (t - (rec.at or 0)) >= 0.20 then
            local player = rec.player
            local afterSet, afterById = snapshotInventory(player)
            local newIds = {}

            for itemId,_ in pairs(afterSet) do
                if not (rec.before and rec.before[itemId]) then
                    table.insert(newIds, itemId)
                end
            end

            if #newIds > 0 then
                -- Deterministic output
                table.sort(newIds)
                for _, itemId in ipairs(newIds) do
                    local it = afterById[itemId]
                    local dn, ft = itemDesc(it)
                    writeSpawnLine(player, "Spawned item: " .. dn .. " (" .. ft .. ")")
                end
            else
                -- Fallback: if we couldn't diff (stacking, timing), log the command hint.
                if rec.hint then
                    writeSpawnLine(player, "Spawned item: " .. tostring(rec.hint))
                else
                    writeSpawnLine(player, "Spawned item (no diff detected)")
                end
            end

            pending[id] = nil
        elseif (t - (rec.at or 0)) > 3.0 then
            pending[id] = nil
        end
    end
end

local function onClientCommand(module, command, player, args)
    if not player then return end
    -- Compat: filter by module/command FIRST (pure Lua), only then touch player Java methods.
    if not looksLikeSpawn(module, command, args) then return end
    if not isStaff(player) then return end
    if not allowRate(player) then return end

    -- Snapshot BEFORE the spawn is applied; diff later.
    local id = onlineIdStr(player)
    local beforeSet = select(1, snapshotInventory(player))
    pending[id] = {
        player = player,
        before = beforeSet,
        at = nowSec(),
        hint = extractHint(args),
        module = tostring(module or ""),
        command = tostring(command or ""),
    }
end

Events.OnClientCommand.Add(onClientCommand)
if Events and Events.OnTick then Events.OnTick.Add(flush) end

print("[RSL_Admin] ItemSpawnWatcher loaded (server, non-invasive).")
