-- RSL_Admin/SafehouseHooksServer.lua (server)
if not isServer() then return end
require "RSL_Admin/Config"
require "RSL_Admin/LogWriter"
require "RSL_Admin/Paths"

local function now() return os.date("%Y-%m-%d %H:%M:%S") end

local function logRelease(player, sh)
    if not (RSL_Admin.Config and RSL_Admin.Config.LogReleasedSafehouses) then return end
    if not player then return end

    local sid, user, access = RSL_Admin.LogWriter:prefix(player)
    local pos = "0,0,0"
    if sh and sh.getX then
        local okx,x = pcall(sh.getX, sh)
        local oky,y = pcall(sh.getY, sh)
        local okz,z = pcall(sh.getZ, sh)
        if okx and oky and okz then
            pos = tostring(x or 0)..","..tostring(y or 0)..","..tostring(z or 0)
        end
    end

    local line = string.format("%s %s [%s]: released safehouse at %s (%s)", sid, user, access, pos, now())
    RSL_Admin.LogWriter:write(RSL_Admin.Paths.ReleasedSafehouses, line)
end

local function wrap(tbl, fname)
    if not tbl or type(tbl[fname]) ~= "function" then return false end
    local orig = tbl[fname]
    tbl[fname] = function(...)
        local args = {...}
        local player, sh = nil, nil
        for _,v in ipairs(args) do
            if v and type(v)=="userdata" then
                if not player and v.getUsername then player = v end
                if not sh and v.getX and v.getW then sh = v end
            end
        end
        local ok, res = pcall(orig, ...)
        if player then pcall(logRelease, player, sh) end
        if ok then return res end
        return nil
    end
    print("[RSL_Admin] SafehouseHooksServer wrapped "..fname)
    return true
end

local okAny = false
if SafeHouse then
    okAny = wrap(SafeHouse, "removeSafeHouse") or okAny
    okAny = wrap(SafeHouse, "releaseSafeHouse") or okAny
    okAny = wrap(SafeHouse, "removeSafeHouseFromPlayer") or okAny
    okAny = wrap(SafeHouse, "removeSafehouseFromPlayer") or okAny
end

print("[RSL_Admin] SafehouseHooksServer loaded. wrapped="..tostring(okAny))
