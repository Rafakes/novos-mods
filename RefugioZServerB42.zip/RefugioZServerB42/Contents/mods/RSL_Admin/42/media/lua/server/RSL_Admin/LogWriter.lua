-- RSL_Admin/LogWriter.lua (server)
-- Same write strategy as Server Shop: getFileWriter("/RSL_Admin/...") -> Zomboid/Lua/RSL_Admin/...

if not isServer() then return end

require "RSL_Admin/Paths"

RSL_Admin = RSL_Admin or {}
RSL_Admin.LogWriter = RSL_Admin.LogWriter or {}

local function sanitizeRelPath(rel)
    if not rel then return nil end
    rel = tostring(rel)
    if rel:find("%.%.") then return nil end
    if rel:sub(1,1) == "/" then return nil end
    rel = rel:gsub("\\", "/")
    return rel
end

local function getSteamID(p)
    -- SteamID público (SteamID64) como STRING (evita perda de precisão do Lua com números grandes).
    -- Prioridade:
    -- 1) UdpConnection.*string (idStr/steamIDStr/etc)
    -- 2) UdpConnection:getSteamID*() + SteamUtils.convertSteamIDToString
    -- 3) p:getSteamID() + SteamUtils.convertSteamIDToString
    -- 4) Último fallback: formatar número (pode ser impreciso se o número já veio como double)

    local DEBUG_STEAMID = false -- deixe true por 1 boot se precisar diagnosticar

    local function dbg(msg)
        if DEBUG_STEAMID then
            print("[RSL_Admin][SteamID] " .. tostring(msg))
        end
    end

    local function asDigitsString(v)
        if v == nil then return nil end
        if type(v) == "string" then
            local s = v:gsub("%s+", "")
            if s:match("^%d+$") then return s end
            return nil
        end
        if type(v) == "number" then
            -- Evita notação científica no tostring()
            local s = string.format("%.0f", v)
            if s:match("^%d+$") then return s end
            return nil
        end
        -- userdata/long Java
        local s = tostring(v)
        s = s:gsub("%s+", "")
        if s:match("^%d+$") then return s end
        return nil
    end

    local function isValidSteamId64(s)
        s = asDigitsString(s)
        if not s then return false end
        -- SteamID64 normalmente tem 17 dígitos (7656119xxxxxxxxxx)
        if #s < 16 or #s > 20 then return false end
        return true
    end

    local function convertIfPossible(v)
        -- Tenta converter usando API do jogo (quando disponível)
        if SteamUtils and SteamUtils.convertSteamIDToString then
            local ok, s = pcall(SteamUtils.convertSteamIDToString, v)
            if ok and isValidSteamId64(s) then return asDigitsString(s) end
        end
        local s = asDigitsString(v)
        if isValidSteamId64(s) then return s end
        return nil
    end

    local function pickConnSteamIdStr(con)
        if not con then return nil end

        -- Campos comuns (strings)
        local candidates = {
            con.idStr,
            con.steamIDStr,
            con.steamIdStr,
            con.steamIDString,
            con.steamIdString,
        }
        for _, v in ipairs(candidates) do
            local s = asDigitsString(v)
            if isValidSteamId64(s) then return s end
        end

        -- Métodos comuns que podem existir nesta B42
        local methods = {
            "getSteamIDString",
            "getSteamIdString",
            "getSteamIDStr",
            "getSteamIdStr",
            "getSteamID",
            "getSteamId",
            "getID",
            "getId",
        }
        for _, m in ipairs(methods) do
            if con[m] then
                local ok, v = pcall(con[m], con)
                if ok then
                    local s = convertIfPossible(v)
                    if s then return s end
                end
            end
        end

        -- Campos numéricos (último recurso)
        local numericCandidates = { con.steamID, con.steamId, con.id }
        for _, v in ipairs(numericCandidates) do
            local s = convertIfPossible(v)
            if s then return s end
        end

        return nil
    end

    -- 1) Melhor fonte: conexão do servidor (dedicado/MP)
    if p and GameServer and GameServer.getConnectionFromPlayer then
        local ok, con = pcall(function() return GameServer.getConnectionFromPlayer(p) end)
        if ok and con then
            local sid = pickConnSteamIdStr(con)
            if sid then return sid end
            dbg("No SteamID string on connection for user=" .. tostring(p.getUsername and p:getUsername() or "?"))
        end
    end

    -- 2) Host/local (quando não há UdpConnection)
    if SteamUser and SteamUser.GetSteamIDString then
        local ok, s = pcall(SteamUser.GetSteamIDString)
        if ok and isValidSteamId64(s) then return asDigitsString(s) end
    end

    -- 3) Fallbacks via player
    if p and p.getSteamID then
        local ok, v = pcall(p.getSteamID, p)
        if ok then
            local sid = convertIfPossible(v)
            if sid then return sid end
        end
    end

    -- 4) Último fallback: OnlineID
    if p and p.getOnlineID then
        local ok, v = pcall(p.getOnlineID, p)
        if ok and v ~= nil then return tostring(v) end
    end

    return "0"
end


local function getDisplayName(p)
    if p and p.getDisplayName then
        local ok, v = pcall(p.getDisplayName, p)
        if ok and v and tostring(v) ~= "" then return tostring(v) end
    end
    if p and p.getUsername then
        local ok, v = pcall(p.getUsername, p)
        if ok and v and tostring(v) ~= "" then return tostring(v) end
    end
    return "unknown"
end

local function getAccessLevel(p)
    if p and p.getAccessLevel then
        local ok, v = pcall(p.getAccessLevel, p)
        if ok and v and tostring(v) ~= "" then return tostring(v) end
    end
    return "None"
end

local function writeLineTo(path, line)
    local ok, writer = pcall(getFileWriter, path, true, true) -- append, create
    if ok and writer then
        pcall(writer.write, writer, line)
        pcall(writer.write, writer, "\r\n")
        pcall(writer.close, writer)
        return true
    end
    return false
end

local function touchFile(path)
    local ok, writer = pcall(getFileWriter, path, true, true) -- append, create
    if ok and writer then
        pcall(writer.close, writer)
        return true
    end
    return false
end


local function sanitizeFileName(name, maxLen)
    name = tostring(name or ""):gsub("\\", "_"):gsub("/", "_")
    name = name:gsub("[^%w%._%-]", "_"):gsub("_+", "_")
    maxLen = tonumber(maxLen) or 64
    if #name > maxLen then name = name:sub(1, maxLen) end
    if name == "" then name = "unknown" end
    return name
end

-- Write a log line to a per-player file inside an approved category directory.
-- This bypasses Paths.Allowed intentionally, but only allows a fixed set of category dirs and sanitizes filenames.
function RSL_Admin.LogWriter:writePlayerFile(categoryDir, player, suffix, line)
    categoryDir = tostring(categoryDir or "")
    local allowedCats = { ADM_power=true, Tiles_log=true, Spawn_Itens=true, Safehouse_logs=true }
    if not allowedCats[categoryDir] then return false end

    local sid, user = self:prefix(player)
    local file = sanitizeFileName(tostring(sid) .. "_" .. tostring(user) .. "_" .. tostring(suffix or "log")) .. ".log"
    file = file:gsub("%.log%.log$", ".log")

    local full = RSL_Admin.Paths.BaseDir .. "/" .. categoryDir .. "/" .. file
    return writeLineTo(full, tostring(line or ""))
end

function RSL_Admin.LogWriter:prefix(player)
    return getSteamID(player), getDisplayName(player), getAccessLevel(player)
end

function RSL_Admin.LogWriter:write(relPath, line)
    relPath = sanitizeRelPath(relPath)
    if not relPath then return false end
    if not (RSL_Admin.Paths.Allowed and RSL_Admin.Paths.Allowed[relPath]) then return false end

    local full = RSL_Admin.Paths.BaseDir .. "/" .. relPath
    return writeLineTo(full, tostring(line or ""))
end

function RSL_Admin.LogWriter:touch(relPath)
    relPath = sanitizeRelPath(relPath)
    if not relPath then return false end
    if not (RSL_Admin.Paths.Allowed and RSL_Admin.Paths.Allowed[relPath]) then return false end

    local full = RSL_Admin.Paths.BaseDir .. "/" .. relPath
    return touchFile(full)
end

function RSL_Admin.LogWriter:touchAll()
    for rel, _ in pairs(RSL_Admin.Paths.Allowed or {}) do
        self:touch(rel)
    end
end
