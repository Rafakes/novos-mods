-- RSL_Admin/AnimalPickupLog.lua (server)
-- Logs when a player gains an "animal" item in inventory (trap animals / live animals / carcasses, etc).
-- MP-safe: server observes and writes. No client trust.

if not isServer() then return end

require "RSL_Admin/Config"
if RSL_Admin and RSL_Admin.Config and RSL_Admin.Config.NonInvasiveMode then return end

require "RSL_Admin/Config"
require "RSL_Admin/LogWriter"
require "RSL_Admin/Paths"

RSL_Admin = RSL_Admin or {}

local known = {}     -- known[onlineID][itemId]=true
local lastScanAt = 0

local function sidKey(player)
    if player and player.getOnlineID then
        local ok, v = pcall(player.getOnlineID, player)
        if ok and v ~= nil then return tostring(v) end
    end
    return tostring(player or "nil")
end

local function getPos(player)
    if not player or not player.getSquare then return "0,0,0" end
    local sq = player:getSquare()
    if not sq then return "0,0,0" end
    return tostring(sq:getX())..","..tostring(sq:getY())..","..tostring(sq:getZ())
end

local function itemFullType(item)
    if item and item.getFullType then
        local ok, v = pcall(item.getFullType, item)
        if ok and v then return tostring(v) end
    end
    return "unknown"
end

local function itemName(item)
    if item and item.getDisplayName then
        local ok, v = pcall(item.getDisplayName, item)
        if ok and v and tostring(v) ~= "" then return tostring(v) end
    end
    return itemFullType(item)
end

local function itemId(item)
    if item and item.getID then
        local ok, v = pcall(item.getID, item)
        if ok and v ~= nil then return tostring(v) end
    end
    return nil
end

local function hasAnyTag(item, tags)
    if not item or not item.hasTag then return false end
    for _, t in ipairs(tags or {}) do
        if t and t ~= "" then
            local ok, v = pcall(item.hasTag, item, t)
            if ok and v then return true end
        end
    end
    return false
end

local function inCategory(item, cats)
    if not item then return false end
    -- Try some common getters (varies by patch)
    local getters = { "getDisplayCategory", "getCategory", "getDisplayCategoryString" }
    local cat = nil
    for _, m in ipairs(getters) do
        if item[m] then
            local ok, v = pcall(item[m], item)
            if ok and v and tostring(v) ~= "" then cat = tostring(v); break end
        end
    end
    if not cat then return false end
    cat = cat:lower()
    for _, c in ipairs(cats or {}) do
        if c and tostring(c) ~= "" then
            if cat == tostring(c):lower() then return true end
        end
    end
    return false
end

local function isAnimalItem(item)
    local cfg = RSL_Admin.Config or {}
    local ft = itemFullType(item)

    if cfg.AnimalItemFullTypes and cfg.AnimalItemFullTypes[ft] then return true end
    if hasAnyTag(item, cfg.AnimalTags) then return true end
    if inCategory(item, cfg.AnimalCategoryNames) then return true end

    -- heuristic fallback (helps when tags/categories differ by patch or mod)
    local low = tostring(ft or ""):lower()
    if low:find("animal") or low:find("live") or low:find("chicken") or low:find("rabbit") or low:find("hare")
       or low:find("pig") or low:find("goat") or low:find("cow") or low:find("sheep") or low:find("turkey") then
        return true
    end

    return false
end

local function scanPlayer(player)
    if not player or not player.getInventory then return end

    local pid = sidKey(player)
    known[pid] = known[pid] or {}

    local function scanContainer(container, depth)
        if not container or not container.getItems then return end
        depth = tonumber(depth) or 0
        if depth > 3 then return end -- avoid weird recursion loops

        local items = container:getItems()
        if not items then return end

        for i=0, items:size()-1 do
            local it = items:get(i)
            local id = itemId(it)
            if id and not known[pid][id] then
                known[pid][id] = true
                if (RSL_Admin.Config and RSL_Admin.Config.LogAnimalPickups) and isAnimalItem(it) then
                    local sid, user, access = RSL_Admin.LogWriter:prefix(player)
                    local line = string.format(
                        "%s %s [%s]: Player picked up animal item [%s] (%s) at %s",
                        sid, user, access, itemFullType(it), itemName(it), getPos(player)
                    )
                    RSL_Admin.LogWriter:write(RSL_Admin.Paths.AnimalPickups, line)
                end
            end

            -- recurse into bags/containers inside inventory
            if it and it.isInventoryContainer and it.getItemContainer then
                local okC, isC = pcall(it.isInventoryContainer, it)
                if okC and isC then
                    local okIC, ic = pcall(it.getItemContainer, it)
                    if okIC and ic then
                        scanContainer(ic, depth + 1)
                    end
                end
            end
        end
    end

    scanContainer(player:getInventory(), 0)
end

local function scanAll()
    if not (RSL_Admin.Config and RSL_Admin.Config.LogAnimalPickups) then return end
    local secs = (RSL_Admin.Config and RSL_Admin.Config.AnimalScanSeconds) or 120
    secs = tonumber(secs) or 120
    if secs < 3 then secs = 3 end

    local t = os.time()
    if (t - lastScanAt) < secs then return end
    lastScanAt = t

    if not getOnlinePlayers then return end
    local players = getOnlinePlayers()
    if not players then return end
    for i=0, players:size()-1 do
        local p = players:get(i)
        scanPlayer(p)
    end
end

if Events and Events.OnTick then
    Events.OnTick.Add(scanAll)
end

print("[RSL_Admin] AnimalPickupLog loaded.")
