-- RSL_Admin/Compat/BurdJournals_RecordProgressFix.lua (server) - STUB
-- This mod should not patch other mods. This stub is here to neutralize old installs
-- that may still attempt: require "RSL_Admin/Compat/BurdJournals_RecordProgressFix"
if not isServer() then return end
print("[RSL_Admin] Compat stub loaded: BurdJournals_RecordProgressFix is DISABLED (pure logs build).")
return
