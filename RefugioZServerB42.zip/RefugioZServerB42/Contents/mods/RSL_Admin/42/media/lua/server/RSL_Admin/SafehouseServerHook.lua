-- RSL_Admin/SafehouseServerHook.lua (server)
-- Extra safety: if safehouse removal runs on server (dedicated/hosted), log it here too.
-- This complements the client auto-log (and does not rely on clients being patched).

if not isServer() then return end

require "RSL_Admin/Config"
require "RSL_Admin/Paths"
require "RSL_Admin/LogWriter"

RSL_Admin = RSL_Admin or {}

if not (RSL_Admin.Config and RSL_Admin.Config.LogReleasedSafehouses) then return end

local function safeNum(fn, obj, def)
    if not obj or not fn then return def end
    local ok, v = pcall(fn, obj)
    if ok and v ~= nil then return tonumber(v) or def end
    return def
end

local function safeStr(fn, obj, def)
    if not obj or not fn then return def end
    local ok, v = pcall(fn, obj)
    if ok and v ~= nil and tostring(v) ~= "" then return tostring(v) end
    return def
end

local function writeLine(player, sh)
    local sid, user, _access
    if player then
        sid, user, _access = RSL_Admin.LogWriter:prefix(player)
    else
        sid, user = "SERVER", "SERVER"
    end

    local title = safeStr(sh.getTitle, sh, "Safehouse")
    local owner = safeStr(sh.getOwner, sh, "unknown")
    local x = safeNum(sh.getX, sh, 0)
    local y = safeNum(sh.getY, sh, 0)
    local w = safeNum(sh.getW, sh, 0)
    local h = safeNum(sh.getH, sh, 0)

    local line = string.format("[%s / %s] released safehouse [%s] of [%s] at [%d, %d, 0] + [%d x %d] after [%.1f] hours since last login.",
        tostring(sid), tostring(user), title, owner, x, y, w, h, 0.0
    )
    RSL_Admin.LogWriter:write(RSL_Admin.Paths.ReleasedSafehouses, line)
end

local function patch()
    if not SafeHouse or not SafeHouse.removeSafeHouse then
        print("[RSL_Admin] SafeHouse.removeSafeHouse not found on server; server hook disabled.")
        return
    end
    if SafeHouse._RSL_AdminServerPatched then return end
    SafeHouse._RSL_AdminServerPatched = true

    local vanilla = SafeHouse.removeSafeHouse
    SafeHouse.removeSafeHouse = function(self, player, ...)
        local sh = self
        -- log first (even if vanilla errors)
        pcall(function() writeLine(player, sh) end)
        return vanilla(self, player, ...)
    end

    print("[RSL_Admin] Server patched SafeHouse.removeSafeHouse for release logging.")
end

if Events and Events.OnServerStarted then
    Events.OnServerStarted.Add(patch)
else
    patch()
end
