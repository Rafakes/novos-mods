-- RSL_Admin/VehicleTowHooksServer.lua (server)
-- Loga quando um jogador conecta/desconecta um veículo como reboque (towing).
-- Multiplayer-safe: o servidor confirma o vínculo no estado real do veículo.
-- Extras:
--  - Indica se ATTACH/DETACH ocorreu dentro de Safehouse
--  - Loga coordenadas do local do DETACH (onde o link foi desfeito)
--  - Monitora pares ativos para garantir DETACH mesmo se não capturar command

if not isServer() then return end

require "RSL_Admin/Config"
if RSL_Admin and RSL_Admin.Config and RSL_Admin.Config.NonInvasiveMode then return end

require "RSL_Admin/Config"
require "RSL_Admin/LogWriter"
require "RSL_Admin/Paths"

local DEBUG_DUMP = false

local WATCH_COMMANDS = {
    attachTrailer = true,
    detachTrailer = true,
    removeTrailer = true,
}

local pending = {}
local activePairs = {} -- key -> pair record

local function zoneNameFromSquare(sq)
    if not sq then return "Unknown" end
    if sq.getZone then
        local ok, z = pcall(sq.getZone, sq)
        if ok and z and z.getName then
            local ok2, n = pcall(z.getName, z)
            if ok2 and n and tostring(n) ~= "" then return tostring(n) end
        end
    end
    return "Unknown"
end

local function safehouseInfoFromSquare(sq)
    if not sq or not SafeHouse or not SafeHouse.getSafeHouse then
        return nil
    end
    local ok, sh = pcall(SafeHouse.getSafeHouse, sq)
    if not ok or not sh then return nil end

    local title, owner = nil, nil
    if sh.getTitle then local ok2, v = pcall(sh.getTitle, sh); if ok2 then title = v end end
    if sh.getOwner then local ok2, v = pcall(sh.getOwner, sh); if ok2 then owner = v end end

    local x1,y1,x2,y2 = nil,nil,nil,nil
    if sh.getX then local ok2,v = pcall(sh.getX, sh); if ok2 then x1=v end end
    if sh.getY then local ok2,v = pcall(sh.getY, sh); if ok2 then y1=v end end
    if sh.getW then local ok2,v = pcall(sh.getW, sh); if ok2 then x2=v end end -- alguns builds usam W/H como width/height
    if sh.getH then local ok2,v = pcall(sh.getH, sh); if ok2 then y2=v end end

    return {
        title = title and tostring(title) or "",
        owner = owner and tostring(owner) or "",
        x = x1, y = y1, w = x2, h = y2,
    }
end

local function safehouseSuffix(sq)
    local sh = safehouseInfoFromSquare(sq)
    if not sh then
        return " safehouse=No"
    end
    local area = ""
    if sh.x and sh.y and sh.w and sh.h then
        area = string.format(" area=%s,%s,%s,%s", tostring(sh.x), tostring(sh.y), tostring(sh.w), tostring(sh.h))
    end
    local t = sh.title ~= "" and (' title="' .. sh.title:gsub('"', "'") .. '"') or ""
    local o = sh.owner ~= "" and (' owner="' .. sh.owner:gsub('"', "'") .. '"') or ""
    return " safehouse=Yes" .. t .. o .. area
end

local function vehicleSquare(vehicle)
    if vehicle and vehicle.getSquare then
        local ok, sq = pcall(vehicle.getSquare, vehicle)
        if ok then return sq end
    end
    return nil
end

local function vehiclePosString(vehicle)
    if not vehicle then return "0,0,0 zone=Unknown safehouse=No" end

    local sq = vehicleSquare(vehicle)
    local x, y, z = -1, -1, -1
    if vehicle.getX then local ok,v = pcall(vehicle.getX, vehicle); if ok and v then x = v end end
    if vehicle.getY then local ok,v = pcall(vehicle.getY, vehicle); if ok and v then y = v end end
    if vehicle.getZ then local ok,v = pcall(vehicle.getZ, vehicle); if ok and v then z = v end end

    if sq and sq.getX then
        local okx, vx = pcall(sq.getX, sq); if okx and vx then x = vx end
        local oky, vy = pcall(sq.getY, sq); if oky and vy then y = vy end
        local okz, vz = pcall(sq.getZ, sq); if okz and vz then z = vz end
    end

    return string.format("%d,%d,%d zone=%s%s", x, y, z, zoneNameFromSquare(sq), safehouseSuffix(sq))
end

local function extractVehicleIds(args)
    local ids = {}
    if type(args) ~= "table" then return ids end

    for k, v in pairs(args) do
        local key = tostring(k):lower()
        if type(v) == "number" and (key:find("vehicle") or key:find("trailer") or key:find("tow")) then
            ids[#ids+1] = v
        end
    end

    if #ids == 0 and type(args.vehicle) == "number" then
        ids[1] = args.vehicle
    end
    return ids
end

local function pendingKey(player)
    if player and player.getOnlineID then
        local ok, v = pcall(player.getOnlineID, player)
        if ok and v ~= nil then return tostring(v) end
    end
    return tostring(player)
end

local function logTow(line)
    -- grava no arquivo padrão
    RSL_Admin.LogWriter:write(RSL_Admin.Paths.VehicleTow, line)
    -- e no console
    print("[RSL_Admin][Veiculos_Reboque] " .. tostring(line))
end

local function getVehicleByIdSafe(id)
    if not id or not getVehicleById then return nil end
    local ok, v = pcall(getVehicleById, id)
    if ok then return v end
    return nil
end

local function isLinked(towing, towed)
    if not towing or not towed then return false end
    if towing.getVehicleTowing then
        local ok, vt = pcall(towing.getVehicleTowing, towing)
        if ok and vt and vt == towed then return true end
    end
    if towed.getVehicleTowedBy then
        local ok, vb = pcall(towed.getVehicleTowedBy, towed)
        if ok and vb and vb == towing then return true end
    end
    return false
end

local function findTowPairFromIds(ids)
    for _, id in ipairs(ids or {}) do
        local v = getVehicleByIdSafe(id)
        if v then
            local towing = nil
            if v.getVehicleTowing then
                local ok, vt = pcall(v.getVehicleTowing, v)
                if ok then towing = vt end
            end
            if towing then
                return v, towing
            end

            local towedBy = nil
            if v.getVehicleTowedBy then
                local ok, vb = pcall(v.getVehicleTowedBy, v)
                if ok then towedBy = vb end
            end
            if towedBy then
                return towedBy, v
            end
        end
    end
    return nil, nil
end

local function pairKey(towingId, towedId)
    return tostring(towingId) .. ":" .. tostring(towedId)
end

local function registerActivePair(towing, towed, player)
    local towingId = towing.getId and towing:getId() or "?"
    local towedId  = towed.getId and towed:getId() or "?"
    local key = pairKey(towingId, towedId)

    local sid, user, access = RSL_Admin.LogWriter:prefix(player)
    activePairs[key] = {
        towingId = towingId,
        towedId = towedId,
        lastLinked = true,
        attachedBySid = sid,
        attachedByUser = user,
        attachedByAccess = access,
        attachedAt = vehiclePosString(towed),
        lastSeenTick = 0,
    }
end

local function onClientCommand(module, command, player, args)
    if module ~= "vehicle" then return end

    if DEBUG_DUMP then
        local sid, user, access = RSL_Admin.LogWriter:prefix(player)
        logTow(string.format("%s %s %q [%s]: DUMP module=%s cmd=%s",
            os.date("[%d-%m-%y %H:%M:%S]"),
            tostring(sid),
            tostring(user):gsub('"', "'"),
            tostring(access),
            tostring(module),
            tostring(command)
        ))
    end

    if not DEBUG_DUMP and not WATCH_COMMANDS[command] then return end

    local ids = extractVehicleIds(args)
    if #ids == 0 then return end

    local key = pendingKey(player)
    pending[key] = pending[key] or {}
    pending[key][#pending[key]+1] = { cmd = command, ids = ids, ticks = 0, player = player }
end

Events.OnClientCommand.Add(onClientCommand)

local function logAttach(player, towing, towed)
    local sid, user, access = RSL_Admin.LogWriter:prefix(player)
    local line = string.format("%s %s %q [%s]: ATTACH towingId=%s towedId=%s at=%s",
        os.date("[%d-%m-%y %H:%M:%S]"),
        tostring(sid),
        tostring(user):gsub('"', "'"),
        tostring(access),
        tostring(towing.getId and towing:getId() or "?"),
        tostring(towed.getId and towed:getId() or "?"),
        vehiclePosString(towed)
    )
    logTow(line)
    registerActivePair(towing, towed, player)
end

local function logDetachByPair(rec, towing, towed, reason)
    -- Coordenada do DETACH: posição atual do rebocado (mais útil pra moderação)
    local detachAt = towed and vehiclePosString(towed) or "unknown"
    local towingAt = towing and vehiclePosString(towing) or "unknown"

    local line = string.format("%s %s %q [%s]: DETACH towingId=%s towedId=%s detachAt=%s towingAt=%s reason=%s",
        os.date("[%d-%m-%y %H:%M:%S]"),
        tostring(rec.attachedBySid or "0"),
        tostring(rec.attachedByUser or "unknown"):gsub('"', "'"),
        tostring(rec.attachedByAccess or "None"),
        tostring(rec.towingId or "?"),
        tostring(rec.towedId or "?"),
        tostring(detachAt),
        tostring(towingAt),
        tostring(reason or "linkLost")
    )
    logTow(line)
end

local function onTick()
    -- 1) Processa pendências (attach/detach capturado por command)
    for pk, list in pairs(pending) do
        for i = #list, 1, -1 do
            local p = list[i]
            p.ticks = (p.ticks or 0) + 1

            if p.ticks >= 1 then
                if p.cmd == "attachTrailer" then
                    local towing, towed = findTowPairFromIds(p.ids)
                    if towing and towed then
                        logAttach(p.player, towing, towed)
                        table.remove(list, i)
                    elseif p.ticks >= 10 then
                        table.remove(list, i)
                    end
                else
                    -- Para detach/remove: não logamos aqui (pra evitar duplicado). O monitor abaixo registra quando o link some.
                    if p.ticks >= 10 then
                        table.remove(list, i)
                    end
                end
            end
        end
        if #list == 0 then pending[pk] = nil end
    end

    -- 2) Monitor de pares ativos: garante DETACH com coordenada
    for key, rec in pairs(activePairs) do
        local towing = getVehicleByIdSafe(rec.towingId)
        local towed  = getVehicleByIdSafe(rec.towedId)

        local linked = isLinked(towing, towed)
        if rec.lastLinked and not linked then
            -- link acabou -> log DETACH
            logDetachByPair(rec, towing, towed, "linkLost")
            activePairs[key] = nil
        else
            rec.lastLinked = linked
        end
    end
end

Events.OnTick.Add(onTick)
