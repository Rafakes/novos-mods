-- RSL_Admin/ItemMoveHooks.lua (shared)
-- B42 MP-safe: we hook vanilla TimedActions and LOG ONLY on the server (TimedAction.complete runs server-side in MP).
-- Goal: produce lines like:
-- [29-07-25 02:24:42.735] 7656... "Billi" container -8 6851,6345,0 [Base.22Box].
-- [29-07-25 02:25:10.587] 7656... "Billi" floor +1 6853,6344,0 [Radio.WalkieTalkie3].

require "RSL_Admin/Config"
require "RSL_Admin/Paths"

RSL_Admin = RSL_Admin or {}

if not (RSL_Admin.Config and RSL_Admin.Config.LogItemMoves) then return end

-- Only require server writer on the server.
if isServer() then
    require "RSL_Admin/LogWriter"
end

local function safeRequire(path)
    local ok, err = pcall(require, path)
    if not ok then
        -- Don't hard-fail: base game paths sometimes move between minor patches.
        if isServer() then
            print("[RSL_Admin] ItemMoveHooks: failed require " .. tostring(path) .. " : " .. tostring(err))
        end
    end
    return ok
end

-- These are the most common vanilla TA files for item movement.
safeRequire("TimedActions/ISInventoryTransferAction")
safeRequire("TimedActions/ISDropItemAction")
safeRequire("TimedActions/ISDropWorldItemAction")

local function epochMs()
    -- Prefer real milliseconds if available.
    if _G.getTimestampMs then
        local ok, v = pcall(_G.getTimestampMs)
        if ok and type(v) == "number" then return v end
    end
    if _G.getTimeInMillis then
        local ok, v = pcall(_G.getTimeInMillis)
        if ok and type(v) == "number" then return v end
    end
    if _G.getTimestamp then
        local ok, v = pcall(_G.getTimestamp)
        if ok and type(v) == "number" then return v * 1000 end
    end
    if os and os.time then return os.time() * 1000 end
    return 0
end

local function stamp()
    local ms = epochMs()
    local sec = math.floor(ms / 1000)
    local mmm = ms - (sec * 1000)
    if mmm < 0 then mmm = 0 end
    local base = (os and os.date) and os.date("%d-%m-%y %H:%M:%S", sec) or tostring(sec)
    return string.format("%s.%03d", base, mmm)
end

local function accessLevelOf(p)
    if not p or not p.getAccessLevel then return "None" end
    local ok, v = pcall(p.getAccessLevel, p)
    if not ok or not v then return "None" end
    v = tostring(v)
    if v == "" then v = "None" end
    return v
end

-- Resolve a container to a world square, if possible.
local function containerSquare(container, player, depth)
    depth = (depth or 0) + 1
    if depth > 6 then return player and player:getSquare() or nil end
    if not container then return player and player:getSquare() or nil end

    if container.getSourceGrid then
        local ok, sq = pcall(container.getSourceGrid, container)
        if ok and sq then return sq end
    end

    if container.getParent then
        local ok, parent = pcall(container.getParent, container)
        if ok and parent then
            if parent.getSquare then
                local ok2, sq = pcall(parent.getSquare, parent)
                if ok2 and sq then return sq end
            end
            -- IsoGridSquare can be the parent in some cases
            if parent.getX and parent.getY and parent.getZ then
                return parent
            end
        end
    end

    -- Bag/container-in-item: climb up to where the item is stored.
    if container.getContainingItem then
        local ok, it = pcall(container.getContainingItem, container)
        if ok and it and it.getContainer then
            local ok2, outer = pcall(it.getContainer, it)
            if ok2 and outer then
                return containerSquare(outer, player, depth)
            end
        end
    end

    return player and player:getSquare() or nil
end

local function xyzStrFromSquare(sq, player)
    if not sq then
        if player and player.getX then
            local x,y,z = 0,0,0
            pcall(function() x = player:getX() end)
            pcall(function() y = player:getY() end)
            pcall(function() z = player:getZ() end)
            return string.format("%d,%d,%d", x, y, z)
        end
        return "0,0,0"
    end
    local x,y,z = 0,0,0
    if sq.getX then pcall(function() x = sq:getX() end) end
    if sq.getY then pcall(function() y = sq:getY() end) end
    if sq.getZ then pcall(function() z = sq:getZ() end) end
    return string.format("%d,%d,%d", x, y, z)
end

local function isFloor(container)
    if not container or not container.getType then return false end
    local ok, t = pcall(container.getType, container)
    return ok and tostring(t) == "floor"
end

local function isPlayerOwned(container, player, depth)
    depth = (depth or 0) + 1
    if depth > 6 then return false end
    if not container then return false end

    if container.getParent then
        local ok, parent = pcall(container.getParent, container)
        if ok and parent then
            if player and parent == player then return true end
            -- heuristic: IsoPlayer has getOnlineID/getUsername
            if parent.getOnlineID and parent.getUsername then return true end
        end
    end

    if container.getContainingItem then
        local ok, it = pcall(container.getContainingItem, container)
        if ok and it and it.getContainer then
            local ok2, outer = pcall(it.getContainer, it)
            if ok2 and outer then
                return isPlayerOwned(outer, player, depth)
            end
        end
    end

    return false
end

local function movedItemsFromAction(self)
    local out = {}
    if self == nil then return out end

    -- Multi-item transfers sometimes store a table
    if type(self.items) == "table" then
        for _, it in ipairs(self.items) do
            if it then table.insert(out, it) end
        end
    end
    if #out == 0 and self.item then
        table.insert(out, self.item)
    end
    return out
end

local function itemAmount(self, it)
    -- If action transfers a partial stack, some versions store self.count.
    if self and self.count and type(self.count) == "number" and self.count > 1 then
        return self.count
    end
    if it and it.getCount then
        local ok, c = pcall(it.getCount, it)
        if ok and type(c) == "number" and c > 1 then return c end
    end
    return 1
end

local function uniqueTypes(items, maxTypes)
    local set, list = {}, {}
    for _, it in ipairs(items or {}) do
        local fullType = nil
        if it and it.getFullType then
            local ok, v = pcall(it.getFullType, it)
            if ok and v then fullType = tostring(v) end
        elseif it and it.getFullName then
            local ok, v = pcall(it.getFullName, it)
            if ok and v then fullType = tostring(v) end
        end
        if fullType and fullType ~= "" and not set[fullType] then
            set[fullType] = true
            table.insert(list, fullType)
            if maxTypes and #list >= maxTypes then break end
        end
    end
    return list
end

-- Server-side per-player rate limit for these logs (separate from ServerCommands.lua).
local lastMoveAt = {}

local function allowMoveRate(player)
    local secs = (RSL_Admin.Config and RSL_Admin.Config.ItemMovesRateLimitSeconds) or 0
    if secs <= 0 then return true end
    local id = -1
    if player and player.getOnlineID then
        pcall(function() id = player:getOnlineID() end)
    end
    local now = epochMs()
    local prev = lastMoveAt[id] or 0
    if (now - prev) < (secs * 1000) then return false end
    lastMoveAt[id] = now
    return true
end

local function writeMoveLine(player, where, signAndCount, xyz, types)
    if not isServer() then return end
    if not allowMoveRate(player) then return end
    if not (RSL_Admin and RSL_Admin.LogWriter and RSL_Admin.LogWriter.write) then return end

    local sid, user = "0", "unknown"
    if RSL_Admin.LogWriter.prefix then
        sid, user = RSL_Admin.LogWriter:prefix(player)
    end

    local list = types or {}
    local inside = table.concat(list, ", ")
    local line = string.format('[%s] %s "%s" %s %s %s [%s].', stamp(), tostring(sid), tostring(user), tostring(where), tostring(signAndCount), tostring(xyz), inside)
    RSL_Admin.LogWriter:write(RSL_Admin.Paths.ItemMoves, line)
end

local function logForContainer(player, container, isDest, count, types)
    if not isServer() then return end
    if not (RSL_Admin.Config and RSL_Admin.Config.LogItemMoves) then return end

    local worldOnly = (RSL_Admin.Config.ItemMovesWorldOnly ~= false)

    if worldOnly and isPlayerOwned(container, player) then
        return
    end

    local where = isFloor(container) and "floor" or "container"
    local signCount

    if isDest and not isFloor(container) and (RSL_Admin.Config.ItemMovesDestPlusZero ~= false) then
        signCount = "+0"
    else
        signCount = string.format("%s%d", isDest and "+" or "-", math.max(1, math.floor(count or 1)))
    end

    local sq = containerSquare(container, player)
    local xyz = xyzStrFromSquare(sq, player)
    writeMoveLine(player, where, signCount, xyz, types)
end

local function logTransferAction(self, okResult)
    if not okResult then return end
    if not isServer() then return end
    if not (RSL_Admin.Config and RSL_Admin.Config.LogItemMoves) then return end

    local player = self and self.character or nil
    if not player then return end

    local items = movedItemsFromAction(self)
    local total = 0
    for _, it in ipairs(items) do
        total = total + itemAmount(self, it)
    end
    if total <= 0 then total = #items end
    if total <= 0 then total = 1 end

    local types = uniqueTypes(items, (RSL_Admin.Config and RSL_Admin.Config.ItemMovesMaxTypes) or 24)

    local src = self and self.srcContainer or nil
    local dest = self and self.destContainer or nil

    -- Log each side independently (worldOnly filter is inside).
    if src then logForContainer(player, src, false, total, types) end
    if dest then logForContainer(player, dest, true, total, types) end
end

-- Patch: ISInventoryTransferAction:complete
if _G.ISInventoryTransferAction and ISInventoryTransferAction.complete and not ISInventoryTransferAction._RSL_ItemMovesPatched then
    local old = ISInventoryTransferAction.complete
    ISInventoryTransferAction.complete = function(self, ...)
        local okRes = old(self, ...)
        -- Note: in SP, complete runs as well; we still only write on server (isServer() true in SP).
        pcall(logTransferAction, self, okRes ~= false)
        return okRes
    end
    ISInventoryTransferAction._RSL_ItemMovesPatched = true
    if isServer() then print("[RSL_Admin] Patched ISInventoryTransferAction.complete for item movement logging.") end
end

-- Optional patches: drop actions (some builds use these instead of transfer-to-floor).
local function patchDrop(className)
    local C = _G[className]
    if not C or not C.complete or C._RSL_ItemMovesPatched then return end
    local old = C.complete
    C.complete = function(self, ...)
        local okRes = old(self, ...)
        pcall(logTransferAction, self, okRes ~= false)
        return okRes
    end
    C._RSL_ItemMovesPatched = true
    if isServer() then print("[RSL_Admin] Patched " .. className .. ".complete for item movement logging.") end
end

patchDrop("ISDropItemAction")
patchDrop("ISDropWorldItemAction")
