-- RSL_Admin/TileHooksServer.lua (server)
-- Destroyed tiles: quando o jogador quebra porta/janela/thumpable batendo até destruir.
-- Best-effort: tenta vários Events que mudam conforme patch.

if not isServer() then return end
require "RSL_Admin/Config"
require "RSL_Admin/LogWriter"
require "RSL_Admin/Paths"

local function posString(obj)
    if not obj or not obj.getSquare then return "0,0,0" end
    local sq = obj:getSquare()
    if not sq then return "0,0,0" end
    return tostring(sq:getX())..","..tostring(sq:getY())..","..tostring(sq:getZ())
end

local function getSpriteName(obj)
    if not obj then return "unknown sprite name" end
    if obj.getSprite and obj:getSprite() and obj:getSprite().getName then
        local ok, v = pcall(function() return obj:getSprite():getName() end)
        if ok and v and tostring(v) ~= "" then return tostring(v) end
    end
    if obj.getSpriteName then
        local ok, v = pcall(obj.getSpriteName, obj)
        if ok and v and tostring(v) ~= "" then return tostring(v) end
    end
    return "unknown sprite name"
end

local function getHealth(obj)
    if obj and obj.getHealth then
        local ok, v = pcall(obj.getHealth, obj)
        if ok and type(v)=="number" then return v end
    end
    return nil
end

local function isGone(obj)
    if not obj or not obj.getSquare then return true end
    local sq = obj:getSquare()
    if not sq or not sq.getObjects then return false end
    local objs = sq:getObjects()
    if not objs then return false end
    for i=0, objs:size()-1 do
        if objs:get(i) == obj then return false end
    end
    return true
end

local pending = {}

local function keyFor(obj)
    if not obj or not obj.getSquare then return nil end
    local sq = obj:getSquare()
    if not sq then return nil end
    return tostring(sq:getX())..":"..tostring(sq:getY())..":"..tostring(sq:getZ())..":"..tostring(getSpriteName(obj))
end

local function queueCheck(player, weapon, obj)
    if not (RSL_Admin.Config and RSL_Admin.Config.LogTPDestroyedTiles) then return end
    if not obj then return end
    local k = keyFor(obj)
    if not k then return end
    pending[k] = { player=player, weapon=weapon, obj=obj, sprite=getSpriteName(obj), pos=posString(obj), ts=os.time() }
end

local function flushPending()
    if not (RSL_Admin.Config and RSL_Admin.Config.LogTPDestroyedTiles) then return end
    for k,v in pairs(pending) do
        local h = getHealth(v.obj)
        if isGone(v.obj) or (h and h <= 0) then
            local sid, user, access = RSL_Admin.LogWriter:prefix(v.player)
            local wname = "unknown"
            if v.weapon and v.weapon.getFullType then
                local ok, wt = pcall(v.weapon.getFullType, v.weapon)
                if ok and wt then wname = tostring(wt) end
            end
            local line = string.format(
              "%s %s [%s]: Player destroyed tile/object [%s] with [%s] at %s",
              sid, user, access, tostring(v.sprite), wname, tostring(v.pos)
            )
            RSL_Admin.LogWriter:write(RSL_Admin.Paths.DestroyedTiles, line)
            pending[k] = nil
        elseif v.ts and (os.time()-v.ts) > 10 then
            pending[k] = nil
        end
    end
end

local function hook(ev, fn)
    if Events and Events[ev] then
        Events[ev].Add(fn)
        print("[RSL_Admin] TileHooksServer hooked "..ev)
        return true
    end
    return false
end

local function onA(character, weapon, obj) queueCheck(character, weapon, obj) end
local function onC(character, obj, weapon) queueCheck(character, weapon, obj) end

local hooked = false
hooked = hook("OnWeaponHitObject", onA) or hooked
hooked = hook("OnWeaponHit", onA) or hooked
hooked = hook("OnHitObject", onC) or hooked
hooked = hook("OnObjectHit", onA) or hooked
hooked = hook("OnWeaponHitObjectServer", onA) or hooked

if Events and Events.OnTick then Events.OnTick.Add(flushPending) end
print("[RSL_Admin] TileHooksServer loaded. hooked="..tostring(hooked))
