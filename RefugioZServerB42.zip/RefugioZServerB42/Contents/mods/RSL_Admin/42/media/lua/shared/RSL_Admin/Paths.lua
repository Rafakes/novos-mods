-- RSL_Admin/Paths.lua (B42)
RSL_Admin = RSL_Admin or {}
RSL_Admin.Paths = RSL_Admin.Paths or {}

RSL_Admin.Paths.BaseDir = "/RSL_Admin"

-- Tiles_log
RSL_Admin.Paths.TileWhitelistDestroy = "Tiles_log/whitelist_destruction.log"
RSL_Admin.Paths.DestroyedTiles       = "Tiles_log/destroyed_tiles.log"

-- Spawn_Itens
RSL_Admin.Paths.ItemSpawn = "Spawn_Itens/item_spawn.log"

-- ADM_power
RSL_Admin.Paths.AdminPowers = "ADM_power/admin_powers.log"

-- Safehouse_logs
RSL_Admin.Paths.ReleasedSafehouses = "Safehouse_logs/released_safehouses.log"

-- Animals_log
RSL_Admin.Paths.AnimalPickups = "Animals_log/animal_pickups.log"

-- Veiculos_Reboque
RSL_Admin.Paths.VehicleTow = "Veiculos_Reboque/vehicle_tow.log"

-- allow-list (server validation)
RSL_Admin.Paths.Allowed = {
  [RSL_Admin.Paths.TileWhitelistDestroy] = true,
  [RSL_Admin.Paths.DestroyedTiles]       = true,
  [RSL_Admin.Paths.ItemSpawn]            = true,
  [RSL_Admin.Paths.AdminPowers]          = true,
  [RSL_Admin.Paths.ReleasedSafehouses]   = true,
  [RSL_Admin.Paths.AnimalPickups]        = true,
  [RSL_Admin.Paths.VehicleTow]           = true,
}
