-- RSL_Admin/ServerCommands.lua (server)
-- Receives client audit events and writes to server-side files under Zomboid/Lua/RSL_Admin/...
-- MP rule: server is source of truth for log persistence (clients only report).

if not isServer() then return end

require "RSL_Admin/LogWriter"
require "RSL_Admin/Paths"
require "RSL_Admin/Config"
require "RSL_Admin/Net"

RSL_Admin = RSL_Admin or {}

local function posString(x, y, z)
    x = tonumber(x) or 0
    y = tonumber(y) or 0
    z = tonumber(z) or 0
    return string.format("%d,%d,%d", x, y, z)
end

-- simple anti-spam per onlineID
local lastAt = {}

local function dbg(player, msg)
    if RSL_Admin.Config and RSL_Admin.Config.DebugServerReceive then
        local sid, user, access = RSL_Admin.LogWriter:prefix(player)
        print("[RSL_Admin][SRV] "..tostring(sid).." "..tostring(user).." ["..tostring(access).."]: "..tostring(msg))
    end
end
local function allowRate(player)
    local secs = (RSL_Admin.Config and RSL_Admin.Config.RateLimitSeconds) or 0.15
    if secs <= 0 then return true end
    local id = -1
    if player and player.getOnlineID then
        pcall(function() id = player:getOnlineID() end)
    end
    local t = getTimestamp and getTimestamp() or (os and os.time and os.time() or 0)
    local prev = lastAt[id] or 0
    if (t - prev) < secs then return false end
    lastAt[id] = t
    return true
end

local function isStaff(player)
    if not player or not player.getAccessLevel then return false end
    local ok, v = pcall(player.getAccessLevel, player)
    if not ok or not v then return false end
    v = tostring(v)
    return v ~= "" and v ~= "None"
end

-- === Tiles_log ===

local function writeTileWhitelistDestroyed(player, args)
    if not (RSL_Admin.Config and RSL_Admin.Config.LogTPWhitelistDestroy) then return end
    if not allowRate(player) then return end

    local sid, user, access = RSL_Admin.LogWriter:prefix(player)
    local sprite = tostring(args.sprite or "unknown sprite name")
    local line = string.format("%s %s [%s]: Player destroyed whitelisted sprite [%s] at %s",
        sid, user, access, sprite, posString(args.x, args.y, args.z)
    )
    RSL_Admin.LogWriter:write(RSL_Admin.Paths.TileWhitelistDestroy, line)
end

local function writeSledgeBroken(player, args)
    if not (RSL_Admin.Config and RSL_Admin.Config.LogTPDestroyedTiles) then return end
    if not allowRate(player) then return end

    local sid, user, access = RSL_Admin.LogWriter:prefix(player)
    local sprite = tostring(args.sprite or "unknown sprite name")
    local line = string.format("%s %s [%s]: Player destroyed tile/object [%s] at %s",
        sid, user, access, sprite, posString(args.x, args.y, args.z)
    )
    RSL_Admin.LogWriter:write(RSL_Admin.Paths.DestroyedTiles, line)
end

-- === Spawn_Itens ===

local function writeItemSpawn(player, args)
    if not (RSL_Admin.Config and RSL_Admin.Config.LogStaffItemSpawns) then return end
    if not allowRate(player) then return end

    local sid, user, _access = RSL_Admin.LogWriter:prefix(player)
    local reason = tostring(args.reason or "Spawned item")
    -- Requested format: steamId [username] reason
    local line = string.format("%s [%s] %s", sid, user, reason)
    RSL_Admin.LogWriter:write(RSL_Admin.Paths.ItemSpawn, line)
end

-- === ADM_power ===

local function writeAdminPowerUsed(player, args)
    if not (RSL_Admin.Config and RSL_Admin.Config.LogAdminPowers) then return end
    if not isStaff(player) then return end
    if not allowRate(player) then return end

    local mod = tostring(args.module or "unknownModule")
    local cmd = tostring(args.command or "unknownCommand")
    local detail = tostring(args.args or args.detail or "")
    local msg = ("Admin power used: " .. mod .. "/" .. cmd)
    if detail ~= "" then msg = msg .. " " .. detail end

    local sid, user, access = RSL_Admin.LogWriter:prefix(player)
    local line = string.format("%s %s %q [%s]: %s",
        os.date("[%d-%m-%y %H:%M:%S]"),
        tostring(sid),
        tostring(user):gsub('"', "'"),
        tostring(access),
        msg
    )
    RSL_Admin.LogWriter:write(RSL_Admin.Paths.AdminPowers, line)
end

-- === Safehouse_logs ===

local function writeSafehouseReleased(player, args)
    if not (RSL_Admin.Config and RSL_Admin.Config.LogReleasedSafehouses) then return end
    if not allowRate(player) then return end

    local sid, user, _access = RSL_Admin.LogWriter:prefix(player)

    local title = tostring(args.title or "Safehouse")
    local owner = tostring(args.owner or "unknown")
    local x = tonumber(args.x) or 0
    local y = tonumber(args.y) or 0
    local w = tonumber(args.w) or 0
    local h = tonumber(args.h) or 0
    local hrs = tonumber(args.hrs) or 0

    local line = string.format("[%s / %s] released safehouse [%s] of [%s] at [%d, %d, 0] + [%d x %d] after [%.1f] hours since last login.",
        sid, user, title, owner, x, y, w, h, hrs
    )
    RSL_Admin.LogWriter:write(RSL_Admin.Paths.ReleasedSafehouses, line)
end

Events.OnClientCommand.Add(function(module, command, player, args)
    if module ~= (RSL_Admin.Net and RSL_Admin.Net.Module or "RSL_Admin") then return end
    if not player then return end
    args = args or {}

    if command == (RSL_Admin.Net and RSL_Admin.Net.Cmd and RSL_Admin.Net.Cmd.TileWhitelistDestroyed or "TileWhitelistDestroyed") then
        dbg(player, "cmd=TileWhitelistDestroyed")

        writeTileWhitelistDestroyed(player, args)
    elseif command == "SledgeBroken" then
        dbg(player, "cmd=SledgeBroken")

        writeSledgeBroken(player, args)end
end)
