-- RSL_Admin/TileHooks.lua (client)
-- MP-safe tile logging: hook vanilla timed actions on the CLIENT and report to the SERVER (which writes the files).
-- Why: in MP the destroy/disassemble actions run on the client; server receives the result. This mirrors BTSE's pattern.

if not isClient() then return end

require "RSL_Admin/Config"
if RSL_Admin and RSL_Admin.Config and RSL_Admin.Config.NonInvasiveMode then return end

require "RSL_Admin/Config"
require "RSL_Admin/Net"
require "RSL_Admin/ClientReport"

RSL_Admin = RSL_Admin or {}

local function whitelistSet()
    local t = (RSL_Admin.Config and RSL_Admin.Config.TileWhitelistSprites) or {}
    if not t or #t == 0 then return nil end -- nil => allow all
    local set = {}
    for _, s in ipairs(t) do
        if s and s ~= "" then set[tostring(s)] = true end
    end
    return set
end

local function spriteNameFromObject(obj)
    if not obj then return "unknown sprite name" end
    -- IsoObject
    if obj.getSprite then
        local ok, sp = pcall(obj.getSprite, obj)
        if ok and sp and sp.getName then
            local ok2, name = pcall(sp.getName, sp)
            if ok2 and name and name ~= "" then return tostring(name) end
        end
    end
    -- MoveablesAction style
    if obj.spriteName then return tostring(obj.spriteName) end
    return "unknown sprite name"
end

local function squareFromObject(obj)
    if not obj then return nil end
    if obj.getSquare then
        local ok, sq = pcall(obj.getSquare, obj)
        if ok then return sq end
    end
    if obj.square then return obj.square end
    return nil
end

local function xyzFromSquare(sq)
    if not sq then return 0,0,0 end
    local x,y,z = 0,0,0
    if sq.getX then pcall(function() x = sq:getX() end) end
    if sq.getY then pcall(function() y = sq:getY() end) end
    if sq.getZ then pcall(function() z = sq:getZ() end) end
    return x,y,z
end

local function isSledge(item)
    if not item then return false end
    if item.hasTag then
        local ok, v = pcall(item.hasTag, item, "Sledgehammer")
        if ok and v then return true end
    end
    if item.getFullType then
        local ok, v = pcall(item.getFullType, item)
        if ok and v and tostring(v):find("Sledgehammer") then return true end
    end
    return false
end

-- === ISDestroyStuffAction (sledge destroy: doors/walls) ===

do
    local okTA = pcall(require, "TimedActions/ISDestroyStuffAction")
    if okTA and ISDestroyStuffAction and ISDestroyStuffAction.perform and not ISDestroyStuffAction._RSL_AdminPatched then
        local vanillaPerform = ISDestroyStuffAction.perform
        ISDestroyStuffAction._RSL_AdminPatched = true

        ISDestroyStuffAction.perform = function(self)
            -- capture before vanilla in case vanilla clears self.item
            local player = self and self.character or getPlayer()
            local obj = self and (self.object or self.item)
            local sprite = spriteNameFromObject(obj)
            local sq = squareFromObject(obj)
            local x,y,z = xyzFromSquare(sq)

            local res = vanillaPerform(self)

            if not (RSL_Admin.Config and RSL_Admin.Config.LogTPDestroyedTiles) then return res end
            if not player then return res end

            -- Only log sledge-related destroys unless user asks otherwise.
            local sledge = self and self.sledge
            if not sledge and player.getPrimaryHandItem then
                pcall(function() sledge = player:getPrimaryHandItem() end)
            end
            local should = (RSL_Admin.Config.LogAllSledgeDestroys == true) or isSledge(sledge)
            if not should then return res end

            local wset = whitelistSet()
            if wset and not wset[sprite] then return res end

            RSL_Admin.ClientReport:send(RSL_Admin.Net.Cmd.DestroyedTiles, { sprite = sprite, x = x, y = y, z = z })
            return res
        end

        print("[RSL_Admin] Patched ISDestroyStuffAction.perform for sledge logging.")
    else
        print("[RSL_Admin] ISDestroyStuffAction not found; sledge logging disabled.")
    end
end

-- === ISMoveablesAction (disassemble/scrap/walls) ===

do
    local okMV = pcall(require, "Moveables/ISMoveablesAction")
    if okMV and ISMoveablesAction and ISMoveablesAction.perform and not ISMoveablesAction._RSL_AdminPatched then
        local vanilla = ISMoveablesAction.perform
        ISMoveablesAction._RSL_AdminPatched = true

        ISMoveablesAction.perform = function(self)
            -- capture before vanilla
            local player = self and self.character or getPlayer()
            local mode = tostring((self and (self.mode or self.action or self.command)) or "unknown")
            local sprite = tostring((self and (self.origSpriteName or (self.moveProps and self.moveProps.spriteName))) or "unknown sprite name")
            -- [RSL_Admin] sprite fallback
            if (not sprite) or sprite == "" or sprite == "unknown sprite name" then
                local obj = self and (self.object or self.item)
                if obj then
                    local s2 = spriteNameFromObject(obj)
                    if s2 and s2 ~= "" then sprite = s2 end
                end
            end

            local sq = self and (self.square or self.worldsquare)
            if not sq and self and self.item then sq = squareFromObject(self.item) end
            local x,y,z = xyzFromSquare(sq)

            local res = vanilla(self)

            if not (RSL_Admin.Config and RSL_Admin.Config.LogTPWhitelistDestroy) then return res end
            if not player then return res end

            -- focus on dismantle-like actions; still catches most wall/door disassembly
            local modeLC = mode:lower()
            if not (modeLC:find("scrap") or modeLC:find("dis") or modeLC:find("dismant") or modeLC:find("take") or modeLC:find("pickup")) then
                return res
            end

            local wset = whitelistSet()
            if wset and not wset[sprite] then return res end

            RSL_Admin.ClientReport:send(RSL_Admin.Net.Cmd.TileWhitelistDestroyed, { sprite = sprite, x = x, y = y, z = z, mode = mode })
            return res
        end

        print("[RSL_Admin] Patched ISMoveablesAction.perform for disassemble logging.")
    else
        print("[RSL_Admin] ISMoveablesAction not found; disassemble logging disabled.")
    end
end
