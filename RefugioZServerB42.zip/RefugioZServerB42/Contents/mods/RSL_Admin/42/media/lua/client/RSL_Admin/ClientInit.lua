-- RSL_Admin client init (B42 MP-safe, NON-INVASIVE)
require "RSL_Admin/Config"
require "RSL_Admin/Paths"
require "RSL_Admin/Net"

local function safeRequire(path)
    local ok, err = pcall(require, path)
    if not ok then
        print("[RSL_Admin] Client failed to load " .. tostring(path) .. ": " .. tostring(err))
    end
    return ok
end

-- Load network wrapper first
safeRequire("RSL_Admin/ClientReport")

-- Non-invasive mode: do NOT load any modules that monkeypatch vanilla functions.
if RSL_Admin and RSL_Admin.Config and RSL_Admin.Config.NonInvasiveMode then
    print("[RSL_Admin] NonInvasiveMode=TRUE (client): skipping TileHooks/ItemSpawnerLog/SafehouseAutoLog/AdminPowerSniffer.")
    return
end

-- (If you disable NonInvasiveMode, you may enable these at your own risk.)
safeRequire("RSL_Admin/TileHooks")
safeRequire("RSL_Admin/ItemSpawnerLog")
safeRequire("RSL_Admin/SafehouseAutoLog")
safeRequire("RSL_Admin/AdminPowerSniffer")
