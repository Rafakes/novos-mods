-- RSL_Admin/AdminPowerSniffer.lua (client)
-- FIX: do NOT break other mods (e.g. RV) by assuming a single sendClientCommand signature.
-- We support BOTH:
--   sendClientCommand(module, command, args)
--   sendClientCommand(playerObj, module, command, args)
--
-- Goal: audit admin power usage by observing outgoing client commands.
-- Server remains source-of-truth: client only reports.

if not isClient() then return end

require "RSL_Admin/Config"
if RSL_Admin and RSL_Admin.Config and RSL_Admin.Config.NonInvasiveMode then return end

require "RSL_Admin/Config"
require "RSL_Admin/Net"
require "RSL_Admin/ClientReport"

local ORIG = nil
local hooked = false

local function resolvePlayer(p)
    if p then return p end
    if getSpecificPlayer then
        local p0 = getSpecificPlayer(0)
        if p0 then return p0 end
    end
    if getPlayer then
        local p1 = getPlayer()
        if p1 then return p1 end
    end
    return nil
end

local function summarizeArgs(args)
    if not args then return nil end
    if type(args) ~= "table" then return tostring(args) end
    local out, n = {}, 0
    for k,v in pairs(args) do
        n = n + 1
        if n > 12 then break end
        local sv = tostring(v)
        if #sv > 80 then sv = sv:sub(1,80).."..." end
        out[#out+1] = tostring(k).."="..sv
    end
    table.sort(out)
    return table.concat(out, ";")
end

local function shouldLog(module, command)
    if not module or not command then return false end
    -- Never log our own module to avoid loops
    if module == (RSL_Admin.Net and RSL_Admin.Net.Module or "RSL_Admin") then return false end
    return true
end

local function reportAdminPower(player, module, command, args)
    if not (RSL_Admin and RSL_Admin.Config and RSL_Admin.Config.LogAdminPowers) then return end
    if not shouldLog(module, command) then return end
    player = resolvePlayer(player)
    if not player then return end
    -- Aurora-style report to server (server decides if user is staff)
    RSL_Admin.ClientReport:send(RSL_Admin.Net.Cmd.AdminPowerUsed, {
        module = tostring(module),
        command = tostring(command),
        args = summarizeArgs(args),
    }, player)
end

local function hookSend()
    if hooked then return true end
    if type(sendClientCommand) ~= "function" then return false end
    if ORIG then return true end

    ORIG = sendClientCommand

    -- Wrapper that supports both signatures without breaking other mods.
    sendClientCommand = function(...)
        local argc = select("#", ...)
        if argc == 3 then
            local module, command, args = ...
            -- Call original
            local ok, res = pcall(ORIG, module, command, args)
            -- Report after call (even if original fails, we don't want to crash other mods)
            pcall(reportAdminPower, nil, module, command, args)
            if ok then return res end
            return nil
        elseif argc == 4 then
            local playerObj, module, command, args = ...
            local ok, res = pcall(ORIG, playerObj, module, command, args)
            pcall(reportAdminPower, playerObj, module, command, args)
            if ok then return res end
            return nil
        else
            -- Unknown signature: pass through
            return ORIG(...)
        end
    end

    hooked = true
    print("[RSL_Admin] AdminPowerSniffer hooked sendClientCommand (signature-safe).")
    return true
end

local function retryHook()
    hookSend()
end

if Events and Events.OnGameStart then Events.OnGameStart.Add(retryHook) end
if Events and Events.OnCreatePlayer then Events.OnCreatePlayer.Add(retryHook) end
if Events and Events.OnTick then Events.OnTick.Add(retryHook) end

retryHook()
