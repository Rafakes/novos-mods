-- RSL_Admin/DebugAdminButtonsLog.lua (client)
-- Optional: mirrors BTSE_Legacy_SecExp SpecialUIButtons.
-- If a RESTRICTED user (accessLevel == "None") has debug/admin buttons visible, report to server for logging.

if not isClient() then return end

require "RSL_Admin/Config"
require "RSL_Admin/Net"
require "RSL_Admin/ClientReport"

if not (RSL_Admin and RSL_Admin.Config and RSL_Admin.Config.LogRestrictedButtonsVisible) then return end

local okEq = pcall(require, "ISUI/ISEquippedItem")
if not okEq or not ISEquippedItem or not ISEquippedItem.initialise then
    print("[RSL_Admin] ISEquippedItem not found; restricted button visibility logging disabled.")
    return
end

local function accessLevelOf(player)
    if player and player.getAccessLevel then
        local ok, v = pcall(player.getAccessLevel, player)
        if ok and v then return tostring(v) end
    end
    return "None"
end

local function isVisible(btn)
    if not btn then return false end
    if btn.isVisible then
        local ok, v = pcall(btn.isVisible, btn)
        if ok then return v == true end
    end
    if btn.getIsVisible then
        local ok, v = pcall(btn.getIsVisible, btn)
        if ok then return v == true end
    end
    return false
end

local vanillaInit = ISEquippedItem.initialise
ISEquippedItem.initialise = function(self, ...)
    local res = vanillaInit(self, ...)

    local player = getPlayer()
    if not player then return res end
    if accessLevelOf(player) ~= "None" then return res end

    local inst = ISEquippedItem.instance
    if not inst then return res end

    local dbg = inst.debugBtn or inst.debugButton
    local adm = inst.adminBtn or inst.adminButton or inst.adminPanelBtn

    if isVisible(dbg) then
        RSL_Admin.ClientReport:send(RSL_Admin.Net.Cmd.RestrictedButtonsVisible, { what = "Debug panel button visible" })
    end
    if isVisible(adm) then
        RSL_Admin.ClientReport:send(RSL_Admin.Net.Cmd.RestrictedButtonsVisible, { what = "Admin panel button visible" })
    end

    return res
end
