-- RSL_Admin server init (B42, MP-safe)
-- Goal: keep logs working with NonInvasiveMode=TRUE without breaking other mods (e.g. BurdJournals).
-- Rule:
--   - Server-side event watchers are OK in NonInvasiveMode.
--   - Function wrapping/monkeypatching stays OFF in NonInvasiveMode.

require "RSL_Admin/PureLogsBoot"
require "RSL_Admin/Config"
require "RSL_Admin/Paths"
require "RSL_Admin/Net"
require "RSL_Admin/LogWriter"
require "RSL_Admin/ServerCommands"
require "RSL_Admin/AdminPowerWatcher"

-- Server-side watchers (non-invasive)
require "RSL_Admin/TileHooksServer"
require "RSL_Admin/VehicleTowHooksServer"
require "RSL_Admin/AnimalPickupLog"

-- Extra watchers for Spawn_Itens and Safehouse_logs (server-side, non-invasive)
if pcall(require, "RSL_Admin/ItemSpawnWatcher") then
    -- ok
end
if pcall(require, "RSL_Admin/SafehouseWatcher") then
    -- ok
end

-- Invasive legacy wrapper: keep OFF in NonInvasiveMode
if not (RSL_Admin and RSL_Admin.Config and RSL_Admin.Config.NonInvasiveMode) then
    require "RSL_Admin/SafehouseHooksServer"
else
    print("[RSL_Admin] NonInvasiveMode=TRUE (server): SafehouseHooksServer disabled (compat).")
end

local function init()
    if not isServer() then return end
    if RSL_Admin and RSL_Admin.LogWriter and RSL_Admin.LogWriter.touchAll then
        RSL_Admin.LogWriter:touchAll()
        print("[RSL_Admin] Server init OK. Log files touched under Zomboid/Lua/RSL_Admin/")
    end
end

if Events and Events.OnServerStarted then
    Events.OnServerStarted.Add(init)
elseif Events and Events.OnGameStart then
    Events.OnGameStart.Add(init)
else
    init()
end
