-- RSL_Admin/PureLogsBoot.lua (server)
if not isServer() then return end
require "RSL_Admin/Config"
local function boot()
    print("[RSL_Admin] PureLogs build active (no compat patches). version=1.0.4-purelogs")
end
if Events and Events.OnServerStarted then
    Events.OnServerStarted.Add(boot)
else
    boot()
end
