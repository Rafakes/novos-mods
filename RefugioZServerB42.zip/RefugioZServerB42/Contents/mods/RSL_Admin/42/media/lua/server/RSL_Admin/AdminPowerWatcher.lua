-- RSL_Admin/AdminPowerWatcher.lua (server)
-- Server-side watcher to log changes in admin powers without client hooks (non-invasive).
-- Extended to track additional toggles and to log relevant admin client commands (for powers without getters).

if not isServer() then return end

require "RSL_Admin/Config"
require "RSL_Admin/Paths"
require "RSL_Admin/LogWriter"

RSL_Admin = RSL_Admin or {}
RSL_Admin.Server = RSL_Admin.Server or {}

-- Respect NonInvasiveMode (this file is passive; still allowed)
if not (RSL_Admin.Config and RSL_Admin.Config.LogAdminPowers) then return end

local last = {}
local lastTickAt = 0

local function safeBool(p, fn)
    if p and p[fn] then
        local ok, v = pcall(p[fn], p)
        if ok then return v == true end
    end
    return nil
end

local function safeBoolAny(p, fns)
    for _, fn in ipairs(fns) do
        local v = safeBool(p, fn)
        if v ~= nil then return v end
    end
    return nil
end

local function accessLevel(p)
    if p and p.getAccessLevel then
        local ok, v = pcall(p.getAccessLevel, p)
        if ok and v and tostring(v) ~= "" then return tostring(v) end
    end
    return "None"
end

-- Try multiple getter names across B42 minor patches (if a getter doesn't exist, we keep it nil)
local powerGetters = {
    GodMod   = {"isGodMod"},
    Invis    = {"isInvisible"},
    NoClip   = {"isNoClip"},
    Ghost    = {"isGhostMode"},

    -- Extra toggles you asked for (names may vary; we try common patterns)
    Mechanics = {"isMechanicsEnabled", "isMechanicsMode", "isMechanicsCheat"},
    Health    = {"isHealthEnabled", "isHealthCheat", "isHealthPanelEnabled"},
    Build     = {"isBuildCheat", "isBuildCheatEnabled", "isBuildMode"},
    FastMove  = {"isFastMove", "isFastMoveCheat", "isFastMoveCheatEnabled"},

    UnlimitedAmmo      = {"isUnlimitedAmmo", "isUnlimitedAmmoEnabled"},
    UnlimitedEndurance = {"isUnlimitedEndurance", "isUnlimitedEnduranceEnabled"},
    UnlimitedCarry     = {"isUnlimitedCarry", "isUnlimitedCarryEnabled", "isUnlimitedCarryWeight"},
}

local function snapshot(p)
    local s = {}
    for k, fns in pairs(powerGetters) do
        s[k] = safeBoolAny(p, fns)
    end
    return s
end

local function same(a, b)
    if not a or not b then return false end
    for k, v in pairs(a) do
        if b[k] ~= v then return false end
    end
    for k, v in pairs(b) do
        if a[k] ~= v then return false end
    end
    return true
end

local function nowSec()
    if _G.getTimestamp then
        local ok, v = pcall(_G.getTimestamp)
        if ok and type(v) == "number" then return v end
    end
    return (os.time() or 0)
end

local function formatPowers(cur)
    -- Stable ordering, omit nils to reduce noise.
    local order = {
        "GodMod","Invis","NoClip","Ghost",
        "Mechanics","Health","Build","FastMove",
        "UnlimitedAmmo","UnlimitedEndurance","UnlimitedCarry",
    }
    local parts = {}
    for _, k in ipairs(order) do
        local v = cur[k]
        if v ~= nil then
            table.insert(parts, string.format("%s=%s", k, tostring(v)))
        end
    end
    return table.concat(parts, " ")
end

local function tick()
    -- throttle to ~1s
    local t = nowSec()
    if (t - lastTickAt) < 1 then return end
    lastTickAt = t

    local players = getOnlinePlayers and getOnlinePlayers() or nil
    if not players then return end

    for i = 0, players:size() - 1 do
        local p = players:get(i)
        if p then
            local sid, user, access = RSL_Admin.LogWriter:prefix(p)
            local key = tostring(sid) .. ":" .. tostring(p.getOnlineID and p:getOnlineID() or i)
            local cur = snapshot(p)

            -- Track only staff or anyone with any power toggled on.
            local lvl = accessLevel(p)
            local anyOn = false
            for _, v in pairs(cur) do
                if v == true then anyOn = true; break end
            end

            if lvl == "None" and not anyOn then
                last[key] = nil
            else
                if not last[key] then
                    last[key] = cur
                elseif not same(cur, last[key]) then
                    local msg = string.format("%s %s %q [%s]: Admin powers changed %s",
                        os.date("[%d-%m-%y %H:%M:%S]"),
                        tostring(sid),
                        tostring(user):gsub('"', "'"),
                        tostring(access),
                        formatPowers(cur)
                    )
                    RSL_Admin.LogWriter:write(RSL_Admin.Paths.AdminPowers, msg)
                    last[key] = cur
                end
            end
        end
    end
end

Events.OnTick.Add(tick)

-- Some admin toggles don't have public getters; log the relevant admin client commands (non-invasive).
local function shallowArgs(args)
    if type(args) ~= "table" then return tostring(args) end
    local out = {}
    local n = 0
    for k, v in pairs(args) do
        n = n + 1
        if n > 24 then
            table.insert(out, "…")
            break
        end
        local ks = tostring(k)
        local vs
        if type(v) == "boolean" or type(v) == "number" then
            vs = tostring(v)
        else
            vs = tostring(v):gsub("[\r\n\t]", " ")
            if #vs > 80 then vs = vs:sub(1, 80) .. "…" end
            vs = string.format("%q", vs)
        end
        table.insert(out, ks .. "=" .. vs)
    end
    table.sort(out)
    return "{" .. table.concat(out, ", ") .. "}"
end

local keywords = {
    "mechanic","health","build","fast","ammo","endurance","carry",
    "god","invis","noclip","ghost","adminpower","power","cheat"
}

local function looksRelevant(module, command)
    local m = tostring(module or ""):lower()
    local c = tostring(command or ""):lower()
    if m == "admin" or m == "debug" then return true end
    for _, kw in ipairs(keywords) do
        if c:find(kw, 1, true) then return true end
    end
    return false
end

local function onClientCommand(module, command, player, args)
if not player then return end

-- Hard-compat: never touch BurdJournals commands (prevents Kahlua ReturnValues NPE chain)
if module == "BurdJournals" then return end

-- Filter FIRST using pure Lua (avoid Java calls on unrelated client-commands)
if not looksRelevant(module, command) then return end

-- Only now check staff/access (Java calls happen only for relevant commands)
local lvl = accessLevel(player)
if lvl == "None" then return end

local sid, user, access = RSL_Admin.LogWriter:prefix(player)
local msg = string.format("%s %s %q [%s]: Admin cmd module=%s command=%s args=%s",
    os.date("[%d-%m-%y %H:%M:%S]"),
    tostring(sid),
    tostring(user):gsub('"', "'"),
    tostring(access),
    tostring(module),
    tostring(command),
    shallowArgs(args)
)
RSL_Admin.LogWriter:write(RSL_Admin.Paths.AdminPowers, msg)

end

Events.OnClientCommand.Add(onClientCommand)
