-- RSL_Admin/SafehouseAutoLog.lua (client)
-- Requested behavior: log automatically whenever a safehouse is released (no context menu button).
-- Implementation: wrap SafeHouse.removeSafeHouse on CLIENT and report to server.
-- Note: SafeHouse may not be available immediately on boot, so we retry on game start.

if not isClient() then return end

require "RSL_Admin/Config"
if RSL_Admin and RSL_Admin.Config and RSL_Admin.Config.NonInvasiveMode then return end

require "RSL_Admin/Config"
require "RSL_Admin/Net"
require "RSL_Admin/ClientReport"

RSL_Admin = RSL_Admin or {}

if not (RSL_Admin.Config and RSL_Admin.Config.LogReleasedSafehouses) then return end

local function safeNum(fn, obj, def)
    if not obj or not fn then return def end
    local ok, v = pcall(fn, obj)
    if ok and v ~= nil then return tonumber(v) or def end
    return def
end

local function safeStr(fn, obj, def)
    if not obj or not fn then return def end
    local ok, v = pcall(fn, obj)
    if ok and v ~= nil and tostring(v) ~= "" then return tostring(v) end
    return def
end

local function tryPatch()
    if not SafeHouse or not SafeHouse.removeSafeHouse then return false end
    if SafeHouse._RSL_AdminPatched then return true end

    local vanilla = SafeHouse.removeSafeHouse
    SafeHouse._RSL_AdminPatched = true

    SafeHouse.removeSafeHouse = function(self, player, ...)
        local sh = self
        local title = safeStr(sh.getTitle, sh, "Safehouse")
        local owner = safeStr(sh.getOwner, sh, "unknown")
        local x = safeNum(sh.getX, sh, 0)
        local y = safeNum(sh.getY, sh, 0)
        local w = safeNum(sh.getW, sh, 0)
        local h = safeNum(sh.getH, sh, 0)

        local caller = player or getPlayer()
        if caller then
            sendClientCommand(caller, "RSL_Admin", "SafehouseReleased", {
                title = title, owner = owner, x = x, y = y, w = w, h = h, hrs = 0
            })
        end

        return vanilla(self, player, ...)
    end

    print("[RSL_Admin] Patched SafeHouse.removeSafeHouse for automatic release logging.")
    return true
end

-- Try now, and retry after world loads
if not tryPatch() then
    if Events and Events.OnGameStart then
        Events.OnGameStart.Add(function() tryPatch() end)
    end
    if Events and Events.OnCreatePlayer then
        Events.OnCreatePlayer.Add(function() tryPatch() end)
    end
end
