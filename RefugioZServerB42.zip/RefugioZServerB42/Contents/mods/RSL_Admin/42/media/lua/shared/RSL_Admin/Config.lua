-- RSL_Admin/Config.lua (B42)
RSL_Admin = RSL_Admin or {}
RSL_Admin.Config = RSL_Admin.Config or {}

-- Non-invasive mode: disables ALL function monkeypatching and intrusive hooks (recommended for compatibility)
RSL_Admin.Config.NonInvasiveMode = true

-- Anti-spam (server)
RSL_Admin.Config.RateLimitSeconds = 0.15

-- Tiles_log
RSL_Admin.Config.LogTPWhitelistDestroy = true
RSL_Admin.Config.LogTPDestroyedTiles  = true

-- Spawn_Itens
RSL_Admin.Config.LogStaffItemSpawns = true

-- ADM_power
RSL_Admin.Config.LogAdminPowers = true
RSL_Admin.Config.AdminPowersPerPlayer = true

-- Safehouse_logs
RSL_Admin.Config.LogReleasedSafehouses = true

-- Debug toggles
RSL_Admin.Config.DebugServerReceive = false
RSL_Admin.Config.DebugClientSends = false

-- Animals_log
RSL_Admin.Config.LogAnimalPickups = true
-- Scans player inventory every N seconds (server); 60-300 is typical.
RSL_Admin.Config.AnimalScanSeconds = 10

-- Detect "animal items" by tags and/or fullType allow-list
RSL_Admin.Config.AnimalTags = { "Animal", "LiveAnimal", "SmallAnimal", "Pet" }
RSL_Admin.Config.AnimalCategoryNames = { "Animals", "Animal" }
RSL_Admin.Config.AnimalItemFullTypes = RSL_Admin.Config.AnimalItemFullTypes or {}
