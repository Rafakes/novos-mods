-- RSL_Admin/SafehouseContext.lua (client)
-- Adds an Admin-only world context option to (attempt to) release a safehouse and log it.
-- Server writes to: /RSL_Admin/Safehouse_logs/btse_tools/released_safehouses.log
-- Log line matches BTSE_Tools format (hours since last login is 0.0 unless you extend it).

if not isClient() then return end

require "RSL_Admin/Config"

if not (RSL_Admin and RSL_Admin.Config and RSL_Admin.Config.EnableSafehouseReleaseContext) then return end

local function accessLevelOf(player)
    if player and player.getAccessLevel then
        local ok, v = pcall(player.getAccessLevel, player)
        if ok and v then return tostring(v) end
    end
    return "None"
end

local function isAdmin(player)
    local al = accessLevelOf(player)
    return al ~= "None"
end

local function getSafehouseFromSquare(sq)
    if not sq then return nil end
    if SafeHouse and SafeHouse.getSafeHouse then
        local ok, sh = pcall(SafeHouse.getSafeHouse, sq)
        if ok then return sh end
    end
    return nil
end

Events.OnFillWorldObjectContextMenu.Add(function(playerIndex, context, worldobjects, test)
    if test then return end

    local player = getSpecificPlayer(playerIndex)
    if not player or not isAdmin(player) then return end
    if not (RSL_Admin and RSL_Admin.Config and RSL_Admin.Config.EnableSafehouseReleaseContext) then return end

    local sq = nil
    if worldobjects then
        for _, o in ipairs(worldobjects) do
            if o and o.getSquare then
                local ok, s = pcall(o.getSquare, o)
                if ok and s then sq = s break end
            end
        end
    end
    if not sq then return end

    local sh = getSafehouseFromSquare(sq)
    if not sh then return end

    local title, owner = "Safehouse", "unknown"
    local x,y,w,h = 0,0,0,0

    if sh.getTitle then pcall(function() title = tostring(sh:getTitle()) end) end
    if sh.getOwner then pcall(function() owner = tostring(sh:getOwner()) end) end
    if sh.getX then pcall(function() x = tonumber(sh:getX()) or 0 end) end
    if sh.getY then pcall(function() y = tonumber(sh:getY()) or 0 end) end
    if sh.getW then pcall(function() w = tonumber(sh:getW()) or 0 end) end
    if sh.getH then pcall(function() h = tonumber(sh:getH()) or 0 end) end

    context:addOption("RSL_Admin: Release Safehouse (log)", worldobjects, function()
        sendClientCommand(player, "RSL_Admin", "SafehouseReleaseAndLog", {
            title = title,
            owner = owner,
            x = x, y = y, w = w, h = h,
            timeDiffHrs = 0.0,
        })
    end)
end)
