-- RSL_Admin/ItemSpawnerLog.lua (client)
-- Logs staff item spawns from the vanilla AdminPanel item list (ISItemsListTable.addItem).
-- Reports to server; server writes to: /RSL_Admin/Spawn_Itens/parp_misc/item_spawn.log

if not isClient() then return end

require "RSL_Admin/Config"
if RSL_Admin and RSL_Admin.Config and RSL_Admin.Config.NonInvasiveMode then return end

require "RSL_Admin/Config"
require "RSL_Admin/Net"
require "RSL_Admin/ClientReport"

local okUI = pcall(require, "ISUI/AdminPanel/ISItemsListTable")
if not okUI or not ISItemsListTable or not ISItemsListTable.addItem then
    print("[RSL_Admin] ISItemsListTable not found; item spawn logging disabled.")
    return
end

local orgAddItem = ISItemsListTable.addItem

ISItemsListTable.addItem = function(self, item)
    local player = getPlayer()
    if player and RSL_Admin and RSL_Admin.Config and RSL_Admin.Config.LogStaffItemSpawns then
        local fullName = "unknown item"
        local fullType = nil

        if type(item) == "table" then
            if item.fullType then fullType = tostring(item.fullType) end
            if item.fullName then fullName = tostring(item.fullName) end
        end
        if item and type(item) ~= "table" then
            if item.getFullName then
                local ok, v = pcall(item.getFullName, item)
                if ok and v then fullName = tostring(v) end
            end
            if item.getFullType then
                local ok, v = pcall(item.getFullType, item)
                if ok and v then fullType = tostring(v) end
            end
        end

        local reason = fullType and ("Spawned item: " .. fullName .. " (" .. fullType .. ")") or ("Spawned item: " .. fullName)
        RSL_Admin.ClientReport:send(RSL_Admin.Net.Cmd.ItemSpawn, { reason = reason })
    end

    if orgAddItem then
        return orgAddItem(self, item)
    end
end
