-- RSL_Admin/ItemMoveHooksServer.lua (server)
if not isServer() then return end
require "RSL_Admin/Config"
print("[RSL_Admin] ItemMoveHooksServer loaded.")
