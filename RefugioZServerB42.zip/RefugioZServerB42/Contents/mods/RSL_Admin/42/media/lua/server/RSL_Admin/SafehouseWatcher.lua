-- RSL_Admin/SafehouseWatcher.lua (server)
-- Non-invasive (Power-ADM style): log safehouse releases/removals without client/UI patches.
-- Strategy:
--  1) Listen to OnClientCommand for likely safehouse release/removal commands.
--  2) Best-effort: resolve the SafeHouse object from args/player square and log details.
--  3) Fallback: periodic scan detects removed safehouses and logs as SERVER if no player context.

if not isServer() then return end

require "RSL_Admin/Config"
require "RSL_Admin/Paths"
require "RSL_Admin/LogWriter"

RSL_Admin = RSL_Admin or {}
RSL_Admin.Server = RSL_Admin.Server or {}

if not (RSL_Admin.Config and RSL_Admin.Config.LogReleasedSafehouses) then return end

local lastAt = {} -- anti-spam per onlineID
local known = {}  -- known safehouses snapshot (fallback scan)
local lastScanAt = 0

local function nowSec()
    -- Return seconds (float). getTimestamp() is usually milliseconds in B42.
    local t
    if _G.getTimestamp then
        local ok, v = pcall(_G.getTimestamp)
        if ok and type(v) == "number" then t = v end
    end
    if not t then t = (os and os.time and os.time()) or 0 end
    if t > 1000000000000 then t = t / 1000 end -- ms -> s
    return t
end

local function onlineIdStr(player)
    if player and player.getOnlineID then
        local ok, v = pcall(player.getOnlineID, player)
        if ok and v ~= nil then return tostring(v) end
    end
    return tostring(player or "nil")
end

local function allowRate(player)
    local secs = (RSL_Admin.Config and RSL_Admin.Config.RateLimitSeconds) or 0.15
    if secs <= 0 then return true end
    local id = onlineIdStr(player)
    local t = nowSec()
    local prev = lastAt[id] or 0
    if (t - prev) < secs then return false end
    lastAt[id] = t
    return true
end

local function safeCall(obj, fn, ...)
    if obj and obj[fn] then
        local ok, v = pcall(obj[fn], obj, ...)
        if ok then return v end
    end
    return nil
end

local function safeNum(obj, fn, def)
    local v = safeCall(obj, fn)
    if v == nil then return def end
    v = tonumber(v)
    if v == nil then return def end
    return v
end

local function safeStr(obj, fn, def)
    local v = safeCall(obj, fn)
    if v == nil then return def end
    v = tostring(v)
    if v == "" then return def end
    return v
end

local function safehouseKey(sh)
    if not sh then return nil end
    local x = safeNum(sh, "getX", 0)
    local y = safeNum(sh, "getY", 0)
    local w = safeNum(sh, "getW", 0)
    local h = safeNum(sh, "getH", 0)
    local owner = safeStr(sh, "getOwner", "unknown")
    local title = safeStr(sh, "getTitle", "Safehouse")
    return string.format("%d:%d:%d:%d:%s:%s", x, y, w, h, owner, title)
end

local function writeLine(player, sh, hrs, note)
    hrs = tonumber(hrs) or 0
    note = note and tostring(note) or nil

    local sid, user
    if player then
        sid, user = RSL_Admin.LogWriter:prefix(player)
    else
        sid, user = "SERVER", "SERVER"
    end

    local title = safeStr(sh, "getTitle", "Safehouse")
    local owner = safeStr(sh, "getOwner", "unknown")
    local x = safeNum(sh, "getX", 0)
    local y = safeNum(sh, "getY", 0)
    local w = safeNum(sh, "getW", 0)
    local h = safeNum(sh, "getH", 0)

    local line = string.format("[%s / %s] released safehouse [%s] of [%s] at [%d, %d, 0] + [%d x %d] after [%.1f] hours since last login.",
        tostring(sid), tostring(user), title, owner, x, y, w, h, hrs
    )
    if note then line = line .. " (" .. note .. ")" end
    RSL_Admin.LogWriter:write(RSL_Admin.Paths.ReleasedSafehouses, line)
end

local function gridSquareFromArgs(args)
    if type(args) ~= "table" then return nil end
    local x = tonumber(args.x or args.X)
    local y = tonumber(args.y or args.Y)
    local z = tonumber(args.z or args.Z) or 0
    if not x or not y then return nil end

    -- try multiple world/cell accessors across patches
    if _G.getCell and type(_G.getCell) == "function" then
        local ok, cell = pcall(_G.getCell)
        if ok and cell and cell.getGridSquare then
            local ok2, sq = pcall(cell.getGridSquare, cell, x, y, z)
            if ok2 then return sq end
        end
    end
    if _G.getWorld and _G.getWorld().getCell then
        local ok, cell = pcall(function() return _G.getWorld():getCell() end)
        if ok and cell and cell.getGridSquare then
            local ok2, sq = pcall(cell.getGridSquare, cell, x, y, z)
            if ok2 then return sq end
        end
    end
    return nil
end

local function resolveSafehouse(player, args)
    if not SafeHouse or not SafeHouse.getSafeHouse then return nil end

    -- Best: from args coords
    local sq = gridSquareFromArgs(args)
    if not sq and player then
        sq = safeCall(player, "getSquare")
    end
    if not sq then return nil end

    local ok, sh = pcall(SafeHouse.getSafeHouse, sq)
    if ok then return sh end
    return nil
end

local function norm(s) return tostring(s or ""):lower() end

local safehouseKW = {
    "safehouse", "safe_house",
}
local releaseKW = {
    "release", "remove", "delete", "unclaim", "kick", "clear",
}

local function looksLikeSafehouseCmd(module, command)
    module = norm(module)
    command = norm(command)

    local modOk = false
    for _,kw in ipairs(safehouseKW) do
        if module:find(kw, 1, true) then modOk = true break end
    end

    local cmdOk = false
    for _,kw in ipairs(releaseKW) do
        if command:find(kw, 1, true) then cmdOk = true break end
    end

    -- module indicates safehouse OR command indicates safehouse; and command indicates release/removal
    if (module == "safehouse" or module:find("safehouse",1,true)) and cmdOk then return true end
    if command:find("safehouse", 1, true) and cmdOk then return true end
    if modOk and cmdOk then return true end
    return false
end

local function onClientCommand(module, command, player, args)
    if not player then return end
    if module == "BurdJournals" then return end -- compat: never touch BurdJournals commands
    if not looksLikeSafehouseCmd(module, command) then return end
    if not allowRate(player) then return end

    local sh = resolveSafehouse(player, args)
    if sh then
        writeLine(player, sh, 0, "via OnClientCommand "..tostring(module).."."..tostring(command))
    else
        -- Still log something, even if we couldn't resolve safehouse object.
        local dummy = {
            getTitle = function() return "Safehouse" end,
            getOwner = function() return "unknown" end,
            getX = function() return tonumber(args and (args.x or args.X) or 0) or 0 end,
            getY = function() return tonumber(args and (args.y or args.Y) or 0) or 0 end,
            getW = function() return tonumber(args and (args.w or args.W) or 0) or 0 end,
            getH = function() return tonumber(args and (args.h or args.H) or 0) or 0 end,
        }
        writeLine(player, dummy, 0, "via OnClientCommand "..tostring(module).."."..tostring(command))
    end
end

Events.OnClientCommand.Add(onClientCommand)

-- ---------- Fallback scan (no player attribution) ----------

local function listSafehouses()
    if not SafeHouse then return nil end
    local candidates = { "getSafehouseList", "getSafeHouseList", "getSafehouses", "getSafeHouses" }
    for _,fn in ipairs(candidates) do
        local f = SafeHouse[fn]
        if type(f) == "function" then
            -- try as static
            local ok, lst = pcall(f)
            if ok and lst then return lst end
            -- try as method
            ok, lst = pcall(f, SafeHouse)
            if ok and lst then return lst end
        end
    end
    return nil
end

local function snapshotSafehouses()
    local snap = {}
    local lst = listSafehouses()
    if not lst or not lst.size then return snap end
    local okSize, size = pcall(lst.size, lst)
    if not okSize or not size then return snap end

    for i=0, size-1 do
        local sh = lst:get(i)
        if sh then
            local k = safehouseKey(sh)
            if k then snap[k] = sh end
        end
    end
    return snap
end

local function scan()
    local interval = 30 -- seconds
    local t = nowSec()
    if (t - lastScanAt) < interval then return end
    lastScanAt = t

    local cur = snapshotSafehouses()

    -- detect removals
    for k, sh in pairs(known) do
        if not cur[k] then
            writeLine(nil, sh, 0, "fallback-scan removal")
        end
    end

    known = cur
end

if Events and Events.OnTick then Events.OnTick.Add(scan) end

print("[RSL_Admin] SafehouseWatcher loaded (server, non-invasive).")
