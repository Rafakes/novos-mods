-- RSL_Admin/Net.lua (shared)
-- Aurora-style: one module name + command constants.
RSL_Admin = RSL_Admin or {}
RSL_Admin.Net = RSL_Admin.Net or {}

RSL_Admin.Net.Module = "RSL_Admin"

RSL_Admin.Net.Cmd = {
    TileWhitelistDestroyed = "TileWhitelistDestroyed",
    DestroyedTiles         = "DestroyedTiles",
    ItemSpawn              = "ItemSpawn",
    AdminPowerUsed         = "AdminPowerUsed",
    SafehouseReleased      = "SafehouseReleased",
}
