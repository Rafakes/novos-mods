-- RSL_Admin/AdminPowerLog.lua (client)
-- MP-safe: client detects UI/admin actions and sends small payloads to server.
-- Server writes to: Zomboid/Lua/RSL_Admin/ADM_power/debug_admin_hide.log

if not isClient() then return end

require "RSL_Admin/Config"

RSL_Admin = RSL_Admin or {}
RSL_Admin.Client = RSL_Admin.Client or {}

local function enabled()
    return RSL_Admin.Config and RSL_Admin.Config.LogAdminPower
end

local function nowSeconds()
    if getGameTime then
        local gt = getGameTime()
        if gt and gt.getWorldAgeHours then
            local ok, hrs = pcall(gt.getWorldAgeHours, gt)
            if ok and hrs then return tonumber(hrs) * 3600 end
        end
    end
    -- fallback: second resolution
    return os.time()
end

-- ------------------------------------------------------------
-- 1) Debug/Admin button visibility (same messages as BTSE)
-- ------------------------------------------------------------

local function patchEquippedItemButtons()
    local ok, err = pcall(require, "ISUI/ISEquippedItem")
    if not ok or not ISEquippedItem then
        print("[RSL_Admin] ISEquippedItem not found; button visibility logging disabled. " .. tostring(err))
        return false
    end
    if not ISEquippedItem.initialise then
        print("[RSL_Admin] ISEquippedItem.initialise not found; button visibility logging disabled.")
        return false
    end
    if ISEquippedItem._rslAdminWrapped then return true end
    ISEquippedItem._rslAdminWrapped = true

    local vanillaInit = ISEquippedItem.initialise

    local function isVisible(btn)
        if not btn then return false end
        if btn.getIsVisible then
            local ok2, v = pcall(btn.getIsVisible, btn)
            if ok2 and v == true then return true end
        end
        return false
    end

    -- session flags to avoid spam
    RSL_Admin.Client._dbgBtnLogged = RSL_Admin.Client._dbgBtnLogged or false
    RSL_Admin.Client._admBtnLogged = RSL_Admin.Client._admBtnLogged or false

    ISEquippedItem.initialise = function(self, ...)
        local ret = vanillaInit(self, ...)

        if not enabled() then return ret end

        local player = getSpecificPlayer(0)
        if not player then return ret end

        local inst = ISEquippedItem.instance
        if not inst then return ret end

        local dbg = inst.debugBtn or inst.debugButton
        local adm = inst.adminBtn or inst.adminButton or inst.adminPanelBtn

        if isVisible(dbg) and not RSL_Admin.Client._dbgBtnLogged then
            RSL_Admin.Client._dbgBtnLogged = true
            sendClientCommand(player, "RSL_Admin", "DebugAdminVisible", { what = "Debug panel button visible" })
        end
        if isVisible(adm) and not RSL_Admin.Client._admBtnLogged then
            RSL_Admin.Client._admBtnLogged = true
            sendClientCommand(player, "RSL_Admin", "DebugAdminVisible", { what = "Admin panel button visible" })
        end

        return ret
    end

    return true
end

-- ------------------------------------------------------------
-- 2) Admin Panel option usage (when you click powers/options)
-- ------------------------------------------------------------

local function patchAdminPanel()
    local ok, err = pcall(require, "ISUI/AdminPanel/ISAdminPanelUI")
    if not ok or not ISAdminPanelUI then
        print("[RSL_Admin] ISAdminPanelUI not found; admin option logging disabled. " .. tostring(err))
        return false
    end
    if not ISAdminPanelUI.onOptionMouseDown then
        print("[RSL_Admin] ISAdminPanelUI.onOptionMouseDown not found; admin option logging disabled.")
        return false
    end
    if ISAdminPanelUI._rslAdminWrapped then return true end
    ISAdminPanelUI._rslAdminWrapped = true

    local org = ISAdminPanelUI.onOptionMouseDown

    -- anti-spam: one log per 0.25s
    RSL_Admin.Client._lastAdminClickS = RSL_Admin.Client._lastAdminClickS or 0

    ISAdminPanelUI.onOptionMouseDown = function(self, button, x, y, ...)
        -- call vanilla first (so we don't block anything)
        local ret = org(self, button, x, y, ...)

        if enabled() then
            local player = getSpecificPlayer(0)
            if player and button then
                local nowS = nowSeconds()
                if (nowS - (RSL_Admin.Client._lastAdminClickS or 0)) >= 0.25 then
                    RSL_Admin.Client._lastAdminClickS = nowS
                    local internal = tostring(button.internal or "unknown")
                    sendClientCommand(player, "RSL_Admin", "AdminOptionUsed", { internal = internal })
                end
            end
        end

        return ret
    end

    return true
end

-- ------------------------------------------------------------
-- Boot: try patch now; retry after load order via OnTick.
-- ------------------------------------------------------------

local tries = 0
local function tryPatch()
    if not enabled() then return true end
    local ok1 = patchEquippedItemButtons()
    local ok2 = patchAdminPanel()
    return ok1 or ok2
end

Events.OnGameBoot.Add(function()
    tryPatch()

    Events.OnTick.Add(function()
        if tries > 600 then return end
        tries = tries + 1
        tryPatch()
    end)
end)
