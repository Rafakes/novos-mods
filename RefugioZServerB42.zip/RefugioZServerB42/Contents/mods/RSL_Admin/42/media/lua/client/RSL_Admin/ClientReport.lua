-- RSL_Admin/ClientReport.lua (client)
-- Aurora-style: one function to report audit events to server.
if not isClient() then return end

require "RSL_Admin/Config"
require "RSL_Admin/Net"

RSL_Admin = RSL_Admin or {}
RSL_Admin.ClientReport = RSL_Admin.ClientReport or {}

local lastAt = 0

local function nowSec()
    if getTimestamp then
        local ok, v = pcall(getTimestamp)
        if ok and type(v) == "number" then return v end
    end
    return (os and os.time and os.time()) or 0
end

local function allowRate()
    local secs = (RSL_Admin.Config and RSL_Admin.Config.RateLimitSeconds) or 0.15
    if secs <= 0 then return true end
    local t = nowSec()
    if (t - lastAt) < secs then return false end
    lastAt = t
    return true
end

local function resolvePlayer(p)
    if p then return p end
    if getSpecificPlayer then
        local p0 = getSpecificPlayer(0)
        if p0 then return p0 end
    end
    if getPlayer then
        local p1 = getPlayer()
        if p1 then return p1 end
    end
    return nil
end

-- sendClientCommand signature varies; try both.
local function sendCompat(player, module, command, args)
    if not sendClientCommand then return false end
    args = args or {}
    -- B41-style / some B42: (module, command, args)
    local ok = pcall(sendClientCommand, module, command, args)
    if ok then return true end
    -- common MP: (player, module, command, args)
    if player then
        ok = pcall(sendClientCommand, player, module, command, args)
        if ok then return true end
    end
    return false
end

function RSL_Admin.ClientReport:send(command, args, player)
    if not (RSL_Admin.Config) then return false end
    if not allowRate() then return false end
    player = resolvePlayer(player)
    if not player then return false end
    return sendCompat(player, RSL_Admin.Net.Module, command, args)
end
