-- RSL_Admin/ItemMoveHooksClient.lua (client)
-- Logs item movements touching WORLD containers/floor.
-- Client observes timed actions and reports small payloads to server; server writes logs.

if not isClient() then return end

require "RSL_Admin/Config"
require "RSL_Admin/Net"
require "RSL_Admin/ClientReport"

RSL_Admin = RSL_Admin or {}

if not (RSL_Admin.Config and RSL_Admin.Config.LogItemMoves) then return end

local function safeCall(obj, fn, ...)
    if obj and obj[fn] then
        local ok, v = pcall(obj[fn], obj, ...)
        if ok then return v end
    end
    return nil
end

local function playerInv(player)
    return (player and player.getInventory) and safeCall(player, "getInventory") or nil
end

local function invContains(inv, item)
    if inv and inv.contains then
        local ok, v = pcall(inv.contains, inv, item)
        if ok then return v == true end
    end
    if inv and inv.Contains then
        local ok, v = pcall(inv.Contains, inv, item)
        if ok then return v == true end
    end
    return false
end

local function containerIsOnPlayer(container, player)
    if not container or not player then return false end
    local inv = playerInv(player)
    if inv and container == inv then return true end

    local containing = safeCall(container, "getContainingItem")
    if containing and inv then
        if invContains(inv, containing) then return true end
        -- sometimes bags are in worn containers; still treat as on-player
        local pItemCont = safeCall(containing, "getContainer")
        if pItemCont and pItemCont == inv then return true end
    end

    local parent = safeCall(container, "getParent")
    if parent == player then return true end

    return false
end

local function squareFromContainer(container)
    if not container then return nil end
    local parent = safeCall(container, "getParent")
    if parent and parent.getSquare then
        local sq = safeCall(parent, "getSquare")
        if sq then return sq end
    end
    if container.getSourceGrid then
        local sq = safeCall(container, "getSourceGrid")
        if sq then return sq end
    end
    return nil
end

local function xyzFromSquare(sq)
    if not sq then return 0,0,0 end
    local x = safeCall(sq, "getX") or 0
    local y = safeCall(sq, "getY") or 0
    local z = safeCall(sq, "getZ") or 0
    return tonumber(x) or 0, tonumber(y) or 0, tonumber(z) or 0
end

local function containerKind(container)
    if not container then return "container" end
    local t = safeCall(container, "getType")
    if t then
        t = tostring(t):lower()
        if t == "floor" then return "floor" end
    end
    return "container"
end

local function fullTypeOf(item)
    local ft = safeCall(item, "getFullType")
    if ft and tostring(ft) ~= "" then return tostring(ft) end
    local t = safeCall(item, "getType")
    if t and tostring(t) ~= "" then return tostring(t) end
    return "Unknown.Item"
end

local function gatherItems(self)
    local out = {}

    -- Some actions expose "items" list; some expose "item"
    local items = self and (self.items or self.itemsToTransfer or self.selectedItems)
    if items and type(items) == "table" then
        for _, it in pairs(items) do
            if it then out[#out+1] = it end
        end
    end

    local single = self and self.item
    if single then out[#out+1] = single end

    return out
end

local function clampTypes(types, maxTypes)
    maxTypes = tonumber(maxTypes) or 24
    local out = {}
    local n = 0
    for _, t in ipairs(types) do
        if t and t ~= "" then
            n = n + 1
            if #out < maxTypes then out[#out+1] = t end
        end
    end
    return out, n, (n > #out)
end

local function sendWorldMove(player, kind, delta, sq, itemTypes)
    if not player or not sendClientCommand then return end
    local x,y,z = xyzFromSquare(sq)
    RSL_Admin.ClientReport:send(RSL_Admin.Net.Cmd.ItemMove, {
        kind = kind,
        delta = delta,
        x = x, y = y, z = z,
        items = itemTypes,
    })
end

local function logTransfer(self, player, src, dest)
    if not player then return end

    local types = {}
    for _, it in ipairs(gatherItems(self)) do
        types[#types+1] = fullTypeOf(it)
    end
    local maxTypes = (RSL_Admin.Config and RSL_Admin.Config.ItemMovesMaxTypes) or 24
    local clamped, n, truncated = clampTypes(types, maxTypes)
    if n <= 0 then return end
    if truncated then clamped[#clamped+1] = "..." end

    local srcOnPlayer = containerIsOnPlayer(src, player)
    local destOnPlayer = containerIsOnPlayer(dest, player)

    -- If only internal inventory/bag moves and world-only is enabled, ignore.
    if (RSL_Admin.Config and RSL_Admin.Config.ItemMovesWorldOnly) and srcOnPlayer and destOnPlayer then
        return
    end

    -- src world => removed from src
    if src and (not srcOnPlayer) then
        local kind = containerKind(src)
        local sq = squareFromContainer(src) or safeCall(player, "getCurrentSquare")
        sendWorldMove(player, kind, "-" .. tostring(n), sq, clamped)
    end

    -- dest world => added to dest
    if dest and (not destOnPlayer) then
        local kind = containerKind(dest)
        local sq = squareFromContainer(dest) or safeCall(player, "getCurrentSquare")
        -- match sample: container uses +0, floor uses +N
        local delta = (kind == "container") and "+0" or ("+" .. tostring(n))
        sendWorldMove(player, kind, delta, sq, clamped)
    end
end

-- Patch ISInventoryTransferAction
do
    local ok, err = pcall(require, "TimedActions/ISInventoryTransferAction")
    if ok and ISInventoryTransferAction and ISInventoryTransferAction.complete and not ISInventoryTransferAction._RSL_AdminItemPatched then
        ISInventoryTransferAction._RSL_AdminItemPatched = true
        local vanilla = ISInventoryTransferAction.complete
        ISInventoryTransferAction.complete = function(self, ...)
            local res = vanilla(self, ...)
            local player = self and (self.character or self.player) or getPlayer()
            local src = self and (self.srcContainer or self.sourceContainer)
            local dest = self and (self.destContainer or self.destinationContainer)
            pcall(function() logTransfer(self, player, src, dest) end)
            return res
        end
        print("[RSL_Admin] Patched ISInventoryTransferAction.complete for item move logging.")
    else
        -- optional; no print spam if file missing
    end
end

-- Patch ISDropItemAction (player -> floor)
do
    local ok, err = pcall(require, "TimedActions/ISDropItemAction")
    if ok and ISDropItemAction and ISDropItemAction.complete and not ISDropItemAction._RSL_AdminItemPatched then
        ISDropItemAction._RSL_AdminItemPatched = true
        local vanilla = ISDropItemAction.complete
        ISDropItemAction.complete = function(self, ...)
            local res = vanilla(self, ...)
            local player = self and (self.character or self.player) or getPlayer()
            local sq = self and (self.square or self.worldsquare) or (player and safeCall(player, "getCurrentSquare"))
            local types = {}
            for _, it in ipairs(gatherItems(self)) do types[#types+1] = fullTypeOf(it) end
            local clamped, n, truncated = clampTypes(types, (RSL_Admin.Config and RSL_Admin.Config.ItemMovesMaxTypes) or 24)
            if n > 0 then
                if truncated then clamped[#clamped+1] = "..." end
                sendWorldMove(player, "floor", "+" .. tostring(n), sq, clamped)
            end
            return res
        end
        print("[RSL_Admin] Patched ISDropItemAction.complete for floor drop logging.")
    end
end

-- Patch ISGrabItemAction (floor/world -> player) if present
do
    local ok, err = pcall(require, "TimedActions/ISGrabItemAction")
    if ok and ISGrabItemAction and ISGrabItemAction.complete and not ISGrabItemAction._RSL_AdminItemPatched then
        ISGrabItemAction._RSL_AdminItemPatched = true
        local vanilla = ISGrabItemAction.complete
        ISGrabItemAction.complete = function(self, ...)
            local res = vanilla(self, ...)
            local player = self and (self.character or self.player) or getPlayer()
            local sq = self and (self.square or self.worldsquare) or (player and safeCall(player, "getCurrentSquare"))
            local types = {}
            for _, it in ipairs(gatherItems(self)) do types[#types+1] = fullTypeOf(it) end
            local clamped, n, truncated = clampTypes(types, (RSL_Admin.Config and RSL_Admin.Config.ItemMovesMaxTypes) or 24)
            if n > 0 then
                if truncated then clamped[#clamped+1] = "..." end
                sendWorldMove(player, "floor", "-" .. tostring(n), sq, clamped)
            end
            return res
        end
        print("[RSL_Admin] Patched ISGrabItemAction.complete for floor pickup logging.")
    end
end
