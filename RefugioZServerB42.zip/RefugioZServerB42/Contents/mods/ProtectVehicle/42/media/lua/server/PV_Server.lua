--[[
    ProtectVehicle - PV_Server.lua
    Core server-side logic and command handling.
    Compatible with AVCS Save Data.
    B42.14.x - Server is TRUTH.
--]]

if not isServer() then return end

PV = PV or {}

-- Coerce sqlid to number when possible (client may send as string)
function PV.toSQLID(v)
    if v == nil then return nil end
    if type(v) == "number" then return v end
    if type(v) == "string" then return tonumber(v) or v end
    return v
end


-- ============================================================
-- DB INITIALIZATION
-- ============================================================
function PV.InitDB()
    -- Migração de chaves antigas: saves feitos com versões anteriores do PV
    -- usavam "AVCSByVehicleSQLID" / "AVCSByPlayerID" (herdado do AVCS).
    -- Se encontrar as chaves antigas e as novas ainda não existirem, copia e remove.
    if ModData.exists("AVCSByVehicleSQLID") and not ModData.exists("PVByVehicleSQLID") then
        local oldData = ModData.get("AVCSByVehicleSQLID")
        ModData.create("PVByVehicleSQLID")
        if type(oldData) == "table" then
            ModData.add("PVByVehicleSQLID", oldData)
        end
        print("[PV] Migração: AVCSByVehicleSQLID -> PVByVehicleSQLID (" .. tostring(type(oldData)) .. ")")
    end
    if ModData.exists("AVCSByPlayerID") and not ModData.exists("PVByPlayerID") then
        local oldData = ModData.get("AVCSByPlayerID")
        ModData.create("PVByPlayerID")
        if type(oldData) == "table" then
            ModData.add("PVByPlayerID", oldData)
        end
        print("[PV] Migração: AVCSByPlayerID -> PVByPlayerID (" .. tostring(type(oldData)) .. ")")
    end

    -- Criar chaves novas se ainda não existem
    if not ModData.exists("PVByVehicleSQLID") then
        ModData.create("PVByVehicleSQLID")
        print("[PV] PVByVehicleSQLID: nova chave criada.")
    else
        print("[PV] PVByVehicleSQLID: chave encontrada.")
    end
    if not ModData.exists("PVByPlayerID") then
        ModData.create("PVByPlayerID")
        print("[PV] PVByPlayerID: nova chave criada.")
    else
        print("[PV] PVByPlayerID: chave encontrada.")
    end
    if not ModData.exists("PV_UsedVehicleIDs") then ModData.create("PV_UsedVehicleIDs") end

    PV.dbByVehicleSQLID = ModData.get("PVByVehicleSQLID")
    PV.dbByPlayerID     = ModData.get("PVByPlayerID")

    -- Garante que são tabelas (ModData pode retornar nil em server dedicado limpo)
    if type(PV.dbByVehicleSQLID) ~= "table" then
        PV.dbByVehicleSQLID = {}
        ModData.add("PVByVehicleSQLID", PV.dbByVehicleSQLID)
        print("[PV] PVByVehicleSQLID era nil/inválido — reinicializado como tabela vazia.")
    end
    if type(PV.dbByPlayerID) ~= "table" then
        PV.dbByPlayerID = {}
        ModData.add("PVByPlayerID", PV.dbByPlayerID)
        print("[PV] PVByPlayerID era nil/inválido — reinicializado como tabela vazia.")
    end

    -- Migra estrutura do DB (campos novos, version bump)
    PV.migrateDB()

    -- Auditoria pós-migração: reportar veículos com dono desconhecido
    local orphans = 0
    for sqlid, entry in pairs(PV.dbByVehicleSQLID) do
        local o = entry.OwnerPlayerID
        if o == nil or o == "" or o == "__UNKNOWN__" then
            orphans = orphans + 1
            print("[PV] AVISO: veículo sqlid=" .. tostring(sqlid) .. " sem OwnerPlayerID válido (valor='" .. tostring(o) .. "'). Use o painel Admin para corrigir ou remover.")
        end
    end
    if orphans > 0 then
        print("[PV] AVISO: " .. orphans .. " veículo(s) órfão(s) detectado(s) após migração. Apenas admins podem fazer unclaim desses veículos.")
    end

    local vCount = 0; for _ in pairs(PV.dbByVehicleSQLID) do vCount = vCount + 1 end
    local pCount = 0; for _ in pairs(PV.dbByPlayerID) do pCount = pCount + 1 end
    print(string.format("[PV] DB pronto. Veículos: %d | Jogadores: %d", vCount, pCount))
end

-- ============================================================
-- CLAIM LOGIC
-- ============================================================
-- Forward declarations for local helpers used by ServerClaimVehicle.
local PV_vehicleIsNearPlayer
local PV_isClaimableVehicle

function PV.ServerClaimVehicle(playerObj, vehicleObj)
    if not playerObj or not vehicleObj then return end
    if not PV_isClaimableVehicle(vehicleObj) then
        PV.Log.claim(playerObj, vehicleObj, "NONE", false, "Unsupported vehicle for claim")
        return
    end
    if not PV_vehicleIsNearPlayer(playerObj, vehicleObj, 6) then
        PV.Log.claim(playerObj, vehicleObj, "NONE", false, "Player too far from vehicle")
        return
    end

    -- 1. Check if already claimed
    local existingID = PV.getVehicleID(vehicleObj)
    if existingID and PV.dbByVehicleSQLID[existingID] then
        PV.Log.claim(playerObj, vehicleObj, existingID, false, "Already claimed")
        return
    end

    -- 2. Check Max Vehicle limit before consuming any item
    if not PV.checkMaxClaim(playerObj) then
        PV.Log.claim(playerObj, vehicleObj, "NONE", false, "Max vehicle limit reached")
        sendServerCommand(playerObj, "ProtectVehicle", "haloNote",
            { text = "IGUI_PV_LimitReached", r=1, g=1, b=0 })
        return
    end

    -- 2. Check Document requirement
    -- Padrão AACS: validação APENAS depois de confirmar que o claim vai acontecer.
    -- Default: "Base.VehicleDocument" (module Base para compatibilidade MP).
    -- Admin pode configurar outro item via VehicleDocumentItemType no sandbox.
    if SandboxVars.ProtectVehicle.RequireVehicleDocumentForClaim then
        local docType = SandboxVars.ProtectVehicle.VehicleDocumentItemType or "Base.VehicleDocument"
        local inv = playerObj:getInventory()
        local item = inv and inv:getFirstTypeRecurse(docType) or nil
        if not item then
            PV.Log.claim(playerObj, vehicleObj, "NONE", false, "Missing document: " .. docType)
            sendServerCommand(playerObj, "ProtectVehicle", "haloNote",
                { text = "IGUI_PV_MissingDocument", r=1, g=0.2, b=0.2 })
            return
        end

        -- Consume if configured (padrão AACS: pcall + inv:Remove + sendRemoveItemFromContainer)
        if SandboxVars.ProtectVehicle.ConsumeVehicleDocumentOnClaim then
            local synced = false
            local ok, err = pcall(function()
                if isServer() then
                    inv:Remove(item)
                    sendRemoveItemFromContainer(inv, item)
                    synced = true
                else
                    inv:Remove(item)
                    synced = true
                end
            end)
            if not ok then
                PV.Log.writeGlobal("ERROR consuming VehicleDocument: " .. tostring(err), "ERROR")
            else
                PV.Log.writeGlobal("VehicleDocument consumed for " .. playerObj:getUsername()
                    .. " (MP sync: " .. tostring(synced) .. ")", "INFO")
            end
        end
    end

    -- 3. Generate/Assign SQLID
    local sqlid = PV.ensureVehicleSQLID(vehicleObj)

    -- 5. Register in DB
    local username = playerObj:getUsername()
    local timestamp = getTimestamp()

    PV.dbByVehicleSQLID[sqlid] = {
        OwnerPlayerID = username,
        ClaimDateTime = timestamp,
        CarModel = vehicleObj:getScript():getFullName(),
        LastLocationX = math.floor(vehicleObj:getX()),
        LastLocationY = math.floor(vehicleObj:getY()),
        LastLocationZ = math.floor(vehicleObj:getZ()),
        LastLocationUpdateDateTime = timestamp,
        PublicFlags = {}, -- Default to all false per migration logic
        AllowList = {},
        AllowSafehouse = false,
        AllowFaction = false,
        AllowSafehouseRV = false,
        AllowFactionRV = false,
    }

    if not PV.dbByPlayerID[username] then
        PV.dbByPlayerID[username] = {
            LastKnownLogonTime = timestamp,
            LastKnownLogoffTime = timestamp,
            [sqlid] = true
        }
    else
        PV.dbByPlayerID[username][sqlid] = true
        PV.dbByPlayerID[username].LastKnownLogonTime = timestamp
    end

    ModData.add("PVByVehicleSQLID", PV.dbByVehicleSQLID)
    ModData.add("PVByPlayerID", PV.dbByPlayerID)

    PV.Log.claim(playerObj, vehicleObj, sqlid, true)

    -- Sync update to all clients
    sendServerCommand("ProtectVehicle", "updateVehicleData", { sqlid = sqlid, data = PV.dbByVehicleSQLID[sqlid] })
    sendServerCommand("ProtectVehicle", "updatePlayerData", { username = username, data = PV.dbByPlayerID[username] })
end

-- ============================================================
-- UNCLAIM LOGIC
-- ============================================================

-- Helper: devolve um VehicleDocument ao jogador ao fazer unclaim.
-- Padrão AACS: instanceItem() + pcall + sendAddItemToContainer.
-- Se inventário cheio, dropa no chão perto do jogador.
local function _giveDocumentToPlayer(playerObj)
    if not playerObj then return false end
    local inv = playerObj:getInventory()
    if not inv then return false end

    local docType = (SandboxVars.ProtectVehicle
        and SandboxVars.ProtectVehicle.VehicleDocumentItemType)
        or "Base.VehicleDocument"

    -- B42: instanceItem() é o método correto no servidor
    local item = nil
    pcall(function() item = instanceItem(docType) end)
    if not item then
        pcall(function() item = InventoryItemFactory.CreateItem(docType) end)
    end
    if not item then
        PV.Log.writeGlobal("_giveDocumentToPlayer: failed to create " .. docType, "ERROR")
        return false
    end

    -- Garantir item limpo
    pcall(function()
        if item.setActivated  then item:setActivated(false) end
        if item.setUsedDelta  then item:setUsedDelta(0) end
        if item.setCondition  then item:setCondition(100) end
    end)

    local added = false
    local ok, err = pcall(function()
        if isServer() then
            inv:AddItem(item)
            sendAddItemToContainer(inv, item)
            added = true
        else
            inv:AddItem(item)
            added = true
        end
    end)

    if not ok then
        PV.Log.writeGlobal("ERROR in _giveDocumentToPlayer: " .. tostring(err), "ERROR")
    end

    if not added then
        -- Fallback: dropar perto do jogador
        pcall(function()
            local sq = playerObj:getCurrentSquare()
            if sq then
                sq:AddWorldInventoryItem(item, 0, 0, 0)
                transmitCompleteItemToClients(item)
            end
        end)
    end
    return added
end

function PV.ServerUnclaimVehicle(playerObj, sqlid, isTimeout)
    sqlid = PV.toSQLID(sqlid)

    -- Defensive: DB não inicializado
    if not PV.dbByVehicleSQLID then
        PV.Log.writeGlobal("[PV] ServerUnclaimVehicle: dbByVehicleSQLID is nil for sqlid=" .. tostring(sqlid))
        if playerObj then
            sendServerCommand(playerObj, "ProtectVehicle", "haloNote",
                { text = "IGUI_PV_Error_DBNotReady", r=1, g=0.2, b=0.2 })
        end
        return
    end

    -- Veículo não existe no DB
    if not PV.dbByVehicleSQLID[sqlid] then
        PV.Log.writeGlobal("[PV] ServerUnclaimVehicle: Vehicle " .. tostring(sqlid) .. " not found in DB")
        if playerObj then
            sendServerCommand(playerObj, "ProtectVehicle", "haloNote",
                { text = "IGUI_PV_Error_VehicleNotClaimed", r=1, g=0.5, b=0.2 })
        end
        return
    end

    local entry = PV.dbByVehicleSQLID[sqlid]
    local owner = entry.OwnerPlayerID

    -- Log it
    if isTimeout then
        PV.Log.timeout(sqlid, owner, (PV.dbByPlayerID[owner] and PV.dbByPlayerID[owner].LastKnownLogoffTime or 0))
    else
        local isAdmin = playerObj:getUsername() ~= owner
        PV.Log.unclaim(playerObj, sqlid, isAdmin)
    end

    -- Remove from Player DB
    if PV.dbByPlayerID[owner] then
        PV.dbByPlayerID[owner][sqlid] = nil
    end

    -- Remove from Vehicle DB
    PV.dbByVehicleSQLID[sqlid] = nil

    ModData.add("PVByVehicleSQLID", PV.dbByVehicleSQLID)
    ModData.add("PVByPlayerID", PV.dbByPlayerID)

    sendServerCommand("ProtectVehicle", "removeVehicle", { sqlid = sqlid, owner = owner })

    -- Devolução do documento ao unclaim (padrão AACS: ReturnDocumentOnUnclaim)
    -- Condição: RequireDoc + ConsumeDoc + ReturnDoc + dono fazendo unclaim manual
    if not isTimeout and playerObj then
        local sv = SandboxVars.ProtectVehicle
        if sv
        and sv.RequireVehicleDocumentForClaim
        and sv.ConsumeVehicleDocumentOnClaim
        and sv.ReturnDocumentOnUnclaim
        and playerObj:getUsername() == owner
        then
            if _giveDocumentToPlayer(playerObj) then
                PV.Log.writeGlobal("VehicleDocument returned to " .. owner .. " on unclaim", "INFO")
            end
        end
    end

    -- Feedback visual para o jogador que executou o unclaim
    if not isTimeout and playerObj then
        sendServerCommand(playerObj, "ProtectVehicle", "haloNote",
            { text = "IGUI_PV_Unclaimed", r = 0.5, g = 1.0, b = 0.5 })
    end
end

-- ============================================================
-- Helper: check if a username is currently online (B42 safe)
-- ============================================================
local function _isUsernameOnline(username)
    if type(username) ~= "string" or username == "" then return false end

    if getPlayerFromUsername then
        return getPlayerFromUsername(username) ~= nil
    end
    if getPlayerByUsername then
        return getPlayerByUsername(username) ~= nil
    end

    if getOnlinePlayers then
        local op = getOnlinePlayers()
        if op then
            for i = 0, op:size() - 1 do
                local pl = op:get(i)
                if pl and pl.getUsername and pl:getUsername() == username then
                    return true
                end
            end
        end
    end
    return false
end


-- ============================================================
-- TIMEOUT CHECK (Every 10 minutes)
-- ============================================================
function PV.CheckTimeouts()
    local timeoutHours = SandboxVars.ProtectVehicle.ClaimTimeoutHours or 0
    if timeoutHours <= 0 then return end

    local now = getTimestamp()
    local timeoutSeconds = timeoutHours * 3600

    local db = PV.dbByVehicleSQLID or {}
    for sqlid, entry in pairs(db) do
        local owner = entry.OwnerPlayerID
        local pData = PV.dbByPlayerID[owner]

        if pData and pData.LastKnownLogoffTime then
            local isOnline = _isUsernameOnline(owner)

            if not isOnline and (now - pData.LastKnownLogoffTime) >= timeoutSeconds then
                PV.ServerUnclaimVehicle(nil, sqlid, true)
            end
        end
    end
end

-- ============================================================
-- COMMAND HANDLER HELPERS
-- ============================================================
PV_vehicleIsNearPlayer = function(playerObj, vehicleObj, maxDistance)
    if not playerObj or not vehicleObj then return false end
    local dx = playerObj:getX() - vehicleObj:getX()
    local dy = playerObj:getY() - vehicleObj:getY()
    local dz = math.abs((playerObj:getZ() or 0) - (vehicleObj:getZ() or 0))
    local maxDist = maxDistance or 6
    return dz <= 1 and ((dx * dx) + (dy * dy)) <= (maxDist * maxDist)
end

PV_isClaimableVehicle = function(vehicleObj)
    if not vehicleObj or vehicleObj:isRemovedFromWorld() then
        return false
    end
    local script = vehicleObj:getScript()
    local name = script and string.lower(script:getName() or "") or ""
    if string.find(name, "burnt", 1, true) or string.find(name, "smashed", 1, true) then
        return false
    end
    return true
end

local function PV_playerCanManageEntry(playerObj, entry)
    if not playerObj or not entry then return false end
    return PV.isStaffPlayer(playerObj) or entry.OwnerPlayerID == playerObj:getUsername()
end

local function PV_syncVehicleData(sqlid)
    sendServerCommand("ProtectVehicle", "updateVehicleData", { sqlid = sqlid, data = PV.dbByVehicleSQLID[sqlid] })
end

local function PV_applyGroupAccessValue(entry, key, value)
    if type(value) ~= "boolean" then return false end
    if (key == "AllowSafehouse" or key == "AllowSafehouseRV")
    and SandboxVars.ProtectVehicle
    and SandboxVars.ProtectVehicle.AllowSafehouse == false then
        value = false
    end
    if (key == "AllowFaction" or key == "AllowFactionRV")
    and SandboxVars.ProtectVehicle
    and SandboxVars.ProtectVehicle.AllowFaction == false then
        value = false
    end
    if entry[key] == value then return false end
    entry[key] = value
    return true
end

-- ============================================================
-- COMMAND HANDLER
-- ============================================================
PV.OnClientCommand = function(module, command, player, args)
    if module ~= "ProtectVehicle" then return end
    if not player then return end
    args = args or {}

    -- 1. Rate Limit check
    if not PV.RateLimit.isAllowed(player, command) then
        return
    end

    -- 2. Command routing
    if command == "claim" then
        local vehicleId = args.vehicleId and (tonumber(args.vehicleId) or args.vehicleId) or nil
        local vehicle = vehicleId and getVehicleById(vehicleId) or nil
        if not vehicle then
            PV.Log.writeGlobal("[PV] Claim failed: runtime vehicle not found for '" .. player:getUsername() .. "'")
            return
        end
        if not PV_isClaimableVehicle(vehicle) then
            PV.Log.claim(player, vehicle, "NONE", false, "Unsupported vehicle for claim")
            return
        end
        if not PV_vehicleIsNearPlayer(player, vehicle, 6) then
            PV.Log.claim(player, vehicle, "NONE", false, "Player too far from vehicle")
            return
        end
        PV.ServerClaimVehicle(player, vehicle)

    elseif command == "unclaim" then
        local sqlid = PV.toSQLID(args.sqlid)

        -- Defensive: DB não pronto
        if type(PV.dbByVehicleSQLID) ~= "table" then
            sendServerCommand(player, "ProtectVehicle", "haloNote",
                { text = "IGUI_PV_Error_DBNotReady", r=1, g=0.2, b=0.2 })
            return
        end

        -- Veículo não existe
        local entry = PV.dbByVehicleSQLID[sqlid]
        if not entry then
            sendServerCommand(player, "ProtectVehicle", "haloNote",
                { text = "IGUI_PV_Error_VehicleNotFound", r=1, g=0.2, b=0.2 })
            PV.Log.writeGlobal("[PV] Unclaim failed: Vehicle " .. tostring(sqlid) .. " not found in DB by " .. player:getUsername())
            return
        end

        -- CRITICAL: OwnerPlayerID nil/vazio/desconhecido = apenas admin pode unclaim
        -- Isso protege veículos migrados do AVCS com dono não identificado
        if PV_playerCanManageEntry(player, entry) then
            PV.ServerUnclaimVehicle(player, sqlid, false)
        else
            sendServerCommand(player, "ProtectVehicle", "haloNote",
                { text = "IGUI_PV_Error_NotOwner", r=1, g=0.2, b=0.2 })
            PV.Log.writeGlobal("[PV] ACTION DENIED 'unclaim_not_owner' for '" .. player:getUsername() .. "' | Vehicle " .. tostring(sqlid) .. " | owner='" .. tostring(entry.OwnerPlayerID) .. "'")
        end

    elseif command == "updateFlags" then
        local sqlid = PV.toSQLID(args.sqlid)
        local delta = args.delta
        local entry = PV.dbByVehicleSQLID and PV.dbByVehicleSQLID[sqlid]
        if entry and PV_playerCanManageEntry(player, entry) and PV.validateFlags(delta) then
            if PV.applyFlagsDelta(sqlid, delta) then
                ModData.add("PVByVehicleSQLID", PV.dbByVehicleSQLID)
                sendServerCommand("ProtectVehicle", "updateFlags", { sqlid = sqlid, flags = PV.dbByVehicleSQLID[sqlid].PublicFlags })
                PV.Log.writeVehicle(sqlid, "Flags updated by " .. player:getUsername(), "INFO")
            end
        end

    elseif command == "addToAllowList" then
        local sqlid        = PV.toSQLID(args.sqlid)
        local targetPlayer = PV.normalizeUsername(args.targetPlayer)
        if not sqlid or not targetPlayer then return end
        local entry = PV.dbByVehicleSQLID[sqlid]
        if not entry then return end
        if not PV_playerCanManageEntry(player, entry) then return end
        if targetPlayer == entry.OwnerPlayerID then return end
        entry.AllowList = entry.AllowList or {}
        if not entry.AllowList[targetPlayer] then
            entry.AllowList[targetPlayer] = {}
            ModData.add("PVByVehicleSQLID", PV.dbByVehicleSQLID)
            PV_syncVehicleData(sqlid)
            PV.Log.writeVehicle(sqlid, "AllowList ADD '" .. targetPlayer .. "' by '" .. player:getUsername() .. "'", "INFO")
        end

    elseif command == "removeFromAllowList" then
        local sqlid        = PV.toSQLID(args.sqlid)
        local targetPlayer = PV.normalizeUsername(args.targetPlayer)
        if not sqlid or not targetPlayer then return end
        local entry = PV.dbByVehicleSQLID[sqlid]
        if not entry then return end
        if not PV_playerCanManageEntry(player, entry) then return end
        if entry.AllowList and entry.AllowList[targetPlayer] ~= nil then
            entry.AllowList[targetPlayer] = nil
            ModData.add("PVByVehicleSQLID", PV.dbByVehicleSQLID)
            PV_syncVehicleData(sqlid)
            PV.Log.writeVehicle(sqlid, "AllowList REMOVE '" .. targetPlayer .. "' by '" .. player:getUsername() .. "'", "INFO")
        end

    elseif command == "updatePlayerFlags" then
        local sqlid        = PV.toSQLID(args.sqlid)
        local targetPlayer = PV.normalizeUsername(args.targetPlayer)
        local flags        = args.flags
        if not sqlid or not targetPlayer or type(flags) ~= "table" then return end
        local entry = PV.dbByVehicleSQLID[sqlid]
        if not entry then return end
        if not PV_playerCanManageEntry(player, entry) then return end
        if targetPlayer == entry.OwnerPlayerID then return end
        -- Validate: only known boolean flags
        for k, v in pairs(flags) do
            if PV.DEFAULT_FLAGS[k] == nil or type(v) ~= "boolean" then return end
        end
        entry.AllowList = entry.AllowList or {}
        local pFlags = entry.AllowList[targetPlayer]
        if type(pFlags) ~= "table" then
            entry.AllowList[targetPlayer] = {}
            pFlags = entry.AllowList[targetPlayer]
        end
        for k, v in pairs(flags) do pFlags[k] = v end
        ModData.add("PVByVehicleSQLID", PV.dbByVehicleSQLID)
        PV_syncVehicleData(sqlid)
        PV.Log.writeVehicle(sqlid, "PlayerFlags UPDATE for '" .. targetPlayer .. "' by '" .. player:getUsername() .. "'", "INFO")



    elseif command == "setGroupAccess" then
        local sqlid = PV.toSQLID(args.sqlid)
        if not sqlid then return end
        local entry = PV.dbByVehicleSQLID and PV.dbByVehicleSQLID[sqlid]
        if not entry then return end

        if not PV_playerCanManageEntry(player, entry) then return end

        local changed = false
        changed = PV_applyGroupAccessValue(entry, "AllowSafehouse", args.allowSafehouse) or changed
        changed = PV_applyGroupAccessValue(entry, "AllowFaction", args.allowFaction) or changed
        changed = PV_applyGroupAccessValue(entry, "AllowSafehouseRV", args.allowSafehouseRV) or changed
        changed = PV_applyGroupAccessValue(entry, "AllowFactionRV", args.allowFactionRV) or changed

        if changed then
            ModData.add("PVByVehicleSQLID", PV.dbByVehicleSQLID)
            PV_syncVehicleData(sqlid)
            PV.Log.writeVehicle(sqlid, "GroupAccess UPDATE by '" .. player:getUsername() ..
                "' safehouse=" .. tostring(entry.AllowSafehouse) ..
                " faction=" .. tostring(entry.AllowFaction) ..
                " safehouseRV=" .. tostring(entry.AllowSafehouseRV) ..
                " factionRV=" .. tostring(entry.AllowFactionRV), "INFO")
        end
    elseif command == "logon" then
        -- FIX #7: registra TODOS os jogadores no DB ao conectar,
        -- não apenas quem já tem veículo. Isso permite rastrear
        -- logon/logoff de qualquer jogador para fins de auditoria e timeout.
        local username  = player:getUsername()
        local now       = getTimestamp()

        if PV.dbByPlayerID[username] then
            -- Jogador já existe: atualiza horários
            PV.dbByPlayerID[username].LastKnownLogonTime  = now
            PV.dbByPlayerID[username].LastKnownLogoffTime = now
        else
            -- Novo jogador: cria entrada mínima
            PV.dbByPlayerID[username] = {
                LastKnownLogonTime  = now,
                LastKnownLogoffTime = now,
            }
            PV.Log.writeGlobal("New player registered in DB: '" .. username .. "'", "INFO")
        end
        ModData.add("PVByPlayerID", PV.dbByPlayerID)

    elseif command == "syncCoord" then
        -- Forçar atualização de coordenada (enter/exit veículo).
        local vehicleId = args.vehicleId and (tonumber(args.vehicleId) or args.vehicleId) or nil
        local vehicleObj = vehicleId and getVehicleById(vehicleId) or nil
        if vehicleObj and PV_vehicleIsNearPlayer(player, vehicleObj, 12) then
            local sqlid = PV.getVehicleID(vehicleObj)
            if sqlid and PV.dbByVehicleSQLID and PV.dbByVehicleSQLID[sqlid] then
                local entry = PV.dbByVehicleSQLID[sqlid]
                local nx = math.floor(vehicleObj:getX())
                local ny = math.floor(vehicleObj:getY())
                local nz = math.floor(vehicleObj:getZ())
                local now = getTimestamp()
                entry.LastLocationX = nx
                entry.LastLocationY = ny
                entry.LastLocationZ = nz
                entry.LastLocationUpdateDateTime = now
                ModData.add("PVByVehicleSQLID", PV.dbByVehicleSQLID)
                sendServerCommand("ProtectVehicle", "updateCoord", {
                    sqlid = sqlid, x = nx, y = ny, z = nz, t = now
                })
                -- LOG: registra entrada/saída do veículo por ID
                PV.Log.coordSync(player, vehicleObj, sqlid, args.source or "enter_exit")
            end
        end
    end
end

-- ============================================================
-- EVENTS
-- B42 does not have Events.OnPlayerQuit.
-- Use polling via EveryOneMinute to detect disconnects.
-- ============================================================
local PV_onlinePlayers = {}

local function PV_PollPlayerDisconnect()
    if not PV.dbByPlayerID then return end
    if type(PV_onlinePlayers) ~= "table" then PV_onlinePlayers = {} end

    -- Build current online set
    -- Build current online set
    local currentOnline = {}
    local players = getOnlinePlayers()
    if not players then
        PV_onlinePlayers = {}
        return
    end

    if type(players) == "table" then
        for _, p in ipairs(players) do
            if p then currentOnline[p:getUsername()] = true end
        end
    elseif players.size and players.get then
        local sz = players:size()
        for i = 0, sz - 1 do
            local p = players:get(i)
            if p then currentOnline[p:getUsername()] = true end
        end
    else
        -- unexpected type (defensive)
        return
    end

    -- Detect who left since last poll
    for username, _ in pairs(PV_onlinePlayers) do
        if not currentOnline[username] then
            if PV.dbByPlayerID[username] then
                PV.dbByPlayerID[username].LastKnownLogoffTime = getTimestamp()
                ModData.add("PVByPlayerID", PV.dbByPlayerID)
                PV.Log.writeGlobal("Player logged off: " .. username .. ". Logoff time updated.")
            end
        end
    end

    PV_onlinePlayers = currentOnline
end

-- ============================================================
-- COORDINATE TRACKING
-- Padrão AVCS: override de Vehicles.LowerCondition
-- Chamado pelo engine a cada degradação de peça — cobre todos
-- os veículos em uso sem polling e sem loop custoso.

-- ============================================================
-- RV Interior server-side validation
-- O mod RVInterior usa módulo "RVServer" / comando "enterRV".
-- Interceptamos OnClientCommand para validar permissão PV
-- ANTES que o handler original do RVInterior processe o comando.
-- Se negado, descartamos o args para que o handler original
-- receba args inválido e não processe (ou enviamos haloNote).
-- ============================================================
local PV_VehicleTowGuard = function(module, command, player, args)
    if module ~= "vehicle" or not player or not args then return end

    if command == "attachTrailer" then
        local vehicleAId = args.vehicleA and (tonumber(args.vehicleA) or args.vehicleA) or nil
        local vehicleBId = args.vehicleB and (tonumber(args.vehicleB) or args.vehicleB) or nil
        local vehicleA = vehicleAId and getVehicleById(vehicleAId) or nil
        local vehicleB = vehicleBId and getVehicleById(vehicleBId) or nil
        if not vehicleA or not vehicleB then return end

        local okA = PV.canPerformAction(player, vehicleA, "AllowTow")
        local okB = PV.canPerformAction(player, vehicleB, "AllowTow")
        if okA and okB then return end

        pcall(function() vehicleA:breakConstraint(true, false) end)
        sendServerCommand(player, "ProtectVehicle", "haloNote",
            { text = "IGUI_PV_NoPermission", r=1, g=0.2, b=0.2 })

        local sidA = PV.getVehicleID(vehicleA)
        local sidB = PV.getVehicleID(vehicleB)
        if sidA and PV.dbByVehicleSQLID and PV.dbByVehicleSQLID[sidA] then
            PV.Log.actionDenied(player, vehicleA, sidA, "attachTrailer")
        end
        if sidB and PV.dbByVehicleSQLID and PV.dbByVehicleSQLID[sidB] then
            PV.Log.actionDenied(player, vehicleB, sidB, "attachTrailer")
        end

    elseif command == "detachTrailer" then
        local vehicleId = args.vehicle and (tonumber(args.vehicle) or args.vehicle) or nil
        local vehicle = vehicleId and getVehicleById(vehicleId) or nil
        if not vehicle then return end
        if PV.canPerformAction(player, vehicle, "AllowTow") then return end

        sendServerCommand(player, "ProtectVehicle", "haloNote",
            { text = "IGUI_PV_NoPermission", r=1, g=0.2, b=0.2 })

        local sid = PV.getVehicleID(vehicle)
        local trailer = vehicle:getVehicleTowing()
        local trailerSid = trailer and PV.getVehicleID(trailer) or nil
        if sid and PV.dbByVehicleSQLID and PV.dbByVehicleSQLID[sid] then
            PV.Log.actionDenied(player, vehicle, sid, "detachTrailer")
        end
        if trailer and trailerSid and PV.dbByVehicleSQLID and PV.dbByVehicleSQLID[trailerSid] then
            PV.Log.actionDenied(player, trailer, trailerSid, "detachTrailer")
        end
    end
end

local PV_RVServerGuard = function(module, command, player, args)
    if module ~= "RVServer" or command ~= "enterRV" then return end
    if not args then return end

    -- Localizar o veículo pelo ID enviado pelo cliente
    local vehicleId = args.vehicleId and (tonumber(args.vehicleId) or args.vehicleId) or nil
    local vehicle = vehicleId and getVehicleById(vehicleId) or nil

    if not vehicle then
        -- Sem veículo identificado: bloquear por segurança
        sendServerCommand(player, "ProtectVehicle", "haloNote",
            { text = "IGUI_PV_NoPermission_RV", r=1, g=0.2, b=0.2 })
        -- Zeramos args para invalidar o comando para handlers subsequentes
        for k in pairs(args) do args[k] = nil end
        PV.Log.writeGlobal("[PV] RV enterRV BLOCKED (vehicle not found) for '" .. player:getUsername() .. "'", "WARN")
        return
    end

    -- Verificar permissão PV
    local allowed = PV.canEnterRV and PV.canEnterRV(player, vehicle) or true
    if not allowed then
        sendServerCommand(player, "ProtectVehicle", "haloNote",
            { text = "IGUI_PV_NoPermission_RV", r=1, g=0.2, b=0.2 })
        for k in pairs(args) do args[k] = nil end
        PV.Log.writeGlobal("[PV] RV enterRV BLOCKED for '" .. player:getUsername() .. "' | vehicleId=" .. tostring(vehicleId), "WARN")
    end
end

Events.OnClientCommand.Add(PV_VehicleTowGuard)
Events.OnClientCommand.Add(PV_RVServerGuard)
Events.OnInitGlobalModData.Add(PV.InitDB)
Events.OnClientCommand.Add(PV.OnClientCommand)
Events.EveryOneMinute.Add(PV_PollPlayerDisconnect)
Events.EveryTenMinutes.Add(PV.CheckTimeouts)
-- Events.OnVehicleAdded NÃO existe na B42 — removido.
