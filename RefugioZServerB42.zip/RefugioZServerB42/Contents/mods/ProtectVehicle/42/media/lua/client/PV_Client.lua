--[[
    ProtectVehicle - PV_Client.lua
    Client-side core logic.
    Handles UI triggers, context menus, and server command responses.
    B42.14.x - Pattern based on AVCS4213.
--]]

if isServer() and not isClient() then return end

PV = PV or {}

require "PV_ClaimAction"
require "PV_UnclaimAction"

-- ============================================================
-- INITIAL SYNC (fires once on first tick after game start)
-- ============================================================
function PV.AfterGameStart()
    ModData.request("PVByVehicleSQLID")
    ModData.request("PVByPlayerID")
    sendClientCommand(getPlayer(), "ProtectVehicle", "logon", {})
    Events.OnServerCommand.Add(PV.OnServerCommand)
    Events.OnTick.Remove(PV.AfterGameStart)
end

-- ============================================================
-- SERVER -> CLIENT HANDLER
-- ============================================================
PV.OnServerCommand = function(module, command, args)
    if module ~= "ProtectVehicle" then return end

    if command == "registerVehicleSQLID" then
        local v = getVehicleById(args.vehicleRuntimeId)
        if v then v:getModData().SQLID = args.sqlid end

    elseif command == "updateVehicleData" then
        if not PV.dbByVehicleSQLID then ModData.request("PVByVehicleSQLID") return end
        PV.dbByVehicleSQLID[args.sqlid] = args.data
        -- Refresh open UI panels
        if PV.UI.AdminInstance and PV.UI.AdminInstance:isVisible() then
            PV.UI.AdminInstance:initList()
            PV.UI.AdminInstance:onSelectionChange()
        end
        if PV.UI.UserInstance and PV.UI.UserInstance:isVisible() then
            PV.UI.UserInstance:refreshList()
        end

    elseif command == "updatePlayerData" then
        if not PV.dbByPlayerID then ModData.request("PVByPlayerID") return end
        PV.dbByPlayerID[args.username] = args.data
        -- Refresh user panel if it's the local player's data
        if args.username == getPlayer():getUsername() then
            if PV.UI.UserInstance and PV.UI.UserInstance:isVisible() then
                PV.UI.UserInstance:refreshList()
            end
        end

    elseif command == "removeVehicle" then
        local sqlid = args and args.sqlid
        if type(sqlid) == "string" then sqlid = tonumber(sqlid) or sqlid end

        -- If global moddata isn't ready yet, request and let the next update refresh UI.
        if not PV.dbByVehicleSQLID or not PV.dbByPlayerID then
            ModData.request("PVByVehicleSQLID")
            ModData.request("PVByPlayerID")
        end

        if PV.dbByVehicleSQLID then PV.dbByVehicleSQLID[sqlid] = nil end
        if PV.dbByPlayerID and args and args.owner and PV.dbByPlayerID[args.owner] then
            PV.dbByPlayerID[args.owner][sqlid] = nil
        end

        -- Refresh open UI panels
        if PV.UI.AdminInstance and PV.UI.AdminInstance:isVisible() then
            PV.UI.AdminInstance:initList()
            PV.UI.AdminInstance:onSelectionChange()
        end
        if PV.UI.UserInstance and PV.UI.UserInstance:isVisible() then
            PV.UI.UserInstance:refreshList()
        end

    elseif command == "updateCoord" then
        if PV.dbByVehicleSQLID and PV.dbByVehicleSQLID[args.sqlid] then
            local e = PV.dbByVehicleSQLID[args.sqlid]
            e.LastLocationX = args.x
            e.LastLocationY = args.y
            e.LastLocationZ = args.z
            e.LastLocationUpdateDateTime = args.t
        end
        -- Refresh admin panel location column
        if PV.UI.AdminInstance and PV.UI.AdminInstance:isVisible() then
            PV.UI.AdminInstance:initList()
        end

    elseif command == "updateFlags" then
        if PV.dbByVehicleSQLID and PV.dbByVehicleSQLID[args.sqlid] then
            PV.dbByVehicleSQLID[args.sqlid].PublicFlags = args.flags
        end

    elseif command == "haloNote" then
        getPlayer():setHaloNote(getText(args.text), args.r or 1, args.g or 1, args.b or 1, 300)

    elseif command == "adminResponse" then
        getPlayer():setHaloNote(getText(args.msg), args.success and 0.5 or 1, 1, args.success and 0.5 or 0.5, 300)

    elseif command == "adminTpToVehicle" then
        -- Só exibe o haloNote de confirmação; o movimento real já foi feito
        -- pelo servidor (teleportTo) + pelo comando "forceTeleport" abaixo.
        local player = getPlayer()
        if player then
            player:setHaloNote(getText("IGUI_PV_Admin_TpToVehicle_Sent"), 0.5, 1, 0.5, 300)
        end

    elseif command == "forceTeleport" then
        -- Fallback idêntico ao AACS: cliente aplica teleporte localmente para garantir
        -- o movimento quando o chunk não estava carregado no servidor no momento do TP.
        local player = getPlayer()
        local x = tonumber(args.x)
        local y = tonumber(args.y)
        local z = tonumber(args.z) or 0
        if player and x and y then
            pcall(function()
                if player.teleportTo then
                    player:teleportTo(x, y, z)
                else
                    if player.setX then player:setX(x) end
                    if player.setY then player:setY(y) end
                    if player.setZ then player:setZ(z) end
                end
            end)
        end

    end  -- fecha if/elseif chain
end  -- fecha PV.OnServerCommand

-- ============================================================
-- VEHICLE CONTEXT MENU (via ISVehicleMenu.FillMenuOutsideVehicle)
-- ============================================================
local function PV_addContextOption(context, text, fn)
    -- B42: ISContextMenu.addOption signature changed across versions/modpacks.
    -- Passing (text, fn, fn) keeps compatibility with both:
    --  - addOption(text, onSelect, param1)
    --  - addOption(text, target, onSelect)
    return context:addOption(text, fn, fn)
end

local function PV_addVehicleOptions(playerObj, context, vehicle)
    local vname = vehicle and vehicle:getScript() and vehicle:getScript():getName() or ""
    if string.match(string.lower(vname), "burnt") or string.match(string.lower(vname), "smashed") then
        return
    end

    local sqlid   = PV.getVehicleID(vehicle)
    local canManage = PV.canManageVehicle(playerObj, vehicle)
    local toolTip = ISToolTip:new()
    toolTip:initialise()
    toolTip:setVisible(false)

    if sqlid ~= nil and type(PV.dbByVehicleSQLID) ~= "table" then
        return
    end

    if sqlid == nil or PV.dbByVehicleSQLID[sqlid] == nil then
        -- UNCLAIMED
        local fn = function() ISTimedActionQueue.add(ISPVClaimAction:new(playerObj, vehicle)) end
        local option = PV_addContextOption(context, getText("IGUI_PV_ContextMenu_ClaimVehicle"), fn)
        toolTip.description = getText("IGUI_PV_Tooltip_CanClaim")
        if SandboxVars.ProtectVehicle and SandboxVars.ProtectVehicle.RequireVehicleDocumentForClaim then
            local docType = SandboxVars.ProtectVehicle.VehicleDocumentItemType or "Base.VehicleDocument"
            if not playerObj:getInventory():containsTypeRecurse(docType) then
                toolTip.description = toolTip.description .. " <LINE> <RGB:1,0.2,0.2> " .. getText("IGUI_PV_Tooltip_RequiresDoc")
                option.notAvailable = true
            end
        end
        if not PV.checkMaxClaim(playerObj) then
            toolTip.description = toolTip.description .. " <LINE> <RGB:1,0.2,0.2> " .. getText("IGUI_PV_Tooltip_LimitReached")
            option.notAvailable = true
        end
        option.toolTip = toolTip
    else
        -- CLAIMED
        if canManage then
            PV_addContextOption(context, getText("IGUI_PV_ContextMenu_UnclaimVehicle"), function()
                ISTimedActionQueue.add(ISPVUnclaimAction:new(playerObj, vehicle, sqlid))
            end)
            PV_addContextOption(context, getText("IGUI_PV_ContextMenu_ManageVehicle"), function() PV.UI.OpenPermissionPanel(sqlid) end)
        else
            local entry  = PV.dbByVehicleSQLID[sqlid]
            local option = context:addOption(getText("IGUI_PV_ContextMenu_OwnedBy", entry.OwnerPlayerID), nil, nil)
            toolTip.description = getText("IGUI_PV_ContextMenu_OwnedBy", entry.OwnerPlayerID)
            option.toolTip      = toolTip
            option.notAvailable = true
        end
    end
end

if not PV.oFillMenuOutsideVehicle then
    PV.oFillMenuOutsideVehicle = ISVehicleMenu.FillMenuOutsideVehicle
end

function ISVehicleMenu.FillMenuOutsideVehicle(player, context, vehicle, test)
    PV.oFillMenuOutsideVehicle(player, context, vehicle, test)
    PV_addVehicleOptions(getSpecificPlayer(player), context, vehicle)
end

-- ============================================================
-- WORLD CONTEXT MENU (My Vehicles + Admin Panel + Player quick-allow)
-- ============================================================
function PV.OnPreFillWorldObjectContextMenu(player, context, worldObjects, test)
    local playerObj = getSpecificPlayer(player)
    local level     = string.lower(playerObj:getAccessLevel() or "none")
    local isAdmin   = (level == "admin" or level == "moderator")

    PV_addContextOption(context, getText("IGUI_PV_ContextMenu_MyVehicles"), function() PV.UI.OpenUserManager() end)

    if isAdmin then
        PV_addContextOption(context, getText("IGUI_PV_ContextMenu_AdminPanel"), function() PV.UI.OpenAdminManager() end)
    end

    -- ---- Quick-allow submenu when right-clicking another player ----
    -- Find IsoPlayer targets (other than self) in worldObjects
    -- worldObjects is a Lua table in B42 (not a Java ArrayList)
    local targetPlayer = nil
    for _, obj in ipairs(worldObjects) do
        if obj and instanceof(obj, "IsoPlayer") then
            if obj:getUsername() ~= playerObj:getUsername() then
                targetPlayer = obj:getUsername()
                break
            end
        end
    end

    if not targetPlayer then return end

    -- Check if local player owns any vehicles
    local username = playerObj:getUsername()
    local pData    = PV.dbByPlayerID and PV.dbByPlayerID[username]
    if not pData then return end

    -- Collect owned sqlids
    local ownedSqlids = {}
    for sqlid, v in pairs(pData) do
        if sqlid ~= "LastKnownLogonTime" and sqlid ~= "LastKnownLogoffTime" and v then
            table.insert(ownedSqlids, sqlid)
        end
    end
    if #ownedSqlids == 0 then return end

    -- Build submenu "ProtectVehicle: [target] > [Veículo] > [ação]"
    local pvOption = context:addOption("ProtectVehicle: " .. targetPlayer, nil, nil)
    local subMenu  = ISContextMenu:getNew(context)
    context:addSubMenu(pvOption, subMenu)

    local function sendQuickAllow(sqlid, flags)
        -- Ensure player is in AllowList
        sendClientCommand(playerObj, "ProtectVehicle", "addToAllowList",
            { sqlid = sqlid, targetPlayer = targetPlayer })
        -- Apply the specific flags
        sendClientCommand(playerObj, "ProtectVehicle", "updatePlayerFlags",
            { sqlid = sqlid, targetPlayer = targetPlayer, flags = flags })
    end

    local function allTrueFlags()
        local t = {}
        for k, _ in pairs(PV.DEFAULT_FLAGS or {}) do t[k] = true end
        return t
    end

    -- For each owned vehicle: vehicle name → sub-submenu with actions
    for _, sqlid in ipairs(ownedSqlids) do
        local vData    = PV.dbByVehicleSQLID and PV.dbByVehicleSQLID[sqlid]
        local rawModel = vData and vData.CarModel or tostring(sqlid)
        local carName  = rawModel
        local idx = string.find(rawModel, "%.")
        if idx then
            carName = getTextOrNull("IGUI_VehicleName" .. string.sub(rawModel, idx+1)) or rawModel
        end

        local vOpt    = subMenu:addOption(carName, nil, nil)
        local vSubMenu = ISContextMenu:getNew(subMenu)
        subMenu:addSubMenu(vOpt, vSubMenu)

        local sid = sqlid -- capture for closures
        -- FIX #5: addOption(text, target, onSelect) — target não pode ser nil em B42
        -- Passamos a função como target E como onSelect (compatibilidade com variações da API)
        local function mkOpt(txt, flags)
            local fn = function() sendQuickAllow(sid, flags) end
            vSubMenu:addOption(txt, fn, fn)
        end
        mkOpt(getText("IGUI_PV_CtxAllow_Drive"),      { AllowDrive = true })
        mkOpt(getText("IGUI_PV_CtxAllow_Passenger"),  { AllowPassenger = true })
        mkOpt(getText("IGUI_PV_CtxAllow_Containers"), { AllowContainersAccess = true })
        mkOpt(getText("IGUI_PV_CtxAllow_All"),        allTrueFlags())
    end
end

-- ============================================================
-- GLOBAL SYNC HELPERS
-- ============================================================
function PV.OnReceiveGlobalModData(key, modData)
    if key == "PVByVehicleSQLID" then
        PV.dbByVehicleSQLID = modData
        -- Refresh panels if open with fresh DB
        if PV.UI.AdminInstance and PV.UI.AdminInstance:isVisible() then
            PV.UI.AdminInstance:initList()
            PV.UI.AdminInstance:onSelectionChange()
        end
        if PV.UI.UserInstance and PV.UI.UserInstance:isVisible() then
            PV.UI.UserInstance:refreshList()
        end
    end
    if key == "PVByPlayerID" then
        PV.dbByPlayerID = modData
        if PV.UI.UserInstance and PV.UI.UserInstance:isVisible() then
            PV.UI.UserInstance:refreshList()
        end
    end
end

Events.OnTick.Add(PV.AfterGameStart)
Events.OnPreFillWorldObjectContextMenu.Add(PV.OnPreFillWorldObjectContextMenu)
Events.OnReceiveGlobalModData.Add(PV.OnReceiveGlobalModData)

-- ============================================================
-- COORD SYNC: Entrada e saída de veículo
--
-- B42 NÃO tem Events.OnCharacterGetInVehicle/Out.
--
-- Entrada: override de ISEnterVehicle:perform() — roda no
--   cliente ao fim da timed action, veículo garantidamente válido.
--
-- Saída: watcher leve via OnTick — compara veículo atual com
--   o do tick anterior; quando muda de "dentro" para "fora"
--   dispara o sync. Custo mínimo: apenas 2 comparações por tick.
-- ============================================================

-- ENTRADA: override ISEnterVehicle:perform()
if ISEnterVehicle then
    local _oPVEnterPerform = ISEnterVehicle.perform
    function ISEnterVehicle:perform()
        _oPVEnterPerform(self)
        -- Dispara sync após entrar no veículo
        local veh = self.vehicle
        if not veh or not self.character then return end
        if self.character ~= getPlayer() then return end
        if not PV.dbByVehicleSQLID then return end
        local sqlid = PV.getVehicleID and PV.getVehicleID(veh)
        if sqlid and PV.dbByVehicleSQLID[sqlid] then
            sendClientCommand(self.character, "ProtectVehicle", "syncCoord", { vehicleId = veh:getId() })
        end
    end
end

-- SAÍDA: watcher via OnTick (única forma confiável em B42)
local _pvLastVehicle = nil

local function PV_WatchVehicleExit()
    local player = getPlayer()
    if not player then return end
    local curVeh = player:getVehicle()
    -- Detecta transição: estava dentro → agora fora
    if _pvLastVehicle and not curVeh then
        if PV.dbByVehicleSQLID then
            local sqlid = PV.getVehicleID and PV.getVehicleID(_pvLastVehicle)
            if sqlid and PV.dbByVehicleSQLID[sqlid] then
                sendClientCommand(player, "ProtectVehicle", "syncCoord", { vehicleId = _pvLastVehicle:getId() })
            end
        end
    end
    _pvLastVehicle = curVeh
end

Events.OnTick.Add(PV_WatchVehicleExit)
