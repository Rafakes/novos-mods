--[[
    ProtectVehicle - PV_AdminManagerMain.lua
    Admin UI for global vehicle management.
    Uses ISCollapsableWindow (B42 pattern from AVCS4213).
    B42.14.x
    
    FIXED:
    - Coordenadas agora aparecem corretamente (loc → location)
    - "Claimed On" agora aparece corretamente (date → claimedDate)
    - Botão "Go To" alterado para "Teleport"
    - Botão "Locate" alterado para "Refresh Loc"
    - Unclaim agora atualiza UI corretamente após remoção
--]]

if not isClient() and isServer() then return end

require "UI/PV_UIShared"

PV = PV or {}
PV.UI = PV.UI or {}

local FONT_HGT_SMALL = getTextManager():getFontHeight(UIFont.NewSmall)
local PAD_TOP = FONT_HGT_SMALL + 1

local function PV_getOwner(list)
    return list.pvOwner
        or list.joypadParent
        or (list.parent and list.parent.parent)
        or list.parent
end


PV.UI.AdminManagerMain = ISCollapsableWindow:derive("PV.UI.AdminManagerMain")

-- ============================================================
-- Custom list mouse down
-- ============================================================
function PV.UI.AdminManagerMain:listOnMouseDown(x, y)
    if #self.items == 0 then return end
    local row = self:rowAt(x, y)
    if row > #self.items then row = #self.items end
    if row < 1 then return end
    if row == self.selected then return end
    getSoundManager():playUISound("UISelectListItem")
    self.selected = row
    if self.onmousedown then
        self.onmousedown(self.target, self.items[self.selected].item)
    end

    local owner = PV_getOwner(self)
    if owner and owner.onSelectionChange then
        owner:onSelectionChange()
    end
end

-- ============================================================
-- Selection change
-- ============================================================
function PV.UI.AdminManagerMain:onSelectionChange()
    -- Guard: buttons may not exist yet if createChildren hasn't completed
    if not self.btnLocate or not self.btnTpToVehicle or not self.btnUnclaim
    or not self.btnPermissions or not self.btnRebuild then return end

    local hasSelection = (#self.listData.items > 0 and self.listData.selected > 0
                          and self.listData.selected <= #self.listData.items)
    self.btnLocate:setEnable(hasSelection)
    self.btnTpToVehicle:setEnable(hasSelection)
    self.btnUnclaim:setEnable(hasSelection)
    self.btnPermissions:setEnable(hasSelection)
    self.btnRebuild:setEnable(true)

    if self.subPanel ~= nil then
        self.subPanel:close()
        self.subPanel:removeFromUIManager()
        self.subPanel = nil
    end
    if self.modDialog ~= nil then
        self.modDialog:close()
        self.modDialog:removeFromUIManager()
        self.modDialog = nil
    end
end

-- ============================================================
-- Custom row renderer
-- ============================================================
function PV.UI.AdminManagerMain:drawRow(y, item, alt)
    if y + self:getYScroll() + self.itemheight < 0 or
       y + self:getYScroll() >= self.height then
        return y + self.itemheight
    end

    local c = (PV.UI.Theme and PV.UI.Theme.colors) or {}
    local h = self.itemheight
    local w = self:getWidth()

    local isSel = (self.selected == item.index)
    local isHover = (self.mouseoverselected == item.index) and not isSel

    local bg = c.listBg or {r=0.08, g=0.08, b=0.10, a=1}
    if isSel and c.listSelected then bg = c.listSelected
    elseif isHover and c.listHover then bg = c.listHover
    elseif alt and c.listAltBg then bg = c.listAltBg end

    self:drawRect(0, y, w, h, bg.a or 1, bg.r, bg.g, bg.b)
    -- subtle row divider
    if c.divider then
        self:drawRect(0, y + h - 1, w, 1, 0.45, c.divider.r, c.divider.g, c.divider.b)
    end

    local a = 1
    local xOff  = 8
    local cols  = self.columns or {}
    local function colX(i)
        local col = cols[i]
        if type(col) == "table" and col.size then
            return col.size
        end
        return w
    end
    local function colRange(i)
        local s = colX(i)
        local e = colX(i+1)
        if e < s then e = s end
        return s, e
    end
    local clipY  = math.max(0, y + self:getYScroll())
    local clipY2 = math.min(self.height, y + self:getYScroll() + h)

    -- Owner
    local c0s, c0e = colRange(1)
    self.javaObject:setStencilRect(c0s, clipY, c0e - c0s, clipY2 - clipY)
    self:drawText(item.item.ownerID or "", c0s + xOff, y + 3, 1, 1, 1, a, self.font)
    self:clearStencilRect()

    -- SQLID
    local c1s, c1e = colRange(2)
    self.javaObject:setStencilRect(c1s, clipY, c1e - c1s, clipY2 - clipY)
    self:drawText(tostring(item.item.sqlid or ""), c1s + xOff, y + 3, 1, 1, 1, a, self.font)
    self:clearStencilRect()

    -- Car model
    local c2s, c2e = colRange(3)
    self.javaObject:setStencilRect(c2s, clipY, c2e - c2s, clipY2 - clipY)
    self:drawText(item.item.carName or "", c2s + xOff, y + 3, 1, 1, 1, a, self.font)
    self:clearStencilRect()

    -- Location (FIXED: location em vez de loc)
    local c3s, c3e = colRange(4)
    self.javaObject:setStencilRect(c3s, clipY, c3e - c3s, clipY2 - clipY)
    self:drawText(item.item.location or "", c3s + xOff, y + 3, 1, 1, 1, a, self.font)
    self:clearStencilRect()

    -- Claim date (FIXED: claimedDate em vez de date)
    local c4s, c4e = colRange(5)
    self.javaObject:setStencilRect(c4s, clipY, c4e - c4s, clipY2 - clipY)
    self:drawText(item.item.claimedDate or "", c4s + xOff, y + 3, 1, 1, 1, a, self.font)
    self:clearStencilRect()

    -- Expiry
    local c5s, c5e = colRange(6)
    self.javaObject:setStencilRect(c5s, clipY, c5e - c5s, clipY2 - clipY)
    self:drawText(item.item.expiry or "", c5s + xOff, y + 3, 1, 1, 1, a, self.font)
    self:clearStencilRect()

    return y + h
end

function PV.UI.AdminManagerMain:listDrawText(str, x, y, r, g, b, a, font)
    if self.javaObject ~= nil then
        self.javaObject:DrawText(font or UIFont.NewSmall, tostring(str), x, y, r, g, b, a)
    end
end

-- ============================================================
-- Filter
-- FIX: Em B42 o ISTextEntryBox.onTextChange é chamado como
--   onTextChange(widgetSelf)  — não passa o 'owner/target'.
--   Por isso usamos closures que capturam 'panel' (AdminManagerMain).
-- ============================================================
local function PV_buildFilterCallback(panel)
    return function(_widget)
        if not panel or not panel.textFilterOwner or not panel.textFilterCar then return end
        local ok1, t1 = pcall(function() return panel.textFilterOwner:getInternalText() end)
        local ok2, t2 = pcall(function() return panel.textFilterCar:getInternalText() end)
        local filterOwner = string.lower((ok1 and t1) or "")
        local filterCar   = string.lower((ok2 and t2) or "")

        panel.listData:clear()
        for _, v in ipairs(panel.varData or {}) do
            local matchOwner = (filterOwner == "") or string.find(string.lower(v.ownerID or ""), filterOwner, 1, true)
            local matchCar   = (filterCar   == "") or string.find(string.lower(v.carName or ""), filterCar,   1, true)
            if matchOwner and matchCar then
                panel.listData:addItem(v.ownerID, v)
            end
        end
        panel:onSelectionChange()
    end
end

-- ============================================================
-- Populate list from DB
-- ============================================================
function PV.UI.AdminManagerMain:initList()
    self.varData = {}
    self.listData:clear()
    if not PV.dbByVehicleSQLID then return end

    local timeoutHours = (SandboxVars.ProtectVehicle and SandboxVars.ProtectVehicle.ClaimTimeoutHours) or 0
    local now          = getTimestamp and getTimestamp() or os.time()

    local function calcExpiry(ownerID)
        if timeoutHours <= 0 then
            return getText("IGUI_PV_Admin_Col_Expiry_Never"), false
        end
        local pData   = PV.dbByPlayerID and PV.dbByPlayerID[ownerID]
        local logoff  = pData and pData.LastKnownLogoffTime or nil
        if not logoff then
            return getText("IGUI_PV_Admin_Col_Expiry_Never"), false
        end
        local isOnline = (getPlayerByUsername and getPlayerByUsername(ownerID) ~= nil) or false
        if isOnline then
            local remaining = math.max(0, (logoff + timeoutHours * 3600) - now)
            local h = math.floor(remaining / 3600)
            local m = math.floor((remaining % 3600) / 60)
            return string.format(getText("IGUI_PV_Admin_Col_Expiry_Online"), h, m), true
        end
        local expireAt  = logoff + timeoutHours * 3600
        local remaining = expireAt - now
        if remaining <= 0 then
            return getText("IGUI_PV_Admin_Col_Expiry_Expired"), false
        end
        local h = math.floor(remaining / 3600)
        local m = math.floor((remaining % 3600) / 60)
        return string.format(getText("IGUI_PV_Admin_Col_Expiry_In"), h, m), false
    end

    local temp = {}
    for sqlid, data in pairs(PV.dbByVehicleSQLID) do
        local rawModel = data.CarModel or ""
    local carName  = PV.getVehicleDisplayNameFromModel(rawModel)
        local loc = ""
        if data.LastLocationX and data.LastLocationY then
            loc = tostring(data.LastLocationX) .. ", " .. tostring(data.LastLocationY)
        end
        local claimedDate = data.ClaimDateTime and os.date("%d-%b-%y %H:%M", data.ClaimDateTime) or ""
        local expiry, expiryOnline = calcExpiry(data.OwnerPlayerID or "")
        table.insert(temp, {
            sqlid         = sqlid,
            ownerID       = data.OwnerPlayerID or "?",
            carName       = carName,
            location      = loc,  -- FIXED: Usando 'location' ao invés de 'loc'
            claimedDate   = claimedDate,  -- FIXED: Usando 'claimedDate' ao invés de 'date'
            expiry        = expiry,
            expiryOnline  = expiryOnline,
        })
    end

    table.sort(temp, function(a, b)
        if a.ownerID == b.ownerID then return (a.carName or "") < (b.carName or "") end
        return (a.ownerID or "") < (b.ownerID or "")
    end)

    self.varData = temp
    for _, v in ipairs(temp) do
        self.listData:addItem(v.ownerID, v)
    end
end

-- ============================================================
-- Button handler
-- ============================================================
function PV.UI.AdminManagerMain:btnOnClick(btn)
    if self.listData.selected < 1 or self.listData.selected > #self.listData.items then return end
    local entry = self.listData.items[self.listData.selected].item
    if not entry then return end

    if btn.internal == "btnLocate" then
        sendClientCommand(getPlayer(), "ProtectVehicle", "adminLocate", { sqlid = entry.sqlid })

    elseif btn.internal == "btnTpToVehicle" then
        sendClientCommand(getPlayer(), "ProtectVehicle", "adminTpToVehicle", { sqlid = entry.sqlid })

    elseif btn.internal == "btnUnclaim" then
        if self.modDialog ~= nil then
            self.modDialog:close(); self.modDialog:removeFromUIManager(); self.modDialog = nil
        end
        local w, h = 300, 110
        self.modDialog = ISModalDialog:new(
            getCore():getScreenWidth() / 2 - w / 2, getCore():getScreenHeight() / 2 - h / 2,
            w, h, getText("UI_PV_Admin_ConfirmUnclaim", entry.ownerID),
            true, self, PV.UI.AdminManagerMain.onConfirmUnclaim,
            getPlayer():getPlayerNum(), nil)
        self.modDialog:initialise()
        self.modDialog:addToUIManager()

    elseif btn.internal == "btnPermissions" then
        if self.subPanel ~= nil then
            self.subPanel:close(); self.subPanel:removeFromUIManager(); self.subPanel = nil
        end
        self.subPanel = PV.UI.OpenPermissionPanel(entry.sqlid, nil)

    elseif btn.internal == "btnRebuild" then
        sendClientCommand(getPlayer(), "ProtectVehicle", "adminRebuildDB", {})
        getPlayer():setHaloNote(getText("IGUI_PV_Admin_RebuildSent"), 0.5, 1, 0.5, 300)
    end
end

function PV.UI.AdminManagerMain:onConfirmUnclaim(btn)
    if btn.internal == "NO" then return end
    if self.listData.selected < 1 then return end
    local entry = self.listData.items[self.listData.selected].item
    if not entry then return end
    
    -- FIXED: Enviar comando unclaim
    sendClientCommand(getPlayer(), "ProtectVehicle", "unclaim", { sqlid = entry.sqlid })
    
    -- FIXED: Aguardar um frame para garantir que o servidor processa antes de atualizar UI
    -- O servidor vai enviar o comando "removeVehicle" que vai limpar o DB e atualizar a UI
    -- Mas precisamos limpar a seleção local imediatamente para evitar clicks duplicados
    self.listData.selected = 0
    self:onSelectionChange()
end

-- ============================================================
-- initialise / createChildren
-- ============================================================
function PV.UI.AdminManagerMain:initialise()
    ISCollapsableWindow.initialise(self)
end

function PV.UI.AdminManagerMain:createChildren()
    ISCollapsableWindow.createChildren(self)

    local tm    = getTextManager()
    local theme = PV.UI.Theme
    local c     = theme.colors
    local m     = theme.metrics

    local PAD = m.pad
    local GAP = m.gap

    local contentY = PAD_TOP + PAD
    local contentH = self.height - contentY - PAD

    -- Layout sizing (adaptive so buttons never get clipped)
    local btnFont   = UIFont.NewSmall
    local filterFont= UIFont.NewMedium
    local filterH   = tm:getFontHeight(filterFont) + 4
    local gapY      = math.floor(8 * m.scale)
    local btnH      = tm:getFontHeight(btnFont) + math.floor(12 * m.scale)

    -- CardPanel inner height = controlsH - (headerH + pad*2)
    local minControlsH = (filterH + gapY + btnH) + m.headerH + (m.pad * 2) + 2
    local controlsH = math.max(math.floor(132 * m.scale), minControlsH)

    local minListH  = math.floor(220 * m.scale) -- list scrolls; allow smaller on low-res/UI scale
    local listCardH = contentH - controlsH - GAP

    if listCardH < minListH then
        -- Keep controls readable; shrink the list instead.
        controlsH = math.max(minControlsH, contentH - minListH - GAP)
        listCardH = contentH - controlsH - GAP
    end

    -- Final clamp (never exceed available contentH)
    local overflow = (listCardH + controlsH + GAP) - contentH
    if overflow > 0 then
        listCardH = math.max(math.floor(100 * m.scale), listCardH - overflow)
    end

    -- ========================================================
    -- LIST CARD
    -- ========================================================
    self.cardList = PV.UI.CardPanel:new(PAD, contentY, self.width - PAD * 2, listCardH, getText("UI_PV_Admin_Section_List"))
    self.cardList:initialise(); self.cardList:instantiate()
    self:addChild(self.cardList)

    local colHeaderH = FONT_HGT_SMALL + 6
    local lx, ly, lw, lh = self.cardList:getInnerRect()

    -- Place list lower so the column header row (drawn ABOVE the list) remains inside the card.
    local listY = ly + colHeaderH + 2
    local listH = lh - colHeaderH - 2

    self.listData = ISScrollingListBox:new(lx, listY, lw, listH)
    self.listData:initialise(); self.listData:instantiate()
    self.listData.joypadParent = self
    self.listData.doDrawItem   = self.drawRow
    self.listData.onMouseDown  = self.listOnMouseDown
    self.listData.drawText     = self.listDrawText
    self.listData.drawBorder   = false
    self.listData:setFont(UIFont.NewSmall, 4)
    self.listData.itemheight   = tm:getFontHeight(UIFont.NewSmall) + 4

    local w = lw
    self.listData:addColumn(getText("IGUI_PV_Admin_Col_Owner"),  0)
    self.listData:addColumn(getText("IGUI_PV_Admin_Col_ID"),     math.floor(w * 0.20))
    self.listData:addColumn(getText("IGUI_PV_Admin_Col_Car"),    math.floor(w * 0.33))
    self.listData:addColumn(getText("IGUI_PV_Admin_Col_Loc"),    math.floor(w * 0.55))
    self.listData:addColumn(getText("IGUI_PV_Admin_Col_Date"),   math.floor(w * 0.70))
    self.listData:addColumn(getText("IGUI_PV_Admin_Col_Expiry"), math.floor(w * 0.84))

    PV.UI.ApplyListStyle(self.listData)
    self.listData.pvOwner = self
    self.cardList:addChild(self.listData)

    -- ========================================================
    -- CONTROLS CARD (filters + buttons)
    -- ========================================================
    local controlsY = contentY + listCardH + GAP
    self.cardControls = PV.UI.CardPanel:new(PAD, controlsY, self.width - PAD * 2, controlsH, getText("UI_PV_Admin_Section_Controls"))
    self.cardControls:initialise(); self.cardControls:instantiate()
    self:addChild(self.cardControls)

    local cx, cy, cw, ch = self.cardControls:getInnerRect()
    -- Uses filterH/btnH/btnFont from layout sizing above

    -- Filter row
    local lblOwnerW = tm:MeasureStringX(UIFont.NewSmall, getText("IGUI_PV_Admin_Filter_Owner") .. " ") + 4
    local lblCarW   = tm:MeasureStringX(UIFont.NewSmall, getText("IGUI_PV_Admin_Filter_Car")   .. " ") + 4
    local halfW     = math.floor(cw / 2)
    local box1W     = halfW - lblOwnerW - 2
    local box2W     = cw - halfW - lblCarW - 2

    local lblOwner = ISLabel:new(cx, cy + 2, filterH, getText("IGUI_PV_Admin_Filter_Owner"), c.textMuted.r, c.textMuted.g, c.textMuted.b, 1, UIFont.NewSmall, true)
    lblOwner:initialise(); lblOwner:instantiate(); self.cardControls:addChild(lblOwner)

    self.textFilterOwner = ISTextEntryBox:new("", cx + lblOwnerW, cy, box1W, filterH)
    self.textFilterOwner.font = UIFont.NewMedium
    self.textFilterOwner:initialise(); self.textFilterOwner:instantiate()
    self.textFilterOwner.onTextChange = PV_buildFilterCallback(self)
    self.textFilterOwner:setClearButton(true)
    self.cardControls:addChild(self.textFilterOwner)

    local lbl2X = cx + halfW
    local lblCar = ISLabel:new(lbl2X, cy + 2, filterH, getText("IGUI_PV_Admin_Filter_Car"), c.textMuted.r, c.textMuted.g, c.textMuted.b, 1, UIFont.NewSmall, true)
    lblCar:initialise(); lblCar:instantiate(); self.cardControls:addChild(lblCar)

    self.textFilterCar = ISTextEntryBox:new("", lbl2X + lblCarW, cy, box2W, filterH)
    self.textFilterCar.font = UIFont.NewMedium
    self.textFilterCar:initialise(); self.textFilterCar:instantiate()
    self.textFilterCar.onTextChange = PV_buildFilterCallback(self)
    self.textFilterCar:setClearButton(true)
    self.cardControls:addChild(self.textFilterCar)

    -- Buttons row
    local btnY = cy + filterH + gapY
    local PAD_BTN = math.floor(8 * m.scale)
    local nBtns = 5
    local usable = cw - (nBtns - 1) * PAD_BTN
    local baseW  = math.floor(usable / nBtns)
    local extra  = usable - (baseW * nBtns)

    local bx = cx
    local btnIndex = 1
    local function nextW()
        local w = baseW
        if btnIndex == nBtns then w = baseW + extra end
        btnIndex = btnIndex + 1
        return w
    end

    local function addBtn(label, internal, variant)
        local w = nextW()
        local b = ISButton:new(bx, btnY, w, btnH, label, self, self.btnOnClick)
        b.internal = internal
        b.font = btnFont
        b:initialise(); b:instantiate()
        PV.UI.ApplyButtonStyle(b, variant)
        b:setEnable(false)
        self.cardControls:addChild(b)
        bx = bx + w + PAD_BTN
        return b
    end

    -- FIXED: Textos alterados conforme solicitado
    self.btnLocate      = addBtn("Refresh Loc",  "btnLocate",      "primary")  -- Alterado de "Locate"
    self.btnTpToVehicle = addBtn("Teleport", "btnTpToVehicle", "primary")  -- Alterado de "Go To"
    self.btnUnclaim     = addBtn(getText("IGUI_PV_Admin_ForceUnclaim"),      "btnUnclaim",     "danger")
    self.btnPermissions = addBtn(getText("IGUI_PV_Admin_Permissions"),       "btnPermissions", "primary")
    self.btnRebuild     = addBtn(getText("IGUI_PV_Admin_Rebuild"),           "btnRebuild",     "success")
    self.btnRebuild:setEnable(true)

    self:initList()
    self:onSelectionChange()
end


function PV.UI.AdminManagerMain:close()
    ISCollapsableWindow.close(self)
    if self.subPanel  ~= nil then self.subPanel:close();  self.subPanel:removeFromUIManager();  self.subPanel  = nil end
    if self.modDialog ~= nil then self.modDialog:close(); self.modDialog:removeFromUIManager(); self.modDialog = nil end
    if PV.UI.AdminInstance then PV.UI.AdminInstance = nil end
    self:removeFromUIManager()
end

function PV.UI.AdminManagerMain:prerender() ISCollapsableWindow.prerender(self) end
function PV.UI.AdminManagerMain:render()    ISCollapsableWindow.render(self)    end

-- ============================================================
-- Constructor
-- ============================================================
function PV.UI.AdminManagerMain:new(x, y, width, height)
    local o = ISCollapsableWindow:new(x, y, width, height)
    setmetatable(o, self)
    self.__index      = self
    o.showBackground  = true
    local c = (PV.UI.Theme and PV.UI.Theme.colors) or {}
    o.backgroundColor = c.windowBg or {r=0.08, g=0.08, b=0.10, a=0.97}
    o.showBorder      = true
    o.borderColor     = c.windowBorder or {r=0.55, g=0.15, b=0.15, a=1}
    o.title           = getText("IGUI_PV_Admin_Title")
    o.width           = width
    o.height          = height
    o.visibleTarget   = o
    o.moveWithMouse   = true
    o.pin             = true
    o.varData         = {}
    o.subPanel        = nil
    o.modDialog       = nil
    o:setResizable(false)
    o:setDrawFrame(true)
    return o
end

function PV.UI.OpenAdminManager()
    if PV.UI.AdminInstance ~= nil then PV.UI.AdminInstance:close() end
    local screenW = getCore():getScreenWidth()
    local screenH = getCore():getScreenHeight()

    local width  = math.min(1100, screenW - 40)
    local height = math.min(700, screenH - 60)
    if height < 500 then height = math.max(480, screenH - 40) end

    local x = screenW / 2 - width  / 2
    local y = math.max(20, screenH / 2 - height / 2)
    PV.UI.AdminInstance = PV.UI.AdminManagerMain:new(x, y, width, height)
    PV.UI.AdminInstance:initialise()
    PV.UI.AdminInstance:addToUIManager()
    PV.UI.AdminInstance:setVisible(true)
end
