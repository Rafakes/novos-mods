--[[
    ProtectVehicle - PV_Shared.lua
    Shared functions (client + server).
    Compatible with AVCS save data: uses same ModData keys.
    B42.14.0 only.
--]]

PV = PV or {}
PV.UI = PV.UI or {}

-- ============================================================
-- DB references (set by server on init, by client on receive)
-- ============================================================
-- PVByVehicleSQLID[sqlid] = { OwnerPlayerID, ClaimDateTime, CarModel,
--   LastLocationX, LastLocationY, LastLocationZ, LastLocationUpdateDateTime,
--   PublicFlags={...}, AllowList={...} }
-- PVByPlayerID[username] = { LastKnownLogonTime, LastKnownLogoffTime, [sqlid]=true, ... }
PV.dbByVehicleSQLID = nil
PV.dbByPlayerID     = nil

-- ============================================================
-- TrunkParts helper
-- ============================================================
function PV.matchTrunkPart(partId)
    if type(partId) ~= "string" or #partId == 0 then return false end
    local cfg = SandboxVars.ProtectVehicle and SandboxVars.ProtectVehicle.TrunkParts or "TrunkDoor;DoorRear"
    for s in string.gmatch(cfg, "([^;]+)") do
        if string.lower(s:match("^%s*(.-)%s*$")) == string.lower(partId) then
            return true
        end
    end
    return false
end

-- ============================================================
-- Vehicle display name helper
-- ============================================================
function PV.getVehicleDisplayNameFromModel(rawModel)
    if rawModel == nil then return "?" end
    rawModel = tostring(rawModel)

    local suffix = rawModel
    local dot = string.find(rawModel, "%.")
    if dot then
        suffix = string.sub(rawModel, dot + 1)
    end

    local key = "IGUI_VehicleName" .. suffix
    local t = getTextOrNull and getTextOrNull(key) or nil
    if t then return t end

    local nice = suffix
    nice = nice:gsub("_", " ")
    nice = nice:gsub("(%l)(%u)", "%1 %2")
    return nice ~= "" and nice or rawModel
end

-- ============================================================
-- Vehicle SQLID access
-- Accepts IsoVehicle, number, or string.
-- ============================================================
function PV.getVehicleID(vehicleObj)
    if vehicleObj == nil then return nil end
    if type(vehicleObj) == "number" then return vehicleObj end
    if type(vehicleObj) == "string" then
        return tonumber(vehicleObj) or vehicleObj
    end
    if not vehicleObj.getModData then return nil end
    local modData = vehicleObj:getModData()
    if not modData then return nil end
    local id = modData.SQLID
    if type(id) == "string" then
        local n = tonumber(id)
        if n ~= nil then return n end
    end
    return id
end

function PV.getAccessLevelName(playerObj)
    if not playerObj or not playerObj.getAccessLevel then
        return "none"
    end
    local level = string.lower(playerObj:getAccessLevel() or "none")
    if level == "" then
        level = "none"
    end
    return level
end

function PV.isStaffPlayer(playerObj)
    return PV.getAccessLevelName(playerObj) ~= "none"
end

function PV.normalizeUsername(username)
    if type(username) ~= "string" then return nil end
    username = username:match("^%s*(.-)%s*$")
    if username == "" then return nil end
    return username
end

function PV.getVehicleEntry(vehicleObj)
    local sqlid = PV.getVehicleID(vehicleObj)
    if sqlid == nil then
        return nil, nil, true
    end
    if type(PV.dbByVehicleSQLID) ~= "table" then
        return sqlid, nil, false
    end
    return sqlid, PV.dbByVehicleSQLID[sqlid], true
end

function PV.canManageVehicle(playerObj, vehicleObj)
    local _, entry, dbReady = PV.getVehicleEntry(vehicleObj)
    if not dbReady or not entry or not playerObj then
        return false
    end
    return PV.isStaffPlayer(playerObj) or entry.OwnerPlayerID == playerObj:getUsername()
end

local function PV_isFactionMember(ownerID, username)
    local fac = ownerID and Faction.getPlayerFaction(ownerID) or nil
    if not fac then return false end
    local members = fac:getPlayers()
    for i = 0, members:size() - 1 do
        if members:get(i) == username then
            return true
        end
    end
    return false
end

local function PV_isSafehouseMember(ownerID, username)
    local sh = ownerID and SafeHouse.hasSafehouse(ownerID) or nil
    if not sh then return false end
    local members = sh:getPlayers()
    for i = 0, members:size() - 1 do
        if members:get(i) == username then
            return true
        end
    end
    return false
end

-- ============================================================
-- Permission check
-- Returns:
--   true            = unclaimed (allow all)
--   { permissions=true,  ownerid=..., logoffTime=... } = full access
--   { permissions=false, ownerid=..., logoffTime=... } = no full access
-- Notes:
--   - AllowList no longer grants blanket access.
--   - Known SQLID + DB not ready fails closed until sync arrives.
-- ============================================================
function PV.checkPermission(playerObj, vehicleObj)
    local sqlid, entry, dbReady = PV.getVehicleEntry(vehicleObj)

    if sqlid == nil then return true end

    if not dbReady then
        return { permissions = false, ownerid = nil, logoffTime = 0, dbPending = true, sqlid = sqlid }
    end

    if entry == nil then return true end

    local ownerID = entry.OwnerPlayerID
    local logoffT = (PV.dbByPlayerID and PV.dbByPlayerID[ownerID] and PV.dbByPlayerID[ownerID].LastKnownLogoffTime) or 0

    local function makeResult(perm, extra)
        local result = { permissions = perm, ownerid = ownerID, logoffTime = logoffT, sqlid = sqlid }
        if type(extra) == "table" then
            for k, v in pairs(extra) do
                result[k] = v
            end
        end
        return result
    end

    if not playerObj then
        return makeResult(false)
    end

    local username = playerObj:getUsername()

    if PV.isStaffPlayer(playerObj) then
        return makeResult(true, { scope = "staff" })
    end

    if ownerID == username then
        return makeResult(true, { scope = "owner" })
    end

    if SandboxVars.ProtectVehicle and SandboxVars.ProtectVehicle.AllowFaction and entry.AllowFaction == true then
        if PV_isFactionMember(ownerID, username) then
            return makeResult(true, { scope = "faction" })
        end
    end

    if SandboxVars.ProtectVehicle and SandboxVars.ProtectVehicle.AllowSafehouse and entry.AllowSafehouse == true then
        if PV_isSafehouseMember(ownerID, username) then
            return makeResult(true, { scope = "safehouse" })
        end
    end

    if entry.AllowList then
        for name, _ in pairs(entry.AllowList) do
            if name == username then
                return makeResult(false, { listed = true })
            end
        end
    end

    return makeResult(false)
end

-- Simplify checkPermission result to boolean
function PV.getSimpleBooleanPermission(result)
    if type(result) == "boolean" then
        return result ~= false
    end
    return result and result.permissions == true
end

-- ============================================================
-- RV Interior specific permission check.
-- Owner/admin always yes.
-- Safehouse/faction use the RV-specific toggles.
-- AllowList uses the AllowEnterRV per-player flag.
-- Public AllowEnterRV still works as fallback.
-- ============================================================
function PV.canEnterRV(playerObj, vehicleObj)
    local sqlid, entry, dbReady = PV.getVehicleEntry(vehicleObj)

    if sqlid == nil then return true end
    if not dbReady then return false end
    if entry == nil then return true end
    if not playerObj then return false end

    if PV.isStaffPlayer(playerObj) then return true end

    local username = playerObj:getUsername()
    if entry.OwnerPlayerID == username then return true end

    if SandboxVars.ProtectVehicle and SandboxVars.ProtectVehicle.AllowFaction and entry.AllowFactionRV == true then
        if PV_isFactionMember(entry.OwnerPlayerID, username) then return true end
    end

    if SandboxVars.ProtectVehicle and SandboxVars.ProtectVehicle.AllowSafehouse and entry.AllowSafehouseRV == true then
        if PV_isSafehouseMember(entry.OwnerPlayerID, username) then return true end
    end

    return PV.getPlayerFlag(sqlid, username, "AllowEnterRV")
end

-- Get a public flag for a vehicle.
-- Returns true if unclaimed or flag is set.
-- Returns false while a claimed vehicle is waiting for DB sync.
function PV.getPublicFlag(vehicleObj, flagName)
    local sqlid = PV.getVehicleID(vehicleObj)
    if sqlid == nil then return true end
    if type(PV.dbByVehicleSQLID) ~= "table" then return false end
    local entry = PV.dbByVehicleSQLID[sqlid]
    if entry == nil then return true end
    if entry.PublicFlags == nil then return false end
    return entry.PublicFlags[flagName] == true
end

-- Get a per-player flag for a vehicle.
-- Returns true if the player is owner, or if a per-player override is true.
-- Falls back to the public flag when there is no per-player override.
-- Returns false while a claimed vehicle is waiting for DB sync.
function PV.getPlayerFlag(vehicleObj, username, flagName)
    local sqlid = PV.getVehicleID(vehicleObj)
    if sqlid == nil then return true end
    if type(PV.dbByVehicleSQLID) ~= "table" then return false end
    local entry = PV.dbByVehicleSQLID[sqlid]
    if entry == nil then return true end
    if entry.OwnerPlayerID == username then return true end

    local al = entry.AllowList
    if al and al[username] and type(al[username]) == "table" then
        local pf = al[username][flagName]
        if pf ~= nil then return pf == true end
    end

    if entry.PublicFlags then
        return entry.PublicFlags[flagName] == true
    end
    return false
end

-- ============================================================
-- Max claim check
-- ============================================================
function PV.checkMaxClaim(playerObj)
    if PV.isStaffPlayer(playerObj) then return true end
    if PV.dbByPlayerID == nil then return true end
    local pEntry = PV.dbByPlayerID[playerObj:getUsername()]
    if pEntry == nil then return true end
    local count = 0
    for k, v in pairs(pEntry) do
        if k ~= "LastKnownLogonTime" and k ~= "LastKnownLogoffTime" then
            count = count + 1
        end
    end
    local max = (SandboxVars.ProtectVehicle and SandboxVars.ProtectVehicle.MaxVehicle) or 3
    return count < max
end

-- ============================================================
-- UI font scale helper
-- ============================================================
function PV.getUIFontScale()
    return 1 + (getCore():getOptionFontSize() - 1) / 4
end

-- ============================================================
-- Update vehicle coordinate (server-side, called from hooks)
-- ============================================================
local _coordPersistTimers = {}

function PV.updateVehicleCoordinate(vehicleObj)
    if not (isServer() and not isClient()) then return end
    local sqlid = PV.getVehicleID(vehicleObj)
    if not sqlid then return end
    if PV.dbByVehicleSQLID == nil then return end
    local entry = PV.dbByVehicleSQLID[sqlid]
    if not entry then return end

    local nx = math.floor(vehicleObj:getX())
    local ny = math.floor(vehicleObj:getY())
    local nz = math.floor(vehicleObj:getZ())

    if entry.LastLocationX == nx and entry.LastLocationY == ny then return end

    local now = getTimestamp()
    entry.LastLocationX = nx
    entry.LastLocationY = ny
    entry.LastLocationZ = nz
    entry.LastLocationUpdateDateTime = now

    sendServerCommand("ProtectVehicle", "updateCoord", {
        sqlid = sqlid,
        x = nx, y = ny, z = nz,
        t = now
    })

    local lastPersist = _coordPersistTimers[sqlid] or 0
    if (now - lastPersist) >= 30 then
        ModData.add("PVByVehicleSQLID", PV.dbByVehicleSQLID)
        _coordPersistTimers[sqlid] = now
    end
end
