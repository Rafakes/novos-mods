--[[
    PV_DBCompat_AVCS.lua
    DB compatibility layer: reads existing AVCS save data and migrates
    missing fields with safe defaults. Does NOT destroy old data.
    B42.14.0 only.
--]]

PV = PV or {}

-- ============================================================
-- Migrate a vehicle DB entry: add missing fields with defaults
-- ============================================================
local function migrateVehicleEntry(sqlid, entry)
    -- ============================================================
    -- FIX AVCS COMPAT: AVCS pode salvar o dono com chaves diferentes.
    -- Normalizar para OwnerPlayerID (chave usada pelo PV em toda validação).
    -- Ordem de prioridade: OwnerPlayerID > OwnerID > Owner > nil
    -- ============================================================
    if entry.OwnerPlayerID == nil or entry.OwnerPlayerID == "" then
        local fallback = entry.OwnerID or entry.Owner or entry.owner or nil
        if fallback and fallback ~= "" then
            entry.OwnerPlayerID = fallback
            print("[PV] migrateVehicleEntry: corrigido OwnerPlayerID para '" .. tostring(fallback) .. "' (sqlid=" .. tostring(sqlid) .. ")")
        else
            -- Sem dono identificável: marca como órfão para auditoria
            -- NÃO remove do DB — admin pode corrigir manualmente
            entry.OwnerPlayerID = "__UNKNOWN__"
            print("[PV] migrateVehicleEntry: AVISO - OwnerPlayerID ausente em sqlid=" .. tostring(sqlid) .. ". Marcado como __UNKNOWN__.")
        end
    end

    -- PublicFlags: all false by default (locked vehicle)
    if entry.PublicFlags == nil then
        entry.PublicFlags = {
            AllowDrive           = false,
            AllowPassenger       = false,
            AllowContainersAccess= false,
            AllowSiphonFuel      = false,
            AllowUninstallParts  = false,
            AllowTakeEngineParts = false,
            AllowOpeningDoors    = false,
            AllowOpeningTrunk    = false,
            AllowInflateTires    = false,
            AllowDeflateTires    = false,
            AllowTow             = false,
            AllowScrapVehicle    = false,
            AllowEnterRV         = false,  -- FIX #1: campo novo adicionado na migração
        }
    else
        -- PublicFlags já existe: garantir que o campo novo está presente
        if entry.PublicFlags.AllowEnterRV == nil then
            entry.PublicFlags.AllowEnterRV = false
        end
    end
    -- AllowList: optional, nil is fine
    if entry.AllowList == nil then
        entry.AllowList = {}
    end
    -- Group access toggles (per-vehicle)
    if entry.AllowSafehouse == nil then
        entry.AllowSafehouse = false
    end
    if entry.AllowFaction == nil then
        entry.AllowFaction = false
    end
    -- FIX #1: campos RV granulares — ausentes em saves anteriores
    if entry.AllowSafehouseRV == nil then
        entry.AllowSafehouseRV = false
    end
    if entry.AllowFactionRV == nil then
        entry.AllowFactionRV = false
    end
    -- LastLocationZ: new field
    if entry.LastLocationZ == nil then
        entry.LastLocationZ = 0
    end
    -- PV_Version marker — bump para 3 com os campos RV
    local v = tonumber(entry.PV_Version) or 1
    if v < 3 then v = 3 end
    entry.PV_Version = v
    return entry
end

-- ============================================================
-- Migrate a player DB entry: add missing fields with defaults
-- ============================================================
local function migratePlayerEntry(username, entry)
    -- LastKnownLogoffTime: new field (default to logon time or now)
    if entry.LastKnownLogoffTime == nil then
        entry.LastKnownLogoffTime = entry.LastKnownLogonTime or getTimestamp()
    end
    return entry
end

-- ============================================================
-- Run migration on all existing entries (called once on server init)
-- ============================================================
function PV.migrateDB()
    if PV.dbByVehicleSQLID == nil or PV.dbByPlayerID == nil then return end

    local changed = false

    for sqlid, entry in pairs(PV.dbByVehicleSQLID) do
        local beforeV   = entry.PV_Version
        local beforeSH  = entry.AllowSafehouse
        local beforeF   = entry.AllowFaction
        local beforeSHRV = entry.AllowSafehouseRV
        local beforeFRV  = entry.AllowFactionRV
        local beforeRVFlag = entry.PublicFlags and entry.PublicFlags.AllowEnterRV
        migrateVehicleEntry(sqlid, entry)
        if entry.PV_Version ~= beforeV
        or entry.AllowSafehouse ~= beforeSH
        or entry.AllowFaction ~= beforeF
        or entry.AllowSafehouseRV ~= beforeSHRV
        or entry.AllowFactionRV ~= beforeFRV
        or (entry.PublicFlags and entry.PublicFlags.AllowEnterRV ~= beforeRVFlag)
        then
            changed = true
        end
    end

    for username, entry in pairs(PV.dbByPlayerID) do
        if type(entry) == "table" then
            local before = entry.LastKnownLogoffTime
            migratePlayerEntry(username, entry)
            if entry.LastKnownLogoffTime ~= before then changed = true end
        end
    end

    if changed then
        ModData.add("PVByVehicleSQLID", PV.dbByVehicleSQLID)
        ModData.add("PVByPlayerID", PV.dbByPlayerID)
        print("[PV] DB migration complete.")
    else
        print("[PV] DB already up to date, no migration needed.")
    end
end

-- ============================================================
-- Rebuild DB: repair missing indices without destroying data
-- Uses PVByVehicleSQLID as source of truth (same as AVCS)
-- ============================================================
function PV.rebuildDB()
    if PV.dbByVehicleSQLID == nil then return end
    local newPlayerDB = {}

    for sqlid, entry in pairs(PV.dbByVehicleSQLID) do
        local owner = entry.OwnerPlayerID
        if owner then
            if not newPlayerDB[owner] then
                newPlayerDB[owner] = {}
                -- Preserve logon/logoff times if available
                if PV.dbByPlayerID and PV.dbByPlayerID[owner] then
                    newPlayerDB[owner].LastKnownLogonTime  = PV.dbByPlayerID[owner].LastKnownLogonTime  or getTimestamp()
                    newPlayerDB[owner].LastKnownLogoffTime = PV.dbByPlayerID[owner].LastKnownLogoffTime or getTimestamp()
                else
                    newPlayerDB[owner].LastKnownLogonTime  = getTimestamp()
                    newPlayerDB[owner].LastKnownLogoffTime = getTimestamp()
                end
            end
            newPlayerDB[owner][sqlid] = true
        end
    end

    PV.dbByPlayerID = newPlayerDB
    ModData.add("PVByPlayerID", PV.dbByPlayerID)
    print("[PV] DB rebuild complete.")
end

-- ============================================================
-- Ensure vehicle has a SQLID (generate if missing)
-- Server-side only. Returns the SQLID.
-- ============================================================
function PV.ensureVehicleSQLID(vehicleObj)
    if not (isServer() and not isClient()) then return nil end
    local existing = vehicleObj:getModData().SQLID
    if existing then return existing end

    -- Generate unique ID using timestamp + vehicle runtime id
    local usedIDs = ModData.exists("PV_UsedVehicleIDs") and ModData.get("PV_UsedVehicleIDs") or {}
    local newID
    local attempts = 0
    repeat
        attempts = attempts + 1
        newID = tonumber(tostring(getTimestamp()):gsub("%.", "") .. tostring(vehicleObj:getId()):sub(-4))
        if newID == nil then
            newID = math.floor(getTimestamp() * 1000) + vehicleObj:getId() + attempts
        end
    until not usedIDs[newID] or attempts > 20

    -- Mark as used immediately
    usedIDs[newID] = true
    ModData.add("PV_UsedVehicleIDs", usedIDs)

    -- Persist on vehicle
    vehicleObj:getModData().SQLID = newID

    -- Sync to clients in same cell
    sendServerCommand("ProtectVehicle", "registerVehicleSQLID", {
        vehicleRuntimeId = vehicleObj:getId(),
        sqlid = newID
    })

    return newID
end
