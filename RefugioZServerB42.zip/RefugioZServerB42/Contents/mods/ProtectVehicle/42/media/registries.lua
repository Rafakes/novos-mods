--[[
    ProtectVehicle - registries.lua
    B42.13+ obrigatório: carregado ANTES de scripts/ e de qualquer Lua.
    
    NOTA: Como o item VehicleDocument usa module Base com ItemType = base:normal
    (padrão do jogo), NÃO é necessário registrar um ItemType customizado.
    Este arquivo fica aqui como placeholder caso futuros itens precisem de
    registro (ex: ItemTag, CharacterTrait, etc).
    
    Referência: Migration Guide B42.13 - registries.lua deve existir em media/.
--]]

-- Nenhum registro customizado necessário no momento.
-- O item Base.VehicleDocument usa ItemType = base:normal (já registrado pelo engine).
