-- ============================================================
-- TsT_FactionManager.lua — Gerenciamento de Fama e Facções (Server)
-- Mod: The Survival Triade | Build 42
-- VERSÃO MIGRADA: Elimina TsT_History, usa apenas player ModData
-- ============================================================

if isClient() then return end

TsT = TsT or {}
TsT.FactionManager = {}

-- Versão do sistema de dados (para detectar necessidade de migração)
local DATA_VERSION = 2

-- ------------------------------------------------------------
-- COMPATIBILIDADE / NORMALIZAÇÃO DE IDs
-- ------------------------------------------------------------
TsT.normalizeFactionId = function(id)
    if id == "mercenary" then return "combatants" end
    if id == "outlaw" then return "survivors" end
    if id == "survivor" then return "specialists" end
    return id
end

local function migrateFameTable(fame)
    if not fame then return { combatants=0, survivors=0, specialists=0 } end
    -- migra chaves antigas → novas
    if fame.mercenary and fame.combatants == nil then fame.combatants = fame.mercenary end
    if fame.outlaw and fame.survivors == nil then fame.survivors = fame.outlaw end
    if fame.survivor and fame.specialists == nil then fame.specialists = fame.survivor end
    fame.mercenary = nil
    fame.outlaw = nil
    fame.survivor = nil
    -- garante presença
    fame.combatants = fame.combatants or 0
    fame.survivors = fame.survivors or 0
    fame.specialists = fame.specialists or 0
    return fame
end

local function cloneTable(value)
    if type(value) ~= "table" then
        return value
    end

    local copy = {}
    for k, v in pairs(value) do
        copy[cloneTable(k)] = cloneTable(v)
    end
    return copy
end

local function cloneFameTable(fame)
    local normalized = migrateFameTable(cloneTable(fame))
    return {
        combatants  = normalized.combatants or 0,
        survivors   = normalized.survivors or 0,
        specialists = normalized.specialists or 0,
    }
end

-- ------------------------------------------------------------
-- MIGRAÇÃO ONE-TIME: TsT_History → player:getModData()
-- Chamado uma vez ao conectar, se dados antigos existirem
-- ------------------------------------------------------------
local function migrateFromHistory(player)
    local username = player:getUsername()
    local oldHistory = ModData.get("TsT_History")
    
    -- Se não há histórico antigo, não há nada para migrar
    if not oldHistory or not oldHistory[username] then
        return false
    end
    
    local oldData = oldHistory[username]
    local md = player:getModData()
    
    -- Se já migrou (tem dataVersion >= 2), ignora
    if md.TsT and md.TsT.dataVersion and md.TsT.dataVersion >= DATA_VERSION then
        return false
    end
    
    print("[TsT-Migration] Migrando dados antigos de TsT_History para " .. username)
    
    -- Copia dados antigos para ModData individual
    md.TsT = md.TsT or {}
    md.TsT.faction = oldData.faction
    md.TsT.fame = migrateFameTable(oldData.fame)
    md.TsT.completedMissions = oldData.completedMissions or {}
    md.TsT.money = oldData.money or 0
    md.TsT.dataVersion = DATA_VERSION
    
    -- Preserva dados de missão ativa se existirem
    md.TsT.activeMission = md.TsT.activeMission or nil
    md.TsT.activeMissionData = md.TsT.activeMissionData or {}
    md.TsT.activeDailyMission = md.TsT.activeDailyMission or nil
    md.TsT.activeDailyMissionData = md.TsT.activeDailyMissionData or {}
    
    -- Sync via SyncData (chamado logo após esta função em FactionManager.sync).
    -- Não usamos transmitModData() para evitar sobrescrever ModData de outros mods.

    -- IMPORTANTE: Não apaga do TsT_History ainda (mantém backup por segurança)
    -- Será limpo automaticamente pela função de limpeza periódica
    
    print("[TsT-Migration] Migração concluída para " .. username)
    return true
end

-- ------------------------------------------------------------
-- GARANTIR ESTRUTURA DE DADOS DO JOGADOR
-- Sempre retorna dados válidos, criando se necessário
-- ------------------------------------------------------------
local function ensurePlayerData(player)
    local md = player:getModData()
    md.TsT = md.TsT or {}
    
    -- Garante campos obrigatórios
    md.TsT.dataVersion = md.TsT.dataVersion or DATA_VERSION
    md.TsT.faction = md.TsT.faction or nil
    md.TsT.fame = migrateFameTable(md.TsT.fame)
    md.TsT.completedMissions = md.TsT.completedMissions or {}
    md.TsT.money = md.TsT.money or 0
    md.TsT.activeMission = md.TsT.activeMission or nil
    md.TsT.activeMissionData = md.TsT.activeMissionData or {}
    md.TsT.activeDailyMission = md.TsT.activeDailyMission or nil
    md.TsT.activeDailyMissionData = md.TsT.activeDailyMissionData or {}
    
    return md.TsT
end

-- ------------------------------------------------------------
-- BACKUP GLOBAL — Sobrevive à morte do personagem
-- TsT_PlayerData: keyed por username, persiste no servidor.
-- Restaurado automaticamente ao criar novo personagem.
-- Apagado apenas ao sair voluntariamente da facção.
-- ------------------------------------------------------------
local function saveToGlobalStore(player)
    local data = ensurePlayerData(player)
    if not data.faction then return end  -- sem facção: nada a salvar

    local store = ModData.getOrCreate("TsT_PlayerData")
    store[player:getUsername()] = {
        faction              = data.faction,
        fame                 = cloneFameTable(data.fame),
        money                    = data.money or 0,
        completedMissions        = cloneTable(data.completedMissions or {}),
        activeMission            = data.activeMission,
        activeMissionData        = cloneTable(data.activeMissionData or {}),
        activeDailyMission       = data.activeDailyMission,
        activeDailyMissionData   = cloneTable(data.activeDailyMissionData or {}),
        lastDailyCompletionTime  = data.lastDailyCompletionTime,
    }
end

-- Exposto para MissionManager salvar estado de missão ativa
function TsT.FactionManager.savePlayerData(player)
    saveToGlobalStore(player)
end

local function restoreFromGlobalStore(player)
    local md = player:getModData()
    -- Só restaura se o personagem é novo (sem facção = morreu e recriou)
    if md.TsT and md.TsT.faction ~= nil then return false end

    local store = ModData.getOrCreate("TsT_PlayerData")
    local saved = store[player:getUsername()]
    if not saved or not saved.faction then return false end

    md.TsT = md.TsT or {}
    local d = md.TsT
    d.dataVersion            = DATA_VERSION
    d.faction                = saved.faction
    d.fame                   = cloneFameTable(saved.fame)
    d.money                  = saved.money or 0
    d.completedMissions      = cloneTable(saved.completedMissions or {})
    d.activeMission          = saved.activeMission
    d.activeMissionData      = cloneTable(saved.activeMissionData or {})
    d.activeDailyMission     = saved.activeDailyMission
    d.activeDailyMissionData = cloneTable(saved.activeDailyMissionData or {})
    d.lastDailyCompletionTime = saved.lastDailyCompletionTime

    print("[TsT] Dados restaurados do backup global para " .. player:getUsername())
    return true
end

-- ------------------------------------------------------------
-- RANKING SNAPSHOT
-- Persiste fama de todos os jogadores para consulta offline.
-- Atualizado sempre que a fama muda ou o jogador conecta.
-- ------------------------------------------------------------
local function updateRankingSnapshot(player)
    local data = ensurePlayerData(player)
    if not data.faction then return end

    local rankings = ModData.getOrCreate("TsT_Rankings")
    rankings[player:getUsername()] = {
        faction = data.faction,
        fame    = {
            combatants  = data.fame.combatants  or 0,
            survivors   = data.fame.survivors   or 0,
            specialists = data.fame.specialists or 0,
        },
    }
end

-- ------------------------------------------------------------
-- SINCRONIZAÇÃO — Envia dados ao jogador ao conectar
-- Chamado em OnClientCommand "RequestSync"
-- ------------------------------------------------------------
function TsT.FactionManager.sync(player)
    -- Tenta migrar dados antigos primeiro
    migrateFromHistory(player)

    -- Restaura do backup global se personagem é novo (morte/recriação)
    restoreFromGlobalStore(player)

    -- Garante estrutura válida
    local data = ensurePlayerData(player)

    -- Atualiza snapshot de ranking e backup global ao conectar
    updateRankingSnapshot(player)
    saveToGlobalStore(player)

    -- Envia para o cliente
    sendServerCommand(player, "TsT", "SyncData", {
        faction = data.faction,
        fame = cloneFameTable(data.fame),
        completedMissions = cloneTable(data.completedMissions),
        money = data.money,
        activeDailyMission = data.activeDailyMission,
        activeDailyMissionData = cloneTable(data.activeDailyMissionData),
        activeMission = data.activeMission,
        activeMissionData = cloneTable(data.activeMissionData),
        lastDailyCompletionTime = data.lastDailyCompletionTime,
    })

    print("[TsT] Sincronizado dados para " .. player:getUsername())
end

-- ------------------------------------------------------------
-- ENTRADA NA FACÇÃO
-- ------------------------------------------------------------
function TsT.FactionManager.joinFaction(player, factionId)
    if not TsT.getFactionById(factionId) then
        return false, "Facção inválida: " .. tostring(factionId)
    end
    
    local data = ensurePlayerData(player)
    
    -- Impede mudança de facção (exceto se nil por desync)
    if data.faction ~= nil then
        return false, "Jogador já pertence à facção: " .. data.faction
    end
    
    -- Registra facção
    data.faction = factionId
    updateRankingSnapshot(player)
    saveToGlobalStore(player)
    -- sendServerCommand("FactionJoined") atualiza o cliente; não precisamos de transmitModData().
    print("[TsT] " .. player:getUsername() .. " ingressou na facção: " .. factionId)
    sendServerCommand(player, "TsT", "FactionJoined", { factionId = factionId })
    return true, "ok"
end

-- ------------------------------------------------------------
-- ADICIONAR FAMA
-- ------------------------------------------------------------
function TsT.FactionManager.addFama(player, quantidade)
    local data = ensurePlayerData(player)
    if not data.faction then return 0 end
    
    local factionId = data.faction
    data.fame[factionId] = (data.fame[factionId] or 0) + quantidade
    
    -- NÃO transmite aqui para evitar sobrescrever activeMission
    -- O código que chama addFama deve transmitir depois
    
    local novaFama = data.fame[factionId]
    updateRankingSnapshot(player)
    saveToGlobalStore(player)
    print("[TsT] " .. player:getUsername() .. " ganhou " .. quantidade .. " fama (" .. factionId .. "): " .. novaFama)
    return novaFama
end

-- ------------------------------------------------------------
-- DINHEIRO
-- ------------------------------------------------------------
function TsT.FactionManager.addMoney(player, quantidade)
    local data = ensurePlayerData(player)
    data.money = (data.money or 0) + quantidade
    -- NÃO transmite aqui
end

function TsT.FactionManager.removeMoney(player, quantidade)
    local data = ensurePlayerData(player)
    if (data.money or 0) < quantidade then
        return false
    end
    data.money = data.money - quantidade
    -- NÃO transmite aqui
    return true
end

function TsT.FactionManager.getMoney(player)
    local data = ensurePlayerData(player)
    return data.money or 0
end

function TsT.FactionManager.getFama(player)
    local data = ensurePlayerData(player)
    if not data.faction then return 0, nil end
    return data.fame[data.faction] or 0, data.faction
end

-- ------------------------------------------------------------
-- MISSÃO CONCLUÍDA
-- ------------------------------------------------------------
function TsT.FactionManager.marcarConcluida(player, missionId)
    local data = ensurePlayerData(player)
    data.completedMissions[missionId] = true
    -- NÃO transmite aqui (completarMissao transmite depois)
end

function TsT.FactionManager.jaConcluiu(player, missionId)
    local data = ensurePlayerData(player)
    return data.completedMissions[missionId] == true
end

-- ------------------------------------------------------------
-- ABANDONAR FACÇÃO
-- ------------------------------------------------------------
function TsT.FactionManager.leaveFaction(player)
    local sb = SandboxVars
    if not (sb and sb.TsT_AllowLeaveFaction) then
        return false, "Abandonar facção está desabilitado."
    end
    
    local md = player:getModData()
    md.TsT = {
        dataVersion = DATA_VERSION,
        faction = nil,
        fame = { combatants=0, survivors=0, specialists=0 },
        money = 0,
        activeMission = nil,
        activeMissionData = {},
        activeDailyMission = nil,
        activeDailyMissionData = {},
        completedMissions = {},
    }
    -- Apaga backup global e snapshot de ranking ao sair da facção
    -- (única situação em que os dados são perdidos intencionalmente)
    local username = player:getUsername()
    local store = ModData.getOrCreate("TsT_PlayerData")
    store[username] = nil
    local rankings = ModData.getOrCreate("TsT_Rankings")
    rankings[username] = nil

    -- sendServerCommand("LeaveFactionOk") atualiza o cliente; não precisamos de transmitModData().
    print("[TsT] " .. player:getUsername() .. " abandonou a facção")
    sendServerCommand(player, "TsT", "LeaveFactionOk", {})
    return true, "ok"
end

-- ------------------------------------------------------------
-- LIMPEZA PERIÓDICA: Remove entradas antigas de TsT_History
-- Chamado a cada 1 hora para limpar dados já migrados
-- ------------------------------------------------------------
local function cleanupOldHistory()
    local oldHistory = ModData.get("TsT_History")
    if not oldHistory then return end

    local players = getOnlinePlayers()
    if not players then return end  -- guard: getOnlinePlayers() pode retornar nil em edge cases

    local onlineUsers = {}

    for i = 0, players:size() - 1 do
        local p = players:get(i)
        if p then
            local username = p:getUsername()
            onlineUsers[username] = true
            
            -- Se jogador online tem dados migrados, remove do histórico
            local md = p:getModData()
            if md.TsT and md.TsT.dataVersion and md.TsT.dataVersion >= DATA_VERSION then
                if oldHistory[username] then
                    print("[TsT-Cleanup] Removendo dados antigos de " .. username .. " (já migrado)")
                    oldHistory[username] = nil
                end
            end
        end
    end
end

-- Executa limpeza a cada hora
Events.EveryHours.Add(cleanupOldHistory)

print("[TsT] TsT_FactionManager.lua (FIXED v2) carregado.")
