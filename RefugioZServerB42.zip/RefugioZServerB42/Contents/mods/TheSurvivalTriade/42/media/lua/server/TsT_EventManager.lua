-- ============================================================
-- TsT_EventManager.lua — Eventos Globais (Server) - OTIMIZADO v2
-- Mod: The Survival Triade | Build 42
-- VERSÃO v2: Broadcast incremental + THROTTLING anti-spam
-- ============================================================

if isClient() then return end

TsT = TsT or {}
TsT.EventManager = {}

-- ------------------------------------------------------------
-- DEFINIÇÕES DOS EVENTOS
-- ------------------------------------------------------------
TsT.EventDefinitions = {
    {
        id          = "event_merc_01",
        factionId   = "combatants",
        type        = "KILL",
        title       = "Operação Extermínio Coletivo",
        description = "Os Combatentes precisam limpar a região. Cada kill conta para a meta global!",
        goal        = { kills = 10000 },
        rewards     = { money = 100, fame = 80 },
    },
    {
        id          = "event_surv_01",
        factionId   = "specialists",
        type        = "LOOT",
        title       = "Grande Coleta dos Especialistas",
        description = "A base precisa de suprimentos urgentes. Deposite o que encontrar!",
        goal        = { items = {
            { name="Base.Plank", count=50 },
            { name="Base.Stake", count=10 },
            { name="Base.Log", count=20 },
        }},
        rewards     = { money = 250, fame = 50 },
    },
    {
        id          = "event_outl_01",
        factionId   = "survivors",
        type        = "MIXED",
        title       = "A Grande Fortificação",
        description = "Os Sobreviventes estão expandindo o território!",
        goal        = {
            kills = 6000,
            items = {
                { name="Base.Log", count=30 },
                { name="Base.Plank", count=50 },
            }
        },
        rewards     = { money = 250, fame = 50 },
    },
}

-- ------------------------------------------------------------
-- THROTTLING: Controla frequência de broadcasts
-- Só envia update a cada 5 segundos OU a cada 10 kills
-- ------------------------------------------------------------
local BroadcastThrottle = {
    combatants = { lastBroadcast = 0, pendingKills = 0 },
    survivors = { lastBroadcast = 0, pendingKills = 0 },
    specialists = { lastBroadcast = 0, pendingKills = 0 },
}

local BROADCAST_INTERVAL = 5  -- segundos
local BROADCAST_KILL_THRESHOLD = 10  -- kills

local function shouldBroadcast(factionId, killsDelta)
    local throttle = BroadcastThrottle[factionId]
    if not throttle then return false end
    
    local now = os.time()
    throttle.pendingKills = (throttle.pendingKills or 0) + killsDelta
    
    -- Broadcast se passou tempo suficiente OU acumulou kills suficientes
    if (now - throttle.lastBroadcast >= BROADCAST_INTERVAL) or 
       (throttle.pendingKills >= BROADCAST_KILL_THRESHOLD) then
        throttle.lastBroadcast = now
        throttle.pendingKills = 0
        return true
    end
    
    return false
end

-- ------------------------------------------------------------
-- SANDBOX OPTIONS
-- ------------------------------------------------------------
local function getSandboxCooldownSeconds()
    local sb = SandboxVars
    local hours = (sb and sb.TsT_EventCooldownHours) or 24
    return math.max(1, hours) * 3600
end

local function getSandboxBonusItems()
    local sb = SandboxVars
    local raw = sb and sb.TsT_EventBonusItems
    if not raw or raw == "" then return {} end
    local result = {}
    for entry in raw:gmatch("[^,]+") do
        local itemType, countStr = entry:match("^%s*([^:]+):(%d+)%s*$")
        if not itemType then
            itemType = entry:match("^%s*([^:]+)%s*$")
            countStr = "1"
        end
        if itemType then
            table.insert(result, { type=itemType, count=tonumber(countStr) or 1 })
        end
    end
    return result
end

-- ------------------------------------------------------------
-- PERSISTÊNCIA OTIMIZADA
-- ------------------------------------------------------------
local function getEventData()
    return ModData.getOrCreate("TsT_EventData")
end

local function ensureEventData(factionId)
    local data = getEventData()
    if not data[factionId] then
        local evDef = TsT.EventManager.getEventDef(factionId)
        data[factionId] = {
            currentEventId = evDef and evDef.id or nil,
            progress = { kills=0, items={} },
            completed = false,
            completedAt = nil,
            nextResetAt = nil,
            contributorCount = 0,
            cycleId = 1,
        }
    end
    return data[factionId]
end

function TsT.EventManager.getEventDef(factionId)
    for _, ev in ipairs(TsT.EventDefinitions) do
        if ev.factionId == factionId then return ev end
    end
    return nil
end

function TsT.EventManager.getEventState(factionId)
    return ensureEventData(factionId)
end

local function resetEvento(factionId, completedTimestamp)
    local data = getEventData()
    local evDef = TsT.EventManager.getEventDef(factionId)
    local previous = data[factionId]
    data[factionId] = {
        currentEventId = evDef and evDef.id or nil,
        progress = { kills=0, items={} },
        completed = false,
        completedAt = nil,
        nextResetAt = (completedTimestamp or getTimestamp()) + getSandboxCooldownSeconds(),
        contributorCount = 0,
        cycleId = previous and ((previous.cycleId or 0) + 1) or 1,
    }
    -- Reseta throttle
    if BroadcastThrottle[factionId] then
        BroadcastThrottle[factionId].lastBroadcast = 0
        BroadcastThrottle[factionId].pendingKills = 0
    end
    print("[TsT-Event] Evento resetado: " .. factionId)
end

-- ------------------------------------------------------------
-- CONTRIBUIÇÃO DE JOGADOR
-- ------------------------------------------------------------
local function marcarContribuidor(player)
    local md = player:getModData()
    md.TsT = md.TsT or {}
    md.TsT.eventContrib = md.TsT.eventContrib or {}
    
    local pos = TsT.getModData(player)
    if not pos.faction then return end
    
    local evState = ensureEventData(pos.faction)
    local eventId = evState.currentEventId
    if not eventId then return end
    
    if md.TsT.eventContrib[eventId] ~= evState.cycleId then
        md.TsT.eventContrib[eventId] = evState.cycleId
        evState.contributorCount = (evState.contributorCount or 0) + 1
    end
end

-- ------------------------------------------------------------
-- CONTRIBUIÇÃO DE KILLS (COM THROTTLING)
-- ------------------------------------------------------------
function TsT.EventManager.contribuirKills(player, quantidade)
    local pos = TsT.getModData(player)
    if not pos.faction then return end
    
    local evState = ensureEventData(pos.faction)
    if evState.completed then return end
    
    local evDef = TsT.EventManager.getEventDef(pos.faction)
    if not evDef then return end
    if evDef.type ~= "KILL" and evDef.type ~= "MIXED" then return end
    
    local currentKills = evState.progress.kills or 0
    local goalKills = evDef.goal.kills or 0
    if currentKills >= goalKills then return end
    
    local newTotal = math.min(goalKills, currentKills + quantidade)
    evState.progress.kills = newTotal
    
    marcarContribuidor(player)
    
    -- Broadcast COM THROTTLING (só a cada 5s ou 10 kills)
    if shouldBroadcast(pos.faction, quantidade) then
        broadcastProgressToFaction(pos.faction, "kills", newTotal)
    end
    
    TsT.EventManager.verificarConclusao(pos.faction)
end

-- ------------------------------------------------------------
-- DEPÓSITO DE ITENS
-- ------------------------------------------------------------
function TsT.EventManager.depositarItens(player, depositos)
    local pos = TsT.getModData(player)
    if not pos.faction then
        sendServerCommand(player, "TsT", "EventError", { msg = "Você não pertence a nenhuma facção." })
        return
    end
    
    local evState = ensureEventData(pos.faction)
    if evState.completed then
        sendServerCommand(player, "TsT", "EventError", { msg = "Evento já concluído." })
        return
    end
    
    local evDef = TsT.EventManager.getEventDef(pos.faction)
    if not evDef then return end
    if evDef.type ~= "LOOT" and evDef.type ~= "MIXED" then
        sendServerCommand(player, "TsT", "EventError", { msg = "Este evento não requer itens." })
        return
    end
    
    local inventario = player:getInventory()
    local depositados = {}
    
    for _, dep in ipairs(depositos) do
        local disponivel = TsT.getItemCount(inventario, dep.name)
        local qtd = math.min(dep.count, disponivel)
        if qtd > 0 then
            local itemsToRemove = TsT.getAllItemsOfType(inventario, dep.name, qtd)
            for _, obj in ipairs(itemsToRemove) do
                if obj then
                    local container = obj:getContainer()
                    if container then
                        container:Remove(obj)
                        sendRemoveItemFromContainer(container, obj)
                    else
                        inventario:Remove(obj)
                        sendRemoveItemFromContainer(inventario, obj)
                    end
                end
            end
            evState.progress.items[dep.name] = (evState.progress.items[dep.name] or 0) + #itemsToRemove
            table.insert(depositados, { name=dep.name, count=#itemsToRemove })
        end
    end
    
    if #depositados == 0 then
        sendServerCommand(player, "TsT", "EventError", { msg = "Você não tem os itens necessários." })
        return
    end
    
    marcarContribuidor(player)
    
    sendServerCommand(player, "TsT", "EventDepositOk", {
        depositados = depositados,
        progress = evState.progress,
    })
    
    -- Broadcast de itens (sem throttling pois é ação manual, não spam)
    broadcastProgressToFaction(pos.faction, "items", evState.progress.items)
    
    TsT.EventManager.verificarConclusao(pos.faction)
end

-- ------------------------------------------------------------
-- BROADCAST INCREMENTAL
-- ------------------------------------------------------------
function broadcastProgressToFaction(factionId, progressType, value)
    local players = getOnlinePlayers()
    for i = 0, players:size() - 1 do
        local p = players:get(i)
        if p then
            local pPos = TsT.getModData(p)
            if pPos.faction == factionId then
                sendServerCommand(p, "TsT", "EventProgressUpdate", {
                    type = progressType,
                    value = value,
                })
            end
        end
    end
end

-- ------------------------------------------------------------
-- VERIFICAR CONCLUSÃO
-- ------------------------------------------------------------
function TsT.EventManager.verificarConclusao(factionId)
    local evState = ensureEventData(factionId)
    local evDef = TsT.EventManager.getEventDef(factionId)
    if not evDef or evState.completed then return end
    
    local concluido = true
    
    if evDef.goal.kills and evDef.goal.kills > 0 then
        if (evState.progress.kills or 0) < evDef.goal.kills then
            concluido = false
        end
    end
    
    if evDef.goal.items and concluido then
        for _, req in ipairs(evDef.goal.items) do
            if (evState.progress.items[req.name] or 0) < req.count then
                concluido = false
                break
            end
        end
    end
    
    if concluido then
        local agora = TsT.getTimestamp()
        evState.completed = true
        evState.completedAt = agora
        evState.nextResetAt = agora + getSandboxCooldownSeconds()
        
        print("[TsT-Event] Evento concluído: " .. evDef.id .. " (" .. factionId .. ")")
        
        local bonusItems = getSandboxBonusItems()
        local players = getOnlinePlayers()
        
        for i = 0, players:size() - 1 do
            local p = players:get(i)
            if p then
                local pPos = TsT.getModData(p)
                local pMd = p:getModData()
                local contrib = pMd.TsT and pMd.TsT.eventContrib or {}
                
                if pPos.faction == factionId and contrib[evDef.id] == evState.cycleId then
                    TsT.FactionManager.addFama(p, evDef.rewards.fame or 0)
                    TsT.FactionManager.addMoney(p, evDef.rewards.money or 0)
                    TsT.FactionManager.savePlayerData(p)
                    local novaFama = TsT.FactionManager.getFama(p)
                    local novoMoney = TsT.FactionManager.getMoney(p)
                    
                    local pInv = p:getInventory()
                    local pSquare = p:getCurrentSquare()
                    for _, bi in ipairs(bonusItems) do
                        for _ = 1, (bi.count or 1) do
                            local newItem = pInv:AddItem(bi.type)
                            if newItem then
                                sendAddItemToContainer(pInv, newItem)
                            elseif pSquare then
                                pSquare:AddWorldInventoryItem(bi.type, ZombRandFloat(0.1, 0.9), ZombRandFloat(0.1, 0.9), 0, true)
                            end
                        end
                    end
                    
                    sendServerCommand(p, "TsT", "EventCompleted", {
                        eventId = evDef.id,
                        title = evDef.title,
                        fameDelta = evDef.rewards.fame or 0,
                        moneyDelta = evDef.rewards.money or 0,
                        novaFama = novaFama,
                        novoMoney = novoMoney,
                        bonusItems = bonusItems,
                        cooldownH = getSandboxCooldownSeconds() / 3600,
                    })
                end
            end
        end
    end
end

-- ------------------------------------------------------------
-- SINCRONIZAÇÃO
-- ------------------------------------------------------------
function TsT.EventManager.syncEvento(player)
    local pos = TsT.getModData(player)
    if not pos.faction then return end
    
    local evState = ensureEventData(pos.faction)
    local evDef = TsT.EventManager.getEventDef(pos.faction)
    if not evDef then return end
    
    local agora = getTimestamp()
    local cooldownRestante = 0
    if evState.completed and evState.nextResetAt then
        cooldownRestante = math.max(0, evState.nextResetAt - agora)
    end
    
    sendServerCommand(player, "TsT", "EventSync", {
        eventDef = {
            id = evDef.id,
            factionId = evDef.factionId,
            type = evDef.type,
            title = evDef.title,
            description = evDef.description,
            goal = evDef.goal,
            rewards = evDef.rewards,
        },
        progress = evState.progress,
        completed = evState.completed,
        contributorCount = evState.contributorCount,
        cooldownRestante = cooldownRestante,
        cooldownTotal = getSandboxCooldownSeconds(),
    })
end

-- ------------------------------------------------------------
-- ADMIN: Reset manual
-- ------------------------------------------------------------
function TsT.EventManager.resetarEvento(factionId)
    resetEvento(factionId, nil)
    
    local players = getOnlinePlayers()
    for i = 0, players:size() - 1 do
        local p = players:get(i)
        if p then
            local pPos = TsT.getModData(p)
            if pPos.faction == factionId then
                local md = p:getModData()
                if md.TsT and md.TsT.eventContrib then
                    md.TsT.eventContrib = {}
                    -- syncEvento() é chamado pelo caller após resetarEvento(); não precisamos de transmitModData().
                end
            end
        end
    end
end

-- ------------------------------------------------------------
-- TIMER: Auto-reset + Flush pendente
-- ------------------------------------------------------------
local function onEveryTenMinutes()
    local data = getEventData()
    local agora = getTimestamp()
    
    -- Auto-reset após cooldown
    for _, fac in ipairs({"combatants", "survivors", "specialists"}) do
        local ev = data[fac]
        if ev and ev.completed and ev.nextResetAt and agora >= ev.nextResetAt then
            print("[TsT-Event] Cooldown expirado: " .. fac)
            resetEvento(fac, nil)
        end
        
        -- Flush broadcasts pendentes (força envio a cada 10 min)
        local throttle = BroadcastThrottle[fac]
        if throttle and throttle.pendingKills > 0 then
            broadcastProgressToFaction(fac, "kills", ev.progress.kills)
            throttle.pendingKills = 0
        end
    end
end

Events.EveryTenMinutes.Add(onEveryTenMinutes)

print("[TsT] TsT_EventManager.lua (OPTIMIZED v2) carregado.")
