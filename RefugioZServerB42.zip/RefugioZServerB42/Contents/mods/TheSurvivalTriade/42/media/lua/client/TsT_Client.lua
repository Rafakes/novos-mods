-- ============================================================
-- TsT_Client.lua — Inicialização, Hooks e Tracking (Client)
-- Mod: The Survival Triade | Build 42
-- ============================================================

require "ISUI/ISPanel"
require "ISUI/ISButton"

TsT = TsT or {}
TsT.Client = {}

-- ------------------------------------------------------------
-- UTILITÁRIO: HaloText seguro (compatível B42)
-- TM42 usa player:HaloText com guard — seguimos o mesmo padrão
-- ------------------------------------------------------------
local function halo(player, text, r, g, b)
    if player and player.HaloText then
        player:HaloText(text, r or 255, g or 255, b or 255)
    end
end

-- ------------------------------------------------------------
-- TRACKING DE PROGRESSO (a cada 15 ticks)
-- ------------------------------------------------------------
local tickCounter = 0

local function onPlayerUpdate(player)
    if not player or not player:isLocalPlayer() then return end

    local pos = TsT.getModData(player)
    local missionsToTrack = {}
    if pos.activeMission then table.insert(missionsToTrack, { id = pos.activeMission, data = pos.activeMissionData }) end
    if pos.activeDailyMission then table.insert(missionsToTrack, { id = pos.activeDailyMission, data = pos.activeDailyMissionData }) end

    if #missionsToTrack == 0 then return end

    tickCounter = tickCounter + 1
    if tickCounter < 15 then return end
    tickCounter = 0

    for _, entry in ipairs(missionsToTrack) do
        local mission = TsT.getMissionById(entry.id)
        if mission then
            local missionData = entry.data or {}
            -- Tracking de KILL
            if (mission.type == "KILL" or mission.type == "MIXED") and mission.objectives and mission.objectives.kills then
                local kills = math.max(0, player:getZombieKills() - (missionData.startKills or 0))
                if kills > 0 then
                    local isDaily = entry.id:sub(1, 6) == "daily_"
                    local prefix = isDaily and "[DIARIA] " or ""
                    local displayKills = math.min(kills, mission.objectives.kills)
                    halo(player, prefix .. mission.title .. ": " .. displayKills .. "/" .. mission.objectives.kills, 255, 200, 100)
                end
            end
        end
    end
end

-- ------------------------------------------------------------
-- RESPOSTAS DO SERVIDOR
-- ------------------------------------------------------------
local function onServerCommand(module, command, args)
    if module ~= "TsT" then return end

    local player = getPlayer()
    if not player then return end

    -- Garante que o ModData existe antes de usar
    local pos = TsT.getModData(player)
    args = args or {}

    -- ---- Sincronização ao entrar no servidor ----
    if command == "SyncData" then
        pos.faction           = args.faction
        -- Garante que fame sempre tem todas as chaves, mesmo se o servidor enviar incompleto
        local fameRecv = args.fame or {}
        pos.fame = {
            combatants  = fameRecv.combatants  or 0,
            survivors   = fameRecv.survivors   or 0,
            specialists = fameRecv.specialists or 0,
        }
        pos.completedMissions  = args.completedMissions or {}
        pos.money              = args.money or 0
        pos.activeDailyMission = args.activeDailyMission
        pos.activeDailyMissionData = args.activeDailyMissionData or {}
        pos.activeMission      = args.activeMission
        pos.activeMissionData  = args.activeMissionData or {}
        pos.lastDailyCompletionTime = args.lastDailyCompletionTime
        -- NÃO chamar player:transmitModData() aqui.
        -- O servidor é autoridade; enviar de volta dados locais pode sobrescrever
        -- completedMissions/fame com dados zerados ou incompletos (race condition B42 MP).

        -- Mostra ícone HUD sempre; abre seleção se sem facção
        TsT.Client.mostrarHUD()
        if not pos.faction then
            TsT.Client.abrirFactionSelect()
        end
        return
    end

    -- ---- Facção confirmada ----
    if command == "FactionJoined" then
        pos.faction = args.factionId
        -- Servidor já transmitiu: não reenviar dados locais para evitar sobrescrever estado do servidor.

        local fac = TsT.getFactionById(args.factionId)
        halo(player, "Bem-vindo ao grupo " .. (fac and fac.nome or args.factionId) .. "!", 100, 255, 100)

        -- Fecha o modal de seleção
        if TsT_FactionSelect and TsT_FactionSelect.instance then
            TsT_FactionSelect.instance:close()
        end

        -- Abre o painel de missões para o jogador ver sua nova facção
        if TsT_MissionBoard and not TsT_MissionBoard.instance then
            TsT_MissionBoard:togglePanel()
        elseif TsT_MissionBoard and TsT_MissionBoard.instance then
            TsT_MissionBoard.instance:refresh()
        end
        return
    end

    -- ---- Missão aceita ----
    if command == "MissionAccepted" then
        local acceptedData = args.missionData or { startKills = player:getZombieKills(), startTime = TsT.getTimestamp(), progress = 0 }
        if args.isDaily then
            pos.activeDailyMission = args.missionId
            pos.activeDailyMissionData = acceptedData
        else
            pos.activeMission = args.missionId
            pos.activeMissionData = acceptedData
        end
        -- Servidor já salvou e transmitiu; apenas atualiza display local.
        halo(player, (args.isDaily and "Missão Diária aceita!" or "Missão aceita!"), 100, 200, 255)
        -- Vai direto para a aba Ativas para mostrar a missão recém aceita
        if TsT_MissionBoard then
            TsT_MissionBoard.irParaAtivas()
        end
        return
    end

    -- ---- Missão concluída ----
    if command == "MissionSuccess" then
        local isDaily = args.missionId:sub(1,6) == "daily_"
        if isDaily then
            pos.activeDailyMission     = nil
            pos.activeDailyMissionData = {}
        else
            pos.activeMission          = nil
            pos.activeMissionData      = {}
        end
        if args.novaFama and pos.faction then
            if not pos.fame then pos.fame = { combatants=0, survivors=0, specialists=0 } end
            pos.fame[pos.faction] = args.novaFama
        end
        pos.money = args.novoMoney or pos.money
        if args.missionId then
            pos.completedMissions = pos.completedMissions or {}
            pos.completedMissions[args.missionId] = true
        end
        -- player:transmitModData() -- Removido para evitar sobrescrever dados do servidor via race condition (o servidor já sincroniza)
        halo(player, "CONCLUÍDA! +" .. (args.moneyDelta or 0) .. " Tampinhas | +" .. (args.fameDelta or 0) .. " fama", 100, 255, 100)
        if TsT_MissionBoard and TsT_MissionBoard.instance then
            TsT_MissionBoard.instance:refresh()
        end
        return
    end

    -- ---- Missão abandonada ----
    if command == "MissionAbandoned" then
        if args.missionId == pos.activeDailyMission then
            pos.activeDailyMission = nil
            pos.activeDailyMissionData = {}
        elseif args.missionId == pos.activeMission then
            pos.activeMission = nil
            pos.activeMissionData = {}
        end
        -- Servidor já transmitiu; apenas atualiza display local.
        halo(player, "Missão abandonada.", 200, 100, 100)
        if TsT_MissionBoard and TsT_MissionBoard.instance then
            TsT_MissionBoard.instance:refresh()
        end
        return
    end

    -- ---- Compra confirmada ----
    if command == "ShopSuccess" then
        pos.money = args.novoMoney or pos.money
        -- player:transmitModData() -- Sincronizado pelo servidor
        halo(player, "Comprado: " .. (args.nome or "item") .. "! Tampinhas: " .. pos.money, 255, 220, 50)
        if TsT_MissionBoard and TsT_MissionBoard.instance then
            TsT_MissionBoard.instance:refresh()
        end
        return
    end

    -- ---- Erro do servidor ----
    if command == "Error" then
        halo(player, "Erro: " .. (args.msg or "desconhecido"), 255, 80, 80)
        return
    end

    -- ---- Sincronização do estado do Evento ----
    if command == "EventSync" then
        if TsT_MissionBoard and TsT_MissionBoard.onEventSync then
            TsT_MissionBoard.onEventSync(args)
        end
        return
    end

    -- ---- Update incremental do progresso do evento ----
    if command == "EventProgressUpdate" then
        if TsT_MissionBoard and TsT_MissionBoard.onEventProgressUpdate then
            TsT_MissionBoard.onEventProgressUpdate(args)
        end
        return
    end

    -- ---- Depósito no Evento confirmado ----
    if command == "EventDepositOk" then
        local deps = args.depositados or {}
        local resumo = {}
        for _, d in ipairs(deps) do
            table.insert(resumo, d.count .. "x " .. TsT.getItemDisplayName(d.name))
        end
        local txt = #resumo > 0 and ("Depositado: " .. table.concat(resumo, ", ")) or "Deposito confirmado!"
        halo(player, txt, 100, 255, 200)
        -- Atualiza eventoCache com o progresso recebido antes de redesenhar
        if args.progress and TsT_MissionBoard and TsT_MissionBoard.onEventSync then
            TsT_MissionBoard.onEventSync({ progress = args.progress })
        elseif TsT_MissionBoard and TsT_MissionBoard.instance then
            TsT_MissionBoard.instance:refresh()
        end
        return
    end

    -- ---- Evento global concluído ----
    if command == "EventCompleted" then
        -- Atualiza fama e dinheiro localmente usando snapshot autoritativo do servidor.
        if pos.faction and args.novaFama ~= nil then
            if not pos.fame then pos.fame = { combatants=0, survivors=0, specialists=0 } end
            pos.fame[pos.faction] = args.novaFama
        elseif args.fameDelta and args.fameDelta > 0 and pos.faction then
            if not pos.fame then pos.fame = { combatants=0, survivors=0, specialists=0 } end
            pos.fame[pos.faction] = (pos.fame[pos.faction] or 0) + args.fameDelta
        end
        pos.money = args.novoMoney or ((pos.money or 0) + (args.moneyDelta or 0))
        -- player:transmitModData() -- Sincronizado pelo servidor

        local bonusMsg = ""
        if args.bonusItems and #args.bonusItems > 0 then
            local nomes = {}
            for _, bi in ipairs(args.bonusItems) do
                table.insert(nomes, bi.count .. "x " .. TsT.getItemDisplayName(bi.type))
            end
            bonusMsg = " | Items: " .. table.concat(nomes, ", ")
        end
        halo(player,
            "EVENTO: " .. (args.title or "Evento") ..
            "! +" .. (args.moneyDelta or 0) .. " Tamp. | +" .. (args.fameDelta or 0) .. " fama" .. bonusMsg,
            255, 220, 50)
        if TsT_MissionBoard and TsT_MissionBoard.instance then
            TsT_MissionBoard.instance:refresh()
        end
        -- Solicita novo sync do evento
        sendClientCommand(player, "TsT", "RequestEventSync", {})
        return
    end

    -- ---- Dados de Ranking recebidos ----
    if command == "RankingData" then
        if TsT_MissionBoard and TsT_MissionBoard.onRankingData then
            TsT_MissionBoard.onRankingData(args)
        end
        return
    end

    -- ---- Abandonou a Facção ----
    if command == "LeaveFactionOk" then
        -- Reseta dados locais para refletir o reset já feito pelo servidor
        pos.faction            = nil
        pos.fame               = { combatants=0, survivors=0, specialists=0 }
        pos.money              = 0
        pos.activeMission      = nil
        pos.activeMissionData  = {}
        pos.activeDailyMission = nil
        pos.activeDailyMissionData = {}
        pos.completedMissions  = {}
        -- Servidor já resetou e transmitiu; não reenviar para evitar race condition.

        halo(player, "Grupo abandonado. Escolha um novo!", 255, 150, 50)

        -- Fecha o painel principal
        if TsT_MissionBoard and TsT_MissionBoard.instance then
            TsT_MissionBoard.instance:close()
        end
        -- Fecha modal de confirmação se ainda aberto
        if TsT_MissionBoard and TsT_MissionBoard._confirmModal then
            TsT_MissionBoard._confirmModal:removeFromUIManager()
            TsT_MissionBoard._confirmModal = nil
        end
        -- Garante que qualquer instância anterior do painel de seleção seja destruída
        -- antes de reabrir, evitando instâncias stale que bloqueiam openPanel()
        if TsT_FactionSelect and TsT_FactionSelect.instance then
            pcall(function() TsT_FactionSelect.instance:removeFromUIManager() end)
            TsT_FactionSelect.instance = nil
        end
        -- Abre seleção de facção
        if TsT_FactionSelect then
            TsT_FactionSelect:openPanel()
        end
        return
    end

    -- ---- Erro de Evento ----
    if command == "EventError" then
        halo(player, "Evento: " .. (args.msg or "erro desconhecido"), 255, 100, 80)
        return
    end

end

-- ------------------------------------------------------------
-- INICIALIZAÇÃO — usa OnGameStart para garantir que a UI está pronta
-- ------------------------------------------------------------
local hudCriado = false

local function onGameStart()
    -- OnGameStart dispara depois que toda a UI já carregou
    -- Seguro para criar elementos de HUD
    if not hudCriado then
        TsT.Client.criarHUD()
        hudCriado = true
    end
end

local function onCreatePlayer()
    local player = getPlayer()
    if not player then return end

    -- Inicializa ModData local
    TsT.initModData(player)

    -- Em multiplayer: solicita sync ao servidor
    if isClient() then
        sendClientCommand(player, "TsT", "RequestSync", {})
    else
        -- Single player: verifica facção e exibe modal se necessário
        -- Usa um tick de delay para garantir que a UI já renderizou
        local waited = false
        local function delayedCheck()
            if waited then
                Events.OnPlayerUpdate.Remove(delayedCheck)
                local pos = TsT.getModData(player)
                TsT.Client.criarHUD()
                if not pos.faction then
                    TsT.Client.abrirFactionSelect()
                end
            end
            waited = true
        end
        Events.OnPlayerUpdate.Add(delayedCheck)
    end
end

-- (F6 removido — painel acessível apenas pelo ícone HUD)

-- ------------------------------------------------------------
-- CONTROLE DO HUD E UIs
-- Ícone HUD arrastável (drag & drop)
-- ------------------------------------------------------------
local hudIcon  = nil
local ICON_SIZE = 42

-- Classe derivada de ISPanel para suporte a drag
local TsT_HUDIcon = ISPanel:derive("TsT_HUDIcon")

function TsT_HUDIcon:new(x, y)
    local o = ISPanel:new(x, y, ICON_SIZE, ICON_SIZE)
    setmetatable(o, self)
    self.__index = self
    o.backgroundColor = { r=0.05, g=0.05, b=0.09, a=0.92 }
    o.borderColor     = { r=0.62, g=0.52, b=0.18, a=1.00 }
    o._dragging       = false
    o._hasMoved       = false
    o._dragOX         = 0
    o._dragOY         = 0
    return o
end

function TsT_HUDIcon:render()
    -- Fundo e borda
    self:drawRect(0, 0, ICON_SIZE, ICON_SIZE, self.backgroundColor.a,
        self.backgroundColor.r, self.backgroundColor.g, self.backgroundColor.b)
    self:drawRectBorder(0, 0, ICON_SIZE, ICON_SIZE, self.borderColor.a,
        self.borderColor.r, self.borderColor.g, self.borderColor.b)

    -- Textura ou texto
    local tex = getTexture("media/textures/UI/pos_icon.png")
    if tex then
        self:drawTextureScaled(tex, 2, 2, ICON_SIZE-4, ICON_SIZE-4, 1)
    else
        self:drawTextCentre("TsT", ICON_SIZE/2, ICON_SIZE/2 - 8, 0.95, 0.82, 0.22, 1, UIFont.Medium)
    end

    -- Indicador de drag (hover: borda mais brilhante)
    if self._dragging then
        self:drawRectBorder(0, 0, ICON_SIZE, ICON_SIZE, 1, 1.0, 0.85, 0.2)
    end
end

function TsT_HUDIcon:onMouseDown(x, y)
    self._dragging  = true
    self._hasMoved  = false
    self._dragOX    = x
    self._dragOY    = y
    self:bringToTop()
end

function TsT_HUDIcon:onMouseMove(dx, dy)
    if self._dragging then
        -- Considera movimento real somente se deslocou mais de 4px
        if math.abs(dx) + math.abs(dy) > 0 then
            self._hasMoved = true
        end
        local nx = self:getX() + dx
        local ny = self:getY() + dy
        -- Mantém dentro da tela
        local sw = getCore():getScreenWidth()
        local sh = getCore():getScreenHeight()
        nx = math.max(0, math.min(sw - ICON_SIZE, nx))
        ny = math.max(0, math.min(sh - ICON_SIZE, ny))
        self:setX(nx)
        self:setY(ny)
    end
end

function TsT_HUDIcon:onMouseUp(x, y)
    local moved = self._hasMoved
    self._dragging = false
    self._hasMoved = false
    -- Se não arrastou = clique simples → abre UI
    if not moved then
        local player = getPlayer()
        if not player then return end
        local pos = TsT.getModData(player)
        if not pos.faction then
            TsT.Client.abrirFactionSelect()
        else
            TsT.Client.toggleMissionBoard()
        end
    end
end

function TsT_HUDIcon:onMouseMoveOutside(dx, dy)
    -- Continua drag mesmo com mouse fora do ícone
    if self._dragging then
        self:onMouseMove(dx, dy)
    end
end

function TsT_HUDIcon:onMouseUpOutside(x, y)
    self._dragging = false
    self._hasMoved = false
end

--- Cria o ícone HUD persistente — arrastável, abaixo do botão admin
function TsT.Client.criarHUD()
    if hudIcon and hudIcon.javaObject then return end

    local sw = getCore():getScreenWidth()
    local sh = getCore():getScreenHeight()
    -- Posição inicial: canto esquerdo, abaixo do painel admin (~300px do fundo)
    local x = 20
    local y = sh - 350

    hudIcon = TsT_HUDIcon:new(x, y)
    hudIcon:initialise()
    hudIcon:addToUIManager()
    hudIcon.tooltip = "Survival Triade | Segure para mover"
end

--- Garante que o HUD está visível
function TsT.Client.mostrarHUD()
    if not hudIcon or not hudIcon.javaObject then
        TsT.Client.criarHUD()
    end
end

--- Oculta o ícone se o painel admin do PZ estiver aberto na tela
local function onUpdateAdminCheck()
    if not hudIcon or not hudIcon.javaObject then return end

    -- Verifica globals que o PZ expõe quando o painel admin está aberto
    local adminOpen = false
    pcall(function()
        if AdminPanel and AdminPanel.instance and AdminPanel.instance:isVisible() then
            adminOpen = true
        end
    end)

    if adminOpen then
        if hudIcon:isVisible() then hudIcon:setVisible(false) end
    else
        if not hudIcon:isVisible() then hudIcon:setVisible(true) end
    end
end

--- Abre o modal de seleção de facção
function TsT.Client.abrirFactionSelect()
    if TsT_FactionSelect then
        TsT_FactionSelect:openPanel()
    end
end

--- Toggle do painel de missões
function TsT.Client.toggleMissionBoard()
    if TsT_MissionBoard then
        TsT_MissionBoard:togglePanel()
    end
end

-- ------------------------------------------------------------
-- REGISTRO DE EVENTOS
-- ------------------------------------------------------------
Events.OnPlayerUpdate.Add(onPlayerUpdate)
Events.OnPlayerUpdate.Add(onUpdateAdminCheck)
Events.OnServerCommand.Add(onServerCommand)
Events.OnCreatePlayer.Add(onCreatePlayer)
Events.OnGameStart.Add(onGameStart)
print("[TsT] TsT_Client.lua carregado com sucesso.")
