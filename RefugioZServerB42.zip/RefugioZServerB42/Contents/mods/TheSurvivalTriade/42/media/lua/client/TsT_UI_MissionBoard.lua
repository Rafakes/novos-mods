-- ============================================================
-- TsT_UI_MissionBoard.lua — Painel Principal (6 Abas)
-- Mod: The Survival Triade | Build 42
-- Abas: Ativas | Quadro | Loja | Status | Ranking | Evento
-- ============================================================

require "ISUI/ISCollapsableWindow"
require "ISUI/ISScrollingListBox"
require "ISUI/ISButton"
require "ISUI/ISLabel"
require "ISUI/ISPanel"

TsT_MissionBoard = ISCollapsableWindow:derive("TsT_MissionBoard")
TsT_MissionBoard.instance = nil

local abaAtiva = 2  -- começa no Quadro

local PAINEL_W = 700
local PAINEL_H = 660

-- ------------------------------------------------------------
-- UTILITÁRIO: HaloText seguro (B42)
-- ------------------------------------------------------------
local function halo(player, text, r, g, b)
    if player and player.HaloText then
        player:HaloText(text, r or 255, g or 255, b or 255)
    end
end

-- ------------------------------------------------------------
-- CORES
-- ------------------------------------------------------------
local C_BG      = { r=0.08, g=0.08, b=0.10, a=0.97 }
local C_BORDER  = { r=0.40, g=0.40, b=0.40, a=1.0  }
local C_GOLD    = { r=0.95, g=0.80, b=0.20, a=1.0  }
local C_GREEN   = { r=0.20, g=0.80, b=0.20, a=1.0  }
local C_RED     = { r=0.80, g=0.20, b=0.10, a=1.0  }
local C_BLUE    = { r=0.30, g=0.60, b=0.95, a=1.0  }
local C_PURPLE  = { r=0.65, g=0.25, b=0.80, a=1.0  }

-- ------------------------------------------------------------
-- UTILITÁRIO: Quebra texto em múltiplas linhas para caber na largura
-- Usa getTextManager() para medir o texto (disponível em B42)
-- ------------------------------------------------------------
local function wrapText(text, maxWidth, font)
    font = font or UIFont.Small
    local tm = getTextManager()
    local words = {}
    for w in text:gmatch("%S+") do table.insert(words, w) end

    local lines = {}
    local currentLine = ""

    for _, word in ipairs(words) do
        local test = currentLine == "" and word or (currentLine .. " " .. word)
        if tm:MeasureStringX(font, test) <= maxWidth then
            currentLine = test
        else
            if currentLine ~= "" then
                table.insert(lines, currentLine)
            end
            currentLine = word
        end
    end
    if currentLine ~= "" then
        table.insert(lines, currentLine)
    end
    return lines
end

-- Adiciona ISLabel com wrap automático; retorna nova posição Y
local function addWrappedLabel(panel, text, x, y, maxW, r, g, b, font)
    font = font or UIFont.Small
    local lineH = 18
    local lines = wrapText(text, maxW, font)
    for _, line in ipairs(lines) do
        local lbl = ISLabel:new(x, y, lineH, line, r, g, b, 1, font, true)
        panel:addChild(lbl)
        y = y + lineH
    end
    return y
end

local rankingCache = nil
local eventoCache  = nil   -- { eventDef={}, progress={}, completed=false, contributors={} }
local lastRankingRequest = 0
local lastEventRequest   = 0

TsT_MissionBoard.selectedTierQuadro = 1

-- Abas
local ABAS = {
    { id=1, titulo=getText("UI_TsT_MissionBoard_Tab_Active") or "Ativas" },
    { id=2, titulo=getText("UI_TsT_MissionBoard_Tab_Board") or "Missões" },
    { id=3, titulo=getText("UI_TsT_MissionBoard_Tab_Shop") or "Loja" },
    { id=4, titulo=getText("UI_TsT_MissionBoard_Tab_Status") or "Status" },
    { id=5, titulo=getText("UI_TsT_MissionBoard_Tab_Ranking") or "Ranking" },
    { id=6, titulo=getText("UI_TsT_MissionBoard_Tab_Event") or "Evento" },
}

-- ------------------------------------------------------------
-- TOGGLE / OPEN / CLOSE
-- ------------------------------------------------------------
function TsT_MissionBoard:togglePanel()
    if TsT_MissionBoard.instance then
        TsT_MissionBoard.instance:close()
        return
    end
    local W = getCore():getScreenWidth()
    local H = getCore():getScreenHeight()
    local ui = TsT_MissionBoard:new((W-PAINEL_W)/2, (H-PAINEL_H)/2, PAINEL_W, PAINEL_H)
    ui:initialise()
    ui:addToUIManager()
    TsT_MissionBoard.instance = ui

    -- Solicita dados frescos do servidor
    local player = getPlayer()
    if player and isClient() then
        local agora = TsT.getTimestamp()
        if agora - lastRankingRequest > 30 then
            sendClientCommand(player, "TsT", "RequestRanking",   {})
            lastRankingRequest = agora
        end
        if agora - lastEventRequest > 30 then
            sendClientCommand(player, "TsT", "RequestEventSync", {})
            lastEventRequest = agora
        end
    end
end

function TsT_MissionBoard:close()
    ISCollapsableWindow.close(self)
    self:removeFromUIManager()
    TsT_MissionBoard.instance = nil
end

function TsT_MissionBoard:refresh()
    if TsT_MissionBoard.instance then
        TsT_MissionBoard.instance:refreshContent()
    end
end

-- Muda para a aba Ativas (1) e atualiza — chamado ao aceitar missão
function TsT_MissionBoard.irParaAtivas()
    if TsT_MissionBoard.instance then
        abaAtiva = 1
        TsT_MissionBoard.instance:updateAbaHighlight()
        TsT_MissionBoard.instance:refreshContent()
    end
end

-- Chamado pelo client quando recebe dados do servidor
function TsT_MissionBoard.onRankingData(data)
    rankingCache = data
    if TsT_MissionBoard.instance and abaAtiva == 5 then
        TsT_MissionBoard.instance:refreshContent()
    end
end

function TsT_MissionBoard.onEventSync(data)
    -- Mescla apenas o progress se já existe cache, preservando eventDef e outros campos
    if eventoCache and data and data.progress and not data.eventDef then
        eventoCache.progress = data.progress
    else
        eventoCache = data
    end
    if TsT_MissionBoard.instance and abaAtiva == 6 then
        TsT_MissionBoard.instance:refreshContent()
    end
end

function TsT_MissionBoard.onEventProgressUpdate(data)
    if not data then return end

    eventoCache = eventoCache or { progress = { kills = 0, items = {} } }
    eventoCache.progress = eventoCache.progress or { kills = 0, items = {} }

    if data.type == "kills" then
        eventoCache.progress.kills = data.value or 0
    elseif data.type == "items" then
        eventoCache.progress.items = data.value or {}
    end

    if TsT_MissionBoard.instance and abaAtiva == 6 then
        TsT_MissionBoard.instance:refreshContent()
    end
end

-- ------------------------------------------------------------
-- CONSTRUTOR
-- ------------------------------------------------------------
function TsT_MissionBoard:new(x, y, w, h)
    local o = ISCollapsableWindow:new(x, y, w, h)
    setmetatable(o, self)
    self.__index = self
    o.title           = ""          -- evita o título nativo duplicado
    o.resizable       = false
    o.backgroundColor = C_BG
    o.borderColor     = C_BORDER
    return o
end

function TsT_MissionBoard:initialise()
    ISCollapsableWindow.initialise(self)
    -- buildStaticLayout and refreshContent are already called by createChildren() via ISCollapsableWindow.initialise()
end

-- ------------------------------------------------------------
-- LAYOUT ESTÁTICO — criado UMA VEZ em initialise()
-- Título, botões de aba, separador. Nunca recriados.
-- ------------------------------------------------------------
function TsT_MissionBoard:buildStaticLayout()
    local W = self:getWidth()

    -- Constantes de layout (precisamos delas em refreshContent também)
    local TITLE_H = 28
    local ABA_H   = 26
    local ABA_GAP = 3
    local sepY    = TITLE_H + 2 + 2*(ABA_H + 2) + 2

    self._TITLE_H   = TITLE_H
    self._ABA_H     = ABA_H
    self._ABA_GAP   = ABA_GAP
    self._sepY      = sepY
    self._contentY  = sepY + 4
    self._contentH  = self:getHeight() - (sepY + 4) - 6
    self._abaButtons = {}

    -- Título centralizado
    local TITLE_TXT  = getText("UI_TsT_MissionBoard_Title") or "Survival Triade"
    local TITLE_FONT = UIFont.Small
    local tm = getTextManager()
    local tW = tm:MeasureStringX(TITLE_FONT, TITLE_TXT)
    local tH = tm:MeasureStringY(TITLE_FONT, TITLE_TXT)
    local titleLbl = ISLabel:new(
        math.floor((W - tW) / 2),
        math.floor((TITLE_H - tH) / 2),
        TITLE_H, TITLE_TXT,
        C_GOLD.r, C_GOLD.g, C_GOLD.b, 1, TITLE_FONT, true)
    self:addChild(titleLbl)

    -- Botão fechar
    local btnClose = ISButton:new(W - 28, 2, 24, 24, "X", self, TsT_MissionBoard.close)
    btnClose.backgroundColor = { r=0.55, g=0.08, b=0.05, a=1 }
    btnClose.borderColor     = { r=0.85, g=0.15, b=0.1, a=1 }
    btnClose:initialise()
    self:addChild(btnClose)

    -- Botões de aba (2 linhas × 4 colunas)
    local abaW = math.floor((W - 3*ABA_GAP - 4) / 4)
    for _, aba in ipairs(ABAS) do
        local linha = math.floor((aba.id - 1) / 4)
        local col   = (aba.id - 1) % 4
        local ax    = 2 + col * (abaW + ABA_GAP)
        local ay    = TITLE_H + 2 + linha * (ABA_H + 2)
        local btn   = ISButton:new(ax, ay, abaW, ABA_H, aba.titulo, self, function(s, b)
            abaAtiva = b.internal
            local p = getPlayer()
            if p and isClient() then
                local agora = TsT.getTimestamp()
                if b.internal == 5 then 
                    if agora - lastRankingRequest > 30 then
                        sendClientCommand(p, "TsT", "RequestRanking",   {})
                        lastRankingRequest = agora
                    end
                end
                if b.internal == 6 then
                    if agora - lastEventRequest > 30 then
                        sendClientCommand(p, "TsT", "RequestEventSync", {})
                        lastEventRequest = agora
                    end
                end
            end
            -- Apenas atualiza highlight dos botões e recarrega conteúdo
            if TsT_MissionBoard.instance then
                TsT_MissionBoard.instance:updateAbaHighlight()
                TsT_MissionBoard.instance:refreshContent()
            end
        end)
        btn.internal        = aba.id
        btn.backgroundColor = { r=0.10, g=0.10, b=0.13, a=1 }
        btn.borderColor     = { r=0.25, g=0.25, b=0.25, a=1 }
        btn:initialise()
        self:addChild(btn)
        self._abaButtons[aba.id] = btn
    end
    self:updateAbaHighlight()

    -- Separador
    local sep = ISPanel:new(0, sepY, W, 2)
    sep.backgroundColor = { r=0.35, g=0.35, b=0.35, a=0.9 }
    sep.borderColor     = sep.backgroundColor
    sep:initialise()
    self:addChild(sep)

    -- Painel de conteúdo (container trocável)
    local cp = ISPanel:new(0, self._contentY, W, self._contentH)
    cp.backgroundColor = { r=0, g=0, b=0, a=0 }
    cp.borderColor     = { r=0, g=0, b=0, a=0 }
    cp:initialise()
    self:addChild(cp)
    self._contentPanel = cp
end

-- Atualiza o highlight visual dos botões de aba sem recriar nada
function TsT_MissionBoard:updateAbaHighlight()
    if not self._abaButtons then return end
    for id, btn in pairs(self._abaButtons) do
        if id == abaAtiva then
            btn.backgroundColor = { r=0.22, g=0.22, b=0.30, a=1 }
            btn.borderColor     = { r=0.65, g=0.65, b=0.65, a=1 }
        else
            btn.backgroundColor = { r=0.10, g=0.10, b=0.13, a=1 }
            btn.borderColor     = { r=0.25, g=0.25, b=0.25, a=1 }
        end
    end
end

-- ------------------------------------------------------------
-- REFRESH DE CONTEÚDO — limpa e recria APENAS o subpainel
-- Chamado ao trocar aba, receber dados do servidor, etc.
-- ------------------------------------------------------------
function TsT_MissionBoard:refreshContent()
    local cp = self._contentPanel
    if not cp then return end

    -- Limpa o painel de conteúdo
    cp:clearChildren()

    local W = self:getWidth()
    local contentX = 0
    local contentY = 0
    local contentW = W
    local contentH = self._contentH or (self:getHeight() - (self._contentY or 90) - 6)

    if abaAtiva == 1 then self:renderAbaAtivas(cp, contentX, contentY, contentW, contentH) end
    if abaAtiva == 2 then self:renderAbaQuadro(cp, contentX, contentY, contentW, contentH) end
    if abaAtiva == 3 then self:renderAbaLoja(cp, contentX, contentY, contentW, contentH) end
    if abaAtiva == 4 then self:renderAbaStatus(cp, contentX, contentY, contentW, contentH) end
    if abaAtiva == 5 then self:renderAbaRanking(cp, contentX, contentY, contentW, contentH) end
    if abaAtiva == 6 then self:renderAbaEvento(cp, contentX, contentY, contentW, contentH) end
end

-- createChildren mantido como alias para compatibilidade com chamadas externas
function TsT_MissionBoard:createChildren()
    if self._contentPanel then
        self:refreshContent()
    else
        self:buildStaticLayout()
        self:refreshContent()
    end
end

-- ============================================================
-- ABA 1 — MISSÕES ATIVAS
-- ============================================================
function TsT_MissionBoard:renderAbaAtivas(cp, x, y, w, h)
    local player = getPlayer()
    if not player then return end
    local pos = TsT.getModData(player)

    local activeMissions = {}
    if pos.activeMission      then table.insert(activeMissions, pos.activeMission) end
    if pos.activeDailyMission then table.insert(activeMissions, pos.activeDailyMission) end

    if #activeMissions == 0 then
        local msg = ISLabel:new(w/2, y+h/2-10, 20, "Nenhuma missao ativa.", 0.5, 0.5, 0.5, 1, UIFont.Medium, true)
        msg:setX(msg:getX() - msg:getWidth()/2)
        cp:addChild(msg)
        return
    end

    local PAD    = 10
    local BTN_H  = 32
    local py     = y + PAD

    for _, mId in ipairs(activeMissions) do
        local mission = TsT.getMissionById(mId)
        if mission then
            local isDaily    = mission.id:sub(1, 6) == "daily_"
            local cardW      = w - PAD * 2

            -- Calculamos cy primeiro para definir a altura do card dinamicamente
            local cy = 8

            -- Título
            cy = cy + 28

            -- Descrição (estimativa de altura — addWrappedLabel retorna o novo cy)
            -- Usamos um dummy para calcular; depois aplicamos ao card real
            local descLines = 0
            local descW = cardW - PAD*2
            local descH = getTextManager():MeasureStringX(UIFont.Small, mission.description)
            local charsPerLine = math.max(1, math.floor(descW / 7))
            descLines = math.ceil(#mission.description / charsPerLine)
            cy = cy + math.max(1, descLines) * 14 + 6

            -- Kills
            if (mission.type == "KILL" or mission.type == "MIXED") and mission.objectives and mission.objectives.kills then
                cy = cy + 22
            end

            -- Itens
            if (mission.type == "LOOT" or mission.type == "MIXED") and mission.objectives and mission.objectives.items then
                cy = cy + #mission.objectives.items * 24
            end

            cy = cy + 8  -- padding antes dos botões
            local btnY  = cy
            local CARD_H = btnY + BTN_H + PAD

            -- Card de fundo com altura calculada
            local card = ISPanel:new(PAD, py, cardW, CARD_H)
            card.backgroundColor = { r=0.06, g=0.06, b=0.09, a=0.95 }
            card.borderColor     = { r=0.30, g=0.30, b=0.35, a=1.0 }
            card:initialise()
            cp:addChild(card)

            cy = 8

            -- Título
            local tituloTxt = (isDaily and "[DIARIA] " or "") .. mission.title
            local lblTit = ISLabel:new(PAD, cy, 24, tituloTxt, C_GOLD.r, C_GOLD.g, C_GOLD.b, 1, UIFont.Large, true)
            card:addChild(lblTit)
            cy = cy + 28

            -- Descrição com wrap
            cy = addWrappedLabel(card, mission.description, PAD, cy, cardW - PAD*2, 0.75, 0.75, 0.75, UIFont.Small)
            cy = cy + 6

            -- Progresso kills
            if (mission.type == "KILL" or mission.type == "MIXED") and mission.objectives and mission.objectives.kills then
                local mId2 = mission.id
                local lblK = ISLabel:new(PAD, cy, 20, "Kills: 0/" .. mission.objectives.kills, 1, 0.8, 0.2, 1, UIFont.Medium, true)
                lblK.render = function(this)
                    local pl = getPlayer(); if not pl then return end
                    local pd = TsT.getModData(pl)
                    local mData = (mId2:sub(1,6)=="daily_") and pd.activeDailyMissionData or pd.activeMissionData
                    local k    = math.max(0, pl:getZombieKills() - (mData.startKills or 0))
                    local meta = mission.objectives.kills
                    local displayKills = math.min(k, meta)
                    this:setName("Kills: " .. displayKills .. " / " .. meta)
                    this.textRed   = k >= meta and 0.2 or 1.0
                    this.textGreen = k >= meta and 0.9 or 0.8
                    this.textBlue  = 0.2
                end
                card:addChild(lblK)
                cy = cy + 22
            end

            -- Progresso itens
            if (mission.type == "LOOT" or mission.type == "MIXED") and mission.objectives and mission.objectives.items then
                for _, req in ipairs(mission.objectives.items) do
                    local iname, icount = req.name, req.count
                    local ROW_H = 22
                    local row = ISPanel:new(PAD, cy, cardW - PAD*2, ROW_H)
                    row.backgroundColor = { r=0, g=0, b=0, a=0 }
                    row.borderColor     = { r=0, g=0, b=0, a=0 }
                    row._iname  = iname
                    row._icount = icount
                    row._icon   = TsT.getItemIconTexture(iname)
                    row.render = function(this)
                        ISPanel.render(this)
                        local pl = getPlayer(); if not pl then return end
                        local n  = TsT.getItemCount(pl:getInventory(), this._iname)
                        local cr = n >= this._icount and 0.2 or 1.0
                        local cg = n >= this._icount and 0.9 or 0.5
                        local textX = 4
                        if this._icon then
                            this:drawTextureScaled(this._icon, 2, 2, 18, 18, 1, 1, 1, 1)
                            textX = 24
                        end
                        this:drawText(TsT.getItemDisplayName(this._iname) .. ": " .. n .. "/" .. this._icount, textX, 4, cr, cg, 0.2, 1, UIFont.Small)
                    end
                    row:initialise()
                    card:addChild(row)
                    cy = cy + ROW_H + 2
                end
            end

            -- Botões COMPLETAR / ABANDONAR logo após o conteúdo
            cy = cy + 8
            local btnW = math.floor((cardW - PAD*3) / 2)

            local mIdCopy = mission.id
            local btnComp = ISButton:new(PAD, cy, btnW, BTN_H, "COMPLETAR", card, function()
                local pl = getPlayer()
                if isClient() then
                    sendClientCommand(pl, "TsT", "completeMission", { missionId = mIdCopy })
                else
                    TsT.MissionManager.completarMissao(pl, mIdCopy)
                    if TsT_MissionBoard.instance then TsT_MissionBoard.instance:refresh() end
                end
            end)
            btnComp.backgroundColor = { r=0.05, g=0.35, b=0.05, a=1 }
            btnComp.borderColor     = { r=0.10, g=0.65, b=0.10, a=1 }
            btnComp:initialise()
            card:addChild(btnComp)

            local btnAban = ISButton:new(PAD*2 + btnW, cy, btnW, BTN_H, "ABANDONAR", card, function()
                local pl = getPlayer()
                if isClient() then
                    sendClientCommand(pl, "TsT", "abandonMission", { missionId = mIdCopy })
                else
                    TsT.MissionManager.abandonarMissao(pl, mIdCopy)
                    if TsT_MissionBoard.instance then TsT_MissionBoard.instance:refresh() end
                end
            end)
            btnAban.backgroundColor = { r=0.35, g=0.05, b=0.05, a=1 }
            btnAban.borderColor     = { r=0.65, g=0.10, b=0.10, a=1 }
            btnAban:initialise()
            card:addChild(btnAban)

            py = py + CARD_H + PAD
        end
    end
end


-- ============================================================
-- ABA 2 — QUADRO DE MISSÕES
-- ============================================================
TsT_MissionBoard.subAbaQuadro = TsT_MissionBoard.subAbaQuadro or 1

function TsT_MissionBoard:renderAbaQuadro(cp, x, y, w, h)
    local player = getPlayer()
    if not player then return end
    local pos = TsT.getModData(player)

    if not pos.faction then
        local msg = ISLabel:new(w/2, y+h/2-10, 20, "Escolha um grupo primeiro.", 0.7, 0.5, 0.2, 1, UIFont.Medium, true)
        msg:setX(msg:getX() - msg:getWidth()/2)
        cp:addChild(msg)
        return
    end

    local fama     = (pos.fame and pos.fame[pos.faction]) or 0
    local nivel, _ = TsT.getNivelFama(fama)
    local faccao   = TsT.getFactionById(pos.faction)
    local cor      = faccao and faccao.cor or { r=1, g=1, b=1 }

    local hdr = ISLabel:new(10, y + 2, 18,
        (faccao and faccao.nome or pos.faction) .. "  |  Fama: " .. fama .. "  |  Tier " .. nivel,
        cor.r, cor.g, cor.b, 1, UIFont.Small, true)
    cp:addChild(hdr)

    -- ────────────────────────────────────────────────────────────
    -- SUB-ABAS (Missões | Diária)
    -- ────────────────────────────────────────────────────────────
    local subAbas = { getText("UI_TsT_MissionBoard_Tab_Board") or "Missões", getText("UI_TsT_MissionBoard_Tab_Daily") or "Diária" }
    local btnW = math.floor((w - 20) / #subAbas)
    local btnH = 24
    local btnY = y + 22

    for i, label in ipairs(subAbas) do
        local isSelected = (TsT_MissionBoard.subAbaQuadro == i)
        local btn = ISButton:new(10 + (i-1)*btnW, btnY, btnW - 2, btnH, label, self, function()
            TsT_MissionBoard.subAbaQuadro = i
            if TsT_MissionBoard.instance then
                TsT_MissionBoard.instance:refresh()
            end
        end)
        
        btn.borderColor = { r=0.4, g=0.4, b=0.4, a=1 }
        if isSelected then
            btn.backgroundColor = { r=cor.r*0.6, g=cor.g*0.6, b=cor.b*0.6, a=1.0 }
            btn.textColor = { r=1, g=1, b=1, a=1 }
        else
            btn.backgroundColor = { r=0.1, g=0.1, b=0.1, a=0.8 }
            btn.textColor = { r=0.6, g=0.6, b=0.6, a=1 }
        end
        btn:initialise()
        cp:addChild(btn)
    end

    local PAD = 10
    local listaY = btnY + btnH + 6

    if TsT_MissionBoard.subAbaQuadro == 1 then
        -- LISTA DE MISSÕES GERAIS (Incluindo concluídas)
        local lista = ISScrollingListBox:new(PAD, listaY, w - PAD*2, h - (listaY - y) - 4)
        lista:initialise()
        lista:setAnchorRight(true)
        lista:setAnchorBottom(true)
        lista.itemheight      = 128
        lista.drawBorder      = true
        lista.borderColor     = C_BORDER
        lista.backgroundColor = { r=0, g=0, b=0, a=0.4 }
        lista.doDrawItem      = TsT_MissionBoard.drawMissionItem
        lista.onMouseDown     = TsT_MissionBoard.onMissionMouseDown
        cp:addChild(lista)
        self.missionLista = lista

        local completadas = pos.completedMissions or {}
        local allMissions = TsT.getMissoesDisponiveis(pos.faction, fama)

        -- Ordena: ativa primeiro, depois disponíveis, depois concluídas
        table.sort(allMissions, function(a, b)
            local aAtiva = (pos.activeMission == a.id)
            local bAtiva = (pos.activeMission == b.id)
            local aConc  = completadas[a.id] == true
            local bConc  = completadas[b.id] == true
            local prioA = aAtiva and 0 or (aConc and 2 or 1)
            local prioB = bAtiva and 0 or (bConc and 2 or 1)
            if prioA ~= prioB then return prioA < prioB end
            if a.tier ~= b.tier then return a.tier < b.tier end
            return a.id < b.id
        end)

        for _, m in ipairs(allMissions) do
            lista:addItem(m.title, {
                mission   = m,
                concluida = completadas[m.id] == true,
                ativa     = pos.activeMission == m.id,
            })
        end

        if #allMissions == 0 then
            local msg2 = ISLabel:new(w/2, listaY + 20, 18, "Nenhuma missao disponivel ainda.", 0.6, 0.6, 0.6, 1, UIFont.Small, true)
            msg2:setX(msg2:getX() - msg2:getWidth()/2)
            cp:addChild(msg2)
        end
    else
        -- MISSÃO DIÁRIA (Integrated from renderAbaDaily)
        -- Cooldown check
        local agora = TsT.getTimestamp()
        local ultimaVez = pos.lastDailyCompletionTime or 0
        local cooldown = 24 * 3600
        local tempoRestante = (ultimaVez + cooldown) - agora

        if tempoRestante > 0 then
            local horas = math.floor(tempoRestante / 3600)
            local mins  = math.floor((tempoRestante % 3600) / 60)
            local msg = string.format("Proxima missao diaria disponivel em: %02dh %02dm", horas, mins)
            local lbl = ISLabel:new(w/2, listaY + 40, 20, msg, 0.6, 0.6, 0.6, 1, UIFont.Medium, true)
            lbl:setX(lbl:getX() - lbl:getWidth()/2)
            cp:addChild(lbl)
        else
            local day = math.floor(agora / 86400)
            local dailies = TsT.DailyMissions[pos.faction] or {}
            if #dailies > 0 then
                local idx = (day % #dailies) + 1
                local mission = dailies[idx]

                local lista = ISScrollingListBox:new(PAD, listaY, w - PAD*2, 130)
                lista:initialise()
                lista.itemheight = 128
                lista.doDrawItem  = TsT_MissionBoard.drawMissionItem
                lista.onMouseDown = TsT_MissionBoard.onMissionMouseDown
                cp:addChild(lista)

                lista:addItem(mission.title, {
                    mission   = mission,
                    concluida = false,
                    ativa     = pos.activeDailyMission == mission.id,
                })

                local info = ISLabel:new(10, listaY + 140, 16, "Complete para ganhar 50 Tampinhas e 20 Notas.", 0.8, 0.8, 0.8, 1, UIFont.Small, false)
                cp:addChild(info)
            end
        end
    end
end




function TsT_MissionBoard.drawMissionItem(this, y, item, alt)
    if not item.height then item.height = this.itemheight end
    local m = item.item.mission
    local W = this:getWidth()

    if this.selected == item.index then
        this:drawRect(0, y, W, item.height, 0.3, 0.2, 0.4, 0.3)
    elseif alt then
        this:drawRect(0, y, W, item.height, 0.08, 0.8, 0.8, 0.8)
    else
        this:drawRect(0, y, W, item.height, 0.12, 0.05, 0.05, 0.05)
    end
    this:drawRectBorder(0, y, W, item.height, 0.5, 0.28, 0.28, 0.28)

    -- Badge tier
    local tc = ({[1]={0.3,0.3,0.3},[2]={0.1,0.3,0.6},[3]={0.1,0.5,0.2},[4]={0.5,0.3,0},[5]={0.5,0,0.5}})[m.tier] or {0.3,0.3,0.3}
    this:drawRect(0, y, 5, item.height, 1, tc[1], tc[2], tc[3])

    local tr, tg, tb = 1, 1, 1
    if item.item.concluida then tr, tg, tb = 0.4, 0.4, 0.4
    elseif item.item.ativa  then tr, tg, tb = 0.4, 1.0, 0.4 end

    -- ── Botão virtual (dimensões fixas) ──────────────────────
    local bW  = 150                          -- largura generosa para "EM ANDAMENTO"
    local bH  = 36
    local bX  = W - bW - 14                 -- 14px de margem direita
    local bY  = y + math.floor((item.height - bH) / 2)

    -- Área de texto (não invade o botão nem a borda esquerda)
    local PAD_L     = 14
    local textAreaW = bX - PAD_L - 6

    local tm2  = getTextManager()
    local BFONT = UIFont.Small               -- fonte padrão para textos da lista

    -- helper: desenha texto centralizado dentro de um rect (sem drawTextCentre)
    -- usa drawText com x calculado via MeasureStringX e y via MeasureStringY
    local function drawBtnText(label, font, rx, ry, rw, rh, r, g, b)
        local tw = tm2:MeasureStringX(font, label)
        local th = tm2:MeasureStringY(font, label)
        local tx = rx + math.floor((rw - tw) / 2)
        local ty = ry + math.floor((rh - th) / 2)
        this:drawText(label, tx, ty, r, g, b, 1, font)
    end

    -- Título (truncado se necessário)
    local title = m.title
    while #title > 4 and tm2:MeasureStringX(UIFont.Medium, title) > textAreaW do
        title = title:sub(1, -2)
    end
    if title ~= m.title then title = title .. "..." end

    local tierTxt = m.tier and ("Tier " .. m.tier) or "DIARIA"
    this:drawText(title, PAD_L, y + 6, tr, tg, tb, 1, UIFont.Medium)
    this:drawText(tierTxt .. "  |  " .. m.type, PAD_L, y + 28, 0.55, 0.55, 0.55, 1, BFONT)

    -- Objetivos e recompensas com ícones
    local ICON_S  = 18   -- tamanho do ícone
    local GAP     = 5    -- espaço entre ícone e texto, e entre itens
    local TXT_OFF = 2    -- offset Y p/ centralizar texto (~14px) com ícone (18px): (18-14)/2 = 2

    -- Linha objetivos: y + 50
    local curX = PAD_L
    local objY = y + 50
    if m.objectives.kills and m.objectives.kills > 0 then
        local killTxt = "Kills: " .. m.objectives.kills .. "  "
        this:drawText(killTxt, curX, objY + TXT_OFF, 0.65, 0.78, 1, 1, BFONT)
        curX = curX + tm2:MeasureStringX(BFONT, killTxt) + GAP
    end
    if m.objectives.items then
        for _, it in ipairs(m.objectives.items) do
            if curX >= PAD_L + textAreaW then break end
            local tex = TsT.getItemIconTexture(it.name)
            if tex then
                this:drawTextureScaled(tex, curX, objY, ICON_S, ICON_S, 1, 1, 1, 1)
                curX = curX + ICON_S + GAP
            end
            local itTxt = TsT.getItemDisplayName(it.name) .. " x" .. it.count
            this:drawText(itTxt, curX, objY + TXT_OFF, 0.65, 0.78, 1, 1, BFONT)
            curX = curX + tm2:MeasureStringX(BFONT, itTxt) + GAP * 3
        end
    end

    -- Linha recompensa dinheiro/fama: y + 76
    local recTxt = (m.rewards.money or 0) .. " Tamp.  |  +" .. (m.rewards.fame or 0) .. " fama"
    this:drawText(recTxt, PAD_L, y + 76, 0.9, 0.78, 0.2, 1, BFONT)

    -- Linha recompensa itens: y + 98
    if m.rewards.items and #m.rewards.items > 0 then
        local rcX = PAD_L
        local rcY = y + 98
        this:drawText("+", rcX, rcY + TXT_OFF, 0.7, 0.9, 0.7, 1, BFONT)
        rcX = rcX + tm2:MeasureStringX(BFONT, "+ ") + GAP
        for _, ri in ipairs(m.rewards.items) do
            if rcX >= PAD_L + textAreaW then break end
            local tex = TsT.getItemIconTexture(ri.type)
            if tex then
                this:drawTextureScaled(tex, rcX, rcY, ICON_S, ICON_S, 1, 1, 1, 1)
                rcX = rcX + ICON_S + GAP
            end
            local riTxt = TsT.getItemDisplayName(ri.type) .. (ri.count > 1 and " x"..ri.count or "")
            this:drawText(riTxt, rcX, rcY + TXT_OFF, 0.7, 0.9, 0.7, 1, BFONT)
            rcX = rcX + tm2:MeasureStringX(BFONT, riTxt) + GAP * 3
        end
    end

    -- ── Botão virtual: centralização precisa via MeasureString ─
    if item.item.concluida then
        this:drawRect(bX, bY, bW, bH, 1, 0.12, 0.12, 0.12)
        this:drawRectBorder(bX, bY, bW, bH, 1, 0.28, 0.28, 0.28)
        drawBtnText("CONCLUIDA", BFONT, bX, bY, bW, bH, 0.45, 0.45, 0.45)
    elseif item.item.ativa then
        this:drawRect(bX, bY, bW, bH, 1, 0.04, 0.38, 0.04)
        this:drawRectBorder(bX, bY, bW, bH, 1, 0.1, 0.75, 0.1)
        drawBtnText("EM ANDAMENTO", BFONT, bX, bY, bW, bH, 0.2, 1, 0.2)
    else
        this:drawRect(bX, bY, bW, bH, 1, 0.04, 0.30, 0.50)
        this:drawRectBorder(bX, bY, bW, bH, 1, 0.08, 0.60, 0.90)
        drawBtnText("ACEITAR", BFONT, bX, bY, bW, bH, 1, 1, 1)
    end

    return y + item.height
end

function TsT_MissionBoard.onMissionMouseDown(this, x, y)
    local row = this:rowAt(x, y)
    if row == -1 then return end
    local item = this.items[row]
    if not item then return end

    local bW = 150
    local bX = this:getWidth() - bW - 14
    if x < bX then return end

    local m = item.item.mission
    if item.item.concluida or item.item.ativa then return end

    local player = getPlayer()
    if not player then return end
    local pos = TsT.getModData(player)
    local isDaily = m.id:sub(1, 6) == "daily_"

    if isDaily then
        if pos.activeDailyMission then
            halo(player, "Você já tem uma missão diária ativa.", 255, 150, 50)
            return
        end
    else
        if pos.activeMission then
            halo(player, "Você já tem uma missão ativa.", 255, 150, 50)
            return
        end
    end

    if isClient() then
        sendClientCommand(player, "TsT", "acceptMission", { missionId = m.id })
    else
        local ok, msg = TsT.MissionManager.aceitarMissao(player, m.id)
        if not ok then
            halo(player, msg or "Não foi possível aceitar a missão.", 255, 150, 50)
        end
    end
end

-- ============================================================
-- ABA 3 — LOJA
-- ============================================================
function TsT_MissionBoard:renderAbaLoja(cp, x, y, w, h)
    if TsT_Shop then
        TsT_Shop:renderInto(cp, x, y, w, h)
    else
        local msg = ISLabel:new(w/2, y+h/2, 18, "Módulo de loja não carregado.", 0.7, 0.2, 0.2, 1, UIFont.Small, true)
        msg:setX(msg:getX() - msg:getWidth()/2)
        cp:addChild(msg)
    end
end

-- ============================================================
-- ABA 4 — STATUS
-- ============================================================
function TsT_MissionBoard:renderAbaStatus(cp, x, y, w, h)
    local player = getPlayer()
    if not player then return end
    local pos = TsT.getModData(player)

    local faccao     = pos.faction and TsT.getFactionById(pos.faction)
    local cor        = faccao and faccao.cor or { r=0.7, g=0.7, b=0.7 }
    local nomeFaccao = faccao and faccao.nome or "Nenhuma"
    local py         = y + 14

    local function lblAdd(text, r, g, b, font)
        local l = ISLabel:new(20, py, 20, text, r, g, b, 1, font or UIFont.Medium, true)
        cp:addChild(l)
        py = py + (font == UIFont.Large and 34 or font == UIFont.Small and 20 or 28)
    end

    lblAdd("Jogador: " .. player:getUsername(), 1, 1, 1, UIFont.Large)
    lblAdd("Grupo: " .. nomeFaccao, cor.r, cor.g, cor.b)
    lblAdd("Tampinhas: " .. (pos.money or 0), C_GREEN.r, C_GREEN.g, C_GREEN.b)

    py = py + 6

    -- ── Barra de progresso de fama ────────────────────────────
    if pos.faction then
        local fama      = (pos.fame and pos.fame[pos.faction]) or 0
        local nivel, nm = TsT.getNivelFama(fama)
        local proxLvl   = TsT.FameLevels[nivel + 1]
        local atualLvl  = TsT.FameLevels[nivel]
        local fameMin   = atualLvl and atualLvl.fameMin or 0

        -- Label do nível atual e próximo
        local lblNivel = ISLabel:new(16, py, 18,
            "Nivel: " .. nm .. (proxLvl and ("  >>  " .. proxLvl.nome) or "  [NIVEL MAXIMO]"),
            C_GOLD.r, C_GOLD.g, C_GOLD.b, 1, UIFont.Small, true)
        cp:addChild(lblNivel)
        py = py + 20

        -- Barra de fama (altura 26px para texto Small caber com margem)
        local barW = w - 32
        local barH = 26

        -- Fundo da barra
        local barBg = ISPanel:new(16, py, barW, barH)
        barBg.backgroundColor = { r=0.10, g=0.10, b=0.12, a=1 }
        barBg.borderColor     = { r=0.35, g=0.35, b=0.35, a=1 }
        barBg:initialise()
        cp:addChild(barBg)

        -- Preenchimento da barra
        local pct = 0
        if proxLvl then
            local range = proxLvl.fameMin - fameMin
            if range > 0 then
                pct = math.min(1.0, (fama - fameMin) / range)
            end
        else
            pct = 1.0  -- nível máximo: barra cheia
        end

        local fillW = math.max(0, math.floor((barW - 2) * pct))
        if fillW > 0 then
            -- Gradiente de cor: cinza (início) → dourado (fim)
            local barFill = ISPanel:new(1, 1, fillW, barH - 2)
            barFill.backgroundColor = {
                r = 0.40 + 0.55 * pct,
                g = 0.30 + 0.50 * pct,
                b = 0.05,
                a = 1
            }
            barFill.borderColor = barFill.backgroundColor
            barFill:initialise()
            barBg:addChild(barFill)
        end

        -- Texto dentro da barra: filho do barBg para coordenadas relativas
        local pctInt = math.floor(pct * 100)
        local barTxt
        if proxLvl then
            barTxt = fama .. " / " .. proxLvl.fameMin .. " fama  (" .. pctInt .. "%)"
        else
            barTxt = fama .. " fama  [NIVEL MAXIMO]"
        end
        local tm2   = getTextManager()
        local lblW  = tm2:MeasureStringX(UIFont.Small, barTxt)
        local fontH = tm2:MeasureStringY(UIFont.Small, barTxt)
        -- Centraliza horizontal e verticalmente dentro da barra
        local lblX = math.floor((barW - lblW) / 2)
        local lblY = math.floor((barH - fontH) / 2)
        local barLbl = ISLabel:new(lblX, lblY, barH, barTxt, 1, 1, 1, 1, UIFont.Small, true)
        barLbl:initialise()
        barBg:addChild(barLbl)  -- filho do barBg → coordenadas relativas à barra

        py = py + barH + 12
    end

    -- Separador
    local sep = ISPanel:new(10, py, w - 20, 1)
    sep.backgroundColor = { r=0.3, g=0.3, b=0.3, a=0.8 }
    sep.borderColor     = sep.backgroundColor
    sep:initialise()
    cp:addChild(sep)
    py = py + 12

    local comp = pos.completedMissions or {}
    local n = 0; for _ in pairs(comp) do n = n + 1 end
    lblAdd("Missoes concluidas: " .. n, 0.8, 0.8, 0.8, UIFont.Small)

    if pos.activeMission then
        local m = TsT.getMissionById(pos.activeMission)
        lblAdd("Missao ativa: " .. (m and m.title or pos.activeMission), 0.4, 1.0, 0.4, UIFont.Small)
    else
        lblAdd("Missao ativa: Nenhuma", 0.5, 0.5, 0.5, UIFont.Small)
    end

    -- ── Botão Abandonar Facção (só aparece se sandbox habilitado) ──
    local sb = SandboxVars
    if pos.faction and sb and sb.TsT_AllowLeaveFaction then
        py = py + 14

        -- Separador vermelho
        local sepL = ISPanel:new(10, py, w - 20, 1)
        sepL.backgroundColor = { r=0.55, g=0.05, b=0.05, a=0.8 }
        sepL.borderColor     = sepL.backgroundColor
        sepL:initialise()
        cp:addChild(sepL)
        py = py + 8

        local btnLvW = 220
        local btnLv = ISButton:new(math.floor((w - btnLvW) / 2), py, btnLvW, 34,
            "ABANDONAR GRUPO", self, function(selfBtn)
                TsT_MissionBoard.mostrarConfirmAbandonar()
            end)
        btnLv.backgroundColor = { r=0.40, g=0.04, b=0.04, a=1 }
        btnLv.borderColor     = { r=0.80, g=0.08, b=0.08, a=1 }
        btnLv:initialise()
        cp:addChild(btnLv)
    end
end

-- ------------------------------------------------------------
-- MODAL DE CONFIRMAÇÃO — Abandonar Facção
-- ------------------------------------------------------------
function TsT_MissionBoard.mostrarConfirmAbandonar()
    -- Evita duplicatas
    if TsT_MissionBoard._confirmModal and TsT_MissionBoard._confirmModal.javaObject then
        return
    end

    local MW = 460
    local MH = 200
    local sw = getCore():getScreenWidth()
    local sh = getCore():getScreenHeight()

    local modal = ISPanel:new(math.floor((sw - MW)/2), math.floor((sh - MH)/2), MW, MH)
    modal.backgroundColor = { r=0.08, g=0.05, b=0.05, a=0.98 }
    modal.borderColor     = { r=0.75, g=0.10, b=0.10, a=1 }
    modal:initialise()
    modal:addToUIManager()
    modal:bringToTop()
    TsT_MissionBoard._confirmModal = modal

    -- Título
    local tm3  = getTextManager()
    local tit  = "ABANDONAR GRUPO"
    local titW = tm3:MeasureStringX(UIFont.Large, tit)
    local lblTit = ISLabel:new(math.floor((MW - titW)/2), 16, 22, tit,
        0.95, 0.20, 0.10, 1, UIFont.Large, true)
    modal:addChild(lblTit)

    -- helper: label centralizado horizontalmente no modal
    local function centeredLbl(text, yPos, lineH, r, g, b, font)
        font = font or UIFont.Small
        local lw = tm3:MeasureStringX(font, text)
        local lbl = ISLabel:new(math.floor((MW - lw) / 2), yPos, lineH, text, r, g, b, 1, font, true)
        modal:addChild(lbl)
    end

    -- Aviso linha 1
    centeredLbl("Voce ira PERDER TODO o seu progresso:", 56, 16, 1, 0.85, 0.85)

    -- Aviso linha 2
    centeredLbl("Fama, Tampinhas, Missoes concluidas e Loja", 74, 16, 0.85, 0.50, 0.50)

    -- Aviso linha 3
    centeredLbl("Esta acao NAO pode ser desfeita!", 96, 16, 0.95, 0.30, 0.10)

    local function fecharModal()
        if TsT_MissionBoard._confirmModal then
            TsT_MissionBoard._confirmModal:removeFromUIManager()
            TsT_MissionBoard._confirmModal = nil
        end
    end

    -- Botão SIM, ABANDONAR
    local btnConf = ISButton:new(40, MH - 52, 170, 34, "SIM, ABANDONAR", modal,
        function()
            fecharModal()
            local player = getPlayer()
            if not player then return end

            if isClient() then
                sendClientCommand(player, "TsT", "leaveFaction", {})
            else
                TsT.FactionManager.leaveFaction(player)
            end
        end)
    btnConf.backgroundColor = { r=0.50, g=0.04, b=0.04, a=1 }
    btnConf.borderColor     = { r=0.90, g=0.10, b=0.10, a=1 }
    btnConf:initialise()
    modal:addChild(btnConf)

    -- Botão CANCELAR
    local btnCanc = ISButton:new(MW - 210, MH - 52, 170, 34, "CANCELAR", modal,
        function() fecharModal() end)
    btnCanc.backgroundColor = { r=0.12, g=0.12, b=0.14, a=1 }
    btnCanc.borderColor     = { r=0.40, g=0.40, b=0.40, a=1 }
    btnCanc:initialise()
    modal:addChild(btnCanc)
end

-- ============================================================
-- ABA 5 — RANKING
-- ============================================================
function TsT_MissionBoard:renderAbaRanking(cp, x, y, w, h)
    local player = getPlayer()
    if not player then return end
    local pos = TsT.getModData(player)

    if not pos.faction then
        local msg = ISLabel:new(w/2, y+h/2, 18, "Escolha um grupo primeiro.", 0.7, 0.5, 0.2, 1, UIFont.Small, true)
        msg:setX(msg:getX() - msg:getWidth()/2)
        cp:addChild(msg)
        return
    end

    local faccao = TsT.getFactionById(pos.faction)
    local cor    = faccao and faccao.cor or { r=1, g=1, b=1 }

    -- Cabeçalho
    local hdr = ISLabel:new(10, y+4, 18,
        "Top Ranking — " .. (faccao and faccao.nome or pos.faction),
        cor.r, cor.g, cor.b, 1, UIFont.Medium, true)
    cp:addChild(hdr)

    if not rankingCache or rankingCache.factionId ~= pos.faction then
        local wait = ISLabel:new(w/2, y+h/2, 16, "Carregando ranking...", 0.5, 0.5, 0.5, 1, UIFont.Small, true)
        wait:setX(wait:getX() - wait:getWidth()/2)
        cp:addChild(wait)
        return
    end

    local lista   = rankingCache.ranking or {}
    local myName  = player:getUsername()
    local myPos   = -1
    for i, entry in ipairs(lista) do
        if entry.username == myName then myPos = i; break end
    end

    -- Lista de ranking
    local scroll = ISScrollingListBox:new(4, y+24, w-8, h-32)
    scroll:initialise()
    scroll:setAnchorRight(true)
    scroll:setAnchorBottom(true)
    scroll.itemheight      = 30
    scroll.drawBorder      = true
    scroll.borderColor     = C_BORDER
    scroll.backgroundColor = { r=0, g=0, b=0, a=0.35 }
    scroll.doDrawItem = function(this, ry, item, alt)
        if not item.height then item.height = this.itemheight end
        local d  = item.item
        local rw = this:getWidth()

        local isMe = d.isMe
        if isMe then
            this:drawRect(0, ry, rw, item.height, 0.5, 0.15, 0.55, 0.15)
        elseif alt then
            this:drawRect(0, ry, rw, item.height, 0.07, 0.7, 0.7, 0.7)
        else
            this:drawRect(0, ry, rw, item.height, 0.10, 0.05, 0.05, 0.05)
        end
        this:drawRectBorder(0, ry, rw, item.height, 0.4, 0.25, 0.25, 0.25)

        -- Medalha top 3
        local mr, mg, mb = 0.8, 0.8, 0.8
        local posTxt = ""
        if d.pos == 1 then 
            posTxt = "1st"
            mr, mg, mb = 1.0, 0.85, 0.1
        elseif d.pos == 2 then 
            posTxt = "2nd"
            mr, mg, mb = 0.75, 0.75, 0.75
        elseif d.pos == 3 then 
            posTxt = "3rd" 
            mr, mg, mb = 0.8, 0.5, 0.2 
        elseif d.pos ~= "" then
            posTxt = "#" .. d.pos
        end

        this:drawText(posTxt, 6, ry+7, mr, mg, mb, 1, UIFont.Small)
        this:drawText(d.username, 40, ry+7, isMe and 0.4 or 0.9, isMe and 1.0 or 0.9, isMe and 0.4 or 0.9, 1, UIFont.Small)
        this:drawText(d.fama .. " fama", rw-100, ry+7, C_GOLD.r, C_GOLD.g, C_GOLD.b, 1, UIFont.Small)

        return ry + item.height
    end
    cp:addChild(scroll)

    -- Adiciona top 20
    local top = math.min(20, #lista)
    for i = 1, top do
        local e = lista[i]
        scroll:addItem(e.username, { pos=i, username=e.username, fama=e.fama, isMe=(e.username==myName) })
    end

    -- Se o jogador está fora do top 20, adiciona ao final da lista de forma integrada
    if myPos > 20 then
        scroll:addItem("separator", { pos="", username="...", fama="", isMe=false })
        local myEntry = lista[myPos]
        if myEntry then
            scroll:addItem(myEntry.username, { pos=myPos, username=myEntry.username, fama=myEntry.fama, isMe=true })
        end
    end
end

-- ============================================================
-- ABA 6 — EVENTO GLOBAL
-- ============================================================
function TsT_MissionBoard:renderAbaEvento(cp, x, y, w, h)
    local player = getPlayer()
    if not player then return end
    local pos = TsT.getModData(player)

    if not pos.faction then
        local msg = ISLabel:new(w/2, y+h/2, 18, "Escolha um grupo primeiro.", 0.7, 0.5, 0.2, 1, UIFont.Small, true)
        msg:setX(msg:getX() - msg:getWidth()/2)
        cp:addChild(msg)
        return
    end

    if not eventoCache then
        local wait = ISLabel:new(w/2, y+h/2, 16, "Carregando evento...", 0.5, 0.5, 0.5, 1, UIFont.Small, true)
        wait:setX(wait:getX() - wait:getWidth()/2)
        cp:addChild(wait)
        return
    end

    local evDef    = eventoCache.eventDef   or {}
    local progress = eventoCache.progress   or { kills=0, items={} }
    local complete = eventoCache.completed  or false
    local faccao   = TsT.getFactionById(pos.faction)
    local cor      = faccao and faccao.cor or { r=1, g=1, b=1 }
    local py       = y + 10

    -- Título do evento
    local lblTit = ISLabel:new(10, py, 24, evDef.title or "Evento Global", cor.r, cor.g, cor.b, 1, UIFont.Large, true)
    cp:addChild(lblTit)
    py = py + 32

    if complete then
        local cooldownR = eventoCache.cooldownRestante or 0
        local cooldownH = eventoCache.cooldownTotal and (eventoCache.cooldownTotal / 3600) or 24
        local compMsg   = "EVENTO CONCLUIDO! Proximo ciclo em "
        if cooldownR > 0 then
            local hRest = math.ceil(cooldownR / 3600)
            compMsg = compMsg .. hRest .. "h"
        else
            compMsg = compMsg .. "breve..."
        end
        py = addWrappedLabel(cp, compMsg, 10, py, w - 20, C_GREEN.r, C_GREEN.g, C_GREEN.b, UIFont.Medium)
        py = py + 8
        local lblCd = ISLabel:new(10, py, 16,
            "Cooldown configurado: " .. cooldownH .. "h (sandbox TsT_EventCooldownHours)",
            0.5, 0.5, 0.5, 1, UIFont.Small, true)
        cp:addChild(lblCd)
        return
    end

    -- Descrição (com wrap automático)
    py = addWrappedLabel(cp, evDef.description or "", 10, py, w - 20, 0.72, 0.72, 0.72, UIFont.Small)
    py = py + 6

    -- Recompensa
    local recTxt = "Recompensa: " .. (evDef.rewards and evDef.rewards.money or 0) ..
        " Tamp. | +" .. (evDef.rewards and evDef.rewards.fame or 0) .. " fama"
    py = addWrappedLabel(cp, recTxt, 10, py, w - 20, C_GOLD.r, C_GOLD.g, C_GOLD.b, UIFont.Small)
    py = py + 4

    -- Separador
    local sep1 = ISPanel:new(6, py, w-12, 1)
    sep1.backgroundColor = { r=0.3, g=0.3, b=0.3, a=0.7 }
    sep1.borderColor = sep1.backgroundColor
    sep1:initialise()
    cp:addChild(sep1)
    py = py + 10

    -- Progresso de kills
    local goal = evDef.goal or {}
    if (evDef.type == "KILL" or evDef.type == "MIXED") and goal.kills and goal.kills > 0 then
        local kills  = progress.kills or 0
        local pct    = math.min(1, kills / goal.kills)
        local barW   = w - 24
        local barH   = 18

        local lblKill = ISLabel:new(10, py, 16,
            "Kills do grupo: " .. kills .. " / " .. goal.kills,
            1, 0.8, 0.2, 1, UIFont.Small, true)
        cp:addChild(lblKill)
        py = py + 18

        -- Barra de progresso
        local barBg = ISPanel:new(10, py, barW, barH)
        barBg.backgroundColor = { r=0.15, g=0.15, b=0.15, a=1 }
        barBg.borderColor     = { r=0.3, g=0.3, b=0.3, a=1 }
        barBg:initialise()
        cp:addChild(barBg)

        local barFill = ISPanel:new(0, 0, math.max(4, math.floor(barW * pct)), barH)
        barFill.backgroundColor = { r=0.7, g=0.2, b=0.1, a=1 }
        barFill.borderColor     = barFill.backgroundColor
        barFill:initialise()
        barBg:addChild(barFill)

        py = py + barH + 8
    end

    -- Progresso de itens
    if (evDef.type == "LOOT" or evDef.type == "MIXED") and goal.items then
        local lblItems = ISLabel:new(10, py, 16, "Itens depositados:", 0.4, 0.8, 1, 1, UIFont.Small, true)
        cp:addChild(lblItems)
        py = py + 18

        for _, req in ipairs(goal.items) do
            local curr  = (progress.items and progress.items[req.name]) or 0
            local pct   = math.min(1, curr / req.count)
            local barW  = w - 24
            local barH   = 14
            local ICON_S = 20   -- ícone maior para melhor visibilidade
            local GAP    = 6    -- espaço entre ícone e texto
            local TXT_OFF = 4   -- centraliza texto (~12px) no ícone (20px)

            -- Painel ícone + label de progresso do evento
            local evRow = ISPanel:new(10, py, barW, ICON_S)
            evRow.backgroundColor = { r=0, g=0, b=0, a=0 }
            evRow.borderColor     = { r=0, g=0, b=0, a=0 }
            evRow._icon  = TsT.getItemIconTexture(req.name)
            evRow._nome  = TsT.getItemDisplayName(req.name)
            evRow._curr  = curr
            evRow._total = req.count
            evRow.render = function(this)
                if this._icon then
                    this:drawTextureScaled(this._icon, 0, 0, ICON_S, ICON_S, 1, 1, 1, 1)
                end
                this:drawText(this._nome .. ": " .. this._curr .. "/" .. this._total,
                    ICON_S + GAP, TXT_OFF, 0.75, 0.75, 0.75, 1, UIFont.Small)
            end
            evRow:initialise()
            cp:addChild(evRow)
            py = py + ICON_S + 4  -- espaço generoso entre linhas

            local barBg = ISPanel:new(10, py, barW, barH)
            barBg.backgroundColor = { r=0.12, g=0.12, b=0.12, a=1 }
            barBg.borderColor     = { r=0.25, g=0.25, b=0.25, a=1 }
            barBg:initialise()
            cp:addChild(barBg)

            local barFill = ISPanel:new(0, 0, math.max(4, math.floor(barW * pct)), barH)
            barFill.backgroundColor = { r=0.1, g=0.45, b=0.65, a=1 }
            barFill.borderColor     = barFill.backgroundColor
            barFill:initialise()
            barBg:addChild(barFill)
            py = py + barH + 6
        end

        -- Botão DEPOSITAR
        py = py + 4
        local btnDepLabel = getText("UI_TsT_Shop_DepositItems") or "DEPOSITAR ITENS DO INVENTARIO"
        local btnDep = ISButton:new(10, py, 200, 34, btnDepLabel, self,
            function(self)
                local p = getPlayer()
                if not p then return end
                local ev = eventoCache
                if not ev or not ev.eventDef or not ev.eventDef.goal then return end
                local deps = {}
                local inv = p:getInventory()
                for _, req in ipairs(ev.eventDef.goal.items or {}) do
                    local n = TsT.getItemCount(inv, req.name)
                    if n > 0 then
                        table.insert(deps, { name=req.name, count=n })
                    end
                end
                if #deps == 0 then
                    halo(p, "Você não tem itens do evento no inventário!", 255, 150, 50)
                    return
                end
                if isClient() then
                    sendClientCommand(p, "TsT", "depositEventItems", { depositos=deps })
                else
                    -- Single Player: chama diretamente o manager (que roda localmente)
                    if TsT.EventManager and TsT.EventManager.depositarItens then
                        TsT.EventManager.depositarItens(p, deps)
                        if TsT_MissionBoard.instance then
                            TsT_MissionBoard.instance:refresh()
                        end
                    end
                end
            end)
        btnDep.backgroundColor = { r=0.05, g=0.3, b=0.55, a=1 }
        btnDep.borderColor     = { r=0.1, g=0.6, b=0.9, a=1 }
        btnDep:initialise()
        cp:addChild(btnDep)

        -- ── Botão administrativo para resetar evento (admin/moderator) ──
        local access = player:getAccessLevel()
        if access == "admin" or access == "moderator" then
            local btnReset = ISButton:new(w - 160, py, 150, 34, "RESETAR EVENTO", self, function(self)
                if isClient() then
                    sendClientCommand(player, "TsT", "resetEvent", { factionId = pos.faction })
                else
                    TsT.EventManager.resetarEvento(pos.faction)
                    if TsT_MissionBoard.instance then
                        TsT_MissionBoard.instance:refresh()
                    end
                end
            end)
            btnReset.backgroundColor = { r=0.5, g=0.1, b=0.1, a=1 }
            btnReset.borderColor     = { r=0.9, g=0.2, b=0.2, a=1 }
            btnReset:initialise()
            cp:addChild(btnReset)
        end
    end
end
