-- ============================================================
-- TsT_UI_Shop.lua — Loja por Facção
-- Mod: The Survival Triade | Build 42
-- Renderizado dentro da aba "Loja" do TsT_MissionBoard
-- ============================================================

require "ISUI/ISScrollingListBox"
require "ISUI/ISLabel"
require "ISUI/ISPanel"

TsT_Shop = TsT_Shop or {}
TsT_Shop.selectedTier = TsT_Shop.selectedTier or 1

-- ------------------------------------------------------------
-- UTILITÁRIO: HaloText seguro (compatível B42)
-- ------------------------------------------------------------
local function halo(player, text, r, g, b)
    if player and player.HaloText then
        player:HaloText(text, r or 255, g or 255, b or 255)
    end
end

-- ------------------------------------------------------------
-- CORES
-- ------------------------------------------------------------
local C_GOLD   = { r=0.95, g=0.80, b=0.20, a=1.0 }
local C_GREEN  = { r=0.20, g=0.80, b=0.20, a=1.0 }
local C_RED    = { r=0.80, g=0.20, b=0.10, a=1.0 }
local C_GRAY   = { r=0.40, g=0.40, b=0.40, a=1.0 }

-- ------------------------------------------------------------
-- PONTO DE ENTRADA — Renderiza a loja dentro de um painel pai
-- Chamado por TsT_UI_MissionBoard:renderAbaLoja()
---@param parentPanel ISCollapsableWindow painel pai
---@param x number
---@param y number
---@param w number
---@param h number
-- ------------------------------------------------------------
function TsT_Shop:renderInto(parentPanel, x, y, w, h)
    local player = getPlayer()
    if not player then return end
    local pos = TsT.getModData(player)

    if not pos.faction then
        local msg = ISLabel:new(w/2, y + h/2 - 10, 18, "Escolha uma facção para acessar a loja.", 0.7, 0.5, 0.2, 1, UIFont.Small, true)
        msg:setX(msg:getX() - msg:getWidth()/2)
        parentPanel:addChild(msg)
        return
    end

    local fama    = (pos.fame and pos.fame[pos.faction]) or 0
    local faccao  = TsT.getFactionById(pos.faction)
    local cor     = faccao and faccao.cor or { r=0.7, g=0.7, b=0.7 }
    local nivel,_ = TsT.getNivelFama(fama)

    -- Cabeçalho Superior
    local hdr = ISLabel:new(10, y + 2, 18,
        (faccao and faccao.nome or pos.faction) .. " | Tampinhas: " .. (pos.money or 0),
        cor.r, cor.g, cor.b, 1, UIFont.Medium, true)
    parentPanel:addChild(hdr)

    -- ────────────────────────────────────────────────────────────
    -- ABAS DE TIER (Filtro)
    -- ────────────────────────────────────────────────────────────
    local btnW = math.floor((w - 20) / 5)
    local btnH = 24
    local btnY = y + 26

    for i = 1, 5 do
        local label = "TIER " .. i
        local isSelected = (TsT_Shop.selectedTier == i)
        local btn = ISButton:new(10 + (i-1)*btnW, btnY, btnW - 2, btnH, label, nil, function()
            TsT_Shop.selectedTier = i
            if TsT_MissionBoard.instance then
                TsT_MissionBoard.instance:refresh()
            end
        end)
        
        btn.borderColor = { r=0.4, g=0.4, b=0.4, a=1 }
        if isSelected then
            btn.backgroundColor = { r=cor.r*0.6, g=cor.g*0.6, b=cor.b*0.6, a=1.0 }
            btn.textColor = { r=1, g=1, b=1, a=1 }
        else
            btn.backgroundColor = { r=0.1, g=0.1, b=0.1, a=0.8 }
            btn.textColor = { r=0.6, g=0.6, b=0.6, a=1 }
            -- Se o player ainda não abriu esse tier, escurece mais
            if i > nivel then
                btn.textColor = { r=0.4, g=0.2, b=0.2, a=1 }
                btn.borderColor = { r=0.3, g=0.1, b=0.1, a=1 }
            end
        end

        btn:initialise()
        parentPanel:addChild(btn)
    end

    -- Lista de itens da loja
    local listaY = btnY + btnH + 6
    local lista = ISScrollingListBox:new(4, listaY, w-8, h - (listaY - y) - 4)
    lista:initialise()
    lista:setAnchorRight(true)
    lista:setAnchorBottom(true)
    lista.itemheight      = 78
    lista.drawBorder      = true
    lista.borderColor     = { r=0.3, g=0.3, b=0.3, a=1 }
    lista.backgroundColor = { r=0, g=0, b=0, a=0.4 }
    lista.doDrawItem      = TsT_Shop.drawShopItem
    lista.onMouseDown     = TsT_Shop.onShopMouseDown
    parentPanel:addChild(lista)

    local itensTudo = TsT.getItensLoja(pos.faction, fama)
    local money = pos.money or 0
    local countItens = 0

    for _, shopItem in ipairs(itensTudo) do
        -- Filtra pelo Tier selecionado
        if shopItem.tierMin == TsT_Shop.selectedTier then
            local podeComprar = money >= shopItem.preco
            lista:addItem(shopItem.nome, { shopItem=shopItem, podeComprar=podeComprar })
            countItens = countItens + 1
        end
    end

    if countItens == 0 then
        local msg2 = ISLabel:new(w/2, listaY + 20, 18, "Nenhum item disponível para o Tier " .. TsT_Shop.selectedTier, 0.6, 0.6, 0.6, 1, UIFont.Small, true)
        msg2:setX(msg2:getX() - msg2:getWidth()/2)
        parentPanel:addChild(msg2)
    end
end

-- ------------------------------------------------------------
-- RENDERIZAÇÃO DE ITEM DA LOJA
-- ------------------------------------------------------------
function TsT_Shop.drawShopItem(this, y, item, alt)
    if not item.height then item.height = this.itemheight end

    local si          = item.item.shopItem
    local podeComprar = item.item.podeComprar
    local W           = this:getWidth()

    -- Fundo zebrado
    if this.selected == item.index then
        this:drawRect(0, y, W, item.height, 0.3, 0.2, 0.3, 0.25)
    elseif alt then
        this:drawRect(0, y, W, item.height, 0.08, 0.8, 0.8, 0.8)
    else
        this:drawRect(0, y, W, item.height, 0.1, 0.05, 0.05, 0.05)
    end
    this:drawRectBorder(0, y, W, item.height, 0.5, 0.25, 0.25, 0.25)

    -- Badge de tier
    local badgeCores = {
        [1]={r=0.3,g=0.3,b=0.3}, [2]={r=0.1,g=0.3,b=0.6},
        [3]={r=0.1,g=0.5,b=0.2}, [4]={r=0.5,g=0.3,b=0.0},
        [5]={r=0.5,g=0.0,b=0.5},
    }
    local bc = badgeCores[si.tierMin] or badgeCores[1]
    this:drawRect(0, y, 5, item.height, 1, bc.r, bc.g, bc.b)

    -- ── Layout: botão à direita, preço abaixo do botão ────────
    local btnW = 110
    local btnH = 28
    local btnX = W - btnW - 10
    local btnY = y + 10   -- topo do botão alinhado ao topo do conteúdo

    -- Área de texto (não invade botão)
    local textAreaW = btnX - 14 - 8  -- bX - paddingLeft - margem

    local tm    = getTextManager()
    local nr, ng, nb = 1, 1, 1
    if not podeComprar then nr, ng, nb = 0.5, 0.5, 0.5 end

    -- Nome do item (truncado se necessário)
    local nome = si.nome
    while #nome > 4 and tm:MeasureStringX(UIFont.Medium, nome) > textAreaW do
        nome = nome:sub(1, -2)
    end
    if nome ~= si.nome then nome = nome .. "..." end
    this:drawText(nome, 14, y + 8, nr, ng, nb, 1, UIFont.Medium)

    -- ID e quantidade
    local idSimples = si.itemType:match("%.(.+)") or si.itemType
    local idTxt = "ID: " .. idSimples .. (si.count > 1 and "  x" .. si.count or "")
    this:drawText(idTxt, 14, y + 30, 0.6, 0.6, 0.6, 1, UIFont.Small)

    -- Tier mínimo
    this:drawText("Tier min: " .. si.tierMin, 14, y + 48, 0.6, 0.7, 0.9, 1, UIFont.Small)

    -- ── Botão COMPRAR: centralização precisa com MeasureStringY ──
    local fontH   = tm:MeasureStringY(UIFont.Small, "A")    -- altura real da fonte
    local btnCX   = btnX + math.floor(btnW / 2)             -- centro horizontal do botão
    local btnTxtY = btnY + math.floor((btnH - fontH) / 2)   -- topo do texto para ficar centrado
    if podeComprar then
        this:drawRect(btnX, btnY, btnW, btnH, 1, 0.04, 0.38, 0.04)
        this:drawRectBorder(btnX, btnY, btnW, btnH, 1, 0.08, 0.72, 0.08)
        this:drawTextCentre("COMPRAR", btnCX, btnTxtY, 1, 1, 1, 1, UIFont.Small)
    else
        this:drawRect(btnX, btnY, btnW, btnH, 1, 0.18, 0.18, 0.18)
        this:drawRectBorder(btnX, btnY, btnW, btnH, 1, 0.30, 0.30, 0.30)
        this:drawTextCentre("COMPRAR", btnCX, btnTxtY, 0.40, 0.40, 0.40, 1, UIFont.Small)
    end

    -- ── Preço abaixo do botão, centralizado horizontalmente ───
    local precoY   = btnY + btnH + 6
    local precoTxt = si.preco .. " Tampinhas"
    local pr, pg, pb = podeComprar and 0.95 or 0.45, podeComprar and 0.82 or 0.42, podeComprar and 0.18 or 0.10
    this:drawTextCentre(precoTxt, btnCX, precoY, pr, pg, pb, 1, UIFont.Small)

    return y + item.height
end

-- ------------------------------------------------------------
-- CLIQUE NO ITEM DA LOJA
-- ------------------------------------------------------------
function TsT_Shop.onShopMouseDown(this, x, y)
    local row = this:rowAt(x, y)
    if row == -1 then return end
    local item = this.items[row]
    if not item then return end

    local btnW = 110
    local btnX = this:getWidth() - btnW - 10
    if x < btnX then return end

    local si          = item.item.shopItem
    local podeComprar = item.item.podeComprar

    local player = getPlayer()
    if not player then return end

    if not podeComprar then
        halo(player, "Tampinhas insuficientes! Custo: " .. si.preco, 255, 100, 100)
        return
    end

    if isClient() then
        sendClientCommand(player, "TsT", "buyItem", { shopItemId = si.id })
        halo(player, "Processando compra...", 200, 200, 100)
    else
        local ok, msg = TsT.MissionManager.comprarItem(player, si.id)
        if not ok then
            halo(player, msg or "Não foi possível concluir a compra.", 255, 100, 100)
        end
    end
end
