-- ============================================================
-- TsT_Factions.lua — Definicoes de Faccoes (Survival Triade)
-- Mod: The Survival Triade | Build 42
-- ============================================================

TsT = TsT or {}

-- Normaliza IDs de faccao (compatibilidade com saves antigos)
TsT.normalizeFactionId = TsT.normalizeFactionId or function(id)
    if id == "mercenary" then return "combatants" end
    if id == "outlaw" then return "survivors" end
    if id == "survivor" then return "specialists" end
    return id
end

TsT.Factions = {}
TsT.FameLevels = {}

-- ------------------------------------------------------------
-- NIVEIS DE FAMA (compartilhado entre todas as faccoes)
-- ------------------------------------------------------------
TsT.FameLevels = {
    { nivel = 1, nome = "Recruta",  fameMin = 0    },
    { nivel = 2, nome = "Agente",   fameMin = 150  },
    { nivel = 3, nome = "Veterano", fameMin = 400  },
    { nivel = 4, nome = "Elite",    fameMin = 800  },
    { nivel = 5, nome = "Lenda",    fameMin = 1500 },
}
-- Alias para acesso direto por indice
TsT.getNomeNivel = function(nivel)
    local t = { "Recruta", "Agente", "Veterano", "Elite", "Lenda" }
    return t[nivel] or "?"
end

-- ------------------------------------------------------------
-- DEFINICOES DAS 3 FACCOES
-- ------------------------------------------------------------
TsT.Factions = {

    -- ==========================
    -- COMBATENTES
    -- ==========================
    {
        id          = "combatants",
        nome        = getText("UI_TsT_Faction_Mercenary_Name") or "Combatentes",
        descricao   = getText("UI_TsT_Faction_Mercenary_Desc") or "Guerreiros de aluguel que vivem pelo combate.",
        foco        = "Combate",
        cor         = { r = 0.8, g = 0.13, b = 0.0, a = 1.0 },
        corHex      = "#CC2200",
        tipoMissao  = "KILL",
    },

    -- ==========================
    -- SOBREVIVENTES
    -- ==========================
    {
        id          = "survivors",
        nome        = getText("UI_TsT_Faction_Outlaw_Name") or "Sobreviventes",
        descricao   = getText("UI_TsT_Faction_Outlaw_Desc") or "Oportunistas adaptaveis que dominam combate e saque.",
        foco        = "Equilibrio e tudo",
        cor         = { r = 0.13, g = 0.67, b = 0.27, a = 1.0 },
        corHex      = "#22AA44",
        tipoMissao  = "MIXED",
    },

    -- ==========================
    -- ESPECIALISTAS
    -- ==========================
    {
        id          = "specialists",
        nome        = getText("UI_TsT_Faction_Survivor_Name") or "Especialistas",
        descricao   = getText("UI_TsT_Faction_Survivor_Desc") or "Especialistas em loot, crafting e sobrevivencia.",
        foco        = "Coleta e Crafting",
        cor         = { r = 0.67, g = 0.47, b = 0.0, a = 1.0 },
        corHex      = "#AA7700",
        tipoMissao  = "LOOT",
    },
}

-- ------------------------------------------------------------
-- FUNCOES UTILITARIAS
-- ------------------------------------------------------------

--- Retorna a definicao de uma faccao pelo ID
---@param id string
---@return table|nil
function TsT.getFactionById(id)
    for _, f in ipairs(TsT.Factions) do
        if f.id == id then return f end
    end
    return nil
end

--- Retorna o nivel de fama (1-5) com base na quantidade de fama
---@param fama number
---@return number nivel, string nomeNivel
function TsT.getNivelFama(fama)
    local nivel = 1
    local nomeNivel = "Recruta"
    for _, lvl in ipairs(TsT.FameLevels) do
        if fama >= lvl.fameMin then
            nivel = lvl.nivel
            nomeNivel = lvl.nome
        end
    end
    return nivel, nomeNivel
end

--- Retorna a fama minima para atingir um tier
---@param tier number
---@return number
function TsT.getFameMinParaTier(tier)
    for _, lvl in ipairs(TsT.FameLevels) do
        if lvl.nivel == tier then return lvl.fameMin end
    end
    return 0
end

--- Retorna o timestamp atual (segundos desde Epoch)
---@return number
function TsT.getTimestamp()
    local ok, result = pcall(function() return getTimestamp() end)
    if ok then return result end
    
    -- Fallback para Client ou ambientes sem getTimestamp() global
    local gt = getGameTime()
    if gt and gt.getWorldAgeHours then
        return math.floor(gt:getWorldAgeHours() * 3600)
    end
    return 0
end

--- Inicializa o ModData do jogador para o mod TsT
---@param player IsoPlayer
---@return table modData
function TsT.initModData(player)
    local md = player:getModData()
    -- Migracao: saves antigos usavam md.PoS (namespace antigo)
    if md.PoS and not md.TsT then
        md.TsT = md.PoS
        md.PoS = nil
    end

    if not md.TsT then
        md.TsT = {
            faction           = nil,
            fame              = { combatants = 0, survivors = 0, specialists = 0 },
            money             = 0,
            activeMission     = nil,
            activeMissionData = {},
            activeDailyMission = nil,
            activeDailyMissionData = {},
            completedMissions = {},
        }
    end
    -- Garante sub-tabelas mesmo se ModData foi corrompido ou parcialmente sincronizado
    local pos = md.TsT
    -- Migra chaves de fama antigas → novas
    if pos and pos.fame then
        if pos.fame.mercenary and pos.fame.combatants == nil then pos.fame.combatants = pos.fame.mercenary end
        if pos.fame.outlaw and pos.fame.survivors == nil then pos.fame.survivors = pos.fame.outlaw end
        if pos.fame.survivor and pos.fame.specialists == nil then pos.fame.specialists = pos.fame.survivor end
        pos.fame.mercenary = nil; pos.fame.outlaw = nil; pos.fame.survivor = nil
    end
    if pos.faction then pos.faction = TsT.normalizeFactionId(pos.faction) end
    if not pos.activeDailyMissionData then pos.activeDailyMissionData = {} end
    if not pos.fame then
        pos.fame = { combatants = 0, survivors = 0, specialists = 0 }
    else
        pos.fame.combatants = pos.fame.combatants or 0
        pos.fame.survivors  = pos.fame.survivors  or 0
        pos.fame.specialists    = pos.fame.specialists    or 0
    end
    if not pos.completedMissions then pos.completedMissions = {} end
    if not pos.activeMissionData  then pos.activeMissionData = {} end
    if pos.money == nil           then pos.money = 0 end
    return pos
end

--- Retorna o TsT ModData ja inicializado
---@param player IsoPlayer
---@return table
function TsT.getModData(player)
    return TsT.initModData(player)
end
