-- ============================================================
-- TsT_Server.lua — Handler de Comandos Client → Server
-- Mod: The Survival Triade | Build 42
-- Executado apenas no servidor
-- ============================================================

if isClient() then return end

-- ------------------------------------------------------------
-- HANDLER PRINCIPAL DE COMANDOS DO CLIENT
-- ------------------------------------------------------------
local function onClientCommand(module, command, player, args)
    -- Ignora comandos de outros módulos
    if module ~= "TsT" then return end

    args = args or {}
    local username = player:getUsername()

    -- ==========================================
    -- SINCRONIZAÇÃO — Chamado ao criar personagem
    -- ==========================================
    if command == "RequestSync" then
        TsT.FactionManager.sync(player)
        return
    end

    -- ==========================================
    -- ENTRAR EM UMA FACÇÃO
    -- ==========================================
    if command == "joinFaction" then
        if not args.factionId then
            print("[TsT] joinFaction sem factionId de " .. username)
            return
        end
        local fid = TsT.normalizeFactionId(args.factionId)
        local ok, msg = TsT.FactionManager.joinFaction(player, fid)
        if not ok then
            sendServerCommand(player, "TsT", "Error", { msg = msg })
        end
        return
    end

    -- ==========================================
    -- ACEITAR MISSÃO
    -- ==========================================
    if command == "acceptMission" then
        if not args.missionId then
            sendServerCommand(player, "TsT", "Error", { msg = "missionId ausente" })
            return
        end
        local ok, msg = TsT.MissionManager.aceitarMissao(player, args.missionId)
        if not ok then
            sendServerCommand(player, "TsT", "Error", { msg = msg })
        end
        return
    end

    -- ==========================================
    -- ABANDONAR MISSÃO
    -- ==========================================
    if command == "abandonMission" then
        TsT.MissionManager.abandonarMissao(player, args.missionId)
        return
    end

    -- ==========================================
    -- COMPLETAR MISSÃO (server valida e recompensa)
    -- ==========================================
    if command == "completeMission" then
        if not args.missionId then
            sendServerCommand(player, "TsT", "Error", { msg = "missionId ausente" })
            return
        end
        local ok, msg = TsT.MissionManager.completarMissao(player, args.missionId)
        if not ok then
            sendServerCommand(player, "TsT", "Error", { msg = msg })
        end
        return
    end

    -- ==========================================
    -- COMPRAR ITEM NA LOJA
    -- ==========================================
    if command == "buyItem" then
        if not args.shopItemId then
            sendServerCommand(player, "TsT", "Error", { msg = "shopItemId ausente" })
            return
        end
        local ok, msg = TsT.MissionManager.comprarItem(player, args.shopItemId)
        if not ok then
            sendServerCommand(player, "TsT", "Error", { msg = msg })
        end
        return
    end

    -- ==========================================
    -- SINCRONIZAR ESTADO DO EVENTO
    -- ==========================================
    if command == "RequestEventSync" then
        TsT.EventManager.syncEvento(player)
        return
    end

    -- ==========================================
    -- DEPOSITAR ITENS NO EVENTO (LOOT/MIXED)
    -- ==========================================
    if command == "depositEventItems" then
        if not args.depositos then
            sendServerCommand(player, "TsT", "EventError", { msg = "Lista de depósitos ausente." })
            return
        end
        TsT.EventManager.depositarItens(player, args.depositos)
        return
    end

    -- ==========================================
    -- ABANDONAR FACÇÃO
    -- ==========================================
    if command == "leaveFaction" then
        local ok, msg = TsT.FactionManager.leaveFaction(player)
        if not ok then
            sendServerCommand(player, "TsT", "Error", { msg = msg })
        end
        return
    end

    -- = ==========================================
    -- RESETAR EVENTO (ADMIN ONLY)
    -- ==========================================
    if command == "resetEvent" then
        local access = player:getAccessLevel()
        if access ~= "admin" and access ~= "moderator" then
            print("[TsT] Jogador " .. username .. " tentou resetar evento sem permissao.")
            return
        end
        local factionId = args.factionId
        if factionId then
            TsT.EventManager.resetarEvento(factionId)
            -- Sincroniza para todos os jogadores dessa facção
            local players = getOnlinePlayers()
            for i = 0, players:size() - 1 do
                local p = players:get(i)
                if p then
                    local pPos = TsT.getModData(p)
                    if pPos.faction == factionId then
                        TsT.EventManager.syncEvento(p)
                    end
                end
            end
        end
        return
    end

    -- ==========================================
    -- SOLICITAR RANKING
    -- ==========================================
    if command == "RequestRanking" then
        local pos2 = TsT.getModData(player)
        local factionId = TsT.normalizeFactionId(pos2.faction)
        if not factionId then return end

        -- Lê snapshot persistente (inclui jogadores offline)
        local rankings = ModData.getOrCreate("TsT_Rankings")

        -- Sobrescreve entradas de jogadores online com dados frescos
        local onlinePlayers = getOnlinePlayers()
        for i = 0, onlinePlayers:size() - 1 do
            local p = onlinePlayers:get(i)
            if p then
                local pData = TsT.getModData(p)
                if pData.faction then
                    rankings[p:getUsername()] = {
                        faction = pData.faction,
                        fame    = {
                            combatants  = pData.fame and pData.fame.combatants  or 0,
                            survivors   = pData.fame and pData.fame.survivors   or 0,
                            specialists = pData.fame and pData.fame.specialists or 0,
                        },
                    }
                end
            end
        end

        -- Monta lista filtrada por facção
        local lista = {}
        for uname, registro in pairs(rankings) do
            if registro.faction == factionId then
                local fameTable = registro.fame or {}
                local fama = fameTable[factionId] or 0
                if fama == 0 then
                    if factionId == "combatants" then fama = fameTable.mercenary or fama end
                    if factionId == "survivors" then fama = fameTable.outlaw or fama end
                    if factionId == "specialists" then fama = fameTable.survivor or fama end
                end
                table.insert(lista, { username=uname, fama=fama })
            end
        end
        -- Ordena decrescente
        table.sort(lista, function(a, b) return a.fama > b.fama end)

        sendServerCommand(player, "TsT", "RankingData", {
            factionId = factionId,
            ranking   = lista,
        })
        return
    end

    -- Comando desconhecido
    print("[TsT] Comando desconhecido recebido de " .. username .. ": " .. tostring(command))
end

-- ------------------------------------------------------------
-- REGISTRA O HANDLER
-- ------------------------------------------------------------
Events.OnClientCommand.Add(onClientCommand)

-- ------------------------------------------------------------
-- HOOK: Contribuição de kills para o Evento Global
-- Chamado quando um zumbi morre no servidor
-- ------------------------------------------------------------
local function onZombieDead(zombie)
    -- Tenta obter o matador via pcall (getAttackedBy pode não existir em todos os builds)
    local killer = nil
    local okGet, killerResult = pcall(function() return zombie:getAttackedBy() end)
    if okGet then killer = killerResult end
    if not killer then return end

    -- Verifica se o matador é realmente um IsoPlayer antes de chamar getUsername().
    -- getAttackedBy() pode retornar IsoZombie (zombie-vs-zombie); sem essa checagem,
    -- o pcall abaixo sempre falha nesse caso desperdiçando CPU em todo kill.
    local isPlayer = false
    pcall(function() isPlayer = instanceof(killer, "IsoPlayer") end)
    if not isPlayer then return end

    local okName, username = pcall(function() return killer:getUsername() end)
    if not okName or not username or username == "" then return end

    -- Busca o IsoPlayer na lista de jogadores online pelo username
    local players = getOnlinePlayers()
    local player = nil
    for i = 0, players:size() - 1 do
        local p = players:get(i)
        if p and p:getUsername() == username then
            player = p
            break
        end
    end
    if not player then return end

    -- Contribui 1 kill para o evento global da facção
    TsT.EventManager.contribuirKills(player, 1)
end

Events.OnZombieDead.Add(onZombieDead)

print("[TsT] TsT_Server.lua carregado com sucesso.")
