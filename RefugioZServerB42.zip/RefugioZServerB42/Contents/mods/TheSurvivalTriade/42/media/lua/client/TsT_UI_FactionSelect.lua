-- ============================================================
-- TsT_UI_FactionSelect.lua — Faction Selection Panel
-- Mod: The Survival Triade | Build 42
-- ============================================================

require "ISUI/ISCollapsableWindow"
require "ISUI/ISButton"
require "ISUI/ISLabel"
require "ISUI/ISPanel"

TsT_FactionSelect = ISCollapsableWindow:derive("TsT_FactionSelect")
TsT_FactionSelect.instance = nil

-- Panel dimensions
local PANEL_W = 680
local PANEL_H = 500

-- ISCollapsableWindow native title bar height (aproximado no B42)
local TITLEBAR_H = 20

-- ------------------------------------------------------------
-- COLORS
-- ------------------------------------------------------------
local C_BG        = { r=0.07, g=0.07, b=0.09, a=0.97 }
local C_BORDER    = { r=0.45, g=0.40, b=0.25, a=1.0  }
local C_SUBTITLE  = { r=0.60, g=0.60, b=0.60, a=1.0  }
local C_CARD_BG   = { r=0.10, g=0.10, b=0.12, a=1.0  }
local C_BTN_OK    = { r=0.12, g=0.45, b=0.12, a=1.0  }
local C_WARN      = { r=0.75, g=0.55, b=0.10, a=1.0  }
local C_GOLD      = { r=0.95, g=0.82, b=0.30, a=1.0  }

-- Faction colors
local COR_FACCAO = {
    combatants = { r=0.85, g=0.15, b=0.05, a=1.0 },
    survivors  = { r=0.15, g=0.70, b=0.28, a=1.0 },
    specialists    = { r=0.75, g=0.50, b=0.05, a=1.0 },
}

-- Currently selected faction
local faccaoSelecionada = nil

-- ------------------------------------------------------------
-- ÍCONE CUSTOMIZADO — ISPanel com render via primitivas
-- Estilo pixel-art / vanilla PZ por grupo
-- ------------------------------------------------------------

-- Mercenários: caveira com capacete militar
local function drawIconMercenary(panel, cor)
    panel.render = function(this)
        local W, H = this:getWidth(), this:getHeight()
        local cx, cy = W/2, H/2
        local r, g, b = cor.r, cor.g, cor.b

        -- Capacete (topo arredondado com rects)
        this:drawRect(cx-10, cy-18, 20, 4,  1, r*0.6, g*0.6, b*0.6)  -- aba do capacete
        this:drawRect(cx-8,  cy-22, 16, 4,  1, r*0.7, g*0.7, b*0.7)  -- lateral
        this:drawRect(cx-6,  cy-26, 12, 4,  1, r*0.8, g*0.8, b*0.8)  -- topo
        this:drawRect(cx-4,  cy-28, 8,  2,  1, r*0.9, g*0.9, b*0.9)  -- cume

        -- Rosto (crânio)
        this:drawRect(cx-8,  cy-16, 16, 14, 1, 0.82, 0.80, 0.75)     -- face
        this:drawRect(cx-10, cy-14, 2,  10, 1, 0.82, 0.80, 0.75)     -- bochecha esq
        this:drawRect(cx+8,  cy-14, 2,  10, 1, 0.82, 0.80, 0.75)     -- bochecha dir

        -- Olhos ocos (escuros)
        this:drawRect(cx-7,  cy-12, 5,  5,  1, 0.05, 0.05, 0.05)     -- olho esq
        this:drawRect(cx+2,  cy-12, 5,  5,  1, 0.05, 0.05, 0.05)     -- olho dir

        -- Nariz (triangulozinho)
        this:drawRect(cx-1,  cy-6,  2,  3,  1, 0.45, 0.43, 0.40)

        -- Mandíbula / dentes
        this:drawRect(cx-7,  cy-2,  14, 4,  1, 0.82, 0.80, 0.75)     -- mandíbula
        this:drawRect(cx-6,  cy+2,  3,  3,  1, 1.0,  1.0,  1.0)      -- dente 1
        this:drawRect(cx-2,  cy+2,  3,  3,  1, 1.0,  1.0,  1.0)      -- dente 2
        this:drawRect(cx+2,  cy+2,  3,  3,  1, 1.0,  1.0,  1.0)      -- dente 3

        -- Estrela de patente no capacete (pontos brancos)
        this:drawRect(cx-1,  cy-27, 2,  2,  1, r, g, b)               -- estrela centro
        this:drawRect(cx-3,  cy-26, 1,  1,  1, r, g, b)
        this:drawRect(cx+2,  cy-26, 1,  1,  1, r, g, b)
        this:drawRect(cx-1,  cy-29, 2,  1,  1, r, g, b)
        this:drawRect(cx-1,  cy-24, 2,  1,  1, r, g, b)
    end
end

-- Sobreviventes: mochila com ferramentas
local function drawIconSurvivor(panel, cor)
    panel.render = function(this)
        local W, H = this:getWidth(), this:getHeight()
        local cx, cy = W/2, H/2
        local r, g, b = cor.r, cor.g, cor.b

        -- Corpo da mochila
        this:drawRect(cx-10, cy-16, 20, 22, 1, 0.35, 0.28, 0.20)     -- corpo principal
        this:drawRect(cx-8,  cy-14, 16, 18, 1, 0.42, 0.34, 0.24)     -- face frontal

        -- Alça superior
        this:drawRect(cx-6,  cy-20, 12, 4,  1, 0.30, 0.24, 0.17)
        this:drawRect(cx-8,  cy-18, 2,  4,  1, 0.28, 0.22, 0.15)     -- alça esq
        this:drawRect(cx+6,  cy-18, 2,  4,  1, 0.28, 0.22, 0.15)     -- alça dir

        -- Bolso frontal
        this:drawRect(cx-5,  cy-6,  10, 10, 1, 0.30, 0.24, 0.17)
        this:drawRect(cx-4,  cy-5,  8,  8,  1, 0.38, 0.30, 0.22)

        -- Fivela do bolso
        this:drawRect(cx-2,  cy-8,  4,  2,  1, 0.65, 0.55, 0.30)

        -- Fechos laterais (pontinhos)
        this:drawRect(cx-10, cy-10, 2,  2,  1, 0.60, 0.50, 0.25)
        this:drawRect(cx+8,  cy-10, 2,  2,  1, 0.60, 0.50, 0.25)

        -- Rodapé da mochila
        this:drawRect(cx-10, cy+6,  20, 3,  1, 0.28, 0.22, 0.15)

        -- Ferramenta saindo do topo (chave inglesa)
        this:drawRect(cx+4,  cy-26, 3,  12, 1, 0.65, 0.65, 0.65)     -- cabo
        this:drawRect(cx+2,  cy-28, 7,  3,  1, 0.65, 0.65, 0.65)     -- cabeça
        this:drawRect(cx+2,  cy-26, 2,  2,  1, 0.20, 0.20, 0.20)     -- furo esq
        this:drawRect(cx+6,  cy-26, 2,  2,  1, 0.20, 0.20, 0.20)     -- furo dir

        -- Folha/planta no topo esq (sobrevivência)
        this:drawRect(cx-10, cy-26, 2,  2,  1, r*0.6, g, b*0.4)
        this:drawRect(cx-12, cy-28, 6,  2,  1, r*0.5, g, b*0.3)
        this:drawRect(cx-11, cy-30, 4,  2,  1, r*0.4, g*0.9, b*0.2)
        this:drawRect(cx-9,  cy-26, 1,  6,  1, r*0.3, g*0.7, b*0.2)  -- caule
    end
end

-- Fora da Lei: chapéu de caubói com máscara
local function drawIconOutlaw(panel, cor)
    panel.render = function(this)
        local W, H = this:getWidth(), this:getHeight()
        local cx, cy = W/2, H/2
        local r, g, b = cor.r, cor.g, cor.b

        -- Aba do chapéu (larga)
        this:drawRect(cx-14, cy-14, 28, 3,  1, 0.28, 0.20, 0.10)
        this:drawRect(cx-12, cy-17, 24, 3,  1, 0.32, 0.24, 0.12)

        -- Copa do chapéu
        this:drawRect(cx-8,  cy-26, 16, 9,  1, 0.35, 0.26, 0.13)
        this:drawRect(cx-6,  cy-28, 12, 2,  1, 0.32, 0.24, 0.12)     -- topo levemente menor

        -- Fita do chapéu
        this:drawRect(cx-8,  cy-17, 16, 3,  1, r*0.7, g*0.7, b*0.2)

        -- Rosto abaixo do chapéu
        this:drawRect(cx-8,  cy-11, 16, 12, 1, 0.78, 0.68, 0.58)     -- pele

        -- Máscara (bandana cobrindo nariz/boca)
        this:drawRect(cx-9,  cy-4,  18, 9,  1, r*0.6, g*0.4, b*0.1)  -- bandana
        this:drawRect(cx-8,  cy-3,  16, 7,  1, r*0.5, g*0.35, b*0.08)-- frente da bandana

        -- Olhos sobre a máscara
        this:drawRect(cx-7,  cy-10, 5,  4,  1, 0.15, 0.12, 0.08)     -- olho esq
        this:drawRect(cx+2,  cy-10, 5,  4,  1, 0.15, 0.12, 0.08)     -- olho dir
        -- brilho nos olhos
        this:drawRect(cx-6,  cy-10, 2,  2,  1, r*0.9, g*0.7, b*0.1)
        this:drawRect(cx+3,  cy-10, 2,  2,  1, r*0.9, g*0.7, b*0.1)

        -- Dobras da bandana
        this:drawRect(cx-8,  cy-1,  3,  1,  1, r*0.4, g*0.3, b*0.05)
        this:drawRect(cx-2,  cy+1,  4,  1,  1, r*0.4, g*0.3, b*0.05)
        this:drawRect(cx+4,  cy,    3,  1,  1, r*0.4, g*0.3, b*0.05)

        -- Cordão do chapéu
        this:drawRect(cx-8,  cy-11, 1,  4,  1, 0.50, 0.38, 0.20)
        this:drawRect(cx+7,  cy-11, 1,  4,  1, 0.50, 0.38, 0.20)

        -- Estrela de xerife riscada (sinal de specialists) no chapéu
        this:drawRect(cx-2,  cy-23, 4,  1,  1, r, g*0.8, b*0.1)
        this:drawRect(cx-1,  cy-24, 2,  3,  1, r, g*0.8, b*0.1)
        this:drawRect(cx-3,  cy-23, 2,  1,  1, r, g*0.8, b*0.1)
        this:drawRect(cx+1,  cy-23, 2,  1,  1, r, g*0.8, b*0.1)
        -- traço de risco na estrela
        this:drawRect(cx-4,  cy-25, 8,  1,  1, 0.85, 0.15, 0.05)
    end
end

local ICON_DRAWS = {
    combatants = drawIconMercenary,
    survivors  = drawIconSurvivor,
    specialists    = drawIconOutlaw,
}

-- ------------------------------------------------------------
-- OPEN / CLOSE
-- ------------------------------------------------------------
function TsT_FactionSelect:openPanel()
    -- Verifica se a instância existente ainda é válida e visível
    local inst = TsT_FactionSelect.instance
    if inst then
        local ok = pcall(function() return inst.javaObject ~= nil end)
        if ok and inst.javaObject then
            -- Instância válida: garante visibilidade e retorna
            pcall(function() inst:setVisible(true) end)
            return
        end
        -- Instância stale (objeto morto): limpa antes de recriar
        pcall(function() inst:removeFromUIManager() end)
        TsT_FactionSelect.instance = nil
    end

    local W = getCore():getScreenWidth()
    local H = getCore():getScreenHeight()
    local x = (W - PANEL_W) / 2
    local y = (H - PANEL_H) / 2

    local ui = TsT_FactionSelect:new(x, y, PANEL_W, PANEL_H)
    ui:initialise()
    ui:addToUIManager()
    TsT_FactionSelect.instance = ui
    faccaoSelecionada = nil
end

function TsT_FactionSelect:close()
    ISCollapsableWindow.close(self)
    self:removeFromUIManager()
    TsT_FactionSelect.instance = nil
    faccaoSelecionada = nil
end

-- Bloqueia ESC antes de confirmar grupo
function TsT_FactionSelect:onKeyPress(key)
    if key == 1 then return end
    ISCollapsableWindow.onKeyPress(self, key)
end

-- ------------------------------------------------------------
-- CONSTRUCTOR
-- ------------------------------------------------------------
function TsT_FactionSelect:new(x, y, w, h)
    local o = ISCollapsableWindow:new(x, y, w, h)
    setmetatable(o, self)
    self.__index = self
    o.title           = "Survival Triade — Escolha seu Grupo"
    o.resizable       = false
    o.backgroundColor = C_BG
    o.borderColor     = C_BORDER
    return o
end

-- ------------------------------------------------------------
-- INITIALISE
-- ------------------------------------------------------------
function TsT_FactionSelect:initialise()
    ISCollapsableWindow.initialise(self)
end

function TsT_FactionSelect:createChildren()
    self:clearChildren()

    local W  = self:getWidth()
    local H  = self:getHeight()
    
    -- Botão fechar
    local btnClose = ISButton:new(W - 28, 2, 24, 24, "X", self, TsT_FactionSelect.close)
    btnClose.backgroundColor = { r=0.55, g=0.08, b=0.05, a=1 }
    btnClose.borderColor     = { r=0.85, g=0.15, b=0.1, a=1 }
    btnClose:initialise()
    self:addChild(btnClose)

    -- Todo o conteúdo começa abaixo da barra de título nativa
    local TY = TITLEBAR_H + 12   -- margem extra após a titlebar

    -- ── Subtítulo centralizado ────────────────────────────────
    local tm = getTextManager()
    local font = UIFont.Small

    local function centeredLabel(text, y)
        local tw = tm:MeasureStringX(font, text)
        local lbl = ISLabel:new(math.floor((W - tw) / 2), y, 16,
            text, C_SUBTITLE.r, C_SUBTITLE.g, C_SUBTITLE.b, 1, font, true)
        self:addChild(lbl)
    end

    centeredLabel("Sua escolha e permanente.", TY)
    centeredLabel("Cada grupo tem missoes, recompensas e loja exclusivas.", TY + 17)

    -- ── Cards (3 colunas) ─────────────────────────────────────
    local margin  = 12
    local gap     = 10
    local cardW   = math.floor((W - margin*2 - gap*2) / 3)
    local cardH   = 330
    local cardY   = TY + 50   -- abaixo das 2 linhas de subtítulo + margem

    for i, faction in ipairs(TsT.Factions) do
        local cx = margin + (i-1) * (cardW + gap)
        self:criarCard(faction, cx, cardY, cardW, cardH)
    end

    -- ── Botão CONFIRMAR (centralizado) ────────────────────────
    local btnW  = 220
    local btnH  = 38
    local btnY  = cardY + cardH + 12
    local btn   = ISButton:new(math.floor((W - btnW) / 2), btnY, btnW, btnH,
        "CONFIRMAR GRUPO", self, TsT_FactionSelect.onConfirmar)
    btn.backgroundColor = C_BTN_OK
    btn.borderColor     = { r=0.20, g=0.75, b=0.20, a=1 }
    btn:initialise()
    self:addChild(btn)
    self.btnConfirmar = btn

    -- ── Aviso (centralizado) ──────────────────────────────────
    local warnTxt = "! Nao e possivel mudar de grupo apos confirmar."
    local warnW   = tm:MeasureStringX(font, warnTxt)
    local warn = ISLabel:new(math.floor((W - warnW) / 2), btnY + btnH + 8, 14,
        warnTxt, C_WARN.r, C_WARN.g, C_WARN.b, 1, font, true)
    self:addChild(warn)

    self:atualizarSelecao()
end

-- ------------------------------------------------------------
-- FACTION CARD CREATION
-- ------------------------------------------------------------
function TsT_FactionSelect:criarCard(faction, x, y, w, h)
    local cor      = COR_FACCAO[faction.id] or { r=0.5, g=0.5, b=0.5, a=1 }
    local drawIcon = ICON_DRAWS[faction.id]

    -- Card base panel
    local card = ISPanel:new(x, y, w, h)
    card.backgroundColor = C_CARD_BG
    card.borderColor     = { r=0.25, g=0.25, b=0.25, a=1 }
    card.factionId       = faction.id
    card:initialise()
    self:addChild(card)

    -- Barra colorida no topo
    local barra = ISPanel:new(0, 0, w, 5)
    barra.backgroundColor = cor
    barra.borderColor     = cor
    barra:initialise()
    card:addChild(barra)

    -- ── Ícone desenhado por primitivas (60x60, centrado) ─────
    local ICON_SIZE = 60
    local iconX = math.floor((w - ICON_SIZE) / 2)
    local iconPanel = ISPanel:new(iconX, 22, ICON_SIZE, ICON_SIZE)
    iconPanel.backgroundColor = { r=0, g=0, b=0, a=0 }
    iconPanel.borderColor     = { r=0, g=0, b=0, a=0 }
    iconPanel:initialise()
    if drawIcon then
        drawIcon(iconPanel, cor)
    end
    card:addChild(iconPanel)

    -- Nome do grupo (centralizado)
    local tm2  = getTextManager()
    local lblNome = ISLabel:new(w/2, 82, 20, faction.nome,
        cor.r, cor.g, cor.b, 1, UIFont.Medium, true)
    lblNome:setX(math.floor(w/2 - tm2:MeasureStringX(UIFont.Medium, faction.nome)/2))
    card:addChild(lblNome)

    -- Tag de foco (centralizada)
    local focoTxt = "[" .. faction.foco .. "]"
    local lblFoco = ISLabel:new(0, 102, 14, focoTxt,
        0.65, 0.65, 0.65, 1, UIFont.Small, true)
    lblFoco:setX(math.floor(w/2 - tm2:MeasureStringX(UIFont.Small, focoTxt)/2))
    card:addChild(lblFoco)

    -- Separador fino
    local sep = ISPanel:new(8, 118, w-16, 1)
    sep.backgroundColor = { r=cor.r*0.4, g=cor.g*0.4, b=cor.b*0.4, a=0.6 }
    sep.borderColor     = sep.backgroundColor
    sep:initialise()
    card:addChild(sep)

    -- Descrição com word-wrap preciso e centralizada ("justificada" visualmente)
    local descY  = 126
    local maxW   = w - 24
    local font   = UIFont.Small
    local palavras = {}
    for p in faction.descricao:gmatch("%S+") do table.insert(palavras, p) end
    local linhas = {}
    local linha  = ""
    for _, p in ipairs(palavras) do
        local teste = linha == "" and p or (linha .. " " .. p)
        if tm2:MeasureStringX(font, teste) <= maxW then
            linha = teste
        else
            if linha ~= "" then table.insert(linhas, linha) end
            linha = p
        end
    end
    if linha ~= "" then table.insert(linhas, linha) end
    for _, l in ipairs(linhas) do
        local twLine = tm2:MeasureStringX(font, l)
        local lbl = ISLabel:new(math.floor(w/2 - twLine/2), descY, 14, l, 0.70, 0.70, 0.70, 1, font, true)
        card:addChild(lbl)
        descY = descY + 16
    end

    -- Botão SELECIONAR (no fundo do card)
    local btnSel = ISButton:new(6, h-40, w-12, 32, "SELECIONAR", self, function()
        faccaoSelecionada = faction.id
        if TsT_FactionSelect.instance then
            TsT_FactionSelect.instance:atualizarSelecao()
        end
    end)
    btnSel.backgroundColor = { r=cor.r*0.22, g=cor.g*0.22, b=cor.b*0.22, a=1 }
    btnSel.borderColor     = { r=cor.r*0.45, g=cor.g*0.45, b=cor.b*0.45, a=0.8 }
    btnSel:initialise()
    card:addChild(btnSel)

    -- Guarda referências para highlight de seleção
    if not self.cards then self.cards = {} end
    self.cards[faction.id] = { panel=card, btn=btnSel, cor=cor }
end

-- ------------------------------------------------------------
-- ATUALIZA HIGHLIGHT DE SELEÇÃO
-- ------------------------------------------------------------
function TsT_FactionSelect:atualizarSelecao()
    if not self.cards then return end
    for fid, data in pairs(self.cards) do
        if fid == faccaoSelecionada then
            data.panel.borderColor   = { r=data.cor.r, g=data.cor.g, b=data.cor.b, a=1 }
            data.btn.backgroundColor = { r=data.cor.r*0.55, g=data.cor.g*0.55, b=data.cor.b*0.55, a=1 }
            data.btn.borderColor     = { r=data.cor.r, g=data.cor.g, b=data.cor.b, a=1 }
        else
            data.panel.borderColor   = { r=0.22, g=0.22, b=0.22, a=1 }
            data.btn.backgroundColor = { r=data.cor.r*0.15, g=data.cor.g*0.15, b=data.cor.b*0.15, a=1 }
            data.btn.borderColor     = { r=data.cor.r*0.4,  g=data.cor.g*0.4,  b=data.cor.b*0.4,  a=0.7 }
        end
    end
end

-- ------------------------------------------------------------
-- CONFIRMAR GRUPO
-- ------------------------------------------------------------
function TsT_FactionSelect:onConfirmar()
    if not faccaoSelecionada then
        local p = getPlayer()
        if p and p.HaloText then
            p:HaloText("Selecione um grupo primeiro!", 255, 150, 50)
        end
        return
    end

    local player = getPlayer()
    if not player then return end

    if isClient() then
        sendClientCommand(player, "TsT", "joinFaction", { factionId = faccaoSelecionada })
    else
        local ok, msg = TsT.FactionManager.joinFaction(player, faccaoSelecionada)
        if not ok and player and player.HaloText then
            player:HaloText(msg or "Não foi possível escolher o grupo.", 255, 150, 50)
        end
    end
end
