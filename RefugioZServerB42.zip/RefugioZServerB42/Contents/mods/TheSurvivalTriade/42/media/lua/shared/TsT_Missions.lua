-- ============================================================
-- TsT_Missions.lua — Definicoes de Todas as Missoes
-- Mod: The Survival Triade | Build 42
-- 60 missoes: 3 faccoes × 5 tiers × 4 missoes
-- ============================================================

TsT = TsT or {}
TsT.Missions = {}

-- Estrutura de cada missao:
-- {
--   id          = string unico (ex: "merc_t1_01")
--   factionId   = "combatants" | "survivors" | "specialists"
--   tier        = 1..5 (nivel de fama exigido)
--   type        = "KILL" | "LOOT" | "MIXED"
--   title       = string
--   description = string
--   objectives  = { kills=N, items={{name="Base.X", count=N}, ...} }
--   rewards     = { money=N, fame=N, items={{type="Base.X", count=N}} }
--   timeLimit   = minutos ou nil
-- }
--
-- Dinheiro base do jogo (Base.Money / Base.MoneyBundle) nas recompensas:
--   Tier 1: 10 → 20 → 30 → 40 notas
--   Tier 2: 50 → 70 → 90 → 110 notas
--   Tier 3: 130 → 150 → 160 → 180 notas
--   Tier 4: 200 → 220 → 240 → 260 notas
--   Tier 5: 300 → 350 → 400 notas | ultima missao = 4x Base.MoneyBundle (maco)

TsT.Missions = {

    -- ============================================================
    -- COMBATENTES — Foco em KILL
    -- ============================================================

    -- TIER 1: Recruta (fama 0+)
    {
        id="merc_t1_01", factionId="combatants", tier=1, type="MIXED",
        title="Batismo de Sangue",
        description="Elimine 15 zumbis na area e traga 2 bandagens para o estoque medico.",
        objectives = { kills=15, items={{name="Base.Bandage", count=2}} },
        rewards = { money=40, fame=30, items={{type="Base.Money", count=10}} },
        timeLimit = nil
    },
    {
        id="merc_t1_02", factionId="combatants", tier=1, type="KILL",
        title="Limpeza Inicial",
        description="Mate 25 zumbis. Vamos ver se voce tem estomago para isso.",
        objectives = { kills=25 },
        rewards = { money=60, fame=35, items={{type="Base.HuntingKnife", count=1},{type="Base.Money", count=20}} },
        timeLimit = nil
    },
    {
        id="merc_t1_03", factionId="combatants", tier=1, type="MIXED",
        title="Primeiros Contratos",
        description="Elimine 40 zumbis e traga uma garrafa d'agua cheia.",
        objectives = { kills=40, items={{name="Base.WaterBottleFull", count=1}} },
        rewards = { money=75, fame=40, items={{type="Base.Bullets9mmBox", count=1},{type="Base.Money", count=30}} },
        timeLimit = nil
    },
    {
        id="merc_t1_04", factionId="combatants", tier=1, type="MIXED",
        title="Prova de Valor",
        description="Abata 60 zumbis e entregue joias recuperadas para financiar a tropa.",
        objectives = { kills=60, items={{name="Base.Necklace_Gold", count=2}} },
        rewards = { money=100, fame=55, items={{type="Base.BaseballBat", count=1},{type="Base.Money", count=40}} },
        timeLimit = nil
    },

    -- TIER 2: Agente (fama 150+)
    {
        id="merc_t2_01", factionId="combatants", tier=2, type="MIXED",
        title="Operacao Contencao",
        description="Elimine 100 zumbis e colete 3 joias para financiar os suprimentos.",
        objectives = { kills=100, items={{name="Base.Necklace_Gold", count=3}} },
        rewards = { money=150, fame=60, items={{type="Base.Pistol", count=1},{type="Base.Money", count=50}} },
        timeLimit = nil
    },
    {
        id="merc_t2_02", factionId="combatants", tier=2, type="MIXED",
        title="Varredura Tatica",
        description="Mate 150 zumbis e entregue uma faca de caca recuperada.",
        objectives = { kills=150, items={{name="Base.HuntingKnife", count=1}} },
        rewards = { money=190, fame=70, items={{type="Base.Bullets9mmBox", count=3},{type="Base.Money", count=70}} },
        timeLimit = nil
    },
    {
        id="merc_t2_03", factionId="combatants", tier=2, type="KILL",
        title="Escolta Armada",
        description="Elimine 200 zumbis bloqueando a rota principal.",
        objectives = { kills=200 },
        rewards = { money=225, fame=80, items={{type="Base.Vest_BulletProof", count=1},{type="Base.Money", count=90}} },
        timeLimit = nil
    },
    {
        id="merc_t2_04", factionId="combatants", tier=2, type="MIXED",
        title="Forca de Choque",
        description="Abata 250 zumbis e entregue joias valiosas para os oficiais.",
        objectives = { kills=250, items={{name="Base.Necklace_Gold", count=5}} },
        rewards = { money=250, fame=90, items={{type="Base.Shotgun", count=1},{type="Base.Money", count=110}} },
        timeLimit = nil
    },

    -- TIER 3: Veterano (fama 400+)
    {
        id="merc_t3_01", factionId="combatants", tier=3, type="KILL",
        title="Zona de Exterminio",
        description="Limpe a area eliminando 400 zumbis. Missao de alto risco, alto retorno.",
        objectives = { kills=400 },
        rewards = { money=350, fame=100, items={{type="Base.ShotgunShellsBox", count=3},{type="Base.Money", count=130}} },
        timeLimit = nil
    },
    {
        id="merc_t3_02", factionId="combatants", tier=3, type="KILL",
        title="Operacao Tempestade",
        description="Elimine 500 zumbis. Os clientes precisam de um profissional.",
        objectives = { kills=500 },
        rewards = { money=425, fame=110, items={{type="Base.Machete", count=1},{type="Base.Money", count=150}} },
        timeLimit = nil
    },
    {
        id="merc_t3_03", factionId="combatants", tier=3, type="KILL",
        title="Assalto Noturno",
        description="Mate 600 zumbis. Condicoes adversas, pagamento superior.",
        objectives = { kills=600 },
        rewards = { money=500, fame=120, items={{type="Base.Axe", count=1},{type="Base.Money", count=160}} },
        timeLimit = nil
    },
    {
        id="merc_t3_04", factionId="combatants", tier=3, type="MIXED",
        title="Rota de Exterminio",
        description="Abate 750 zumbis e garanta um suprimento de joias para o bando.",
        objectives = { kills=750, items={{name="Base.Necklace_Gold", count=8}} },
        rewards = { money=600, fame=130, items={{type="Base.Pistol3", count=1},{type="Base.Money", count=180}} },
        timeLimit = nil
    },

    -- TIER 4: Elite (fama 800+)
    {
        id="merc_t4_01", factionId="combatants", tier=4, type="KILL",
        title="Cacador de Elite",
        description="Elimine 1000 zumbis. Apenas os melhores chegam ate aqui.",
        objectives = { kills=1000 },
        rewards = { money=750, fame=150, items={{type="Base.AssaultRifle", count=1},{type="Base.Money", count=200}} },
        timeLimit = nil
    },
    {
        id="merc_t4_02", factionId="combatants", tier=4, type="KILL",
        title="Protocolo Devastador",
        description="Mate 1250 zumbis. A situacao escalou — precisamos de voce.",
        objectives = { kills=1250 },
        rewards = { money=900, fame=160, items={{type="Base.556Box", count=2},{type="Base.Money", count=220}} },
        timeLimit = nil
    },
    {
        id="merc_t4_03", factionId="combatants", tier=4, type="KILL",
        title="Forca Maxima",
        description="Elimine 1500 zumbis. Total comprometimento com a missao.",
        objectives = { kills=1500 },
        rewards = { money=1000, fame=170, items={{type="Base.Vest_BulletPolice", count=1},{type="Base.Money", count=240}} },
        timeLimit = nil
    },
    {
        id="merc_t4_04", factionId="combatants", tier=4, type="MIXED",
        title="Operacao Fantasma",
        description="Abate 2000 zumbis e colete um pesado lote de joias de luxo.",
        objectives = { kills=2000, items={{name="Base.Necklace_Gold", count=12}} },
        rewards = { money=1250, fame=180, items={{type="Base.44Box", count=2},{type="Base.Money", count=260}} },
        timeLimit = nil
    },

    -- TIER 5: Lenda (fama 1500+)
    {
        id="merc_t5_01", factionId="combatants", tier=5, type="KILL",
        title="O Ultimo Contrato",
        description="Elimine 3000 zumbis. A lenda esta sendo forjada.",
        objectives = { kills=3000 },
        rewards = { money=2000, fame=250, items={{type="Base.Katana", count=1},{type="Base.Money", count=300}} },
        timeLimit = nil
    },
    {
        id="merc_t5_02", factionId="combatants", tier=5, type="KILL",
        title="Aniquilador",
        description="Mate 4000 zumbis. Voce e a razao pela qual os mortos temem os vivos.",
        objectives = { kills=4000 },
        rewards = { money=2500, fame=300, items={{type="Base.Pistol3", count=1},{type="Base.44Box", count=3},{type="Base.Money", count=350}} },
        timeLimit = nil
    },
    {
        id="merc_t5_03", factionId="combatants", tier=5, type="KILL",
        title="Exterminador Supremo",
        description="Elimine 5000 zumbis. O apocalipse teme o seu nome.",
        objectives = { kills=5000 },
        rewards = { money=3000, fame=350, items={{type="Base.AssaultRifle", count=1},{type="Base.556Box", count=4},{type="Base.Money", count=400}} },
        timeLimit = nil
    },
    {
        id="merc_t5_04", factionId="combatants", tier=5, type="MIXED",
        title="Lenda Viva",
        description="7500 mortos e um tesouro em joias. Sua lenda sera eterna.",
        objectives = { kills=7500, items={{name="Base.Necklace_Gold", count=20}} },
        rewards = { money=5000, fame=500, items={{type="Base.AssaultRifle", count=1},{type="Base.Pistol3", count=1},{type="Base.556Box", count=4},{type="Base.44Box", count=2},{type="Base.Vest_BulletPolice", count=1},{type="Base.MoneyBundle", count=4}} },
        timeLimit = nil
    },

    -- ============================================================
    -- ESPECIALISTAS — Foco em LOOT
    -- ============================================================

    -- TIER 1: Recruta (fama 0+)
    {
        id="surv_t1_01", factionId="specialists", tier=1, type="LOOT",
        title="Materiais da Natureza",
        description="Colete gravetos e pedras ao redor. Sao a base de tudo que construiremos.",
        objectives = { items={{name="Base.Twigs", count=8},{name="Base.Stone2", count=5}} },
        rewards = { money=40, fame=30, items={{type="Base.WaterBottleFull", count=2},{type="Base.Money", count=10}} },
        timeLimit = nil
    },
    {
        id="surv_t1_02", factionId="specialists", tier=1, type="LOOT",
        title="Lenha para o Acampamento",
        description="Precisamos de troncos para construir e aquecer o grupo.",
        objectives = { items={{name="Base.Log", count=4}} },
        rewards = { money=50, fame=35, items={{type="Base.Saw", count=1},{type="Base.Money", count=20}} },
        timeLimit = nil
    },
    {
        id="surv_t1_03", factionId="specialists", tier=1, type="LOOT",
        title="Ferramentas de Sobrevivencia",
        description="Encontre um martelo e pregos. Precisamos reforcar as barricadas.",
        objectives = { items={{name="Base.Hammer", count=1},{name="Base.NailsBox", count=1}} },
        rewards = { money=60, fame=40, items={{type="Base.Crowbar", count=1},{type="Base.Money", count=30}} },
        timeLimit = nil
    },
    {
        id="surv_t1_04", factionId="specialists", tier=1, type="LOOT",
        title="Primeiros Socorros",
        description="Colete antibioticos e desinfetante. A saude do grupo depende disso.",
        objectives = { items={{name="Base.Antibiotics", count=2},{name="Base.Disinfectant", count=1}} },
        rewards = { money=75, fame=55, items={{type="Base.Bag_DuffelBag", count=1},{type="Base.Money", count=40}} },
        timeLimit = nil
    },

    -- TIER 2: Agente (fama 150+)
    {
        id="surv_t2_01", factionId="specialists", tier=2, type="LOOT",
        title="Estoque de Combustivel",
        description="Traga 2 galoes de gasolina. Precisamos do gerador funcionando.",
        objectives = { items={{name="Base.PetrolCan", count=2}} },
        rewards = { money=140, fame=55, items={{type="Base.ElectronicsMag4", count=1},{type="Base.Money", count=50}} },
        timeLimit = nil
    },
    {
        id="surv_t2_02", factionId="specialists", tier=2, type="LOOT",
        title="Kit de Reparo",
        description="Colete materiais para manutencao: chave inglesa, chave de fenda e fita.",
        objectives = { items={{name="Base.Wrench", count=1},{name="Base.Screwdriver", count=1},{name="Base.DuctTape", count=2}} },
        rewards = { money=160, fame=65, items={{type="Base.Bag_ALICEpack_Army", count=1},{type="Base.Money", count=70}} },
        timeLimit = nil
    },
    {
        id="surv_t2_03", factionId="specialists", tier=2, type="LOOT",
        title="Suprimentos Medicos",
        description="Traga um kit medico completo para o posto de saude improvisado.",
        objectives = { items={{name="Base.FirstAidKit_New", count=1},{name="Base.Bandage", count=8},{name="Base.Antibiotics", count=3}} },
        rewards = { money=200, fame=75, items={{type="Base.Axe", count=1},{type="Base.Money", count=90}} },
        timeLimit = nil
    },
    {
        id="surv_t2_04", factionId="specialists", tier=2, type="LOOT",
        title="Reserva de Alimentos",
        description="Colete uma variedade de alimentos para as proximas semanas.",
        objectives = { items={{name="Base.TinnedBeans", count=3},{name="Base.TinnedSoup", count=3},{name="Base.CannedCorn", count=3}} },
        rewards = { money=175, fame=70, items={{type="Base.FishingRod", count=1},{type="Base.Money", count=110}} },
        timeLimit = nil
    },

    -- TIER 3: Veterano (fama 400+)
    {
        id="surv_t3_01", factionId="specialists", tier=3, type="LOOT",
        title="Equipamento de Construcao",
        description="Traga materiais para expandir o abrigo. Construcao em andamento.",
        objectives = { items={{name="Base.Plank", count=10},{name="Base.NailsBox", count=3},{name="Base.Hammer", count=1}} },
        rewards = { money=300, fame=90, items={{type="Base.Sledgehammer", count=1},{type="Base.Money", count=130}} },
        timeLimit = nil
    },
    {
        id="surv_t3_02", factionId="specialists", tier=3, type="LOOT",
        title="Coleta de Sementes",
        description="Encontre sementes para comecar a plantacao de emergencia.",
        objectives = { items={{name="Base.TomatoSeed", count=2},{name="Base.PotatoSeed", count=2},{name="Base.CarrotSeed", count=2}} },
        rewards = { money=350, fame=100, items={{type="Base.TentKit", count=1},{type="Base.Money", count=150}} },
        timeLimit = nil
    },
    {
        id="surv_t3_03", factionId="specialists", tier=3, type="LOOT",
        title="Arsenal Defensivo",
        description="Colete municoes para defesa do perimetro.",
        objectives = { items={{name="Base.Bullets9mmBox", count=3},{name="Base.ShotgunShellsBox", count=2}} },
        rewards = { money=400, fame=110, items={{type="Base.Pistol", count=1},{type="Base.Money", count=160}} },
        timeLimit = nil
    },
    {
        id="surv_t3_04", factionId="specialists", tier=3, type="LOOT",
        title="Livros de Conhecimento",
        description="Recupere manuais tecnicos. O conhecimento e nossa maior arma.",
        objectives = { items={{name="Base.BookCarpentry1", count=1},{name="Base.BookMechanic1", count=1},{name="Base.BookFirstAid1", count=1}} },
        rewards = { money=450, fame=120, items={{type="Base.Bag_ALICEpack_Army", count=1},{type="Base.Money", count=180}} },
        timeLimit = nil
    },

    -- TIER 4: Elite (fama 800+)
    {
        id="surv_t4_01", factionId="specialists", tier=4, type="LOOT",
        title="Projeto Gerador",
        description="Reuna tudo para instalar o gerador principal do abrigo.",
        objectives = { items={{name="Base.PetrolCan", count=4},{name="Base.ElectronicsMag4", count=1},{name="Base.Wrench", count=2}} },
        rewards = { money=600, fame=140, items={{type="Base.Generator", count=1},{type="Base.Money", count=200}} },
        timeLimit = nil
    },
    {
        id="surv_t4_02", factionId="specialists", tier=4, type="LOOT",
        title="Farmacia Completa",
        description="Monte um estoque medico avancado para a base.",
        objectives = { items={{name="Base.Antibiotics", count=5},{name="Base.Bandage", count=15},{name="Base.SutureNeedle", count=2},{name="Base.Splint", count=3}} },
        rewards = { money=750, fame=150, items={{type="Base.Shotgun", count=1},{type="Base.Money", count=220}} },
        timeLimit = nil
    },
    {
        id="surv_t4_03", factionId="specialists", tier=4, type="LOOT",
        title="Armamento Pesado",
        description="Colete armas avancadas para defesa da base.",
        objectives = { items={{name="Base.Shotgun", count=1},{name="Base.ShotgunShellsBox", count=4}} },
        rewards = { money=900, fame=160, items={{type="Base.AssaultRifle", count=1},{type="Base.Money", count=240}} },
        timeLimit = nil
    },
    {
        id="surv_t4_04", factionId="specialists", tier=4, type="LOOT",
        title="Reservas Estrategicas",
        description="Acumule recursos para sustentar a base por meses.",
        objectives = { items={{name="Base.TinnedBeans", count=8},{name="Base.WaterBottleFull", count=6},{name="Base.PetrolCan", count=3}} },
        rewards = { money=1000, fame=175, items={{type="Base.MRE", count=5},{type="Base.Money", count=260}} },
        timeLimit = nil
    },

    -- TIER 5: Lenda (fama 1500+)
    {
        id="surv_t5_01", factionId="specialists", tier=5, type="LOOT",
        title="Acervo da Humanidade",
        description="Preserve o conhecimento reunindo uma biblioteca de sobrevivencia.",
        objectives = { items={{name="Base.BookCarpentry3", count=1},{name="Base.BookMechanic3", count=1},{name="Base.BookFirstAid3", count=1},{name="Base.BookElectrician3", count=1}} },
        rewards = { money=1750, fame=250, items={{type="Base.Katana", count=1},{type="Base.Money", count=300}} },
        timeLimit = nil
    },
    {
        id="surv_t5_02", factionId="specialists", tier=5, type="LOOT",
        title="Projeto Arca",
        description="Colete tudo necessario para uma base sustentavel a longo prazo.",
        objectives = { items={{name="Base.PetrolCan", count=8},{name="Base.TinnedBeans", count=15},{name="Base.Antibiotics", count=10},{name="Base.NailsBox", count=5}} },
        rewards = { money=2500, fame=300, items={{type="Base.Generator", count=1},{type="Base.PetrolCan", count=4},{type="Base.Money", count=350}} },
        timeLimit = nil
    },
    {
        id="surv_t5_03", factionId="specialists", tier=5, type="LOOT",
        title="Arsenal da Resistencia",
        description="Arme a base com tudo o que ha de melhor.",
        objectives = { items={{name="Base.AssaultRifle", count=1},{name="Base.556Box", count=5},{name="Base.Pistol3", count=1},{name="Base.44Box", count=3}} },
        rewards = { money=3000, fame=350, items={{type="Base.Vest_BulletPolice", count=1},{type="Base.Shoes_ArmyBoots", count=1},{type="Base.Money", count=400}} },
        timeLimit = nil
    },
    {
        id="surv_t5_04", factionId="specialists", tier=5, type="LOOT",
        title="Legado dos Especialistas",
        description="Monte o acervo final — a prova de que a humanidade sobreviveu.",
        objectives = { items={{name="Base.BookCarpentry5", count=1},{name="Base.Generator", count=1},{name="Base.AssaultRifle", count=1},{name="Base.TinnedBeans", count=20}} },
        rewards = { money=5000, fame=500, items={{type="Base.AssaultRifle", count=1},{type="Base.Katana", count=1},{type="Base.Bag_ALICEpack_Army", count=1},{type="Base.MoneyBundle", count=4}} },
        timeLimit = nil
    },

    -- ============================================================
    -- SOBREVIVENTES — Foco em MIXED (KILL + LOOT)
    -- ============================================================

    -- TIER 1: Recruta (fama 0+)
    {
        id="outl_t1_01", factionId="survivors", tier=1, type="MIXED",
        title="Oportunismo",
        description="Mate 10 zumbis e pegue o que tiver de util nos corpos e arredores.",
        objectives = { kills=10, items={{name="Base.Bandage", count=2}} },
        rewards = { money=50, fame=25, items={{type="Base.HuntingKnife", count=1},{type="Base.Money", count=10}} },
        timeLimit = nil
    },
    {
        id="outl_t1_02", factionId="survivors", tier=1, type="MIXED",
        title="Pilhagem",
        description="Elimine 20 zumbis e colete suprimentos da area.",
        objectives = { kills=20, items={{name="Base.TinnedBeans", count=2}} },
        rewards = { money=65, fame=35, items={{type="Base.WaterBottleFull", count=2},{type="Base.Money", count=20}} },
        timeLimit = nil
    },
    {
        id="outl_t1_03", factionId="survivors", tier=1, type="MIXED",
        title="Lei do Mais Forte",
        description="Mate 30 zumbis e pegue ferramentas basicas. Sobrevivencia pura.",
        objectives = { kills=30, items={{name="Base.Hammer", count=1}} },
        rewards = { money=80, fame=40, items={{type="Base.Crowbar", count=1},{type="Base.Money", count=30}} },
        timeLimit = nil
    },
    {
        id="outl_t1_04", factionId="survivors", tier=1, type="MIXED",
        title="Coleta Sangrenta",
        description="Elimine 50 zumbis e traga municao para futuras operacoes.",
        objectives = { kills=50, items={{name="Base.Bullets9mmBox", count=1}} },
        rewards = { money=100, fame=50, items={{type="Base.Pistol", count=1},{type="Base.Money", count=40}} },
        timeLimit = nil
    },

    -- TIER 2: Agente (fama 150+)
    {
        id="outl_t2_01", factionId="survivors", tier=2, type="MIXED",
        title="Trabalho Sujo",
        description="Mate 80 zumbis e colete materiais de construcao para reforcar o esconderijo.",
        objectives = { kills=80, items={{name="Base.Plank", count=5}} },
        rewards = { money=175, fame=65, items={{type="Base.Bag_DuffelBag", count=1},{type="Base.Money", count=50}} },
        timeLimit = nil
    },
    {
        id="outl_t2_02", factionId="survivors", tier=2, type="MIXED",
        title="Operacao Mercado Negro",
        description="Elimine 100 zumbis e traga suprimentos medicos. Mercadorias valiosas.",
        objectives = { kills=100, items={{name="Base.Antibiotics", count=2},{name="Base.Bandage", count=5}} },
        rewards = { money=210, fame=75, items={{type="Base.Shotgun", count=1},{type="Base.Money", count=70}} },
        timeLimit = nil
    },
    {
        id="outl_t2_03", factionId="survivors", tier=2, type="MIXED",
        title="Assalto ao Deposito",
        description="Limpe a area (120 kills) e colete combustivel para os veiculos.",
        objectives = { kills=120, items={{name="Base.PetrolCan", count=2}} },
        rewards = { money=250, fame=85, items={{type="Base.Machete", count=1},{type="Base.Money", count=90}} },
        timeLimit = nil
    },
    {
        id="outl_t2_04", factionId="survivors", tier=2, type="MIXED",
        title="Roubo Justificado",
        description="Mate 150 zumbis e colete armas para o grupo.",
        objectives = { kills=150, items={{name="Base.Pistol", count=1}} },
        rewards = { money=290, fame=90, items={{type="Base.ShotgunShellsBox", count=3},{type="Base.Money", count=110}} },
        timeLimit = nil
    },

    -- TIER 3: Veterano (fama 400+)
    {
        id="outl_t3_01", factionId="survivors", tier=3, type="MIXED",
        title="Zona de Guerra",
        description="Elimine 250 zumbis e colete armas para fortalecer o bando.",
        objectives = { kills=250, items={{name="Base.Shotgun", count=1}} },
        rewards = { money=400, fame=110, items={{type="Base.Pistol3", count=1},{type="Base.Money", count=130}} },
        timeLimit = nil
    },
    {
        id="outl_t3_02", factionId="survivors", tier=3, type="MIXED",
        title="Negocios Sombrios",
        description="Mate 300 zumbis e reuna suprimentos valiosos do mercado negro.",
        objectives = { kills=300, items={{name="Base.Antibiotics", count=4},{name="Base.PetrolCan", count=2}} },
        rewards = { money=475, fame=120, items={{type="Base.Bag_ALICEpack_Army", count=1},{type="Base.Money", count=150}} },
        timeLimit = nil
    },
    {
        id="outl_t3_03", factionId="survivors", tier=3, type="MIXED",
        title="Fronteira Vermelha",
        description="Limpe o perimetro (350 kills) e colete municao pesada.",
        objectives = { kills=350, items={{name="Base.556Box", count=2}} },
        rewards = { money=550, fame=130, items={{type="Base.AssaultRifle", count=1},{type="Base.Money", count=160}} },
        timeLimit = nil
    },
    {
        id="outl_t3_04", factionId="survivors", tier=3, type="MIXED",
        title="Conquista Brutal",
        description="Abate 450 zumbis e colete equipamentos militares.",
        objectives = { kills=450, items={{name="Base.Vest_BulletPolice", count=1}} },
        rewards = { money=650, fame=140, items={{type="Base.Axe", count=1},{type="Base.Sledgehammer", count=1},{type="Base.Money", count=180}} },
        timeLimit = nil
    },

    -- TIER 4: Elite (fama 800+)
    {
        id="outl_t4_01", factionId="survivors", tier=4, type="MIXED",
        title="Rei do Submundo",
        description="Elimine 700 zumbis e colete arsenal para dominar a regiao.",
        objectives = { kills=700, items={{name="Base.AssaultRifle", count=1},{name="Base.556Box", count=3}} },
        rewards = { money=900, fame=160, items={{type="Base.Pistol3", count=1},{type="Base.Money", count=200}} },
        timeLimit = nil
    },
    {
        id="outl_t4_02", factionId="survivors", tier=4, type="MIXED",
        title="Imposto de Sangue",
        description="Mate 900 zumbis e reuna suprimentos para a operacao especial.",
        objectives = { kills=900, items={{name="Base.Bandage", count=10},{name="Base.Antibiotics", count=5},{name="Base.PetrolCan", count=3}} },
        rewards = { money=1100, fame=170, items={{type="Base.MRE", count=4},{type="Base.Money", count=220}} },
        timeLimit = nil
    },
    {
        id="outl_t4_03", factionId="survivors", tier=4, type="MIXED",
        title="Operacao Furacao",
        description="Elimine 1000 zumbis e colete equipamentos pesados.",
        objectives = { kills=1000, items={{name="Base.Shotgun", count=1},{name="Base.ShotgunShellsBox", count=5}} },
        rewards = { money=1250, fame=180, items={{type="Base.Vest_BulletPolice", count=1},{type="Base.Money", count=240}} },
        timeLimit = nil
    },
    {
        id="outl_t4_04", factionId="survivors", tier=4, type="MIXED",
        title="Territorio Conquistado",
        description="Abata 1200 zumbis e estabeleca controle total da zona.",
        objectives = { kills=1200, items={{name="Base.AssaultRifle", count=1},{name="Base.Pistol3", count=1}} },
        rewards = { money=1500, fame=200, items={{type="Base.44Box", count=3},{type="Base.556Box", count=3},{type="Base.Money", count=260}} },
        timeLimit = nil
    },

    -- TIER 5: Lenda (fama 1500+)
    {
        id="outl_t5_01", factionId="survivors", tier=5, type="MIXED",
        title="O Indomavel",
        description="Elimine 2000 zumbis e monte o arsenal definitivo dos Sobreviventes.",
        objectives = { kills=2000, items={{name="Base.AssaultRifle", count=1},{name="Base.Pistol3", count=1},{name="Base.Shotgun", count=1}} },
        rewards = { money=2500, fame=300, items={{type="Base.Katana", count=1},{type="Base.556Box", count=4},{type="Base.Money", count=300}} },
        timeLimit = nil
    },
    {
        id="outl_t5_02", factionId="survivors", tier=5, type="MIXED",
        title="A Lei que Fazemos",
        description="Mate 3000 zumbis e reuna os suprimentos para a nova ordem.",
        objectives = { kills=3000, items={{name="Base.PetrolCan", count=5},{name="Base.Antibiotics", count=8},{name="Base.AssaultRifle", count=1}} },
        rewards = { money=3250, fame=350, items={{type="Base.Bag_ALICEpack_Army", count=1},{type="Base.MRE", count=5},{type="Base.Money", count=350}} },
        timeLimit = nil
    },
    {
        id="outl_t5_03", factionId="survivors", tier=5, type="MIXED",
        title="Imperio das Cinzas",
        description="Elimine 4500 zumbis e consolide o dominio total.",
        objectives = { kills=4500, items={{name="Base.Vest_BulletPolice", count=1},{name="Base.AssaultRifle", count=1},{name="Base.44Box", count=3}} },
        rewards = { money=4000, fame=400, items={{type="Base.Pistol3", count=1},{type="Base.AssaultRifle", count=1},{type="Base.556Box", count=4},{type="Base.Money", count=400}} },
        timeLimit = nil
    },
    {
        id="outl_t5_04", factionId="survivors", tier=5, type="MIXED",
        title="O Sobrevivente Eterno",
        description="6000 mortos e o arsenal completo. Ninguem questionara sua lenda.",
        objectives = { kills=6000, items={{name="Base.AssaultRifle", count=2},{name="Base.Katana", count=1},{name="Base.Pistol3", count=1}} },
        rewards = { money=6000, fame=500, items={{type="Base.AssaultRifle", count=1},{type="Base.Katana", count=1},{type="Base.Pistol3", count=1},{type="Base.Vest_BulletPolice", count=1},{type="Base.Shoes_ArmyBoots", count=1},{type="Base.MoneyBundle", count=4}} },
        timeLimit = nil
    },
}

-- ------------------------------------------------------------
-- MISSOES DIARIAS (Variacao de 5 para cada grupo)
-- Recompensas: 50 tampinhas + 20 Notas (Base.Money)
-- Cooldown: 24h apos conclusao.
-- ------------------------------------------------------------
TsT.DailyMissions = {
    combatants = {
        { id="daily_merc_01", factionId="combatants", type="KILL", title="Abate Rapido", description="Elimine 25 zumbis para manter a ordem regional.", objectives={kills=25}, rewards={money=50, items={{type="Base.Money", count=20}}} },
        { id="daily_merc_02", factionId="combatants", type="KILL", title="Treinamento de Recruta", description="Abata 40 zumbis como exercicio diario de tiro.", objectives={kills=40}, rewards={money=50, items={{type="Base.Money", count=20}}} },
        { id="daily_merc_03", factionId="combatants", type="KILL", title="Seguranca Regional", description="Limpe o perimetro eliminando 60 zumbis.", objectives={kills=60}, rewards={money=50, items={{type="Base.Money", count=20}}} },
        { id="daily_merc_04", factionId="combatants", type="MIXED", title="Contrato Menor", description="Elimine 15 zumbis e entregue 2 bandagens para o estoque medico.", objectives={kills=15, items={{name="Base.Bandage", count=2}}}, rewards={money=50, items={{type="Base.Money", count=20}}} },
        { id="daily_merc_05", factionId="combatants", type="KILL", title="Varredura Diaria", description="Realize uma varredura de rotina: 35 zumbis mortos.", objectives={kills=35}, rewards={money=50, items={{type="Base.Money", count=20}}} },
    },
    specialists = {
        { id="daily_surv_01", factionId="specialists", type="LOOT", title="Lenha do Dia", description="Reuna 2 troncos para manter a fogueira da base.", objectives={items={{name="Base.Log", count=2}}}, rewards={money=50, items={{type="Base.Money", count=20}}} },
        { id="daily_surv_02", factionId="specialists", type="LOOT", title="Reparos Basicos", description="Traga 10 pregos e um martelo para reparos urgentes.", objectives={items={{name="Base.Nails", count=10},{name="Base.Hammer", count=1}}}, rewards={money=50, items={{type="Base.Money", count=20}}} },
        { id="daily_surv_03", factionId="specialists", type="LOOT", title="Jardinagem de Emergencia", description="Encontre 2 pacotes de sementes (tomate ou batata).", objectives={items={{name="Base.TomatoSeeds", count=2}}}, rewards={money=50, items={{type="Base.Money", count=20}}} },
        { id="daily_surv_04", factionId="specialists", type="LOOT", title="Estoque de Agua", description="Colete 3 garrafas de agua para o reservatorio.", objectives={items={{name="Base.WaterBottleFull", count=3}}}, rewards={money=50, items={{type="Base.Money", count=20}}} },
        { id="daily_surv_05", factionId="specialists", type="LOOT", title="Materiais de Construcao", description="Colete 8 tabuas para reforcar as defesas.", objectives={items={{name="Base.Plank", count=8}}}, rewards={money=50, items={{type="Base.Money", count=20}}} },
    },
    survivors = {
        { id="daily_outl_01", factionId="survivors", type="MIXED", title="Pintou Oportunidade", description="Elimine 15 zumbis e pegue 2 latas de comida no caminho.", objectives={kills=15, items={{name="Base.CannedBeans", count=2}}}, rewards={money=50, items={{type="Base.Money", count=20}}} },
        { id="daily_outl_02", factionId="survivors", type="MIXED", title="Assalto de Rua", description="Mate 20 zumbis e recupere 5 notas de dinheiro.", objectives={kills=20, items={{name="Base.Money", count=5}}}, rewards={money=50, items={{type="Base.Money", count=20}}} },
        { id="daily_outl_03", factionId="survivors", type="MIXED", title="Cobranca de Divida", description="Elimine 10 zumbis e traga 1 joia valiosa.", objectives={kills=10, items={{name="Base.Necklace_Gold", count=1}}}, rewards={money=50, items={{type="Base.Money", count=20}}} },
        { id="daily_outl_04", factionId="survivors", type="LOOT", title="Ferramentas do Crime", description="Encontre um pe de cabra para a proxima invasao.", objectives={items={{name="Base.Crowbar", count=1}}}, rewards={money=50, items={{type="Base.Money", count=20}}} },
        { id="daily_outl_05", factionId="survivors", type="KILL", title="Limpeza de Area", description="Elimine 30 zumbis na zona de interesse.", objectives={kills=30}, rewards={money=50, items={{type="Base.Money", count=20}}} },
    }
}

function TsT.getDailyMissionById(id)
    if not id then return nil end
    for faction, list in pairs(TsT.DailyMissions) do
        for _, m in ipairs(list) do
            if m.id == id then return m end
        end
    end
    return nil
end

-- ------------------------------------------------------------
-- FUNCOES UTILITARIAS
-- ------------------------------------------------------------

--- Retorna uma missao pelo ID
---@param id string
---@return table|nil
function TsT.getMissionById(id)
    for _, m in ipairs(TsT.Missions) do
        if m.id == id then return m end
    end
    -- Busca nas diarias tambem
    return TsT.getDailyMissionById(id)
end

--- Retorna todas as missoes de uma faccao disponiveis para o nivel de fama atual
---@param factionId string
---@param fama number
---@return table[] lista de missoes disponiveis
function TsT.getMissoesDisponiveis(factionId, fama)
    local nivel, _ = TsT.getNivelFama(fama)
    local resultado = {}
    for _, m in ipairs(TsT.Missions) do
        if m.factionId == factionId and m.tier <= nivel then
            table.insert(resultado, m)
        end
    end
    return resultado
end

--- Retorna o nome de exibicao traduzido de um item pelo seu fullType (ex: "Base.Bandage")
--- Usa getScriptManager():FindItem() para obter o DisplayName correto do jogo.
--- Fallback: parte apos o ponto (ex: "Bandage"), ou o proprio fullType se tudo falhar.
---@param fullType string  ex: "Base.Bandage"
---@return string  nome legivel, ex: "Bandage"
function TsT.getItemDisplayName(fullType)
    if not fullType then return "?" end
    local ok, result = pcall(function()
        local scriptItem = getScriptManager():FindItem(fullType)
        if scriptItem then
            return scriptItem:getDisplayName()
        end
        return nil
    end)
    if ok and result and result ~= "" then
        return result
    end
    -- Fallback: extrai a parte apos o ponto ("Base.Bandage" → "Bandage")
    return fullType:match("%.(.+)") or fullType
end

--- Retorna a textura do icone de um item pelo seu fullType (ex: "Base.Bandage")
--- Usa scriptItem:getNormalTexture() — o mesmo metodo usado pelo inventario do jogo.
--- Retorna nil se nao encontrar.
---@param fullType string
---@return texture|nil
function TsT.getItemIconTexture(fullType)
    if not fullType then return nil end
    local ok, tex = pcall(function()
        local scriptItem = getScriptManager():FindItem(fullType)
        if not scriptItem then return nil end
        local t = scriptItem:getNormalTexture()
        if t then return t end
        -- fallback via getTexture("Item_XXX")
        local icon = scriptItem:getIcon()
        if icon and icon ~= "" then
            return getTexture("media/textures/Item_" .. icon .. ".png") or getTexture("Item_" .. icon)
        end
        return nil
    end)
    if ok then return tex end
    return nil
end

-- ------------------------------------------------------------
-- SISTEMA DE ALIASES — Resolve problemas de itens com nomes multiplos
-- ex: WaterBottleFull vs WaterBottle, TomatoSeeds vs TomatoSeed
-- ------------------------------------------------------------
local ITEM_ALIASES = {
    ["Base.WaterBottleFull"] = { "Base.WaterBottle", "Base.FullWaterBottle", "Base.WaterFull", "Base.PlasticWaterBottle" },
    ["Base.WaterBottle"]     = { "Base.WaterBottleFull", "Base.FullWaterBottle", "Base.WaterFull", "Base.PlasticWaterBottle" },
    ["Base.TinnedBeans"]     = { "Base.CannedBeans", "Base.CannedBeansFull" },
    ["Base.CannedBeans"]     = { "Base.TinnedBeans", "Base.CannedBeansFull" },
    ["Base.TomatoSeeds"]     = { "Base.TomatoSeed", "Base.TomatoSeedPacket", "Base.TomatoSeedsPacket" },
    ["Base.TomatoSeed"]      = { "Base.TomatoSeeds", "Base.TomatoSeedPacket", "Base.TomatoSeedsPacket" },
    ["Base.PotatoSeeds"]     = { "Base.PotatoSeed", "Base.PotatoSeedPacket", "Base.PotatoSeedsPacket" },
    ["Base.PotatoSeed"]      = { "Base.PotatoSeeds", "Base.PotatoSeedPacket", "Base.PotatoSeedsPacket" },
    ["Base.CarrotSeeds"]     = { "Base.CarrotSeed", "Base.CarrotSeedPacket", "Base.CarrotSeedsPacket" },
    ["Base.CarrotSeed"]      = { "Base.CarrotSeeds", "Base.CarrotSeedPacket", "Base.CarrotSeedsPacket" },
    ["Base.BroccoliSeeds"]   = { "Base.BroccoliSeed", "Base.BroccoliSeedPacket", "Base.BroccoliSeedsPacket" },
    ["Base.BroccoliSeed"]    = { "Base.BroccoliSeeds", "Base.BroccoliSeedPacket", "Base.BroccoliSeedsPacket" },
    ["Base.CabbageSeeds"]    = { "Base.CabbageSeed", "Base.CabbageSeedPacket", "Base.CabbageSeedsPacket" },
    ["Base.CabbageSeed"]     = { "Base.CabbageSeeds", "Base.CabbageSeedPacket", "Base.CabbageSeedsPacket" },
    ["Base.RadishSeeds"]     = { "Base.RadishSeed", "Base.RadishSeedPacket", "Base.RadishSeedsPacket" },
    ["Base.RadishSeed"]      = { "Base.RadishSeeds", "Base.RadishSeedPacket", "Base.RadishSeedsPacket" },
    ["Base.StrawberrySeeds"] = { "Base.StrawberrySeed", "Base.StrawberrySeedPacket", "Base.StrawberrySeedsPacket" },
    ["Base.StrawberrySeed"]  = { "Base.StrawberrySeeds", "Base.StrawberrySeedPacket", "Base.StrawberrySeedsPacket" },
    ["Base.Necklace_Gold"]   = { "Base.Necklace_Silver", "Base.Ring_Gold", "Base.Ring_Silver", "Base.Bracelet_Gold", "Base.Bracelet_Silver", "Base.Earring_Gold", "Base.Earring_Silver" },
}

--- Conta a quantidade de um item no inventario (recursivo)
---@param container ItemContainer
---@param itemType string
---@return number
function TsT.getItemCount(container, itemType)
    if not container or not itemType then return 0 end
    
    local function countRecurse(cont, target)
        local count = 0
        local items = cont:getItems()
        for i=0, items:size()-1 do
            local item = items:get(i)
            if item:getFullType() == target then
                count = count + 1
            elseif item:getCategory() == "Container" then
                count = count + countRecurse(item:getInventory(), target)
            end
        end
        return count
    end

    local total = countRecurse(container, itemType)

    local aliases = ITEM_ALIASES[itemType]
    if aliases then
        for _, alias in ipairs(aliases) do
            total = total + countRecurse(container, alias)
        end
    end
    return total
end

--- Retorna uma lista de objetos de item (InventoryItem) (recursivo)
---@param container ItemContainer
---@param itemType string
---@param max number (opcional)
---@return table lista de itens
function TsT.getAllItemsOfType(container, itemType, max)
    if not container or not itemType then return {} end
    local result = {}
    
    local function findRecurse(cont, target)
        local items = cont:getItems()
        for i=0, items:size()-1 do
            if max and #result >= max then return end
            local item = items:get(i)
            if item:getFullType() == target then
                table.insert(result, item)
            elseif item:getCategory() == "Container" then
                findRecurse(item:getInventory(), target)
            end
        end
    end

    findRecurse(container, itemType)
    local aliases = ITEM_ALIASES[itemType]
    if aliases then
        for _, alias in ipairs(aliases) do
            if max and #result >= max then break end
            findRecurse(container, alias)
        end
    end
    return result
end
