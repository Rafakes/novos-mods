-- ============================================================
-- TsT_MissionManager.lua — Validação e Recompensas de Missões (Server)
-- Mod: The Survival Triade | Build 42
-- Executado apenas no servidor
-- ============================================================

if isClient() then return end

TsT = TsT or {}
TsT.MissionManager = {}

-- ------------------------------------------------------------
-- Mapa estático de arma → magazine compatível (B42)
-- Valor nil = arma sem clip separado (bala direta)
-- ------------------------------------------------------------
local WEAPON_MAGAZINE_MAP = {
    ["Base.Pistol"]              = "Base.9mmClip",
    ["Base.Pistol2"]             = "Base.9mmClip",
    ["Base.Pistol3"]             = "Base.44Clip",
    ["Base.AssaultRifle"]        = "Base.556Clip",
    ["Base.AssaultRifle2"]       = "Base.556Clip",
    ["Base.M14"]                 = "Base.308Clip",
    ["Base.HuntingRifle"]        = nil,
    ["Base.DoubleBarrelShotgun"] = nil,
    ["Base.Shotgun"]             = nil,
}

local function getMagazineTypeForWeapon(itemType)
    if WEAPON_MAGAZINE_MAP[itemType] ~= nil then
        return WEAPON_MAGAZINE_MAP[itemType]
    end
    -- Detecta dinamicamente via ClipType no ScriptItem (fallback)
    local ok, si = pcall(function() return getScriptManager():FindItem(itemType) end)
    if ok and si then
        local clip
        pcall(function()
            if si.getClipItem then clip = si:getClipItem()
            elseif si.getMagazineType then clip = si:getMagazineType() end
        end)
        if clip and clip ~= "" then return clip end
    end
    return nil
end

-- ------------------------------------------------------------
-- UTILITÁRIO: Entregar item ao jogador no inventário (server B42)
-- Não depende de ScriptManager.instance (falha silenciosa em
-- dedicated server). Adiciona magazine automaticamente para armas.
-- Fallback no chão se AddItem retornar nil.
-- ------------------------------------------------------------
local function giveItemToPlayer(player, itemType, count)
    if not player or not itemType then return end
    local qtd    = count or 1
    local inv    = player:getInventory()
    local square = player:getCurrentSquare()

    -- Detecta magazine uma única vez antes do loop
    local magazineType = getMagazineTypeForWeapon(itemType)

    for _ = 1, qtd do
        local ok, newItem = pcall(function() return inv:AddItem(itemType) end)
        if ok and newItem then
            if sendAddItemToContainer then sendAddItemToContainer(inv, newItem) end
            pcall(function() if newItem.syncItemFields then newItem:syncItemFields() end end)
            -- item:transmitModData() removido: sendAddItemToContainer + syncItemFields já sincronizam o item.

            -- Adiciona magazine junto com a arma
            if magazineType then
                local mok, mag = pcall(function() return inv:AddItem(magazineType) end)
                if mok and mag then
                    if sendAddItemToContainer then sendAddItemToContainer(inv, mag) end
                    print("[TsT] Magazine adicionado: " .. magazineType .. " para " .. itemType)
                else
                    print("[TsT] AVISO: falha ao adicionar magazine " .. tostring(magazineType) .. " para " .. itemType)
                end
            end
        elseif square then
            print("[TsT] giveItemToPlayer: AddItem retornou nil para " .. tostring(itemType) .. " — dropando no chão")
            local offX = ZombRandFloat(0.1, 0.9)
            local offY = ZombRandFloat(0.1, 0.9)
            square:AddWorldInventoryItem(itemType, offX, offY, 0, true)
            if magazineType then
                square:AddWorldInventoryItem(magazineType, offX, offY, 0, true)
            end
        else
            print("[TsT] ERRO: não foi possível entregar " .. tostring(itemType) .. " para " .. player:getUsername())
        end
    end
end

-- ------------------------------------------------------------
-- ACEITAR MISSÃO
-- ------------------------------------------------------------

--- Registra o início de uma missão para o jogador
---@param player IsoPlayer
---@param missionId string
---@return boolean sucesso, string mensagem
function TsT.MissionManager.aceitarMissao(player, missionId)
    local mission = TsT.getMissionById(missionId)
    if not mission then
        return false, "Missão não encontrada: " .. tostring(missionId)
    end

    local md = player:getModData()
    local pos = TsT.getModData(player)

    local isDaily = missionId:sub(1, 6) == "daily_"

    -- Verifica se já tem missão ativa no slot correspondente
    if isDaily then
        if pos.activeDailyMission ~= nil then
            return false, "Já tem uma missão diária ativa."
        end
    else
        if pos.activeMission ~= nil then
            return false, "Já tem uma missão ativa."
        end
    end

    -- Verifica se já completou esta missão (apenas para missões normais, diárias repetem)
    if not isDaily and TsT.FactionManager.jaConcluiu(player, missionId) then
        return false, "Missão já concluída"
    end

    -- Verifica se a facção do jogador bate com a da missão
    if pos.faction ~= mission.factionId then
        return false, "Missão pertence a outra facção"
    end

    -- Verifica o tier
    local fama = pos.fame[pos.faction] or 0
    local nivelAtual, _ = TsT.getNivelFama(fama)
    if not isDaily and mission.tier > nivelAtual then
        return false, "Fama insuficiente para este tier"
    end

    -- Inicializa dados de progresso
    local agora = {
        startKills = player:getZombieKills(),
        startTime  = TsT.getTimestamp(),
        progress   = 0,       -- usado para LOOT: contagem de itens entregues
    }

    if isDaily then
        pos.activeDailyMission     = missionId
        pos.activeDailyMissionData = agora
    else
        pos.activeMission     = missionId
        pos.activeMissionData = agora
    end

    -- Salva missão ativa no backup global (persiste após morte)
    TsT.FactionManager.savePlayerData(player)

    print("[TsT] " .. player:getUsername() .. " aceitou missão: " .. missionId)
    sendServerCommand(player, "TsT", "MissionAccepted", {
        missionId = missionId,
        isDaily = isDaily,
        missionData = agora,
    })
    return true, "ok"
end

-- ------------------------------------------------------------
-- ABANDONAR MISSÃO
-- ------------------------------------------------------------

---@param player IsoPlayer
---@param missionId string
function TsT.MissionManager.abandonarMissao(player, missionId)
    local pos = TsT.getModData(player)
    
    if missionId == pos.activeDailyMission then
        pos.activeDailyMission = nil
        pos.activeDailyMissionData = {}
    elseif missionId == pos.activeMission then
        pos.activeMission = nil
        pos.activeMissionData = {}
    end

    -- Salva estado (missão removida) no backup global
    TsT.FactionManager.savePlayerData(player)

    print("[TsT] " .. player:getUsername() .. " abandonou missão: " .. tostring(missionId))
    sendServerCommand(player, "TsT", "MissionAbandoned", { missionId = missionId })
end

-- ------------------------------------------------------------
-- COMPLETAR MISSÃO — Validação Server-Side
-- ------------------------------------------------------------

--- Valida e recompensa o jogador ao completar uma missão
---@param player IsoPlayer
---@param missionId string
---@return boolean sucesso, string mensagem
function TsT.MissionManager.completarMissao(player, missionId)
    local mission = TsT.getMissionById(missionId)
    if not mission then
        return false, "Missão não encontrada"
    end

    local pos = TsT.getModData(player)
    local isDaily = (missionId:sub(1, 6) == "daily_")
    local missionData = isDaily and pos.activeDailyMissionData or pos.activeMissionData

    -- Verifica se a missão está realmente ativa no slot correto
    if isDaily then
        if pos.activeDailyMission ~= missionId then
            return false, "Esta missão diária não está ativa"
        end
    else
        if pos.activeMission ~= missionId then
            return false, "Esta missão não está ativa"
        end
    end

    -- Verifica se já foi concluída antes (apenas para normais)
    if not isDaily and TsT.FactionManager.jaConcluiu(player, missionId) then
        return false, "Missão já concluída anteriormente"
    end

    local autorizado  = true
    local motivo      = ""

    -- ---- Validação: KILL ----
    if mission.type == "KILL" or mission.type == "MIXED" then
        if mission.objectives and mission.objectives.kills then
            local killsFeitos = player:getZombieKills() - (missionData.startKills or 0)
            if killsFeitos < mission.objectives.kills then
                autorizado = false
                motivo = "Kills insuficientes: " .. killsFeitos .. "/" .. mission.objectives.kills
            end
        end
    end

    -- ---- Validação: LOOT ----
    if autorizado and (mission.type == "LOOT" or mission.type == "MIXED") then
        if mission.objectives and mission.objectives.items then
            local inventario = player:getInventory()
            for _, itemReq in ipairs(mission.objectives.items) do
                -- Usa o helper TsT que lida com Alias de itens (importante para Build 42)
                -- e já faz a recursão em mochilas (getItemCount em shared/TsT_Missions.lua)
                local count = TsT.getItemCount(inventario, itemReq.name)
                
                if count < itemReq.count then
                    autorizado = false
                    motivo = "Item insuficiente: " .. itemReq.name .. " (" .. count .. "/" .. itemReq.count .. ")"
                    break
                end
            end
        end
    end

    -- ---- Missão não autorizada ----
    if not autorizado then
        print("[TsT] " .. player:getUsername() .. " tentativa inválida (" .. missionId .. "): " .. motivo)
        sendServerCommand(player, "TsT", "Error", { msg = motivo })
        return false, motivo
    end

    -- ---- Remove itens LOOT do inventário ----
    if mission.type == "LOOT" or mission.type == "MIXED" then
        if mission.objectives and mission.objectives.items then
            local inventario = player:getInventory()
            for _, itemReq in ipairs(mission.objectives.items) do
                -- Remoção manual recursiva (mais confiável em Build 42 server-side)
                local itemsToRemove = TsT.getAllItemsOfType(inventario, itemReq.name, itemReq.count)
                for _, itemObj in ipairs(itemsToRemove) do
                    if itemObj then
                        local container = itemObj:getContainer()
                        if container then
                            container:Remove(itemObj)
                            sendRemoveItemFromContainer(container, itemObj)
                        else
                            inventario:Remove(itemObj)
                            sendRemoveItemFromContainer(inventario, itemObj)
                        end
                    end
                end
            end
        end
    end

    -- ---- Entrega as recompensas ----
    if mission.rewards then
        -- Recompensas de itens (inventário primeiro, chão se cheio)
        if mission.rewards.items then
            for _, recompensa in ipairs(mission.rewards.items) do
                giveItemToPlayer(player, recompensa.type, recompensa.count or 1)
            end
        end

        -- Dinheiro do mod
        if mission.rewards.money and mission.rewards.money > 0 then
            TsT.FactionManager.addMoney(player, mission.rewards.money)
        end

        -- Fama
        if mission.rewards.fame and mission.rewards.fame > 0 then
            TsT.FactionManager.addFama(player, mission.rewards.fame)
        end
    end

    -- ---- Atualiza estado ----
    TsT.FactionManager.marcarConcluida(player, missionId)

    if isDaily then
        pos.lastDailyCompletionTime = TsT.getTimestamp()
        pos.activeDailyMission      = nil
        pos.activeDailyMissionData  = {}
    else
        pos.activeMission           = nil
        pos.activeMissionData       = {}
    end

    -- Salva estado final (missão concluída, fama e dinheiro atualizados) no backup global
    TsT.FactionManager.savePlayerData(player)

    local novaFama, _ = TsT.FactionManager.getFama(player)
    local novoMoney   = TsT.FactionManager.getMoney(player)
    local novoNivel, nomeNivel = TsT.getNivelFama(novaFama)

    print("[TsT] " .. player:getUsername() .. " completou missão " .. missionId ..
          " | Fama: +" .. (mission.rewards.fame or 0) .. " (" .. novaFama .. ") | Dinheiro: +" .. (mission.rewards.money or 0))

    sendServerCommand(player, "TsT", "MissionSuccess", {
        missionId  = missionId,
        fameDelta  = mission.rewards.fame or 0,
        moneyDelta = mission.rewards.money or 0,
        novaFama   = novaFama,
        novoMoney  = novoMoney,
        nivel      = novoNivel,
        nomeNivel  = nomeNivel,
    })

    return true, "ok"
end

-- ------------------------------------------------------------
-- COMPRA NA LOJA
-- ------------------------------------------------------------

---@param player IsoPlayer
---@param shopItemId string
---@return boolean sucesso, string mensagem
function TsT.MissionManager.comprarItem(player, shopItemId)
    local shopItem = TsT.getShopItemById(shopItemId)
    if not shopItem then
        return false, "Item de loja não encontrado: " .. tostring(shopItemId)
    end

    local pos     = TsT.getModData(player)
    local fama    = pos.fame[pos.faction] or 0
    local nivel,_ = TsT.getNivelFama(fama)

    -- Verifica facção
    if shopItem.factionId ~= pos.faction then
        return false, "Item pertence a outra facção"
    end

    -- Verifica tier mínimo
    if shopItem.tierMin > nivel then
        return false, "Tier insuficiente para este item"
    end

    -- Verifica saldo
    if not TsT.FactionManager.removeMoney(player, shopItem.preco) then
        return false, "Dinheiro insuficiente"
    end

    -- Entrega o item (inventário primeiro, chão se cheio)
    giveItemToPlayer(player, shopItem.itemType, shopItem.count or 1)

    local novoMoney = TsT.FactionManager.getMoney(player)
    -- Salva saldo atualizado no backup global
    TsT.FactionManager.savePlayerData(player)
    print("[TsT] " .. player:getUsername() .. " comprou " .. shopItem.nome .. " por " .. shopItem.preco)

    sendServerCommand(player, "TsT", "ShopSuccess", {
        shopItemId = shopItemId,
        nome       = shopItem.nome,
        novoMoney  = novoMoney,
    })

    return true, "ok"
end
