-- ============================================================
-- TsT_Items.lua — Catalogos de Loja por Faccao e Tier
-- Mod: The Survival Triade | Build 42
-- ============================================================

TsT = TsT or {}
TsT.ShopItems = {}

-- Estrutura de cada item da loja:
-- {
--   id         = string unico
--   factionId  = "combatants" | "survivors" | "specialists"
--   tierMin    = tier minimo para compra (1..5)
--   itemType   = string (ex: "Base.Pistol")
--   nome       = string (nome de exibicao)
--   preco      = number (moeda interna TsT)
--   count      = number (quantidade entregue)
-- }

TsT.ShopItems = {

    -- ============================================================
    -- LOJA DOS COMBATENTES — Foco em Combate
    -- ============================================================

    -- Tier 1 (Recruta)
    { id="shop_merc_01", factionId="combatants", tierMin=1, itemType="Base.Bullets9mmBox",    nome="Municao 9mm",         preco=80,   count=1 },
    { id="shop_merc_02", factionId="combatants", tierMin=1, itemType="Base.ShotgunShellsBox", nome="Cartuchos Escopeta",  preco=80,   count=1 },
    { id="shop_merc_03", factionId="combatants", tierMin=1, itemType="Base.HuntingKnife",     nome="Faca de Caca",        preco=100,  count=1 },
    { id="shop_merc_04", factionId="combatants", tierMin=1, itemType="Base.BaseballBat",      nome="Taco de Beisebol",    preco=90,   count=1 },
    { id="shop_merc_new_1", factionId="combatants", tierMin=1, itemType="Base.HolsterDouble",  nome="Coldre Duplo",        preco=120,  count=1 },
    { id="shop_merc_new_2", factionId="combatants", tierMin=1, itemType="Base.AmmoStraps",     nome="Bandoleira de Rifle", preco=100,  count=1 },

    -- Tier 2 (Agente)
    { id="shop_merc_05", factionId="combatants", tierMin=2, itemType="Base.Pistol",           nome="Pistola M9",          preco=500,  count=1 },
    { id="shop_merc_06", factionId="combatants", tierMin=2, itemType="Base.Shotgun",          nome="Escopeta JS-2000",    preco=700,  count=1 },
    { id="shop_merc_07", factionId="combatants", tierMin=2, itemType="Base.Machete",          nome="Facao",               preco=350,  count=1 },
    { id="shop_merc_08", factionId="combatants", tierMin=2, itemType="Base.Vest_BulletProof", nome="Colete a Prova de Balas", preco=600, count=1 },
    { id="shop_merc_new_3", factionId="combatants", tierMin=2, itemType="Base.M14",            nome="Rifle M14",           preco=800,  count=1 },

    -- Tier 3 (Veterano)
    { id="shop_merc_09", factionId="combatants", tierMin=3, itemType="Base.44Box",            nome="Municao .44 Magnum",  preco=250,  count=1 },
    { id="shop_merc_10", factionId="combatants", tierMin=3, itemType="Base.556Box",           nome="Municao 5.56mm",      preco=300,  count=1 },
    { id="shop_merc_11", factionId="combatants", tierMin=3, itemType="Base.Pistol3",          nome="Desert Eagle",        preco=1200, count=1 },
    { id="shop_merc_12", factionId="combatants", tierMin=3, itemType="Base.Axe",              nome="Machado de Bombeiro", preco=400,  count=1 },
    { id="shop_merc_new_4", factionId="combatants", tierMin=3, itemType="Base.44Box",          nome="Pacote Municao .44 (3x)", preco=650, count=3 },

    -- Tier 4 (Elite)
    { id="shop_merc_13", factionId="combatants", tierMin=4, itemType="Base.AssaultRifle",     nome="Rifle de Assalto M16", preco=3000, count=1 },
    { id="shop_merc_14", factionId="combatants", tierMin=4, itemType="Base.Vest_BulletPolice", nome="Colete Policial",    preco=800,  count=1 },
    { id="shop_merc_15", factionId="combatants", tierMin=4, itemType="Base.Shoes_ArmyBoots",  nome="Botas Militares",    preco=600,  count=1 },
    { id="shop_merc_16", factionId="combatants", tierMin=4, itemType="Base.556Clip",          nome="Pente 5.56mm",        preco=200,  count=1 },
    { id="shop_merc_new_5", factionId="combatants", tierMin=4, itemType="Base.556Box",         nome="Pacote Municao 5.56 (3x)", preco=850, count=3 },

    -- Tier 5 (Lenda)
    { id="shop_merc_17", factionId="combatants", tierMin=5, itemType="Base.Katana",           nome="Katana Autentica",    preco=5000, count=1 },
    { id="shop_merc_18", factionId="combatants", tierMin=5, itemType="Base.AssaultRifle",     nome="Rifle M16 (Extra)",   preco=4000, count=1 },
    { id="shop_merc_19", factionId="combatants", tierMin=5, itemType="Base.556Box",           nome="Caixao de Municao",   preco=600,  count=3 },
    { id="shop_merc_20", factionId="combatants", tierMin=5, itemType="Base.Pistol3",          nome="D. Eagle (Reserva)", preco=1500, count=1 },
    { id="shop_merc_new_6", factionId="combatants", tierMin=5, itemType="Base.ShotgunShellsBox", nome="Pacote Cartuchos (3x)", preco=1200, count=3 },
    { id="shop_merc_book1", factionId="combatants", tierMin=5, itemType="Base.BookFirstAid5",    nome="Primeiros Socorros Nivel 5", preco=2000, count=1 },
    { id="shop_merc_book2", factionId="combatants", tierMin=5, itemType="Base.BookTailoring5",   nome="Costura Nivel 5", preco=2000, count=1 },

    -- ============================================================
    -- LOJA DOS ESPECIALISTAS — Foco em Sobrevivencia/Crafting
    -- ============================================================

    -- Tier 1 (Recruta)
    { id="shop_surv_01", factionId="specialists", tierMin=1, itemType="Base.WaterBottle",        nome="Garrafa d'Agua",      preco=50,   count=2 },
    { id="shop_surv_02", factionId="specialists", tierMin=1, itemType="Base.TinnedBeans",       nome="Feijao Enlatado",     preco=40,   count=3 },
    { id="shop_surv_03", factionId="specialists", tierMin=1, itemType="Base.Bandage",           nome="Bandagens",           preco=60,   count=5 },
    { id="shop_surv_04", factionId="specialists", tierMin=1, itemType="Base.Saw",               nome="Serra",               preco=80,   count=1 },
    { id="shop_surv_new_1", factionId="specialists", tierMin=1, itemType="Base.Woodglue",        nome="Cola de Madeira",     preco=80,   count=1 },
    { id="shop_surv_new_2", factionId="specialists", tierMin=1, itemType="Base.DuctTape",        nome="Fita Adesiva",        preco=80,   count=1 },
    { id="shop_surv_new_7", factionId="specialists", tierMin=1, itemType="Base.AxeStone",        nome="Machado de Pedra",    preco=70,   count=1 },

    -- Tier 2 (Agente)
    { id="shop_surv_05", factionId="specialists", tierMin=2, itemType="Base.Bag_DuffelBag",     nome="Mochila Duffle",      preco=300,  count=1 },
    { id="shop_surv_06", factionId="specialists", tierMin=2, itemType="Base.Crowbar",           nome="Pe de Cabra",         preco=250,  count=1 },
    { id="shop_surv_07", factionId="specialists", tierMin=2, itemType="Base.Antibiotics",       nome="Antibioticos",        preco=150,  count=2 },
    { id="shop_surv_08", factionId="specialists", tierMin=2, itemType="Base.FishingRod",        nome="Vara de Pesca",       preco=200,  count=1 },
    { id="shop_surv_new_3", factionId="specialists", tierMin=2, itemType="Base.NailsBox",        nome="Caixa de Pregos",     preco=200,  count=1 },

    -- Tier 3 (Veterano)
    { id="shop_surv_09", factionId="specialists", tierMin=3, itemType="Base.Bag_ALICEpack_Army", nome="Mochila Militar",   preco=700,  count=1 },
    { id="shop_surv_10", factionId="specialists", tierMin=3, itemType="Base.Sledgehammer",       nome="Marreta",           preco=500,  count=1 },
    { id="shop_surv_11", factionId="specialists", tierMin=3, itemType="Base.ElectronicsMag4",    nome="Revista Gerador",   preco=800,  count=1 },
    { id="shop_surv_12", factionId="specialists", tierMin=3, itemType="Base.CampingTentKit2_Packed", nome="Kit de Barraca",    preco=400,  count=1 },
    { id="shop_surv_new_4", factionId="specialists", tierMin=3, itemType="Base.Plank",           nome="Pack 10 Tabuas",      preco=450,  count=10 },

    -- Tier 4 (Elite)
    { id="shop_surv_13", factionId="specialists", tierMin=4, itemType="Base.Generator",         nome="Gerador",            preco=2500, count=1 },
    { id="shop_surv_14", factionId="specialists", tierMin=4, itemType="Base.PetrolCan",         nome="Galao de Gasolina",  preco=200,  count=2 },
    { id="shop_surv_15", factionId="specialists", tierMin=4, itemType="Base.WaterRationCan",               nome="Racao Militar",      preco=250,  count=3 },
    { id="shop_surv_16", factionId="specialists", tierMin=4, itemType="Base.FirstAidKit",       nome="Kit de Primeiros Socorros", preco=600, count=1 },
    { id="shop_surv_new_5", factionId="specialists", tierMin=4, itemType="Base.SheetMetal",      nome="Pacote Chapas Metal (5x)", preco=1200, count=5 },

    -- Tier 5 (Lenda)
    { id="shop_surv_17", factionId="specialists", tierMin=5, itemType="Base.BookCarpentry5",    nome="Carpintaria Nivel 5", preco=2000, count=1 },
    { id="shop_surv_18", factionId="specialists", tierMin=5, itemType="Base.BookMechanic5",     nome="Mecanica Nivel 5",   preco=2000, count=1 },
    { id="shop_surv_19", factionId="specialists", tierMin=5, itemType="Base.Katana",            nome="Katana (Defesa)",    preco=4000, count=1 },
    { id="shop_surv_20", factionId="specialists", tierMin=5, itemType="Base.Generator",        nome="Gerador Extra",      preco=3000, count=1 },
    { id="shop_surv_new_6", factionId="specialists", tierMin=5, itemType="Base.SmallSheetMetal", nome="Pact. Chapas Pequenas (5x)", preco=1000, count=5 },

    -- ============================================================
    -- LOJA DOS SOBREVIVENTES — Misto (Combate + Sobrevivencia)
    -- ============================================================

    -- Tier 1 (Recruta)
    { id="shop_outl_01", factionId="survivors", tierMin=1, itemType="Base.HuntingKnife",       nome="Faca de Caca",        preco=80,   count=1 },
    { id="shop_outl_02", factionId="survivors", tierMin=1, itemType="Base.Crowbar",            nome="Pe de Cabra",         preco=150,  count=1 },
    { id="shop_outl_03", factionId="survivors", tierMin=1, itemType="Base.TinnedBeans",        nome="Racao (Roubada)",     preco=30,   count=4 },
    { id="shop_outl_04", factionId="survivors", tierMin=1, itemType="Base.Bullets9mmBox",      nome="Municao 9mm",         preco=70,   count=1 },
    { id="shop_outl_new_1", factionId="survivors", tierMin=1, itemType="Base.Screwdriver",       nome="Chave de Fenda",      preco=60,   count=1 },
    { id="shop_outl_new_2", factionId="survivors", tierMin=1, itemType="Base.WeldingMask",       nome="Mascara de Solda",    preco=150,  count=1 },

    -- Tier 2 (Agente)
    { id="shop_outl_05", factionId="survivors", tierMin=2, itemType="Base.Pistol",             nome="Pistola M9",          preco=450,  count=1 },
    { id="shop_outl_06", factionId="survivors", tierMin=2, itemType="Base.Machete",            nome="Facao",               preco=300,  count=1 },
    { id="shop_outl_07", factionId="survivors", tierMin=2, itemType="Base.PetrolCan",          nome="Combustivel",         preco=160,  count=1 },
    { id="shop_outl_08", factionId="survivors", tierMin=2, itemType="Base.Bag_DuffelBag",      nome="Mochila (Furtada)",   preco=250,  count=1 },
    { id="shop_outl_new_3", factionId="survivors", tierMin=2, itemType="Base.BlowTorch",         nome="Macarico (Cheio)",    preco=400,  count=1 },

    -- Tier 3 (Veterano)
    { id="shop_outl_09", factionId="survivors", tierMin=3, itemType="Base.Shotgun",            nome="Escopeta",            preco=600,  count=1 },
    { id="shop_outl_10", factionId="survivors", tierMin=3, itemType="Base.Bag_ALICEpack_Army", nome="Mochila Militar",    preco=600,  count=1 },
    { id="shop_outl_11", factionId="survivors", tierMin=3, itemType="Base.Antibiotics",        nome="Remedios (Duvidosos)", preco=120, count=3 },
    { id="shop_outl_12", factionId="survivors", tierMin=3, itemType="Base.ShotgunShellsBox",   nome="Cartuchos",          preco=150,  count=2 },
    { id="shop_outl_new_4", factionId="survivors", tierMin=3, itemType="Base.PropaneTank",       nome="Tanque de Propano",   preco=500,  count=1 },
    { id="shop_outl_new_5", factionId="survivors", tierMin=3, itemType="Base.DoubleBarrelShotgun", nome="Escopeta Cano Duplo", preco=800,  count=1 },

    -- Tier 4 (Elite)
    { id="shop_outl_13", factionId="survivors", tierMin=4, itemType="Base.AssaultRifle",       nome="Rifle M16",          preco=2800, count=1 },
    { id="shop_outl_14", factionId="survivors", tierMin=4, itemType="Base.Pistol3",            nome="Desert Eagle",       preco=1100, count=1 },
    { id="shop_outl_15", factionId="survivors", tierMin=4, itemType="Base.Vest_BulletPolice",  nome="Colete Tatico",      preco=750,  count=1 },
    { id="shop_outl_16", factionId="survivors", tierMin=4, itemType="Base.WaterRationCan",                nome="Racao de Campo",     preco=200,  count=3 },
    { id="shop_outl_new_6", factionId="survivors", tierMin=4, itemType="Base.HuntingRifle",      nome="Rifle de Caca 700",   preco=1800, count=1 },

    -- Tier 5 (Lenda)
    { id="shop_outl_17", factionId="survivors", tierMin=5, itemType="Base.Katana",             nome="Katana dos Renegados", preco=4500, count=1 },
    { id="shop_outl_18", factionId="survivors", tierMin=5, itemType="Base.AssaultRifle",       nome="Segundo M16",        preco=3500, count=1 },
    { id="shop_outl_19", factionId="survivors", tierMin=5, itemType="Base.556Box",             nome="Caixao de 5.56",     preco=500,  count=3 },
    { id="shop_outl_20", factionId="survivors", tierMin=5, itemType="Base.Shoes_ArmyBoots",    nome="Botas Militares",    preco=550,  count=1 },
    { id="shop_outl_book1", factionId="survivors", tierMin=5, itemType="Base.BookForaging5",     nome="Coleta Nivel 5", preco=1800, count=1 },
    { id="shop_outl_book2", factionId="survivors", tierMin=5, itemType="Base.BookCooking5",      nome="Culinaria Nivel 5", preco=1800, count=1 },
}

-- ------------------------------------------------------------
-- FUNCOES UTILITARIAS
-- ------------------------------------------------------------

--- Retorna um item da loja pelo ID
---@param id string
---@return table|nil
function TsT.getShopItemById(id)
    for _, item in ipairs(TsT.ShopItems) do
        if item.id == id then return item end
    end
    return nil
end

--- Retorna os itens da loja disponiveis para uma faccao e nivel de fama
---@param factionId string
---@param fama number
---@return table[] lista de itens disponiveis
function TsT.getItensLoja(factionId, fama)
    local nivel, _ = TsT.getNivelFama(fama)
    local resultado = {}
    for _, item in ipairs(TsT.ShopItems) do
        if item.factionId == factionId and item.tierMin <= nivel then
            table.insert(resultado, item)
        end
    end
    return resultado
end
