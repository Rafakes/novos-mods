if isServer() and not isClient() then
    return
end

require "RoleSafehouseExpansion/00_RoleSafehouseExpansion_Shared"
require "ISUI/ISButton"
require "ISUI/ISLabel"
require "ISUI/ISCollapsableWindow"

local RSE = RoleSafehouseExpansion

RSE.ClientPreview = RSE.ClientPreview or {
    oldRect = nil,
    newRect = nil,
    mode = "expand",
    z = 0,
    appliedSquares = {},
    lastRefreshMs = 0,
    throttleMs = 150,
}

local function previewKey(x, y, z)
    return tostring(x) .. "," .. tostring(y) .. "," .. tostring(z)
end

local function getBetterSafehouseViewer()
    local betterSafehouse = rawget(_G, "BetterSafehouse")
    if not betterSafehouse then
        return nil
    end

    if type(betterSafehouse.Viewer) ~= "table" then
        return nil
    end

    return betterSafehouse.Viewer
end

local function betterSafehouseHasAppliedHighlight(key)
    local viewer = getBetterSafehouseViewer()
    if not viewer or type(viewer.appliedSquares) ~= "table" then
        return false
    end

    return viewer.appliedSquares[key] == true
end

local function applyBetterSafehouseHighlightToSquare(square)
    if not square then return end

    local floor = square.getFloor and square:getFloor() or nil
    if floor and floor.setHighlightColor then
        floor:setHighlightColor(0.15, 0.45, 1.0, 0.55)
    end
    if floor and floor.setHighlighted then
        floor:setHighlighted(true, false)
    end
    if square.setHighlight then
        square:setHighlight(true)
    end
end

local function unhighlightSquareByKey(key)
    local x, y, z = tostring(key or ""):match("^(%-?%d+),(%-?%d+),(%-?%d+)$")
    if not x then return end

    local cell = getCell and getCell() or nil
    if not cell then return end

    local square = cell:getGridSquare(tonumber(x), tonumber(y), tonumber(z))
    if not square then return end

    if betterSafehouseHasAppliedHighlight(key) then
        applyBetterSafehouseHighlightToSquare(square)
        return
    end

    local floor = square.getFloor and square:getFloor() or nil
    if floor and floor.setHighlighted then
        floor:setHighlighted(false, false)
    end
    if square.setHighlight then
        square:setHighlight(false)
    end
end

local function clearPreviewSquares()
    for key, _ in pairs(RSE.ClientPreview.appliedSquares or {}) do
        unhighlightSquareByKey(key)
    end
    RSE.ClientPreview.appliedSquares = {}
end

local function tableHasEntries(values)
    if type(values) ~= "table" then
        return false
    end

    for _, _ in pairs(values) do
        return true
    end

    return false
end

local function applyPreviewToSquare(square, mode)
    if not square then return end

    local floor = square.getFloor and square:getFloor() or nil
    local r = 1.0
    local g = 0.55
    local b = 0.15
    local a = 0.55

    if RSE.isShrinkMode(mode) then
        r = 0.88
        g = 0.18
        b = 0.18
        a = 0.6
    end

    if floor and floor.setHighlightColor then
        floor:setHighlightColor(r, g, b, a)
    end
    if floor and floor.setHighlighted then
        floor:setHighlighted(true, false)
    end
    if square.setHighlight then
        square:setHighlight(true)
    end
end

local function shrinkPreviewShouldBeTextOnly()
    local viewer = getBetterSafehouseViewer()
    if not viewer or type(viewer.appliedSquares) ~= "table" then
        return false
    end

    for _, _ in pairs(viewer.appliedSquares) do
        return true
    end

    return false
end

function RSE.clearClientPreview()
    RSE.ClientPreview.oldRect = nil
    RSE.ClientPreview.newRect = nil
    RSE.ClientPreview.mode = "expand"
    RSE.ClientPreview.lastRefreshMs = 0
    clearPreviewSquares()
end

function RSE.setClientPreview(oldRect, newRect, z, mode)
    if not oldRect or not newRect then
        RSE.clearClientPreview()
        return
    end

    RSE.ClientPreview.oldRect = RSE.copyRect(oldRect)
    RSE.ClientPreview.newRect = RSE.copyRect(newRect)
    RSE.ClientPreview.mode = RSE.normalizeResizeMode(mode) or "expand"
    RSE.ClientPreview.z = math.floor(tonumber(z) or 0)
    RSE.ClientPreview.lastRefreshMs = 0
    clearPreviewSquares()
end

local function previewOnTick()
    local oldRect = RSE.ClientPreview.oldRect
    local newRect = RSE.ClientPreview.newRect
    local mode = RSE.ClientPreview.mode

    if not oldRect or not newRect then
        if tableHasEntries(RSE.ClientPreview.appliedSquares) then
            clearPreviewSquares()
        end
        return
    end

    local now = 0
    if getTimestampMs then
        local okNow, value = pcall(function()
            return getTimestampMs()
        end)
        if okNow and type(value) == "number" then
            now = value
        end
    end

    if now > 0 and (now - (RSE.ClientPreview.lastRefreshMs or 0)) < (RSE.ClientPreview.throttleMs or 150) then
        return
    end

    RSE.ClientPreview.lastRefreshMs = now

    local cell = getCell and getCell() or nil
    if not cell then return end

    local wanted = {}
    local targetZ = RSE.ClientPreview.z or 0

    RSE.forEachPreviewTile(oldRect, newRect, mode, function(x, y)
        local key = previewKey(x, y, targetZ)
        wanted[key] = true

        if not RSE.ClientPreview.appliedSquares[key] then
            local square = cell:getGridSquare(x, y, targetZ)
            if square then
                applyPreviewToSquare(square, mode)
                RSE.ClientPreview.appliedSquares[key] = true
            end
        end

        return true
    end)

    for key, _ in pairs(RSE.ClientPreview.appliedSquares) do
        if not wanted[key] then
            unhighlightSquareByKey(key)
            RSE.ClientPreview.appliedSquares[key] = nil
        end
    end
end

local function sayLocalMessage(message)
    message = tostring(message or "")
    if message == "" then return end

    local playerObj = getPlayer and getPlayer() or nil
    if playerObj and HaloTextHelper and HaloTextHelper.addText then
        HaloTextHelper.addText(playerObj, message)
        return
    end

    if playerObj and playerObj.Say then
        playerObj:Say(message)
        return
    end

    print("[RoleSafehouseExpansion] " .. message)
end

local function localizeServerResult(args)
    if not args then return "" end

    local fallback = tostring(args.msg or "")
    if args.key then
        return RSE.getTextOrFallback(args.key, fallback ~= "" and fallback or tostring(args.key), (table.unpack or unpack)(args.args or {}))
    end

    return fallback
end

local function tryCall(obj, method)
    if obj and obj[method] then
        pcall(function()
            obj[method](obj)
        end)
        return true
    end
    return false
end

local function tryRefreshSafehouseUI()
    if triggerEvent then
        pcall(function()
            triggerEvent("OnSafehousesChanged")
        end)
    end

    local candidates = {}

    local function addCandidate(ui)
        if not ui or candidates[ui] then return end
        candidates[ui] = true
    end

    if ISSafehouseUI and ISSafehouseUI.instance then
        addCandidate(ISSafehouseUI.instance)
    end
    if ISSafehousesList and ISSafehousesList.instance then
        addCandidate(ISSafehousesList.instance)
    end
    if ISAdminPanelUI and ISAdminPanelUI.instance then
        addCandidate(ISAdminPanelUI.instance)
    end

    if UIManager and UIManager.getUI and instanceof then
        local okList, uiList = pcall(function()
            return UIManager.getUI()
        end)
        if okList and uiList and uiList.size and uiList.get then
            for index = 0, uiList:size() - 1 do
                local ui = uiList:get(index)
                if ui and (instanceof(ui, "ISSafehouseUI") or instanceof(ui, "ISSafehousesList")) then
                    addCandidate(ui)
                end
            end
        end
    end

    for ui, _ in pairs(candidates) do
        tryCall(ui, "populateList")
        tryCall(ui, "populate")
        tryCall(ui, "refresh")
        tryCall(ui, "update")
    end
end

local function refreshSafehouseDetailLabels(ui)
    if not ui or not ui.safehouse then return end

    local safehouse = ui.safehouse

    if ui.title and ui.title.setName and safehouse.getTitle then
        pcall(function()
            ui.title:setName(safehouse:getTitle())
        end)
    end

    if ui.owner and ui.owner.setName and safehouse.getOwner then
        pcall(function()
            ui.owner:setName(safehouse:getOwner())
        end)
    end

    if ui.pos and ui.pos.setName and safehouse.getX and safehouse.getY and getText then
        pcall(function()
            ui.pos:setName(getText("IGUI_SafehouseUI_Pos2", safehouse:getX(), safehouse:getY()))
        end)
    end

    if ui.points and ui.points.setName and safehouse.getHitPoints then
        pcall(function()
            ui.points:setName(tostring(safehouse:getHitPoints()))
        end)
    end
end

local function updateBetterSafehouseViewerTarget(oldRect, newRect)
    local betterSafehouse = rawget(_G, "BetterSafehouse")
    if not betterSafehouse then return end

    local playerObj = getPlayer and getPlayer() or nil
    if not playerObj then return end

    if not betterSafehouse.getClientViewerTarget or not betterSafehouse.setClientViewerTarget then
        return
    end

    local okTarget, target = pcall(function()
        return betterSafehouse.getClientViewerTarget(playerObj)
    end)
    if not okTarget or type(target) ~= "table" then
        return
    end

    local tx = math.floor(tonumber(target.x) or 0)
    local ty = math.floor(tonumber(target.y) or 0)
    local tw = math.floor(tonumber(target.w) or 0)
    local th = math.floor(tonumber(target.h) or 0)

    if tx == oldRect.x and ty == oldRect.y and tw == oldRect.w and th == oldRect.h then
        pcall(function()
            betterSafehouse.setClientViewerTarget(playerObj, {
                x = newRect.x,
                y = newRect.y,
                w = newRect.w,
                h = newRect.h,
                z = tonumber(target.z) or (playerObj.getZ and playerObj:getZ() or 0),
            })
        end)
    end
end

local function mutateSafehouseObject(safehouse, newRect, onlineId)
    if not safehouse or not safehouse.setX or not safehouse.setY or not safehouse.setW or not safehouse.setH then
        return false
    end

    local ok = pcall(function()
        safehouse:setX(newRect.x)
        safehouse:setY(newRect.y)
        safehouse:setW(newRect.w)
        safehouse:setH(newRect.h)
        if safehouse.setOnlineID and type(onlineId) == "number" then
            safehouse:setOnlineID(onlineId)
        end
    end)

    return ok == true
end

local function collectSafehouseCandidates(oldRect, oldOnlineId)
    local candidates = {}

    local function addCandidate(safehouse)
        if not safehouse then return end
        if RSE.safehouseMatchesRect(safehouse, oldRect) then
            candidates[safehouse] = true
            return
        end

        if oldOnlineId and safehouse.getOnlineID then
            local okId, value = pcall(function()
                return safehouse:getOnlineID()
            end)
            if okId and value == oldOnlineId then
                candidates[safehouse] = true
            end
        end
    end

    if ISSafehouseUI and ISSafehouseUI.instance and ISSafehouseUI.instance.safehouse then
        addCandidate(ISSafehouseUI.instance.safehouse)
    end
    if ISSafehousesListUI and ISSafehousesListUI.instance and ISSafehousesListUI.instance.selectedSafehouse then
        addCandidate(ISSafehousesListUI.instance.selectedSafehouse)
    end
    if ISSafehousesList and ISSafehousesList.instance and ISSafehousesList.instance.selectedSafehouse then
        addCandidate(ISSafehousesList.instance.selectedSafehouse)
    end

    if SafeHouse and SafeHouse.getSafeHouse and oldOnlineId then
        local okById, safehouse = pcall(function()
            return SafeHouse.getSafeHouse(oldOnlineId)
        end)
        if okById and safehouse then
            addCandidate(safehouse)
        end
    end

    local list = RSE.getSafehouseList()
    for _, safehouse in RSE.eachSafehouse(list) do
        addCandidate(safehouse)
    end

    return candidates
end

local function applySafehouseResized(args)
    if not args then return end

    local oldRect = RSE.makeRect(args.oldX, args.oldY, args.oldW, args.oldH)
    local newRect = RSE.makeRect(args.x, args.y, args.w, args.h)
    local oldOnlineId = math.floor(tonumber(args.oldOnlineID) or 0)
    local newOnlineId = math.floor(tonumber(args.onlineID) or 0)

    local mutatedRef = nil
    local candidates = collectSafehouseCandidates(oldRect, oldOnlineId > 0 and oldOnlineId or nil)
    for safehouse, _ in pairs(candidates) do
        if mutateSafehouseObject(safehouse, newRect, newOnlineId > 0 and newOnlineId or nil) and not mutatedRef then
            mutatedRef = safehouse
        end
    end

    updateBetterSafehouseViewerTarget(oldRect, newRect)

    if RSEExpandSafehouseWindow and RSEExpandSafehouseWindow.instance and RSEExpandSafehouseWindow.instance.safehouse then
        if RSE.safehouseMatchesRect(RSEExpandSafehouseWindow.instance.safehouse, oldRect) and mutatedRef then
            RSEExpandSafehouseWindow.instance.safehouse = mutatedRef
            pcall(function()
                RSEExpandSafehouseWindow.instance:updatePreview()
            end)
        end
    end

    if ISSafehouseUI and ISSafehouseUI.instance then
        refreshSafehouseDetailLabels(ISSafehouseUI.instance)
    end

    tryRefreshSafehouseUI()
end

local function walkChildren(root, callback)
    if not root or not root.children or not callback then
        return nil
    end

    for _, child in pairs(root.children) do
        if child then
            local result = callback(child, root)
            if result ~= nil then
                return result
            end

            local nested = walkChildren(child, callback)
            if nested ~= nil then
                return nested
            end
        end
    end

    return nil
end

local function findButtonByHeuristic(root, checker)
    local result = walkChildren(root, function(child, parent)
        if child and child.Type == "ISButton" and checker(child) then
            return {
                btn = child,
                parent = child.parent or parent or root,
            }
        end
        return nil
    end)

    return result
end

local function findReferenceButton(root)
    local refresh = findButtonByHeuristic(root, function(child)
        local internal = RSE.lowerString(child.internal or "")
        local title = RSE.lowerString(child.title or "")
        return internal == "refresh"
            or internal == "refreshlist"
            or title:find("refresh", 1, true) ~= nil
            or title:find("atualizar", 1, true) ~= nil
    end)
    if refresh then return refresh end

    return findButtonByHeuristic(root, function(child)
        local internal = RSE.lowerString(child.internal or "")
        local title = RSE.lowerString(child.title or "")
        return internal == "ok"
            or internal == "close"
            or title == "ok"
            or title:find("close", 1, true) ~= nil
            or title:find("fechar", 1, true) ~= nil
    end)
end

local function getExpandButtonWidth()
    local label = RSE.getTextOrFallback("IGUI_RSE_ExpandSafehouse_Button", "Resize Safehouse")
    local width = 150

    if getTextManager and getTextManager() and getTextManager().MeasureStringX then
        local okMeasure, measured = pcall(function()
            return getTextManager():MeasureStringX(UIFont.Small, label)
        end)
        if okMeasure and type(measured) == "number" then
            width = math.max(width, math.floor(measured) + 28)
        end
    end

    return width
end

local function updateExpandButtonState(ui)
    if not ui or not ui.RSE_expandButton then return end

    local playerObj = getPlayer and getPlayer() or nil
    local button = ui.RSE_expandButton
    local enabled = false
    local tooltip = RSE.getTextOrFallback("IGUI_RSE_ExpandSafehouse_Button_tooltip", "Owner-only safehouse resize.")

    if not RSE.isEnabled() then
        tooltip = RSE.getTextOrFallback("IGUI_RSE_Expand_DisabledBySandbox", "Safehouse resize is disabled in sandbox.")
    elseif not playerObj or not ui.safehouse then
        tooltip = RSE.getTextOrFallback("IGUI_RSE_Expand_InvalidSafehouse", "Invalid safehouse.")
    elseif not RSE.isSafehouseOwner(playerObj, ui.safehouse) then
        tooltip = RSE.getTextOrFallback("IGUI_RSE_Expand_OwnerOnly", "Only the safehouse owner can resize it.")
    elseif not RSE.isPlayerRoleAllowed(playerObj) then
        tooltip = RSE.getTextOrFallback("IGUI_RSE_Expand_RoleDenied", "Your role cannot resize safehouses.")
    else
        enabled = true
    end

    if button.setEnable then
        button:setEnable(enabled)
    else
        button.enable = enabled
    end

    if button.setTooltip then
        button:setTooltip(tooltip)
    else
        button.tooltip = tooltip
    end
end

local function repositionExpandButton(ui)
    if not ui or not ui.RSE_expandButton then return end

    local button = ui.RSE_expandButton
    local ref = findReferenceButton(ui)
    local width = getExpandButtonWidth()
    local height = 24
    local parent = ui
    local x = 10
    local y = (ui.height or 0) - height - 38

    if ref and ref.btn and ref.btn.getX and ref.btn.getY then
        parent = ref.parent or ref.btn.parent or ui

        if button.parent ~= parent then
            pcall(function()
                if button.parent and button.parent.removeChild then
                    button.parent:removeChild(button)
                end
            end)
            pcall(function()
                parent:addChild(button)
            end)
        end

        local refX = ref.btn.getX and ref.btn:getX() or ref.btn.x or 0
        local refY = ref.btn.getY and ref.btn:getY() or ref.btn.y or 0
        local refH = ref.btn.getHeight and ref.btn:getHeight() or ref.btn.height or height
        local parentW = parent.getWidth and parent:getWidth() or parent.width or width + 20

        x = refX - width - 10
        if x < 10 then x = 10 end
        if x + width > parentW - 10 then
            x = math.max(10, parentW - width - 10)
        end

        y = refY
        height = refH
    end

    if button.setX then button:setX(x) else button.x = x end
    if button.setY then button:setY(y) else button.y = y end
    if button.setWidth then button:setWidth(width) else button.width = width end
    if button.setHeight then button:setHeight(height) else button.height = height end
    if button.bringToTop then
        pcall(function()
            button:bringToTop()
        end)
    end
end

local function onExpandButtonClicked(ui)
    if not ui or not ui.safehouse then return end

    if RSEExpandSafehouseWindow and RSEExpandSafehouseWindow.instance then
        pcall(function()
            RSEExpandSafehouseWindow.instance:close()
        end)
    end

    local window = nil
    if RSE.openExpandWindow then
        window = RSE.openExpandWindow(ui.safehouse, ui)
    end

    if window and window.parentUI ~= ui then
        window.parentUI = ui
    end
end

local function installExpandButton(ui)
    if not ui or ui.RSE_expandButton then return end
    if not ISButton or not ui.safehouse then return end

    local label = RSE.getTextOrFallback("IGUI_RSE_ExpandSafehouse_Button", "Resize Safehouse")
    local button = ISButton:new(10, 10, getExpandButtonWidth(), 24, label, ui, onExpandButtonClicked)
    button:initialise()
    button.internal = "RSE_EXPAND_SAFEHOUSE"

    local ref = findReferenceButton(ui)
    local parent = (ref and ref.parent) or ui
    if parent and parent.addChild then
        parent:addChild(button)
    else
        ui:addChild(button)
    end

    ui.RSE_expandButton = button
    repositionExpandButton(ui)
    updateExpandButtonState(ui)
end

local function patchISSafehouseUI()
    if not ISSafehouseUI then return end
    if ISSafehouseUI._RSEExpandPatched then return end

    ISSafehouseUI._RSEExpandPatched = true

    local oldCreateChildren = ISSafehouseUI.createChildren
    if oldCreateChildren then
        ISSafehouseUI.createChildren = function(self, ...)
            local result = oldCreateChildren(self, ...)
            pcall(function() installExpandButton(self) end)
            pcall(function() repositionExpandButton(self) end)
            pcall(function() updateExpandButtonState(self) end)
            return result
        end
    end

    local oldPopulateList = ISSafehouseUI.populateList
    if oldPopulateList then
        ISSafehouseUI.populateList = function(self, ...)
            local result = oldPopulateList(self, ...)
            pcall(function() installExpandButton(self) end)
            pcall(function() repositionExpandButton(self) end)
            pcall(function() updateExpandButtonState(self) end)
            return result
        end
    end
end

Events.OnGameStart.Add(patchISSafehouseUI)
pcall(patchISSafehouseUI)

RSEExpandSafehouseWindow = ISCollapsableWindow:derive("RSEExpandSafehouseWindow")
RSEExpandSafehouseWindow.instance = nil

function RSEExpandSafehouseWindow:new(x, y, width, height, safehouse, parentUI)
    local window = ISCollapsableWindow:new(x, y, width, height)
    setmetatable(window, self)
    self.__index = self

    window.safehouse = safehouse
    window.parentUI = parentUI
    window.selectedAction = nil
    window.selectedMode = "expand"
    window.previewSteps = 1
    window.pendingRequest = false
    window.previewRect = nil
    window.previewMessageKey = nil
    window.moveWithMouse = true
    window.resizable = false
    window.pin = false
    window.title = RSE.getTextOrFallback("IGUI_RSE_Expand_WindowTitle", "Resize Safehouse")

    return window
end

function RSEExpandSafehouseWindow:initialise()
    ISCollapsableWindow.initialise(self)
end

function RSEExpandSafehouseWindow:getCurrentRect()
    return RSE.rectFromSafehouse(self.safehouse)
end

function RSEExpandSafehouseWindow:getPreviewStepCount(allowZero)
    return RSE.normalizeResizeSteps(self.previewSteps, allowZero == true)
end

function RSEExpandSafehouseWindow:getPreviewTotalStep()
    return RSE.getTotalResizeStep(RSE.getExpandStepTiles(), self:getPreviewStepCount(false))
end

function RSEExpandSafehouseWindow:refreshStepButtons()
    local queuedSteps = self:getPreviewStepCount(true) or 0
    local hasAction = self.selectedAction ~= nil
    local maxSteps = math.max(1, math.floor(tonumber(RSE.MAX_RESIZE_STEPS) or 200))

    if self.stepValueLabel and self.stepValueLabel.setName then
        self.stepValueLabel:setName(RSE.getTextOrFallback(
            "IGUI_RSE_Resize_StepCounter",
            "x%1",
            tostring(queuedSteps)
        ))
    end

    if self.decreaseStepButton and self.decreaseStepButton.setEnable then
        self.decreaseStepButton:setEnable(hasAction and queuedSteps > 0)
    end

    if self.increaseStepButton and self.increaseStepButton.setEnable then
        self.increaseStepButton:setEnable(hasAction and queuedSteps < maxSteps)
    end
end

function RSEExpandSafehouseWindow:updateStatusText()
    local currentRect = self:getCurrentRect()
    if not currentRect then
        if self.currentLabel and self.currentLabel.setName then
            self.currentLabel:setName(RSE.getTextOrFallback("IGUI_RSE_Expand_InvalidSafehouse", "Invalid safehouse."))
        end
        if self.stepLabel and self.stepLabel.setName then
            self.stepLabel:setName("")
        end
        if self.previewLabel and self.previewLabel.setName then
            self.previewLabel:setName("")
        end
        return
    end

    local currentText = RSE.getTextOrFallback(
        "IGUI_RSE_Expand_CurrentStatus",
        "Current: %1x%2 | Step: %3",
        tostring(currentRect.w),
        tostring(currentRect.h),
        tostring(RSE.getExpandStepTiles())
    )

    if self.currentLabel and self.currentLabel.setName then
        self.currentLabel:setName(currentText)
    end

    if self.stepLabel and self.stepLabel.setName then
        local queuedSteps = self:getPreviewStepCount(true) or 0
        local totalChange = RSE.getExpandStepTiles() * queuedSteps
        self.stepLabel:setName(RSE.getTextOrFallback(
            "IGUI_RSE_Resize_StepSummary",
            "Queued steps: %1 | Total change: %2",
            tostring(queuedSteps),
            tostring(totalChange)
        ))
    end

    if self.previewLabel and self.previewLabel.setName then
        if self.previewRect then
            local changedTiles = RSE.countPreviewTiles(currentRect, self.previewRect, self.selectedMode)
            local previewKey = "IGUI_RSE_Resize_PreviewStatusAdd"
            local fallback = "Result: %1x%2 | Added tiles: %3"
            if RSE.isShrinkMode(self.selectedMode) then
                previewKey = "IGUI_RSE_Resize_PreviewStatusRemove"
                fallback = "Result: %1x%2 | Removed tiles: %3"
            end

            self.previewLabel:setName(RSE.getTextOrFallback(
                previewKey,
                fallback,
                tostring(self.previewRect.w),
                tostring(self.previewRect.h),
                tostring(changedTiles)
            ))
        elseif self.previewMessageKey then
            self.previewLabel:setName(RSE.getTextOrFallback(
                self.previewMessageKey,
                self.previewMessageKey
            ))
        else
            self.previewLabel:setName(RSE.getTextOrFallback(
                "IGUI_RSE_Expand_SelectDirection",
                "Select how to resize the safehouse."
            ))
        end
    end
end

function RSEExpandSafehouseWindow:refreshActionButtons()
    local colorSelected = { r = 0.25, g = 0.55, b = 0.25, a = 1.0 }
    local colorDefault = { r = 0.25, g = 0.25, b = 0.30, a = 1.0 }
    local hover = { r = 0.35, g = 0.35, b = 0.40, a = 1.0 }

    for action, button in pairs(self.actionButtons or {}) do
        local selected = (action == self.selectedAction)
        button.backgroundColor = selected and colorSelected or colorDefault
        button.backgroundColorMouseOver = hover
        button.borderColor = { r = 1, g = 1, b = 1, a = selected and 0.45 or 0.2 }
    end
end

function RSEExpandSafehouseWindow:refreshModeButtons()
    local hover = { r = 0.35, g = 0.35, b = 0.40, a = 1.0 }

    for mode, button in pairs(self.modeButtons or {}) do
        local selected = (mode == self.selectedMode)
        local colorSelected = { r = 0.24, g = 0.55, b = 0.24, a = 1.0 }
        if mode == "shrink" then
            colorSelected = { r = 0.62, g = 0.22, b = 0.22, a = 1.0 }
        end

        button.backgroundColor = selected and colorSelected or { r = 0.25, g = 0.25, b = 0.30, a = 1.0 }
        button.backgroundColorMouseOver = hover
        button.borderColor = { r = 1, g = 1, b = 1, a = selected and 0.45 or 0.2 }
    end
end

function RSEExpandSafehouseWindow:updatePreview()
    local currentRect = self:getCurrentRect()
    local queuedSteps = self:getPreviewStepCount(true) or 0

    self.previewRect = nil
    self.previewMessageKey = nil
    if self.applyButton and self.applyButton.setEnable then
        self.applyButton:setEnable(false)
    end

    if not currentRect or not self.selectedAction then
        RSE.clearClientPreview()
        self:updateStatusText()
        self:refreshActionButtons()
        self:refreshModeButtons()
        self:refreshStepButtons()
        return
    end

    if queuedSteps <= 0 then
        self.previewMessageKey = "IGUI_RSE_Resize_NoQueuedSteps"
        RSE.clearClientPreview()
        self:updateStatusText()
        self:refreshActionButtons()
        self:refreshModeButtons()
        self:refreshStepButtons()
        return
    end

    local previewRect = RSE.calcResizedRect(currentRect, self.selectedAction, self:getPreviewTotalStep(), self.selectedMode)
    if not previewRect then
        self.previewMessageKey = "IGUI_RSE_Resize_InvalidResult"
        RSE.clearClientPreview()
        self:updateStatusText()
        self:refreshActionButtons()
        self:refreshModeButtons()
        self:refreshStepButtons()
        return
    end

    self.previewRect = previewRect

    local playerObj = getPlayer and getPlayer() or nil
    local targetZ = playerObj and playerObj.getZ and playerObj:getZ() or 0
    if RSE.isShrinkMode(self.selectedMode) and shrinkPreviewShouldBeTextOnly() then
        RSE.clearClientPreview()
    else
        RSE.setClientPreview(currentRect, previewRect, targetZ, self.selectedMode)
    end

    if self.applyButton and self.applyButton.setEnable then
        self.applyButton:setEnable(self.pendingRequest ~= true)
    end

    self:updateStatusText()
    self:refreshActionButtons()
    self:refreshModeButtons()
    self:refreshStepButtons()
end

function RSEExpandSafehouseWindow:onSelectAction(button)
    if not button then return end
    self.selectedAction = tostring(button.internal or "")
    if (self:getPreviewStepCount(true) or 0) < 1 then
        self.previewSteps = 1
    end
    self.pendingRequest = false
    self:updatePreview()
end

function RSEExpandSafehouseWindow:onSelectMode(button)
    if not button then return end
    self.selectedMode = RSE.normalizeResizeMode(button.internal) or "expand"
    self.pendingRequest = false
    self:updatePreview()
end

function RSEExpandSafehouseWindow:changePreviewSteps(delta)
    if not self.selectedAction then
        return
    end

    local current = self:getPreviewStepCount(true) or 0
    local nextValue = current + math.floor(tonumber(delta) or 0)
    local maxSteps = math.max(1, math.floor(tonumber(RSE.MAX_RESIZE_STEPS) or 200))

    if nextValue < 0 then
        nextValue = 0
    elseif nextValue > maxSteps then
        nextValue = maxSteps
    end

    self.previewSteps = nextValue
    self.pendingRequest = false
    self:updatePreview()
end

function RSEExpandSafehouseWindow:onIncreasePreviewSteps()
    self:changePreviewSteps(1)
end

function RSEExpandSafehouseWindow:onDecreasePreviewSteps()
    self:changePreviewSteps(-1)
end

function RSEExpandSafehouseWindow:onApply()
    local currentRect = self:getCurrentRect()
    local queuedSteps = self:getPreviewStepCount(false)
    if not currentRect or not self.selectedAction or self.pendingRequest or not queuedSteps then
        return
    end

    local playerObj = getPlayer and getPlayer() or nil
    if not playerObj then
        return
    end

    self.pendingRequest = true
    if self.applyButton and self.applyButton.setEnable then
        self.applyButton:setEnable(false)
    end

    sendClientCommand(playerObj, RSE.NET_MODULE, "Resize", {
        x = currentRect.x,
        y = currentRect.y,
        w = currentRect.w,
        h = currentRect.h,
        action = self.selectedAction,
        mode = self.selectedMode,
        steps = queuedSteps,
    })
end

function RSEExpandSafehouseWindow:onCancel()
    self:close()
end

function RSEExpandSafehouseWindow:createActionButton(action, x, y, width, height)
    local button = ISButton:new(x, y, width, height, action, self, RSEExpandSafehouseWindow.onSelectAction)
    button:initialise()
    button.internal = action
    self:addChild(button)
    self.actionButtons[action] = button
end

function RSEExpandSafehouseWindow:createModeButton(mode, label, x, y, width, height)
    local button = ISButton:new(x, y, width, height, label, self, RSEExpandSafehouseWindow.onSelectMode)
    button:initialise()
    button.internal = mode
    self:addChild(button)
    self.modeButtons[mode] = button
end

function RSEExpandSafehouseWindow:createChildren()
    ISCollapsableWindow.createChildren(self)

    self.actionButtons = {}
    self.modeButtons = {}
    self:setResizable(false)

    local pad = 12
    local fontH = 14
    if getTextManager and getTextManager() and getTextManager().getFontHeight then
        local okFont, value = pcall(function()
            return getTextManager():getFontHeight(UIFont.Small)
        end)
        if okFont and type(value) == "number" and value > 0 then
            fontH = value
        end
    end

    self.currentLabel = ISLabel:new(pad, 34, fontH, "", 1, 1, 1, 1, UIFont.Small, true)
    self.currentLabel:initialise()
    self:addChild(self.currentLabel)

    self.stepLabel = ISLabel:new(pad, 52, fontH, "", 0.8, 0.9, 1.0, 1, UIFont.Small, true)
    self.stepLabel:initialise()
    self:addChild(self.stepLabel)

    self.previewLabel = ISLabel:new(pad, 70, fontH, "", 0.95, 0.85, 0.65, 1, UIFont.Small, true)
    self.previewLabel:initialise()
    self:addChild(self.previewLabel)

    local hintLabel = ISLabel:new(
        pad,
        88,
        fontH,
        RSE.getTextOrFallback("IGUI_RSE_Resize_PreviewHint", "Preview highlights the tiles that will change."),
        0.75, 0.75, 0.75, 1,
        UIFont.Small,
        true
    )
    hintLabel:initialise()
    self:addChild(hintLabel)

    local modeTop = 112
    local modeW = 108
    local modeH = 24
    local modeGap = 10
    local totalModeW = (modeW * 2) + modeGap
    local modeX = math.floor((self.width - totalModeW) / 2)

    self:createModeButton(
        "expand",
        RSE.getTextOrFallback("IGUI_RSE_Resize_ModeExpand", "Expand"),
        modeX,
        modeTop,
        modeW,
        modeH
    )
    self:createModeButton(
        "shrink",
        RSE.getTextOrFallback("IGUI_RSE_Resize_ModeShrink", "Shrink"),
        modeX + modeW + modeGap,
        modeTop,
        modeW,
        modeH
    )

    local stepControlTop = 142
    local stepButtonW = 30
    local stepButtonH = 24
    local stepValueW = 70
    local stepGap = 10
    local totalStepControlsW = (stepButtonW * 2) + stepValueW + (stepGap * 2)
    local stepStartX = math.floor((self.width - totalStepControlsW) / 2)

    self.decreaseStepButton = ISButton:new(stepStartX, stepControlTop, stepButtonW, stepButtonH, "-", self, RSEExpandSafehouseWindow.onDecreasePreviewSteps)
    self.decreaseStepButton:initialise()
    self.decreaseStepButton:setTooltip(RSE.getTextOrFallback("IGUI_RSE_Resize_RemoveStep", "Remove one queued step from the preview."))
    self:addChild(self.decreaseStepButton)

    self.stepValueLabel = ISLabel:new(stepStartX + stepButtonW + stepGap, stepControlTop + 4, fontH, "", 1, 1, 1, 1, UIFont.Small, true)
    self.stepValueLabel:initialise()
    self:addChild(self.stepValueLabel)

    self.increaseStepButton = ISButton:new(stepStartX + stepButtonW + stepGap + stepValueW + stepGap, stepControlTop, stepButtonW, stepButtonH, "+", self, RSEExpandSafehouseWindow.onIncreasePreviewSteps)
    self.increaseStepButton:initialise()
    self.increaseStepButton:setTooltip(RSE.getTextOrFallback("IGUI_RSE_Resize_AddStep", "Add one more queued step to the preview."))
    self:addChild(self.increaseStepButton)

    local gridTop = 172
    local buttonW = 68
    local buttonH = 28
    local gap = 8
    local totalW = (buttonW * 3) + (gap * 2)
    local startX = math.floor((self.width - totalW) / 2)

    local rows = {
        { "NW", "N",  "NE" },
        { "W",  "ALL","E"  },
        { "SW", "S",  "SE" },
    }

    for rowIndex, row in ipairs(rows) do
        for colIndex, action in ipairs(row) do
            local x = startX + ((colIndex - 1) * (buttonW + gap))
            local y = gridTop + ((rowIndex - 1) * (buttonH + gap))
            self:createActionButton(action, x, y, buttonW, buttonH)
        end
    end

    self.applyButton = ISButton:new(
        self.width - 180,
        self.height - 36,
        78,
        24,
        RSE.getTextOrFallback("IGUI_RSE_Expand_Apply", "Apply"),
        self,
        RSEExpandSafehouseWindow.onApply
    )
    self.applyButton:initialise()
    self:addChild(self.applyButton)

    self.cancelButton = ISButton:new(
        self.width - 92,
        self.height - 36,
        78,
        24,
        RSE.getTextOrFallback("IGUI_RSE_Generic_Close", "Close"),
        self,
        RSEExpandSafehouseWindow.onCancel
    )
    self.cancelButton:initialise()
    self:addChild(self.cancelButton)

    self:updateStatusText()
    self:refreshActionButtons()
    self:refreshModeButtons()
    self:refreshStepButtons()
    if self.applyButton and self.applyButton.setEnable then
        self.applyButton:setEnable(false)
    end
end

function RSEExpandSafehouseWindow:close()
    RSE.clearClientPreview()
    if RSEExpandSafehouseWindow.instance == self then
        RSEExpandSafehouseWindow.instance = nil
    end
    self:setVisible(false)
    if self.removeFromUIManager then
        self:removeFromUIManager()
    end
end

function RSE.openExpandWindow(safehouse, parentUI)
    local width = 348
    local height = 330
    local screenW = getCore():getScreenWidth()
    local screenH = getCore():getScreenHeight()
    local x = math.floor((screenW - width) / 2)
    local y = math.floor((screenH - height) / 2)

    if parentUI and parentUI.getX and parentUI.getY then
        x = math.floor(parentUI:getX() + 32)
        y = math.floor(parentUI:getY() + 32)
    end

    if x + width > screenW then
        x = math.max(0, screenW - width)
    end
    if y + height > screenH then
        y = math.max(0, screenH - height)
    end

    local window = RSEExpandSafehouseWindow:new(x, y, width, height, safehouse, parentUI)
    window:initialise()
    window:instantiate()
    window:addToUIManager()
    window:setVisible(true)

    RSEExpandSafehouseWindow.instance = window
    return window
end

local function onServerCommand(module, command, args)
    if module ~= RSE.NET_MODULE then return end

    if command == "ExpandResult" then
        if RSEExpandSafehouseWindow and RSEExpandSafehouseWindow.instance then
            if args and args.ok then
                pcall(function()
                    RSEExpandSafehouseWindow.instance:close()
                end)
            else
                RSEExpandSafehouseWindow.instance.pendingRequest = false
                pcall(function()
                    RSEExpandSafehouseWindow.instance:updatePreview()
                end)
            end
        else
            RSE.clearClientPreview()
        end

        local text = localizeServerResult(args)
        if text ~= "" then
            sayLocalMessage(text)
        end
        return
    end

    if command == "SafehouseResized" then
        applySafehouseResized(args)
        return
    end
end

if not RSE._ClientEventsInstalled then
    Events.OnTick.Add(previewOnTick)
    Events.OnServerCommand.Add(onServerCommand)
    RSE._ClientEventsInstalled = true
end
