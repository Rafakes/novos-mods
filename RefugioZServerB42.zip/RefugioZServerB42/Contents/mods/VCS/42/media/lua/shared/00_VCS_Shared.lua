-- VCS (Vehicle Color/Skin) - Shared
-- Build 42.14.1 (B42), Multiplayer-safe (server authoritative)

VCS = VCS or {}
VCS.MOD_ID = "VCS"
VCS.NET_MODULE = "vcs"

function VCS.log(msg)
    print("[VCS] " .. tostring(msg))
end

-- Time helper (ms). Works on server + client.
function VCS.nowMs()
    local t = nil
    if getTimestampMs then
        t = getTimestampMs()
    elseif getTimestamp then
        t = getTimestamp()
    elseif os and os.time then
        t = os.time()
    end
    t = tonumber(t) or 0
    -- convert seconds -> ms (epoch seconds ~ 1.7e9, ms ~ 1.7e12)
    if t > 0 and t < 10000000000 then
        t = t * 1000
    end
    return t
end

local function _getSandbox()
    if SandboxVars and SandboxVars.VCS then
        return SandboxVars.VCS
    end
    return nil
end

function VCS.isEnabled()
    local sb = _getSandbox()
    if sb and sb.EnableSkinChanger ~= nil then
        return sb.EnableSkinChanger == true
    end
    return true -- default enabled
end

function VCS.adminOnly()
    local sb = _getSandbox()
    if sb and sb.AdminOnly ~= nil then
        return sb.AdminOnly == true
    end
    return false
end

function VCS.maxDistance()
    return 6 -- tiles
end
