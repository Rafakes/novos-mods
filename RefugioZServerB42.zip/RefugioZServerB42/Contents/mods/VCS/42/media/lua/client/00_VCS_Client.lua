-- VCS - Client (Build 42.14.1)
-- Adds a context-menu option to rotate/select vehicle skins.
-- MP-safe: client requests via proper vehicle command system, server validates & broadcasts.

VCS = VCS or {}
VCS.Client = VCS.Client or {}
VCS.NET_MODULE = VCS.NET_MODULE or "vcs"

VCS.Client._cooldownMs = 350 -- anti-spam local (server also validates)

local function nowMs()
    if VCS.nowMs then return VCS.nowMs() end
    return 0
end

local function say(player, text)
    if player and player.Say then
        player:Say(text)
    else
        print("[VCS] " .. tostring(text))
    end
end

local function isEnabled()
    if VCS.isEnabled then return VCS.isEnabled() end
    return true
end

local function findVehicleById(id)
    if getVehicleById then
        return getVehicleById(id)
    end
    if getCell and getCell() and getCell().getVehicles then
        local vs = getCell():getVehicles()
        if vs then
            for i = 0, vs:size() - 1 do
                local v = vs:get(i)
                if v and v.getId and v:getId() == id then
                    return v
                end
            end
        end
    end
    return nil
end

-- Reads a named field from a raw Java object using PZ's reflection API.
-- This is the correct B42 way to access Java object fields (e.g. VehicleScript$Skin.texture).
-- Equivalent to Bikinitools:getFieldValue(object, field).
local function getJavaField(obj, fieldName)
    if not obj then return nil end
    local ok, count = pcall(function() return getNumClassFields(obj) end)
    if not ok or not count then return nil end
    for i = 0, count - 1 do
        local ok2, fld = pcall(function() return getClassField(obj, i) end)
        if ok2 and fld then
            -- Extract simple field name (last segment after ".")
            local simple = tostring(fld):match("([^%.]+)$")
            if simple == fieldName then
                local ok3, val = pcall(function() return getClassFieldVal(obj, fld) end)
                if ok3 then return val end
                break
            end
        end
    end
    return nil
end

-- Returns the skin count for a vehicle with fallback to vehicle script.
local function getVehicleSkinCount(vehicle)
    if vehicle.getSkinCount then
        local n = vehicle:getSkinCount()
        if n and n > 0 then return n end
    end
    if vehicle.getScript then
        local script = vehicle:getScript()
        if script and script.getSkins then
            local ok, skins = pcall(function() return script:getSkins() end)
            if ok and skins then return skins:size() end
        end
    end
    return 1
end

-- Returns the vehicle the player is interacting with.
-- Uses multiple detection strategies: in-vehicle, cursor pick, proximity, worldobjects.
-- worldobjects is a Lua table (ipairs), NOT a Java ArrayList.
local function getVehicleForMenu(player, worldobjects)
    -- 1) Player is driving/sitting in a vehicle
    local v = player and player.getVehicle and player:getVehicle() or nil
    if v then return v end

    -- 2) Cursor-based detection (same method the engine uses in ISVehicleMenu)
    if IsoObjectPicker and IsoObjectPicker.Instance then
        local ok, picked = pcall(function()
            return IsoObjectPicker.Instance:PickVehicle(getMouseXScaled(), getMouseYScaled())
        end)
        if ok and picked then return picked end
    end

    -- 3) Proximity-based (useableVehicle / nearVehicle)
    if ISVehicleMenu and ISVehicleMenu.getVehicleToInteractWith then
        v = ISVehicleMenu.getVehicleToInteractWith(player)
        if v then return v end
    end

    -- 4) Iterate worldobjects (Lua table, use ipairs)
    if worldobjects then
        for _, obj in ipairs(worldobjects) do
            if obj and instanceof(obj, "BaseVehicle") then
                return obj
            end
        end
    end

    return nil
end

function VCS.Client._applyLocal(vehicle, index)
    if not vehicle or index == nil or index < 0 then return end
    if vehicle.setSkinIndex then
        vehicle:setSkinIndex(index)
    end
    if vehicle.updateSkin then
        vehicle:updateSkin()
    end
end

function VCS.Client.requestSetSkin(player, vehicle, index)
    if not isEnabled() then return end
    if not player or not vehicle or index == nil then return end

    -- local cooldown
    local t = nowMs()
    if VCS.Client._lastRequestAt and (t - VCS.Client._lastRequestAt) < VCS.Client._cooldownMs then
        return
    end
    VCS.Client._lastRequestAt = t

    -- instant feedback (client-side); server will confirm/overwrite if needed
    VCS.Client._applyLocal(vehicle, index)

    -- Use the proper vehicle command system (same as bikinitools B42)
    sendClientCommand(player, "vehicle", "setSkinIndex", {
        vehicle = vehicle:getId(),
        index = index,
    })

    -- Also send to our custom handler for additional validation/feedback
    sendClientCommand(player, VCS.NET_MODULE, "setSkin", {
        vehicleId = vehicle:getId(),
        index = index,
        requestId = tostring(t),
    })
end

-- Builds the skin change sub-menu.
-- Uses a sub-sub-menu for "Select Skin" (3-level nesting works in B42).
local function addSkinMenu(context, player, vehicle)
    if not context or not player or not vehicle then return end

    local skinCount = getVehicleSkinCount(vehicle)
    local current = (vehicle.getSkinIndex and vehicle:getSkinIndex()) or 0

    -- Top-level entry
    local top = context:addOption(getText("IGUI_VCS_ChangeSkin"), nil, nil)
    local sub = ISContextMenu:getNew(context)
    context:addSubMenu(top, sub)

    -- Status line
    sub:addOption(getText("IGUI_VCS_Current") .. " " .. tostring(current + 1) .. "/" .. tostring(skinCount), nil, nil).notAvailable = true

    if skinCount <= 1 then
        sub:addOption(getText("IGUI_VCS_NoSkins"), nil, nil).notAvailable = true
        return
    end

    -- Previous skin
    sub:addOption("[<<] " .. getText("IGUI_VCS_PrevSkin"), player, function(_, v)
        local idx = (v.getSkinIndex and v:getSkinIndex() or 0) - 1
        local cnt = getVehicleSkinCount(v)
        if idx < 0 then idx = cnt - 1 end
        VCS.Client.requestSetSkin(player, v, idx)
    end, vehicle)

    -- Next skin
    sub:addOption(getText("IGUI_VCS_NextSkin") .. " [>>]", player, function(_, v)
        local idx = (v.getSkinIndex and v:getSkinIndex() or 0) + 1
        local cnt = getVehicleSkinCount(v)
        if idx >= cnt then idx = 0 end
        VCS.Client.requestSetSkin(player, v, idx)
    end, vehicle)

    -- "Select Skin" sub-sub-menu (same pattern as bikinitools, works in B42)
    local optSelect = sub:addOption(getText("IGUI_VCS_SelectSkin"), nil, nil)
    local subSelect = ISContextMenu:getNew(sub)
    sub:addSubMenu(optSelect, subSelect)

    for i = 0, skinCount - 1 do
        local skinName = nil

        -- Try to get skin name from vehicle script.
        -- VehicleScript$Skin is a raw Java object in B42 — use Java reflection
        -- (getNumClassFields/getClassField/getClassFieldVal) to read the "texture" field,
        -- exactly as Bikinitools does with getFieldValue(skin, "texture").
        if vehicle.getScript then
            local ok, script = pcall(function() return vehicle:getScript() end)
            if ok and script and script.getSkin then
                local ok2, skin = pcall(function() return script:getSkin(i) end)
                if ok2 and skin then
                    local texture = getJavaField(skin, "texture")
                    if texture then
                        skinName = tostring(texture):match("([^/]+)$")
                        if skinName then skinName = skinName:gsub('"', "") end
                    end
                end
            end
        end

        local label = skinName or (getText("IGUI_VCS_SkinNo") .. " " .. tostring(i + 1))

        subSelect:addOption(label, player, function(_, v, idx)
            VCS.Client.requestSetSkin(player, v, idx)
        end, vehicle, i)
    end
end

function VCS.Client.onFillWorldObjectContextMenu(playerIndex, context, worldobjects, test)
    if test then return end
    if not isEnabled() then return end

    local player = getSpecificPlayer(playerIndex)
    if not player then return end

    -- worldobjects is a Lua table (use ipairs), NOT a Java ArrayList
    local vehicle = getVehicleForMenu(player, worldobjects)
    if not vehicle then return end

    addSkinMenu(context, player, vehicle)
end

function VCS.Client.onServerCommand(module, command, args)
    if module ~= VCS.NET_MODULE then return end
    if not args then return end

    if command == "syncSkin" then
        local vehicle = findVehicleById(args.vehicleId)
        if vehicle then
            VCS.Client._applyLocal(vehicle, args.index)
        end
        return
    end

    if command == "error" then
        local player = getPlayer()
        if player then
            if args.key then
                say(player, getText(args.key))
            elseif args.text then
                say(player, args.text)
            end
        end
        return
    end
end

Events.OnFillWorldObjectContextMenu.Add(VCS.Client.onFillWorldObjectContextMenu)
Events.OnServerCommand.Add(VCS.Client.onServerCommand)
