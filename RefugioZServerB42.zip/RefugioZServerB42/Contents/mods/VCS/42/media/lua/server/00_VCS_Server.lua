-- VCS - Server (Build 42.14.1, Dedicated-ready)
-- Server is authoritative: validates requests and broadcasts updates.
-- Handles both "vehicle" module commands (from game engine) and custom VCS commands

VCS = VCS or {}
VCS.Server = VCS.Server or {}
VCS.NET_MODULE = VCS.NET_MODULE or "vcs"
VCS.Server._cooldowns = VCS.Server._cooldowns or {} -- by username/onlineID

local function nowMs()
    if VCS.nowMs then return VCS.nowMs() end
    return 0
end

local function isEnabled()
    if VCS.isEnabled then return VCS.isEnabled() end
    return true
end

local function adminOnly()
    if VCS.adminOnly then return VCS.adminOnly() end
    return false
end

local function maxDistance()
    if VCS.maxDistance then return VCS.maxDistance() end
    return 6
end

local function isStaff(playerObj)
    local lvl = playerObj and playerObj.getAccessLevel and playerObj:getAccessLevel()
    return lvl and lvl ~= "None"
end

local function distSq(a, b)
    local dx = (a:getX() - b:getX())
    local dy = (a:getY() - b:getY())
    return dx*dx + dy*dy
end

local function getVehicleSkinCount(vehicle)
    if vehicle.getSkinCount then
        local n = vehicle:getSkinCount()
        if n and n > 0 then return n end
    end
    if vehicle.getScript then
        local script = vehicle:getScript()
        if script and script.getSkins then
            local ok, skins = pcall(function() return script:getSkins() end)
            if ok and skins then return skins:size() end
        end
    end
    return 1
end

local function findVehicleById(id)
    if getVehicleById then
        return getVehicleById(id)
    end
    if getCell and getCell() and getCell().getVehicles then
        local vs = getCell():getVehicles()
        if vs then
            for i = 0, vs:size() - 1 do
                local v = vs:get(i)
                if v and v.getId and v:getId() == id then
                    return v
                end
            end
        end
    end
    return nil
end

local function sendToAll(command, args)
    local list = getOnlinePlayers()
    if not list then return end
    for i = 0, list:size() - 1 do
        local p = list:get(i)
        sendServerCommand(p, VCS.NET_MODULE, command, args)
    end
end

local function sendErrorAndResync(playerObj, vehicle, key)
    if not playerObj then return end
    sendServerCommand(playerObj, VCS.NET_MODULE, "error", { key = key })
    if vehicle and vehicle.getSkinIndex then
        sendServerCommand(playerObj, VCS.NET_MODULE, "syncSkin", {
            vehicleId = vehicle:getId(),
            index = vehicle:getSkinIndex(),
        })
    end
end

function VCS.Server.setSkin(playerObj, args)
    if not isEnabled() then return end
    if not playerObj or not args then return end

    if adminOnly() and not isStaff(playerObj) then
        sendErrorAndResync(playerObj, nil, "IGUI_VCS_Err_AdminOnly")
        return
    end

    -- Handle both vehicleId (VCS) and vehicle (engine) field names
    local vehicleId = args.vehicleId or args.vehicle
    local index = args.index
    if vehicleId == nil or index == nil then return end

    local vehicle = findVehicleById(vehicleId)
    if not vehicle then
        sendErrorAndResync(playerObj, nil, "IGUI_VCS_Err_NoVehicle")
        return
    end

    -- distance / anti-grief check
    local maxDist = maxDistance()
    if distSq(playerObj, vehicle) > (maxDist * maxDist) then
        sendErrorAndResync(playerObj, vehicle, "IGUI_VCS_Err_TooFar")
        return
    end

    -- rate limit per player
    local key = tostring(playerObj:getUsername() or playerObj:getOnlineID() or "unknown")
    local t = nowMs()
    local last = VCS.Server._cooldowns[key] or 0
    if (t - last) < 350 then
        return
    end
    VCS.Server._cooldowns[key] = t

    -- validate index
    local count = getVehicleSkinCount(vehicle)
    if type(index) ~= "number" then index = tonumber(index) end
    if not index or index < 0 or index >= count then
        sendErrorAndResync(playerObj, vehicle, "IGUI_VCS_Err_InvalidSkin")
        return
    end

    -- Apply skin change
    if vehicle.setSkinIndex then
        vehicle:setSkinIndex(index)
    end
    if vehicle.updateSkin then
        vehicle:updateSkin()
    end

    -- Sync to all clients
    sendToAll("syncSkin", { vehicleId = vehicleId, index = index })
    
    VCS.log("Skin changed for vehicle " .. vehicleId .. " to index " .. index .. " by " .. playerObj:getUsername())
end

function VCS.Server.onClientCommand(module, command, playerObj, args)
    -- Handle both our custom module and the engine's vehicle module
    if module == VCS.NET_MODULE then
        if command == "setSkin" then
            VCS.Server.setSkin(playerObj, args)
        end
    elseif module == "vehicle" then
        if command == "setSkinIndex" then
            -- This is called by the game engine's vehicle command system
            -- We still want to validate it through our system
            VCS.Server.setSkin(playerObj, args)
        end
    end
end

Events.OnClientCommand.Add(VCS.Server.onClientCommand)
