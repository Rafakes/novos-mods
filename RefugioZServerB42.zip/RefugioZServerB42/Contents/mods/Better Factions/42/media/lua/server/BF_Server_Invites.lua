-- Better Factions: Server Invite System
-- Funções do servidor para gerenciar convites

if not isServer() then
    return
end

require "BF_Shared"
require "BF_InviteSystem"

BF = BF or {}
BF.Server = BF.Server or {}
BF.Server.Invites = BF.Server.Invites or {}

local ServerInvites = BF.Server.Invites

-- Inicializar sistema de convites no ModData
function ServerInvites.initState(state)
    state.invites = state.invites or {}
    state.invites.active = state.invites.active or {}  -- invites ativos (pending)
    state.invites.nextId = state.invites.nextId or 1
    return state
end

-- Obter convite por ID
function ServerInvites.getInviteById(inviteId)
    local state = BF.Server.getState()
    return state.invites.active[inviteId]
end

-- Obter todos os convites pendentes para um jogador
function ServerInvites.getInvitesForPlayer(username)
    local state = BF.Server.getState()
    local invites = {}
    
    for inviteId, invite in pairs(state.invites.active) do
        if invite.playerUsername == username and invite.status == BF.Invites.STATUS.PENDING then
            if not BF.Invites.isExpired(invite, getTimestamp()) then
                table.insert(invites, invite)
            end
        end
    end
    
    return invites
end

-- Obter todos os convites pendentes de uma guild
function ServerInvites.getInvitesFromGuild(guildId)
    local state = BF.Server.getState()
    local invites = {}
    
    for inviteId, invite in pairs(state.invites.active) do
        if invite.guildId == guildId and invite.status == BF.Invites.STATUS.PENDING then
            if not BF.Invites.isExpired(invite, getTimestamp()) then
                table.insert(invites, invite)
            end
        end
    end
    
    return invites
end

-- Verificar se já existe convite ativo entre guild e player
function ServerInvites.hasActiveInvite(guildId, username)
    local state = BF.Server.getState()
    
    for inviteId, invite in pairs(state.invites.active) do
        if invite.guildId == guildId and 
           invite.playerUsername == username and 
           invite.status == BF.Invites.STATUS.PENDING then
            if not BF.Invites.isExpired(invite, getTimestamp()) then
                return true, invite
            end
        end
    end
    
    return false, nil
end

-- Contar convites pendentes de um jogador
function ServerInvites.countPendingInvites(username)
    local invites = ServerInvites.getInvitesForPlayer(username)
    return #invites
end

-- Criar novo convite
function ServerInvites.createInvite(guildId, guildName, playerUsername, inviterUsername, inviteType)
    local state = BF.Server.getState()
    
    -- Gerar ID
    local inviteId = state.invites.nextId
    state.invites.nextId = inviteId + 1
    
    -- Criar invite
    local invite = BF.Invites.create(
        guildId,
        guildName,
        playerUsername,
        inviterUsername,
        inviteType,
        getTimestamp()
    )
    invite.id = inviteId
    
    -- Salvar
    state.invites.active[inviteId] = invite
    
    return invite
end

-- Aceitar convite
function ServerInvites.acceptInvite(inviteId)
    local state = BF.Server.getState()
    local invite = state.invites.active[inviteId]
    
    if not invite then
        return false, "notfound"
    end
    
    if invite.status ~= BF.Invites.STATUS.PENDING then
        return false, "notpending"
    end
    
    if BF.Invites.isExpired(invite, getTimestamp()) then
        invite.status = BF.Invites.STATUS.EXPIRED
        state.invites.active[inviteId] = nil
        return false, "expired"
    end
    
    -- Marcar como aceito
    invite.status = BF.Invites.STATUS.ACCEPTED
    invite.acceptedAt = getTimestamp()
    
    -- Remover dos ativos (aceito não precisa ficar pendente)
    state.invites.active[inviteId] = nil
    
    return true, invite
end

-- Rejeitar convite
function ServerInvites.rejectInvite(inviteId)
    local state = BF.Server.getState()
    local invite = state.invites.active[inviteId]
    
    if not invite then
        return false, "notfound"
    end
    
    if invite.status ~= BF.Invites.STATUS.PENDING then
        return false, "notpending"
    end
    
    -- Marcar como rejeitado e remover
    invite.status = BF.Invites.STATUS.REJECTED
    invite.rejectedAt = getTimestamp()
    state.invites.active[inviteId] = nil
    
    return true, invite
end

-- Cancelar convite (quem enviou pode cancelar)
function ServerInvites.cancelInvite(inviteId)
    local state = BF.Server.getState()
    local invite = state.invites.active[inviteId]
    
    if not invite then
        return false, "notfound"
    end
    
    if invite.status ~= BF.Invites.STATUS.PENDING then
        return false, "notpending"
    end
    
    -- Marcar como cancelado e remover
    invite.status = BF.Invites.STATUS.CANCELLED
    invite.cancelledAt = getTimestamp()
    state.invites.active[inviteId] = nil
    
    return true, invite
end

-- Cancelar todos os convites de um jogador para outras guilds (quando aceita uma)
function ServerInvites.cancelAllPlayerInvites(username, exceptInviteId)
    local state = BF.Server.getState()
    local toRemove = {}

    for inviteId, invite in pairs(state.invites.active) do
        if invite.playerUsername == username and
           invite.status == BF.Invites.STATUS.PENDING and
           inviteId ~= exceptInviteId then
            table.insert(toRemove, inviteId)
        end
    end

    for _, inviteId in ipairs(toRemove) do
        local invite = state.invites.active[inviteId]
        if invite then
            invite.status = BF.Invites.STATUS.CANCELLED
            state.invites.active[inviteId] = nil
        end
    end

    return #toRemove
end

-- Limpar convites expirados
function ServerInvites.cleanExpiredInvites()
    local state = BF.Server.getState()
    local currentTime = getTimestamp and getTimestamp() or 0
    local toRemove = {}

    for inviteId, invite in pairs(state.invites.active) do
        if BF.Invites.isExpired(invite, currentTime) then
            table.insert(toRemove, inviteId)
        end
    end

    local cleaned = #toRemove
    for _, inviteId in ipairs(toRemove) do
        local invite = state.invites.active[inviteId]
        if invite then
            invite.status = BF.Invites.STATUS.EXPIRED
            state.invites.active[inviteId] = nil
        end
    end
    
    if cleaned > 0 then
        print("[BetterFactions][Invites] Cleaned " .. tostring(cleaned) .. " expired invites")
        BF.Server.persist()
    end
    
    return cleaned
end

-- Listar guilds com vagas abertas
function ServerInvites.getGuildsWithOpenSlots()
    local state = BF.Server.getState()
    local guildsWithSlots = {}
    
    for guildId, guild in pairs(state.guilds) do
        local memberCount = BF.Server.countMembers(guild)
        local memberCap = BF.getMemberCapForGuild(guild)
        
        if memberCount < memberCap then
            table.insert(guildsWithSlots, {
                id = guild.id,
                name = guild.name,
                owner = guild.owner,
                memberCount = memberCount,
                memberCap = memberCap,
                level = guild.progress and guild.progress.level or 1,
                renown = guild.progress and guild.progress.renown or 0,
            })
        end
    end
    
    -- Ordenar por level (desc) e depois por renown (desc)
    table.sort(guildsWithSlots, function(a, b)
        if a.level ~= b.level then
            return a.level > b.level
        end
        return a.renown > b.renown
    end)
    
    return guildsWithSlots
end
