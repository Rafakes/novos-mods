require "ISUI/ISCollapsableWindow"
require "ISUI/ISButton"
require "ISUI/ISLabel"
require "ISUI/ISRichTextPanel"
require "ISUI/ISTextEntryBox"
require "ISUI/ISScrollingListBox"

BF_MainPanel = ISCollapsableWindow:derive("BF_MainPanel")

local TAB_IDS = { "overview", "upgrades", "benefits", "missions", "members", "ranking", "management" }
local ACTION_BUTTON_ORDER = {
    "deposit",
    "contribute",
    "buyHall",
    "buyScholarship",
    "buyWarcamp",
    "syncNative",
    "xpWoodwork",
    "xpMechanics",
    "xpAiming",
    "slayer",
    "memberToTreasurer",
    "memberToOfficer",
    "memberToMember",
    "memberRemove",
    "trait",
    "acceptInvite",
    "rejectInvite",
    "cancelInvite",
    "requestJoin",
    "browseGuilds",
    "deleteGuild",
    "payTax",
    "setTax",
}

local function rgba(r, g, b, a)
    return { r = r / 255, g = g / 255, b = b / 255, a = a }
end

local THEME = {
    windowBackground = rgba(14, 11, 9, 0.95),
    windowBorder = rgba(120, 76, 42, 0.95),
    frame = rgba(24, 19, 15, 0.94),
    frameBorder = rgba(112, 82, 51, 0.95),
    section = rgba(31, 25, 20, 0.92),
    sectionBorder = rgba(132, 97, 58, 0.95),
    paragraph = rgba(219, 210, 194, 1.00),
    paragraphDim = rgba(171, 160, 142, 1.00),
    ember = rgba(171, 87, 53, 1.00),
    brass = rgba(191, 150, 78, 1.00),
    moss = rgba(92, 129, 82, 1.00),
    ash = rgba(108, 119, 123, 1.00),
}

local BUTTON_SKINS = {
    neutral = {
        bg = rgba(33, 26, 21, 0.95),
        hover = rgba(56, 42, 33, 0.98),
        border = rgba(132, 97, 58, 0.95),
        activeBg = rgba(85, 57, 31, 0.98),
        activeHover = rgba(111, 72, 38, 1.00),
        activeBorder = rgba(204, 153, 84, 1.00),
        text = rgba(232, 222, 205, 1.00),
    },
    accent = {
        bg = rgba(72, 47, 23, 0.98),
        hover = rgba(104, 68, 31, 1.00),
        border = rgba(215, 166, 92, 1.00),
        activeBg = rgba(120, 78, 34, 1.00),
        activeHover = rgba(154, 99, 42, 1.00),
        activeBorder = rgba(235, 191, 112, 1.00),
        text = rgba(248, 237, 214, 1.00),
    },
    scholar = {
        bg = rgba(34, 44, 42, 0.98),
        hover = rgba(48, 66, 62, 1.00),
        border = rgba(90, 150, 136, 1.00),
        activeBg = rgba(54, 78, 72, 1.00),
        activeHover = rgba(69, 101, 94, 1.00),
        activeBorder = rgba(125, 189, 171, 1.00),
        text = rgba(224, 236, 229, 1.00),
    },
    war = {
        bg = rgba(66, 31, 23, 0.98),
        hover = rgba(96, 41, 28, 1.00),
        border = rgba(184, 88, 63, 1.00),
        activeBg = rgba(121, 50, 33, 1.00),
        activeHover = rgba(153, 63, 41, 1.00),
        activeBorder = rgba(216, 110, 78, 1.00),
        text = rgba(244, 225, 214, 1.00),
    },
    gold = {
        bg = rgba(63, 52, 24, 0.98),
        hover = rgba(92, 76, 31, 1.00),
        border = rgba(196, 162, 69, 1.00),
        activeBg = rgba(120, 94, 38, 1.00),
        activeHover = rgba(147, 117, 45, 1.00),
        activeBorder = rgba(223, 189, 91, 1.00),
        text = rgba(247, 236, 201, 1.00),
    },
    member = {
        bg = rgba(30, 36, 43, 0.98),
        hover = rgba(46, 56, 67, 1.00),
        border = rgba(108, 135, 155, 1.00),
        activeBg = rgba(63, 78, 91, 1.00),
        activeHover = rgba(78, 98, 114, 1.00),
        activeBorder = rgba(145, 178, 203, 1.00),
        text = rgba(228, 237, 243, 1.00),
    },
    danger = {
        bg = rgba(70, 24, 24, 0.98),
        hover = rgba(104, 31, 31, 1.00),
        border = rgba(178, 78, 78, 1.00),
        activeBg = rgba(128, 39, 39, 1.00),
        activeHover = rgba(161, 48, 48, 1.00),
        activeBorder = rgba(224, 103, 103, 1.00),
        text = rgba(248, 225, 225, 1.00),
    },
    moss = {
        bg = rgba(28, 42, 28, 0.98),
        hover = rgba(42, 64, 40, 1.00),
        border = rgba(90, 140, 80, 1.00),
        activeBg = rgba(52, 84, 50, 1.00),
        activeHover = rgba(66, 108, 62, 1.00),
        activeBorder = rgba(120, 180, 108, 1.00),
        text = rgba(220, 240, 214, 1.00),
    },
}

local SECTION_META = {
    noGuild = {
        titleKey = "IGUI_BF_Section_NoGuild_Title",
        hintKey = "IGUI_BF_Section_NoGuild_Hint",
        skin = "accent",
    },
    overview = {
        titleKey = "IGUI_BF_Section_Overview_Title",
        hintKey = "IGUI_BF_Section_Overview_Hint",
        skin = "accent",
    },
    upgrades = {
        titleKey = "IGUI_BF_Section_Upgrades_Title",
        hintKey = "IGUI_BF_Section_Upgrades_Hint",
        skin = "gold",
    },
    treasury = {
        titleKey = "IGUI_BF_Section_Treasury_Title",
        hintKey = "IGUI_BF_Section_Treasury_Hint",
        skin = "accent",
    },
    benefits = {
        titleKey = "IGUI_BF_Section_Benefits_Title",
        hintKey = "IGUI_BF_Section_Benefits_Hint",
        skin = "scholar",
    },
    members = {
        titleKey = "IGUI_BF_Section_Members_Title",
        hintKey = "IGUI_BF_Section_Members_Hint",
        skin = "member",
    },
    invites = {
        titleKey = "IGUI_BF_Section_Invites_Title",
        hintKey = "IGUI_BF_Section_Invites_Hint",
        skin = "member",
    },
    management = {
        titleKey = "IGUI_BF_Section_Management_Title",
        hintKey = "IGUI_BF_Section_Management_Hint",
        skin = "gold",
    },
    ranking = {
        titleKey = "IGUI_BF_Section_Ranking_Title",
        hintKey = "IGUI_BF_Section_Ranking_Hint",
        skin = "accent",
    },
    missions = {
        titleKey = "IGUI_BF_Section_Missions_Title",
        hintKey = "IGUI_BF_Section_Missions_Hint",
        skin = "war",
    },
}

local TAB_SKINS = {
    overview   = "accent",
    upgrades   = "gold",
    management = "gold",
    benefits   = "scholar",
    members    = "member",
    ranking    = "accent",
    missions   = "war",
}

local TAB_TOOLTIP_KEYS = {
    overview   = "IGUI_BF_Tooltip_Tab_Overview",
    upgrades   = "IGUI_BF_Tooltip_Tab_Upgrades",
    management = "IGUI_BF_Tooltip_Tab_Management",
    benefits   = "IGUI_BF_Tooltip_Tab_Benefits",
    members    = "IGUI_BF_Tooltip_Tab_Members",
    ranking    = "IGUI_BF_Tooltip_Tab_Ranking",
    missions   = "IGUI_BF_Tooltip_Tab_Missions",
}

local function cloneColor(source)
    return { r = source.r, g = source.g, b = source.b, a = source.a }
end

local function floorNumber(value)
    return math.floor((tonumber(value) or 0) + 0.00001)
end

local function moneyText(value)
    return "$" .. tostring(floorNumber(value))
end

local function safeText(value)
    if value == nil or value == "" then
        return "-"
    end
    return tostring(value)
end

local function fmtTimeLeft(snapshotTime, expiresAt)
    if not expiresAt then
        return "-"
    end
    local remaining = math.max(0, floorNumber((expiresAt or 0) - (snapshotTime or 0)))
    local minutes = math.floor(remaining / 60)
    local seconds = remaining % 60
    return string.format("%02d:%02d", minutes, seconds)
end

local function applyButtonSkin(button, skinName, active)
    local skin = BUTTON_SKINS[skinName] or BUTTON_SKINS.neutral
    local background = active and skin.activeBg or skin.bg
    local hover = active and skin.activeHover or skin.hover
    local border = active and skin.activeBorder or skin.border

    button.backgroundColor = cloneColor(background)
    button.backgroundColorMouseOver = cloneColor(hover)
    button.borderColor = cloneColor(border)
    button.textColor = cloneColor(skin.text)
    button.displayBackground = true
    button.font = UIFont.Small
end

function BF_MainPanel:new(x, y, width, height, playerObj)
    local o = ISCollapsableWindow:new(x, y, width, height)
    setmetatable(o, self)
    self.__index = self
    o.playerObj = playerObj
    o.snapshot = nil
    o.activeTab = "overview"
    o.flashMessage = nil
    o.flashUntil = 0
    o.resizable = true
    o.pin = false
    o.title = getText("IGUI_BF_Title")
    o.backgroundColor = cloneColor(THEME.windowBackground)
    o.borderColor = cloneColor(THEME.windowBorder)
    o.layout = {}
    return o
end

function BF_MainPanel:initialise()
    ISCollapsableWindow.initialise(self)
end

function BF_MainPanel:createChildren()
    ISCollapsableWindow.createChildren(self)

    self.refreshButton = ISButton:new(0, 0, 108, 28, getText("IGUI_BF_Refresh"), self, self.onRefresh)
    self.refreshButton:initialise()
    self.refreshButton:instantiate()
    self:addChild(self.refreshButton)

    self.noticeLabel = ISLabel:new(22, 36, 20, "", 0.95, 0.80, 0.56, 1.00, UIFont.Small, true)
    self.noticeLabel:initialise()
    self.noticeLabel:instantiate()
    self:addChild(self.noticeLabel)

    self.createNameLabel = ISLabel:new(22, 122, 20, getText("IGUI_BF_GuildName"), 0.93, 0.88, 0.80, 1.00, UIFont.Medium, true)
    self.createNameLabel:initialise()
    self.createNameLabel:instantiate()
    self:addChild(self.createNameLabel)

    self.nameEntry = ISTextEntryBox:new("", 22, 148, 360, 28)
    self.nameEntry:initialise()
    self.nameEntry:instantiate()
    self:addChild(self.nameEntry)

    self.createButton = ISButton:new(396, 148, 208, 28, getText("IGUI_BF_CreateGuild"), self, self.onCreateGuild)
    self.createButton:initialise()
    self.createButton:instantiate()
    self:addChild(self.createButton)

    self.content = ISRichTextPanel:new(20, 210, self.width - 40, self.height - 330)
    self.content:initialise()
    self.content:instantiate()
    self.content.autosetheight = false
    self.content.background = false
    self.content.clip = true
    self.content.marginLeft = 14
    self.content.marginTop = 12
    self:addChild(self.content)

    self.memberList = ISScrollingListBox:new(self.width - 310, 210, 290, self.height - 330)
    self.memberList:initialise()
    self.memberList:instantiate()
    self.memberList.itemheight = 24
    self.memberList.selected = 0
    self.memberList.doDrawItem = self.drawMemberItem
    self.memberList.backgroundColor = cloneColor(THEME.section)
    self.memberList.borderColor = cloneColor(THEME.sectionBorder)
    self:addChild(self.memberList)

    self.inviteList = ISScrollingListBox:new(self.width - 310, 210, 290, self.height - 330)
    self.inviteList:initialise()
    self.inviteList:instantiate()
    self.inviteList.itemheight = 32
    self.inviteList.selected = 0
    self.inviteList.doDrawItem = self.drawInviteItem
    self.inviteList.backgroundColor = cloneColor(THEME.section)
    self.inviteList.borderColor = cloneColor(THEME.sectionBorder)
    self:addChild(self.inviteList)

    self.inviteTargetLabel = ISLabel:new(22, 122, 20, getText("IGUI_BF_SendInvite"), 0.93, 0.88, 0.80, 1.00, UIFont.Medium, true)
    self.inviteTargetLabel:initialise()
    self.inviteTargetLabel:instantiate()
    self:addChild(self.inviteTargetLabel)

    self.inviteEntry = ISTextEntryBox:new("", 22, 148, 360, 28)
    self.inviteEntry:initialise()
    self.inviteEntry:instantiate()
    self:addChild(self.inviteEntry)

    self.sendInviteButton = ISButton:new(396, 148, 208, 28, getText("IGUI_BF_SendInvite"), self, self.onSendInvite)
    self.sendInviteButton:initialise()
    self.sendInviteButton:instantiate()
    self:addChild(self.sendInviteButton)

    -- Contribute amount entry (management tab)
    self.contributeAmountLabel = ISLabel:new(22, 0, 20, getText("IGUI_BF_DepositAmountLabel"), 0.93, 0.88, 0.80, 1.00, UIFont.Small, true)
    self.contributeAmountLabel:initialise(); self.contributeAmountLabel:instantiate()
    self:addChild(self.contributeAmountLabel)

    self.contributeAmountEntry = ISTextEntryBox:new("", 22, 0, 130, 24)
    self.contributeAmountEntry:initialise(); self.contributeAmountEntry:instantiate()
    self:addChild(self.contributeAmountEntry)

    -- Tax widgets (management tab for admins)
    self.taxAmountLabel = ISLabel:new(22, 122, 20, getText("IGUI_BF_Tax_Amount"), 0.93, 0.88, 0.80, 1.00, UIFont.Small, true)
    self.taxAmountLabel:initialise(); self.taxAmountLabel:instantiate()
    self:addChild(self.taxAmountLabel)

    self.taxAmountEntry = ISTextEntryBox:new("", 22, 140, 120, 24)
    self.taxAmountEntry:initialise(); self.taxAmountEntry:instantiate()
    self:addChild(self.taxAmountEntry)

    self.taxDaysLabel = ISLabel:new(154, 122, 20, getText("IGUI_BF_Tax_Days"), 0.93, 0.88, 0.80, 1.00, UIFont.Small, true)
    self.taxDaysLabel:initialise(); self.taxDaysLabel:instantiate()
    self:addChild(self.taxDaysLabel)

    self.taxDaysEntry = ISTextEntryBox:new("", 154, 140, 80, 24)
    self.taxDaysEntry:initialise(); self.taxDaysEntry:instantiate()
    self:addChild(self.taxDaysEntry)

    self.overviewPanels = {}
    self.overviewPanels.status = self:createOverviewPanel()
    self.overviewPanels.benefits = self:createOverviewPanel()
    self.overviewPanels.audit = self:createOverviewPanel()

    self.tabButtons = {}
    for _, id in ipairs(TAB_IDS) do
        local labelKey = "IGUI_BF_Tab_" .. string.upper(string.sub(id, 1, 1)) .. string.sub(id, 2)
        local button = ISButton:new(20, 120, 150, 28, getText(labelKey), self, self.onTabClicked)
        button.internal = id
        button:initialise()
        button:instantiate()
        self:addChild(button)
        self.tabButtons[id] = button
    end

    self.bottomButtons = {}
    self.bottomButtons.deposit = self:createBottomButton("deposit", getText("IGUI_BF_Deposit"), self.onDeposit, "accent")
    self.bottomButtons.contribute = self:createBottomButton("contribute", getText("IGUI_BF_ContributeAll"), self.onContributeAll, "accent")
    self.bottomButtons.buyHall = self:createBottomButton("buyHall", getText("IGUI_BF_Upgrade_Hall"), self.onBuyHall, "gold")
    self.bottomButtons.buyScholarship = self:createBottomButton("buyScholarship", getText("IGUI_BF_Upgrade_Scholarship"), self.onBuyScholarship, "scholar")
    self.bottomButtons.buyWarcamp = self:createBottomButton("buyWarcamp", getText("IGUI_BF_Upgrade_Warcamp"), self.onBuyWarcamp, "war")
    self.bottomButtons.syncNative = self:createBottomButton("syncNative", getText("IGUI_BF_SyncNative"), self.onSyncNative, "member")
    self.bottomButtons.xpWoodwork = self:createBottomButton("xpWoodwork", getText("IGUI_BF_ActivateXPBuff_Carpentry"), self.onActivateXPWoodwork, "scholar")
    self.bottomButtons.xpMechanics = self:createBottomButton("xpMechanics", getText("IGUI_BF_ActivateXPBuff_Mechanics"), self.onActivateXPMechanics, "scholar")
    self.bottomButtons.xpAiming = self:createBottomButton("xpAiming", getText("IGUI_BF_ActivateXPBuff_Aiming"), self.onActivateXPAiming, "scholar")
    self.bottomButtons.slayer = self:createBottomButton("slayer", getText("IGUI_BF_ActivateSlayer"), self.onActivateSlayer, "war")
    self.bottomButtons.memberToTreasurer = self:createBottomButton("memberToTreasurer", getText("IGUI_BF_PromoteTreasurer"), self.onPromoteTreasurer, "gold")
    self.bottomButtons.memberToOfficer = self:createBottomButton("memberToOfficer", getText("IGUI_BF_PromoteOfficer"), self.onPromoteOfficer, "member")
    self.bottomButtons.memberToMember = self:createBottomButton("memberToMember", getText("IGUI_BF_DemoteMember"), self.onDemoteMember, "neutral")
    self.bottomButtons.memberRemove = self:createBottomButton("memberRemove", getText("IGUI_BF_RemoveMember"), self.onRemoveMember, "danger")
    self.bottomButtons.trait = self:createBottomButton("trait", getText("IGUI_BF_RequestTraitBoon"), self.onRequestTraitBoon, "danger")
    self.bottomButtons.acceptInvite = self:createBottomButton("acceptInvite", getText("IGUI_BF_AcceptInvite"), self.onAcceptInvite, "moss")
    self.bottomButtons.rejectInvite = self:createBottomButton("rejectInvite", getText("IGUI_BF_RejectInvite"), self.onRejectInvite, "danger")
    self.bottomButtons.cancelInvite = self:createBottomButton("cancelInvite", getText("IGUI_BF_CancelInvite"), self.onCancelInvite, "neutral")
    self.bottomButtons.requestJoin = self:createBottomButton("requestJoin", getText("IGUI_BF_RequestJoinGuild"), self.onRequestJoin, "accent")
    self.bottomButtons.browseGuilds = self:createBottomButton("browseGuilds", getText("IGUI_BF_ViewGuilds"), self.onBrowseGuilds, "member")
    self.bottomButtons.deleteGuild = self:createBottomButton("deleteGuild", getText("IGUI_BF_DeleteGuild"), self.onDeleteGuild, "danger")
    self.bottomButtons.payTax = self:createBottomButton("payTax", getText("IGUI_BF_Tax_Header"), self.onPayTax, "gold")
    self.bottomButtons.setTax = self:createBottomButton("setTax", getText("IGUI_BF_Tax_SetRate"), self.onSetTax, "neutral")

    self:applyStaticStyles()
    self:updateLayout(false)
    self:refreshFromSnapshot()
end

function BF_MainPanel:createOverviewPanel()
    local panel = ISRichTextPanel:new(20, 210, 200, 120)
    panel:initialise()
    panel:instantiate()
    panel.autosetheight = false
    panel.background = false
    panel.clip = true
    panel.marginLeft = 12
    panel.marginTop = 10
    self:addChild(panel)
    return panel
end

function BF_MainPanel:createBottomButton(id, title, handler, skin)
    local button = ISButton:new(20, self.height - 108, 160, 30, title, self, handler)
    button:initialise()
    button:instantiate()
    button.internalButtonId = id
    button.internalSkin = skin or "neutral"
    self:addChild(button)
    return button
end

function BF_MainPanel:applyStaticStyles()
    applyButtonSkin(self.refreshButton, "neutral", false)
    self.refreshButton:setTooltip(getText("IGUI_BF_Tooltip_Refresh"))

    applyButtonSkin(self.createButton, "accent", true)
    self.createButton:setTooltip(getText("IGUI_BF_Tooltip_CreateGuild", moneyText(BF.getCreateCost())))
    self.nameEntry.tooltip = getText("IGUI_BF_Tooltip_GuildName")

    for _, id in ipairs(TAB_IDS) do
        local button = self.tabButtons[id]
        applyButtonSkin(button, TAB_SKINS[id], id == self.activeTab)
        button:setTooltip(getText(TAB_TOOLTIP_KEYS[id]))
    end

    for _, button in pairs(self.bottomButtons) do
        applyButtonSkin(button, button.internalSkin, false)
        button:setOverlayText(nil)
    end
end

function BF_MainPanel:updateLayout(hasGuild)
    local showMemberList = hasGuild and self.activeTab == "members"
    local isManagement = hasGuild and self.activeTab == "management"
    local showInviteList = isManagement or
                           (not hasGuild and (self.guildsWithSlots ~= nil or self:hasPendingInvites()))
    -- Invite entry (send-by-name) is on the members tab, at the bottom
    local showInviteEntry = hasGuild and self.activeTab == "members" and
                            self.snapshot and self.snapshot.player and
                            self.snapshot.player.permissions and
                            self.snapshot.player.permissions.inviteMembers == true
    -- Contribute entry always visible on management; tax entry only when setGuildTax perm
    local showContributeEntry = isManagement
    local showTaxEntry = isManagement and
                         self.snapshot and self.snapshot.player and
                         self.snapshot.player.permissions and
                         self.snapshot.player.permissions.setGuildTax == true

    local tabGap = 10
    local tabWidth = math.floor((self.width - 40 - (tabGap * (#TAB_IDS - 1))) / #TAB_IDS)
    local titleY = hasGuild and 192 or 78
    local hintY = hasGuild and 214 or 102
    local createLabelY = 122
    local createRowY = 148
    local contentY = hasGuild and 248 or 206
    local actionY = self.height - 108
    -- Start with comfortable gap before action area
    local contentHeight = math.max(130, actionY - contentY - 48)
    -- Reserve bottom space for input rows
    if showInviteEntry then
        contentHeight = math.max(80, contentHeight - 68)
    end
    if showContributeEntry then
        contentHeight = math.max(80, contentHeight - 68)
    end
    if showTaxEntry then
        contentHeight = math.max(60, contentHeight - 68)
    end
    local contentWidth = self.width - 40
    local memberWidth = 290
    local memberGap = 14

    if showMemberList or showInviteList then
        contentWidth = self.width - 40 - memberWidth - memberGap
    end

    self.layout = {
        hasGuild = hasGuild,
        showMemberList = showMemberList,
        showInviteList = showInviteList,
        showInviteEntry = showInviteEntry,
        showContributeEntry = showContributeEntry,
        showTaxEntry = showTaxEntry,
        summaryY = 62,
        summaryHeight = hasGuild and 78 or 0,
        tabsY = hasGuild and 144 or 120,
        titleY = titleY,
        hintY = hintY,
        contentX = 20,
        contentY = contentY,
        contentWidth = contentWidth,
        contentHeight = contentHeight,
        memberX = 20 + contentWidth + memberGap,
        memberY = contentY,
        memberWidth = memberWidth,
        memberHeight = contentHeight,
        inviteListX = 20 + contentWidth + memberGap,
        inviteListY = contentY,
        inviteListWidth = memberWidth,
        inviteListHeight = contentHeight,
        actionY = actionY,
    }

    self.refreshButton:setX(self.width - 128)
    self.refreshButton:setY(28)

    self.createNameLabel:setX(22)
    self.createNameLabel:setY(createLabelY)
    self.nameEntry:setX(22)
    self.nameEntry:setY(createRowY)
    self.nameEntry:setWidth(math.min(420, math.max(250, self.width - 300)))
    self.createButton:setX(self.nameEntry:getX() + self.nameEntry:getWidth() + 14)
    self.createButton:setY(createRowY)
    self.createButton:setWidth(math.min(220, self.width - self.createButton:getX() - 22))

    local tabX = 20
    for _, id in ipairs(TAB_IDS) do
        local button = self.tabButtons[id]
        button:setX(tabX)
        button:setY(self.layout.tabsY)
        button:setWidth(tabWidth)
        button:setHeight(28)
        tabX = tabX + tabWidth + tabGap
    end

    self.content:setX(self.layout.contentX)
    self.content:setY(self.layout.contentY)
    self.content:setWidth(self.layout.contentWidth)
    self.content:setHeight(self.layout.contentHeight)

    self.memberList:setX(self.layout.memberX)
    self.memberList:setY(self.layout.memberY)
    self.memberList:setWidth(self.layout.memberWidth)
    self.memberList:setHeight(self.layout.memberHeight)

    self.inviteList:setX(self.layout.inviteListX)
    self.inviteList:setY(self.layout.inviteListY)
    self.inviteList:setWidth(self.layout.inviteListWidth)
    self.inviteList:setHeight(self.layout.inviteListHeight)

    -- Invite entry: at the bottom of the left panel on members tab
    local inviteLabelY = actionY - 56
    local inviteEntryY = actionY - 36
    local inviteEntryW = math.min(300, math.max(180, self.width - 240))
    self.inviteTargetLabel:setX(22)
    self.inviteTargetLabel:setY(inviteLabelY)
    self.inviteEntry:setX(22)
    self.inviteEntry:setY(inviteEntryY)
    self.inviteEntry:setWidth(inviteEntryW)
    self.sendInviteButton:setX(22 + inviteEntryW + 10)
    self.sendInviteButton:setY(inviteEntryY)
    self.sendInviteButton:setWidth(math.min(180, self.width - (22 + inviteEntryW + 10) - 22))

    -- Bottom input rows for management tab (stacked above action bar)
    -- Contribute row is always shown; tax row is above it when also shown
    local bottomRow1Y  = actionY - 36  -- entry y (lowest row)
    local bottomRow1LY = actionY - 56  -- label y (lowest row)
    local bottomRow2Y  = actionY - 92  -- entry y (row above)
    local bottomRow2LY = actionY - 112 -- label y (row above)

    if showContributeEntry and showTaxEntry then
        -- Contribute is row2 (top), tax is row1 (bottom)
        self.contributeAmountLabel:setX(22)
        self.contributeAmountLabel:setY(bottomRow2LY)
        self.contributeAmountEntry:setX(22)
        self.contributeAmountEntry:setY(bottomRow2Y)
        self.contributeAmountEntry:setWidth(130)
        self.taxAmountLabel:setX(22)
        self.taxAmountLabel:setY(bottomRow1LY)
        self.taxAmountEntry:setX(22)
        self.taxAmountEntry:setY(bottomRow1Y)
        self.taxAmountEntry:setWidth(100)
        self.taxDaysLabel:setX(136)
        self.taxDaysLabel:setY(bottomRow1LY)
        self.taxDaysEntry:setX(136)
        self.taxDaysEntry:setY(bottomRow1Y)
        self.taxDaysEntry:setWidth(80)
    elseif showContributeEntry then
        -- Contribute is the only row
        self.contributeAmountLabel:setX(22)
        self.contributeAmountLabel:setY(bottomRow1LY)
        self.contributeAmountEntry:setX(22)
        self.contributeAmountEntry:setY(bottomRow1Y)
        self.contributeAmountEntry:setWidth(130)
        -- Tax fields parked off-screen
        self.taxAmountLabel:setY(-100)
        self.taxAmountEntry:setY(-100)
        self.taxDaysLabel:setY(-100)
        self.taxDaysEntry:setY(-100)
    else
        -- Tax only (management + setGuildTax but showContributeEntry always true when management, so this branch unused)
        self.taxAmountLabel:setX(22)
        self.taxAmountLabel:setY(bottomRow1LY)
        self.taxAmountEntry:setX(22)
        self.taxAmountEntry:setY(bottomRow1Y)
        self.taxAmountEntry:setWidth(100)
        self.taxDaysLabel:setX(136)
        self.taxDaysLabel:setY(bottomRow1LY)
        self.taxDaysEntry:setX(136)
        self.taxDaysEntry:setY(bottomRow1Y)
        self.taxDaysEntry:setWidth(80)
    end

    local innerX = self.layout.contentX + 12
    local innerY = self.layout.contentY + 12
    local innerWidth = self.layout.contentWidth - 24
    local innerHeight = self.layout.contentHeight - 24
    local overviewGap = 12
    local topBoxHeight = math.min(160, math.max(122, math.floor(innerHeight * 0.36)))
    local auditBoxY = innerY + topBoxHeight + overviewGap
    local auditBoxHeight = math.max(120, innerHeight - topBoxHeight - overviewGap)
    local halfWidth = math.floor((innerWidth - overviewGap) / 2)

    self.layout.overviewBoxes = {
        status = { x = innerX, y = innerY, width = halfWidth, height = topBoxHeight },
        benefits = { x = innerX + halfWidth + overviewGap, y = innerY, width = innerWidth - halfWidth - overviewGap, height = topBoxHeight },
        audit = { x = innerX, y = auditBoxY, width = innerWidth, height = auditBoxHeight },
    }

    self.overviewPanels.status:setX(self.layout.overviewBoxes.status.x + 8)
    self.overviewPanels.status:setY(self.layout.overviewBoxes.status.y + 8)
    self.overviewPanels.status:setWidth(self.layout.overviewBoxes.status.width - 16)
    self.overviewPanels.status:setHeight(self.layout.overviewBoxes.status.height - 16)

    self.overviewPanels.benefits:setX(self.layout.overviewBoxes.benefits.x + 8)
    self.overviewPanels.benefits:setY(self.layout.overviewBoxes.benefits.y + 8)
    self.overviewPanels.benefits:setWidth(self.layout.overviewBoxes.benefits.width - 16)
    self.overviewPanels.benefits:setHeight(self.layout.overviewBoxes.benefits.height - 16)

    self.overviewPanels.audit:setX(self.layout.overviewBoxes.audit.x + 8)
    self.overviewPanels.audit:setY(self.layout.overviewBoxes.audit.y + 8)
    self.overviewPanels.audit:setWidth(self.layout.overviewBoxes.audit.width - 16)
    self.overviewPanels.audit:setHeight(self.layout.overviewBoxes.audit.height - 16)
end

function BF_MainPanel:onResize()
    ISCollapsableWindow.onResize(self)
    self:refreshFromSnapshot()
end

function BF_MainPanel:addFlashMessage(text)
    self.flashMessage = text
    self.flashUntil = getTimestamp() + 8
    if self.noticeLabel.setName then
        self.noticeLabel:setName(text or "")
    else
        self.noticeLabel.name = text or ""
    end
end

function BF_MainPanel:setSnapshot(snapshot)
    self.snapshot = snapshot
    self:refreshFromSnapshot()
end

function BF_MainPanel:onRefresh()
    BF.Client.requestSnapshot()
end

function BF_MainPanel:onCreateGuild()
    BF.Client.createGuild(self.nameEntry:getText())
end

function BF_MainPanel:onTabClicked(button)
    self.activeTab = button.internal
    self:refreshFromSnapshot()
end

function BF_MainPanel:onDeposit()
    local amount = tonumber(self.contributeAmountEntry and self.contributeAmountEntry:getText()) or 0
    if amount > 0 then
        BF.Client.contributeAmount(amount)
    end
end

function BF_MainPanel:onContributeAll()
    BF.Client.contributeAllCash()
end

function BF_MainPanel:onBuyHall()
    BF.Client.buyUpgrade("hall")
end

function BF_MainPanel:onBuyScholarship()
    BF.Client.buyUpgrade("scholarship")
end

function BF_MainPanel:onBuyWarcamp()
    BF.Client.buyUpgrade("warcamp")
end

function BF_MainPanel:onSyncNative()
    BF.Client.syncNativeFaction()
end

function BF_MainPanel:onActivateXPWoodwork()
    BF.Client.activateXPBuff("Woodwork")
end

function BF_MainPanel:onActivateXPMechanics()
    BF.Client.activateXPBuff("Mechanics")
end

function BF_MainPanel:onActivateXPAiming()
    BF.Client.activateXPBuff("Aiming")
end

function BF_MainPanel:onActivateSlayer()
    BF.Client.activateSlayerFocus()
end

function BF_MainPanel:onPromoteTreasurer()
    local item = self:getSelectedMember()
    if item then
        BF.Client.setMemberRole(item.username, "treasurer")
    end
end

function BF_MainPanel:onPromoteOfficer()
    local item = self:getSelectedMember()
    if item then
        BF.Client.setMemberRole(item.username, "officer")
    end
end

function BF_MainPanel:onDemoteMember()
    local item = self:getSelectedMember()
    if item then
        BF.Client.setMemberRole(item.username, "member")
    end
end

function BF_MainPanel:onRemoveMember()
    local item = self:getSelectedMember()
    if item then
        BF.Client.removeMember(item.username)
    end
end

function BF_MainPanel:onRequestTraitBoon()
    BF.Client.requestTraitBoon()
end

function BF_MainPanel:getSelectedMember()
    if not self.memberList or self.memberList.selected <= 0 then
        return nil
    end
    local row = self.memberList.items[self.memberList.selected]
    return row and row.item or nil
end

function BF_MainPanel:drawMemberItem(y, item, alt)
    local role = item.item.role or "member"
    local roleColor = THEME.paragraphDim
    if role == "owner" then
        roleColor = THEME.brass
    elseif role == "treasurer" then
        roleColor = THEME.moss
    elseif role == "officer" then
        roleColor = THEME.ember
    else
        roleColor = THEME.paragraph
    end

    if self.selected == item.index then
        self:drawRect(0, y, self:getWidth(), self.itemheight - 1, 0.34, THEME.ember.r, THEME.ember.g, THEME.ember.b)
    elseif alt then
        self:drawRect(0, y, self:getWidth(), self.itemheight - 1, 0.10, THEME.frame.r, THEME.frame.g, THEME.frame.b)
    end

    self:drawText(item.item.username, 10, y + 4, THEME.paragraph.r, THEME.paragraph.g, THEME.paragraph.b, 0.98, UIFont.Small)
    self:drawTextRight(getText(BF.getRoleLabelKey(role)), self:getWidth() - 10, y + 4, roleColor.r, roleColor.g, roleColor.b, 0.98, UIFont.Small)

    -- Tax status tag (second line, only when tax is configured)
    local taxStatuses = self._panelRef and self._panelRef.snapshot and self._panelRef.snapshot.guild and self._panelRef.snapshot.guild.taxStatuses
    if taxStatuses and self.itemheight >= 36 then
        local ts = taxStatuses[item.item.username]
        if ts then
            local tagText, tr, tg, tb
            if ts.status == "paid" then
                tagText = getText("IGUI_BF_Tax_Status_Paid") .. " (" .. getText("IGUI_BF_Tax_DaysLeft", tostring(ts.daysLeft or 0)) .. ")"
                tr, tg, tb = THEME.moss.r, THEME.moss.g, THEME.moss.b
            elseif ts.status == "overdue" then
                tagText = getText("IGUI_BF_Tax_Status_Overdue") .. " (" .. getText("IGUI_BF_Tax_DaysOverdue", tostring(ts.daysOverdue or 0)) .. ")"
                tr, tg, tb = THEME.ember.r, THEME.ember.g, THEME.ember.b
            else
                tagText = getText("IGUI_BF_Tax_Status_Due")
                tr, tg, tb = THEME.brass.r, THEME.brass.g, THEME.brass.b
            end
            self:drawText(tagText, 10, y + 20, tr, tg, tb, 0.90, UIFont.Small)
        end
    end

    return y + self.itemheight
end

function BF_MainPanel:populateMembers()
    self.memberList:clear()
    self.memberList._panelRef = self   -- reference for drawMemberItem to access taxStatuses
    local guild = self.snapshot and self.snapshot.guild or nil
    if not guild or not guild.members then
        return
    end

    for _, member in ipairs(guild.members) do
        self.memberList:addItem(member.username, member)
    end
end

function BF_MainPanel:getSectionMeta(hasGuild)
    local id = hasGuild and self.activeTab or "noGuild"
    local meta = SECTION_META[id] or SECTION_META.overview
    return {
        title = getText(meta.titleKey),
        hint = getText(meta.hintKey),
        skin = meta.skin or "neutral",
    }
end

function BF_MainPanel:getActiveBenefitCard()
    local snapshot = self.snapshot
    local guild = snapshot and snapshot.guild or nil
    if not guild then
        return {
            value = getText("IGUI_BF_Card_NoBenefit"),
            meta = getText("IGUI_BF_Card_Benefit_Ready"),
            skin = "neutral",
        }
    end

    local xp = guild.activeBenefits and guild.activeBenefits.xp or nil
    if xp then
        local perk = BF.getXPBuffOption(xp.perkId)
        local perkLabel = perk and getText(perk.labelKey) or safeText(xp.perkId)
        return {
            value = perkLabel,
            meta = getText("IGUI_BF_Card_XPStatus", tostring((xp.multiplier or 1) * 100), fmtTimeLeft(snapshot.serverTime, xp.expiresAt)),
            skin = "scholar",
        }
    end

    local slayer = guild.activeBenefits and guild.activeBenefits.slayer or nil
    if slayer then
        return {
            value = getText("IGUI_BF_Card_SlayerTitle"),
            meta = getText("IGUI_BF_Card_SlayerStatus", tostring(slayer.renownBonus or 0), fmtTimeLeft(snapshot.serverTime, slayer.expiresAt)),
            skin = "war",
        }
    end

    return {
        value = getText("IGUI_BF_Card_NoBenefit"),
        meta = getText("IGUI_BF_Card_Benefit_Ready"),
        skin = "neutral",
    }
end

function BF_MainPanel:drawSummaryCards()
    local snapshot = self.snapshot
    local guild = snapshot and snapshot.guild or nil
    if not guild then
        return
    end

    local cardGap = 10
    local cardWidth = math.floor((self.width - 40 - (cardGap * 3)) / 4)
    local cardHeight = self.layout.summaryHeight or 68
    local y = self.layout.summaryY or 62

    local benefitCard = self:getActiveBenefitCard()
    local renownMeta = guild.progress.nextLevelRenown
        and getText("IGUI_BF_Card_NextLine", tostring(guild.progress.nextLevelRenown))
        or getText("IGUI_BF_Card_MaxLevel")

    local cards = {
        {
            label = getText("IGUI_BF_Card_Treasury"),
            value = moneyText(guild.treasury.balance or 0),
            meta = getText("IGUI_BF_Card_LifetimeLine", moneyText(guild.treasury.lifetimeIn or 0)),
            skin = "gold",
        },
        {
            label = getText("IGUI_BF_Card_Renown"),
            value = "Lv " .. tostring(guild.progress.level or 1),
            meta = renownMeta,
            skin = "accent",
        },
        {
            label = getText("IGUI_BF_Card_Members"),
            value = tostring(guild.memberCount or 0) .. " / " .. tostring(guild.memberCap or 0),
            meta = getText("IGUI_BF_Card_OwnerLine", safeText(guild.owner)),
            skin = "member",
        },
        {
            label = getText("IGUI_BF_Card_Benefit"),
            value = benefitCard.value,
            meta = benefitCard.meta,
            skin = benefitCard.skin,
        },
    }

    for index, card in ipairs(cards) do
        local skin = BUTTON_SKINS[card.skin] or BUTTON_SKINS.neutral
        local x = 20 + ((index - 1) * (cardWidth + cardGap))
        local useSmallValue = #safeText(card.value) > 16
        local valueFont = useSmallValue and UIFont.Small or UIFont.Medium
        local valueY = useSmallValue and 29 or 26
        self:drawRect(x, y, cardWidth, cardHeight, 0.32, skin.bg.r, skin.bg.g, skin.bg.b)
        self:drawRectBorder(x, y, cardWidth, cardHeight, skin.border.a, skin.border.r, skin.border.g, skin.border.b)
        self:drawText(card.label, x + 10, y + 8, THEME.paragraphDim.r, THEME.paragraphDim.g, THEME.paragraphDim.b, 0.95, UIFont.Small)
        self:drawText(card.value, x + 10, y + valueY, skin.text.r, skin.text.g, skin.text.b, 1.00, valueFont)
        self:drawText(card.meta, x + 10, y + 58, THEME.paragraphDim.r, THEME.paragraphDim.g, THEME.paragraphDim.b, 0.92, UIFont.Small)
    end
end

function BF_MainPanel:prerender()
    ISCollapsableWindow.prerender(self)

    if self.flashMessage and self.flashUntil > 0 and getTimestamp() >= self.flashUntil then
        self:addFlashMessage(nil)
    end

    local hasGuild = self.snapshot ~= nil and self.snapshot.guild ~= nil
    local meta = self:getSectionMeta(hasGuild)
    local contentInsetX = (self.layout.contentX or 20) - 4
    local contentInsetY = (self.layout.contentY or 210) - 10
    local contentInsetW = (self.layout.contentWidth or (self.width - 40)) + 8
    local contentInsetH = (self.layout.contentHeight or 200) + 18

    self:drawRect(14, 56, self.width - 28, self.height - 70, THEME.frame.a, THEME.frame.r, THEME.frame.g, THEME.frame.b)
    self:drawRectBorder(14, 56, self.width - 28, self.height - 70, THEME.windowBorder.a, THEME.windowBorder.r, THEME.windowBorder.g, THEME.windowBorder.b)

    if not hasGuild then
        self:drawRect(18, 118, self.width - 36, 68, 0.22, THEME.section.r, THEME.section.g, THEME.section.b)
        self:drawRectBorder(18, 118, self.width - 36, 68, THEME.sectionBorder.a, THEME.sectionBorder.r, THEME.sectionBorder.g, THEME.sectionBorder.b)
    end

    self:drawText(meta.title, 22, self.layout.titleY or 78, THEME.paragraph.r, THEME.paragraph.g, THEME.paragraph.b, 1.00, UIFont.Medium)
    self:drawText(meta.hint, 22, self.layout.hintY or 102, THEME.paragraphDim.r, THEME.paragraphDim.g, THEME.paragraphDim.b, 0.95, UIFont.Small)

    if hasGuild then
        self:drawSummaryCards()
    end

    self:drawRect(contentInsetX, contentInsetY, contentInsetW, contentInsetH, 0.32, THEME.section.r, THEME.section.g, THEME.section.b)
    self:drawRectBorder(contentInsetX, contentInsetY, contentInsetW, contentInsetH, THEME.sectionBorder.a, THEME.sectionBorder.r, THEME.sectionBorder.g, THEME.sectionBorder.b)

    if hasGuild and self.activeTab == "overview" then
        for _, box in pairs(self.layout.overviewBoxes or {}) do
            self:drawRect(box.x, box.y, box.width, box.height, 0.20, THEME.frame.r, THEME.frame.g, THEME.frame.b)
            self:drawRectBorder(box.x, box.y, box.width, box.height, THEME.sectionBorder.a, THEME.sectionBorder.r, THEME.sectionBorder.g, THEME.sectionBorder.b)
        end
    end

    if self.layout.showMemberList then
        local memberInsetX = (self.layout.memberX or (self.width - 310)) - 4
        local memberInsetY = (self.layout.memberY or 210) - 10
        local memberInsetW = (self.layout.memberWidth or 290) + 8
        local memberInsetH = (self.layout.memberHeight or 200) + 18
        self:drawRect(memberInsetX, memberInsetY, memberInsetW, memberInsetH, 0.32, THEME.section.r, THEME.section.g, THEME.section.b)
        self:drawRectBorder(memberInsetX, memberInsetY, memberInsetW, memberInsetH, THEME.sectionBorder.a, THEME.sectionBorder.r, THEME.sectionBorder.g, THEME.sectionBorder.b)
    end

    if self.layout.showInviteList then
        local inviteInsetX = (self.layout.inviteListX or (self.width - 310)) - 4
        local inviteInsetY = (self.layout.inviteListY or 210) - 10
        local inviteInsetW = (self.layout.inviteListWidth or 290) + 8
        local inviteInsetH = (self.layout.inviteListHeight or 200) + 18
        self:drawRect(inviteInsetX, inviteInsetY, inviteInsetW, inviteInsetH, 0.32, THEME.section.r, THEME.section.g, THEME.section.b)
        self:drawRectBorder(inviteInsetX, inviteInsetY, inviteInsetW, inviteInsetH, THEME.sectionBorder.a, THEME.sectionBorder.r, THEME.sectionBorder.g, THEME.sectionBorder.b)
    end

    local visibleButtons = self:getVisibleActionButtons()
    if #visibleButtons > 0 then
        local actionBoxY = (self.layout.actionY or (self.height - 108)) - 12
        local actionBoxH = self.layout.actionBoxHeight or 86
        self:drawRect(18, actionBoxY, self.width - 36, actionBoxH, 0.22, THEME.section.r, THEME.section.g, THEME.section.b)
        self:drawRectBorder(18, actionBoxY, self.width - 36, actionBoxH, THEME.sectionBorder.a, THEME.sectionBorder.r, THEME.sectionBorder.g, THEME.sectionBorder.b)
        self:drawText(getText("IGUI_BF_ActionBar_Title"), 24, (self.layout.actionY or (self.height - 108)) - 6, THEME.paragraphDim.r, THEME.paragraphDim.g, THEME.paragraphDim.b, 0.95, UIFont.Small)
    end
end

function BF_MainPanel:buildNoGuildText()
    local snapshot = self.snapshot or {}
    local nativeInfo = snapshot.nativeFaction or {}
    local config = snapshot.config or {}
    local money = snapshot.player and snapshot.player.moneyOnPerson or 0
    local lines = {
        getText("IGUI_BF_NoGuildHeader"),
        " <LINE> ",
        getText("IGUI_BF_NoGuildBody"),
        " <LINE> <LINE> ",
        getText("IGUI_BF_CreateHint"),
        " <LINE> <LINE> ",
        getText("IGUI_BF_CreateCost", tostring(config.createCost or 0)),
        " <LINE> ",
        getText("IGUI_BF_MoneyOnPerson", tostring(money)),
    }

    if nativeInfo and nativeInfo.name then
        table.insert(lines, " <LINE> ")
        table.insert(lines, getText("IGUI_BF_NativeFactionInfo", tostring(nativeInfo.name), tostring(nativeInfo.memberCount or 0)))
    end

    return table.concat(lines)
end

function BF_MainPanel:buildOverviewText()
    local snapshot = self.snapshot
    local guild = snapshot.guild
    local activeXP = guild.activeBenefits and guild.activeBenefits.xp or nil
    local activeSlayer = guild.activeBenefits and guild.activeBenefits.slayer or nil
    local lines = {
        getText("IGUI_BF_GuildLine", guild.name),
        " <LINE> ",
        getText("IGUI_BF_OwnerLine", guild.owner),
        " <LINE> ",
        getText("IGUI_BF_MemberCapLine", tostring(guild.memberCount), tostring(guild.memberCap)),
        " <LINE> ",
        getText("IGUI_BF_TreasuryLine", tostring(guild.treasury.balance or 0)),
        " <LINE> ",
        getText("IGUI_BF_LifetimeContribLine", tostring(guild.treasury.lifetimeIn or 0)),
        " <LINE> ",
        getText("IGUI_BF_RenownLine", tostring(guild.progress.renown or 0)),
        " <LINE> ",
        getText("IGUI_BF_LevelLine", tostring(guild.progress.level or 1)),
        " <BR> ",
        " <H2> ",
        getText("IGUI_BF_ActiveBenefitsHeader"),
        " <LINE> ",
        " <TEXT> ",
    }

    if activeXP then
        local perk = BF.getXPBuffOption(activeXP.perkId)
        local perkLabel = perk and getText(perk.labelKey) or tostring(activeXP.perkId)
        table.insert(lines, getText("IGUI_BF_ActiveXPLine", perkLabel, tostring((activeXP.multiplier or 1) * 100), fmtTimeLeft(snapshot.serverTime, activeXP.expiresAt)))
        table.insert(lines, " <LINE> ")
    else
        table.insert(lines, getText("IGUI_BF_NoActiveXP"))
        table.insert(lines, " <LINE> ")
    end

    if activeSlayer then
        table.insert(lines, getText("IGUI_BF_ActiveSlayerLine", tostring(activeSlayer.renownBonus or 0), fmtTimeLeft(snapshot.serverTime, activeSlayer.expiresAt), tostring(activeSlayer.kills or 0)))
    else
        table.insert(lines, getText("IGUI_BF_NoActiveSlayer"))
    end

    table.insert(lines, " <BR> ")
    table.insert(lines, " <H2> ")
    table.insert(lines, getText("IGUI_BF_AuditHeader"))
    table.insert(lines, " <LINE> ")
    table.insert(lines, " <TEXT> ")
    for _, row in ipairs(guild.auditTail or {}) do
        table.insert(lines, " <LINE> ")
        table.insert(lines, string.format("#%s %s - %s", tostring(row.id), tostring(row.actor), tostring(row.action)))
    end

    return table.concat(lines)
end

function BF_MainPanel:buildOverviewStatusText()
    local guild = self.snapshot.guild
    local lines = {
        " <H2> ",
        getText("IGUI_BF_Block_Status"),
        " <LINE> ",
        " <TEXT> ",
        getText("IGUI_BF_GuildLine", guild.name),
        " <LINE> ",
        getText("IGUI_BF_OwnerLine", guild.owner),
        " <LINE> ",
        getText("IGUI_BF_MemberCapLine", tostring(guild.memberCount), tostring(guild.memberCap)),
        " <LINE> ",
        getText("IGUI_BF_TreasuryLine", tostring(guild.treasury.balance or 0)),
        " <LINE> ",
        getText("IGUI_BF_LifetimeContribLine", tostring(guild.treasury.lifetimeIn or 0)),
        " <LINE> ",
        getText("IGUI_BF_RenownLine", tostring(guild.progress.renown or 0)),
        " <LINE> ",
        getText("IGUI_BF_LevelLine", tostring(guild.progress.level or 1)),
    }
    return table.concat(lines)
end

function BF_MainPanel:buildOverviewBenefitsText()
    local snapshot = self.snapshot
    local guild = snapshot.guild
    local activeXP = guild.activeBenefits and guild.activeBenefits.xp or nil
    local activeSlayer = guild.activeBenefits and guild.activeBenefits.slayer or nil
    local lines = {
        " <H2> ",
        getText("IGUI_BF_ActiveBenefitsHeader"),
        " <LINE> ",
        " <TEXT> ",
    }

    if activeXP then
        local perk = BF.getXPBuffOption(activeXP.perkId)
        local perkLabel = perk and getText(perk.labelKey) or tostring(activeXP.perkId)
        table.insert(lines, getText("IGUI_BF_ActiveXPLine", perkLabel, tostring((activeXP.multiplier or 1) * 100), fmtTimeLeft(snapshot.serverTime, activeXP.expiresAt)))
    else
        table.insert(lines, getText("IGUI_BF_NoActiveXP"))
    end

    table.insert(lines, " <LINE> ")

    if activeSlayer then
        table.insert(lines, getText("IGUI_BF_ActiveSlayerLine", tostring(activeSlayer.renownBonus or 0), fmtTimeLeft(snapshot.serverTime, activeSlayer.expiresAt), tostring(activeSlayer.kills or 0)))
    else
        table.insert(lines, getText("IGUI_BF_NoActiveSlayer"))
    end

    return table.concat(lines)
end

function BF_MainPanel:buildOverviewAuditText()
    local guild = self.snapshot.guild
    local lines = {
        " <H2> ",
        getText("IGUI_BF_AuditHeader"),
        " <LINE> ",
        " <TEXT> ",
    }

    for _, row in ipairs(guild.auditTail or {}) do
        table.insert(lines, " <LINE> ")
        table.insert(lines, string.format("#%s %s - %s", tostring(row.id), tostring(row.actor), tostring(row.action)))
    end

    return table.concat(lines)
end

function BF_MainPanel:updateOverviewPanels()
    if not self.snapshot or not self.snapshot.guild then
        return
    end

    self.overviewPanels.status.text = self:buildOverviewStatusText()
    self.overviewPanels.status:paginate()

    self.overviewPanels.benefits.text = self:buildOverviewBenefitsText()
    self.overviewPanels.benefits:paginate()

    self.overviewPanels.audit.text = self:buildOverviewAuditText()
    self.overviewPanels.audit:paginate()
end

function BF_MainPanel:buildProgressText()
    local snapshot = self.snapshot
    local guild = snapshot.guild

    -- Section 1: guild rank
    local lines = {
        " <H2> ",
        getText("IGUI_BF_Section_Progress_Title"),
        " <LINE> ",
        " <TEXT> ",
        getText("IGUI_BF_LevelLine", tostring(guild.progress.level or 1)),
        " <LINE> ",
        getText("IGUI_BF_RenownLine", tostring(guild.progress.renown or 0)),
        " <LINE> ",
    }

    if guild.progress.nextLevelRenown then
        table.insert(lines, getText("IGUI_BF_NextLevelLine", tostring(guild.progress.nextLevelRenown)))
    else
        table.insert(lines, getText("IGUI_BF_MaxLevelLine"))
    end

    -- Section 2: upgrades, each entry separated by a blank line
    table.insert(lines, " <BR> ")
    table.insert(lines, " <H2> ")
    table.insert(lines, getText("IGUI_BF_UpgradeHeader"))

    for i, upgradeId in ipairs({ "hall", "scholarship", "warcamp" }) do
        local row = guild.upgrades[upgradeId]
        if i > 1 then
            table.insert(lines, " <BR> ")
        end
        -- Upgrade name + level as a sub-heading
        table.insert(lines, " <LINE> ")
        table.insert(lines, " <H2> ")
        table.insert(lines, getText(row.labelKey) .. "   " .. tostring(row.level) .. " / " .. tostring(row.maxLevel))
        -- Description and cost as normal text below the heading
        table.insert(lines, " <LINE> ")
        table.insert(lines, " <TEXT> ")
        table.insert(lines, getText(row.summaryKey))
        table.insert(lines, " <LINE> ")
        table.insert(lines, getText("IGUI_BF_UpgradeCostLine", tostring(row.cost), tostring(row.minLevel)))
    end

    return table.concat(lines)
end

function BF_MainPanel:buildTreasuryText()
    local snapshot = self.snapshot
    local guild = snapshot.guild
    local contributions = guild.contributions or {}
    local lines = {
        getText("IGUI_BF_TreasuryLine", tostring(guild.treasury.balance or 0)),
        " <LINE> ",
        getText("IGUI_BF_LifetimeContribLine", tostring(guild.treasury.lifetimeIn or 0)),
        " <LINE> ",
        getText("IGUI_BF_MoneyOnPerson", tostring(snapshot.player and snapshot.player.moneyOnPerson or 0)),
        " <BR> ",
        " <H2> ",
        getText("IGUI_BF_ContributionHeader"),
        " <LINE> ",
        " <TEXT> ",
    }

    for _, member in ipairs(guild.members or {}) do
        local row = contributions[member.username]
        local total = row and row.total or 0
        table.insert(lines, " <LINE> ")
        table.insert(lines, getText("IGUI_BF_ContributionLine", member.username, tostring(total)))
    end

    return table.concat(lines)
end

function BF_MainPanel:buildBenefitsText()
    local snapshot = self.snapshot
    local guild = snapshot.guild
    local xp = guild.activeBenefits and guild.activeBenefits.xp or nil
    local slayer = guild.activeBenefits and guild.activeBenefits.slayer or nil
    local lines = {
        " <H2> ",
        getText("IGUI_BF_BenefitsHeader"),
        " <LINE> ",
        " <TEXT> ",
        getText("IGUI_BF_XPBuffPurchaseLine", tostring(snapshot.config.xpBuffCost or 0), tostring(snapshot.config.xpBuffDurationMinutes or 0), tostring(snapshot.config.xpBuffMultiplierPercent or 100)),
        " <LINE> ",
        getText("IGUI_BF_SlayerPurchaseLine", tostring(snapshot.config.slayerFocusCost or 0), tostring(snapshot.config.slayerFocusDurationMinutes or 0), tostring(snapshot.config.slayerKillRenownBonus or 0)),
        " <BR> ",
    }

    if xp then
        local perk = BF.getXPBuffOption(xp.perkId)
        local perkLabel = perk and getText(perk.labelKey) or tostring(xp.perkId)
        table.insert(lines, getText("IGUI_BF_ActiveXPLine", perkLabel, tostring((xp.multiplier or 1) * 100), fmtTimeLeft(snapshot.serverTime, xp.expiresAt)))
    else
        table.insert(lines, getText("IGUI_BF_NoActiveXP"))
    end

    table.insert(lines, " <LINE> ")

    if slayer then
        table.insert(lines, getText("IGUI_BF_ActiveSlayerLine", tostring(slayer.renownBonus or 0), fmtTimeLeft(snapshot.serverTime, slayer.expiresAt), tostring(slayer.kills or 0)))
    else
        table.insert(lines, getText("IGUI_BF_NoActiveSlayer"))
    end

    table.insert(lines, " <BR> ")
    table.insert(lines, getText("IGUI_BF_TraitBoonLine", tostring(snapshot.config.traitBoonCost or 0)))

    return table.concat(lines)
end

function BF_MainPanel:buildMembersText()
    local snapshot = self.snapshot
    local lines = {
        " <H2> ",
        getText("IGUI_BF_MemberManagementHeader"),
        " <LINE> ",
        " <TEXT> ",
        getText("IGUI_BF_MemberManagementBody"),
        " <BR> ",
        getText("IGUI_BF_Role_Owner") .. ": " .. getText("IGUI_BF_RoleDesc_Owner"),
        " <LINE> ",
        getText("IGUI_BF_Role_Treasurer") .. ": " .. getText("IGUI_BF_RoleDesc_Treasurer"),
        " <LINE> ",
        getText("IGUI_BF_Role_Officer") .. ": " .. getText("IGUI_BF_RoleDesc_Officer"),
        " <LINE> ",
        getText("IGUI_BF_Role_Member") .. ": " .. getText("IGUI_BF_RoleDesc_Member"),
        " <LINE> <LINE> ",
        getText("IGUI_BF_NativeLinkLine", tostring((snapshot.nativeFaction and snapshot.nativeFaction.name) or "-")),
    }

    return table.concat(lines)
end

function BF_MainPanel:updateContentText()
    local useOverviewPanels = self.snapshot and self.snapshot.guild and self.activeTab == "overview"

    self.content:setVisible(not useOverviewPanels)
    self.overviewPanels.status:setVisible(useOverviewPanels == true)
    self.overviewPanels.benefits:setVisible(useOverviewPanels == true)
    self.overviewPanels.audit:setVisible(useOverviewPanels == true)

    if not self.snapshot or not self.snapshot.guild then
        self.content.text = self:buildNoGuildText()
        self.content:paginate()
        return
    end

    if useOverviewPanels then
        self:updateOverviewPanels()
        return
    end

    local text = ""
    if self.activeTab == "upgrades" then
        text = self:buildProgressText()
    elseif self.activeTab == "management" then
        text = self:buildManagementText()
    elseif self.activeTab == "benefits" then
        text = self:buildBenefitsText()
    elseif self.activeTab == "members" then
        text = self:buildMembersText()
    elseif self.activeTab == "ranking" then
        text = self:buildRankingText()
    elseif self.activeTab == "missions" then
        text = self:buildMissionsText()
    else
        text = self:buildOverviewText()
    end

    self.content.text = text
    self.content:paginate()
end

function BF_MainPanel:getVisibleActionButtons()
    local visible = {}
    for _, id in ipairs(ACTION_BUTTON_ORDER) do
        local button = self.bottomButtons[id]
        if button and button:getIsVisible() then
            table.insert(visible, button)
        end
    end
    return visible
end

function BF_MainPanel:layoutActionButtons()
    local visible = self:getVisibleActionButtons()
    if #visible == 0 then
        self.layout.actionRows = 0
        self.layout.actionBoxHeight = 0
        return
    end

    local cols = math.min(3, #visible)
    if #visible == 4 then
        cols = 2
    end

    local gap = 12
    local buttonWidth = math.floor((self.width - 40 - (gap * (cols - 1))) / cols)
    if cols == 1 then
        buttonWidth = math.min(360, buttonWidth)
    elseif cols == 2 then
        buttonWidth = math.min(300, buttonWidth)
    else
        buttonWidth = math.min(240, buttonWidth)
    end
    local startY = self.layout.actionY or (self.height - 108)
    local rows = math.ceil(#visible / cols)
    self.layout.actionRows = rows
    self.layout.actionBoxHeight = rows > 1 and 96 or 62

    for index, button in ipairs(visible) do
        local row = math.floor((index - 1) / cols)
        local col = (index - 1) % cols
        local rowCount = math.min(cols, #visible - (row * cols))
        local rowWidth = (rowCount * buttonWidth) + ((rowCount - 1) * gap)
        local rowStartX = math.floor((self.width - rowWidth) / 2)
        button:setX(rowStartX + (col * (buttonWidth + gap)))
        button:setY(startY + (row * 36))
        button:setWidth(buttonWidth)
        button:setHeight(30)
    end
end

function BF_MainPanel:updateTabStyles()
    for _, id in ipairs(TAB_IDS) do
        local button = self.tabButtons[id]
        applyButtonSkin(button, TAB_SKINS[id], id == self.activeTab)
    end
end

function BF_MainPanel:updateDynamicTooltips()
    local snapshot = self.snapshot or {}
    local config = snapshot.config or {}
    local player = snapshot.player or {}
    local guild = snapshot.guild or {}
    local upgrades = guild.upgrades or {}
    local hall = upgrades.hall or { level = 0, maxLevel = BF.UPGRADES.hall.maxLevel, cost = BF.getUpgradeCost("hall"), minLevel = BF.UPGRADES.hall.minLevel }
    local scholarship = upgrades.scholarship or { level = 0, maxLevel = BF.UPGRADES.scholarship.maxLevel, cost = BF.getUpgradeCost("scholarship"), minLevel = BF.UPGRADES.scholarship.minLevel }
    local warcamp = upgrades.warcamp or { level = 0, maxLevel = BF.UPGRADES.warcamp.maxLevel, cost = BF.getUpgradeCost("warcamp"), minLevel = BF.UPGRADES.warcamp.minLevel }
    local createCost = config.createCost or BF.getCreateCost()
    local hallBonus = config.hallUpgradeMemberBonus or BF.getHallUpgradeMemberBonus()
    local xpCost = config.xpBuffCost or BF.getXPBuffCost()
    local xpDuration = config.xpBuffDurationMinutes or (BF.getXPBuffDurationSeconds() / 60)
    local xpMultiplier = config.xpBuffMultiplierPercent or (BF.getXPBuffMultiplier() * 100)
    local slayerCost = config.slayerFocusCost or BF.getSlayerFocusCost()
    local slayerDuration = config.slayerFocusDurationMinutes or (BF.getSlayerFocusDurationSeconds() / 60)
    local slayerBonus = config.slayerKillRenownBonus or BF.getSlayerKillRenownBonus()
    local traitCost = config.traitBoonCost or BF.getTraitBoonCost()

    self.refreshButton:setTooltip(getText("IGUI_BF_Tooltip_Refresh"))
    self.createButton:setTooltip(getText("IGUI_BF_Tooltip_CreateGuild", moneyText(createCost)))
    self.nameEntry.tooltip = getText("IGUI_BF_Tooltip_GuildName")

    self.bottomButtons.deposit:setTooltip(getText("IGUI_BF_Tooltip_Deposit"))
    self.bottomButtons.contribute:setTooltip(getText("IGUI_BF_Tooltip_ContributeAll", moneyText(player.moneyOnPerson or 0)))
    self.bottomButtons.syncNative:setTooltip(getText("IGUI_BF_Tooltip_SyncNative"))
    self.bottomButtons.buyHall:setTooltip(getText("IGUI_BF_Tooltip_Upgrade_Hall", tostring(hall.level or 0), tostring(hall.maxLevel or 0), moneyText(hall.cost or 0), tostring(hallBonus)))
    self.bottomButtons.buyScholarship:setTooltip(getText("IGUI_BF_Tooltip_Upgrade_Scholarship", tostring(scholarship.level or 0), tostring(scholarship.maxLevel or 0), moneyText(scholarship.cost or 0), tostring(scholarship.minLevel or 0)))
    self.bottomButtons.buyWarcamp:setTooltip(getText("IGUI_BF_Tooltip_Upgrade_Warcamp", tostring(warcamp.level or 0), tostring(warcamp.maxLevel or 0), moneyText(warcamp.cost or 0), tostring(warcamp.minLevel or 0)))
    self.bottomButtons.xpWoodwork:setTooltip(getText("IGUI_BF_Tooltip_XPBuff_Carpentry", moneyText(xpCost), tostring(xpDuration), tostring(xpMultiplier)))
    self.bottomButtons.xpMechanics:setTooltip(getText("IGUI_BF_Tooltip_XPBuff_Mechanics", moneyText(xpCost), tostring(xpDuration), tostring(xpMultiplier)))
    self.bottomButtons.xpAiming:setTooltip(getText("IGUI_BF_Tooltip_XPBuff_Aiming", moneyText(xpCost), tostring(xpDuration), tostring(xpMultiplier)))
    self.bottomButtons.slayer:setTooltip(getText("IGUI_BF_Tooltip_Slayer", moneyText(slayerCost), tostring(slayerDuration), tostring(slayerBonus)))
    self.bottomButtons.memberToTreasurer:setTooltip(getText("IGUI_BF_Tooltip_PromoteTreasurer"))
    self.bottomButtons.memberToOfficer:setTooltip(getText("IGUI_BF_Tooltip_PromoteOfficer"))
    self.bottomButtons.memberToMember:setTooltip(getText("IGUI_BF_Tooltip_DemoteMember"))
    self.bottomButtons.memberRemove:setTooltip(getText("IGUI_BF_Tooltip_RemoveMember"))
    self.bottomButtons.trait:setTooltip(getText("IGUI_BF_Tooltip_TraitBoon", moneyText(traitCost)))
    self.bottomButtons.acceptInvite:setTooltip(getText("IGUI_BF_Tooltip_AcceptInvite"))
    self.bottomButtons.rejectInvite:setTooltip(getText("IGUI_BF_Tooltip_RejectInvite"))
    self.bottomButtons.cancelInvite:setTooltip(getText("IGUI_BF_Tooltip_CancelInvite"))
    self.bottomButtons.requestJoin:setTooltip(getText("IGUI_BF_Tooltip_RequestJoinGuild"))
    self.bottomButtons.browseGuilds:setTooltip(getText("IGUI_BF_Tooltip_ViewGuilds"))
    self.bottomButtons.deleteGuild:setTooltip(getText("IGUI_BF_Tooltip_DeleteGuild"))
    self.bottomButtons.payTax:setTooltip(getText("IGUI_BF_Tax_Header"))
    self.bottomButtons.setTax:setTooltip(getText("IGUI_BF_Tooltip_Tax_SetRate"))
    if self.sendInviteButton then
        self.sendInviteButton:setTooltip(getText("IGUI_BF_Tooltip_SendInvite"))
    end
end

function BF_MainPanel:updateActionOverlays()
    local snapshot = self.snapshot or {}
    local config = snapshot.config or {}
    local player = snapshot.player or {}
    local guild = snapshot.guild or {}
    local upgrades = guild.upgrades or {}

    self.createButton:setOverlayText(nil)
    self.bottomButtons.deposit:setOverlayText(nil)
    self.bottomButtons.contribute:setOverlayText(nil)
    self.bottomButtons.buyHall:setOverlayText(nil)
    self.bottomButtons.buyScholarship:setOverlayText(nil)
    self.bottomButtons.buyWarcamp:setOverlayText(nil)
    self.bottomButtons.syncNative:setOverlayText(nil)
    self.bottomButtons.xpWoodwork:setOverlayText(nil)
    self.bottomButtons.xpMechanics:setOverlayText(nil)
    self.bottomButtons.xpAiming:setOverlayText(nil)
    self.bottomButtons.slayer:setOverlayText(nil)
    self.bottomButtons.memberToTreasurer:setOverlayText(nil)
    self.bottomButtons.memberToOfficer:setOverlayText(nil)
    self.bottomButtons.memberToMember:setOverlayText(nil)
    self.bottomButtons.memberRemove:setOverlayText(nil)
    self.bottomButtons.trait:setOverlayText(nil)
    self.bottomButtons.acceptInvite:setOverlayText(nil)
    self.bottomButtons.rejectInvite:setOverlayText(nil)
    self.bottomButtons.cancelInvite:setOverlayText(nil)
    self.bottomButtons.requestJoin:setOverlayText(nil)
    self.bottomButtons.browseGuilds:setOverlayText(nil)
    self.bottomButtons.deleteGuild:setOverlayText(nil)
    self.bottomButtons.payTax:setOverlayText(nil)
    self.bottomButtons.setTax:setOverlayText(nil)
end

function BF_MainPanel:updateBottomButtons()
    for _, button in pairs(self.bottomButtons) do
        button:setVisible(false)
    end

    local snapshot = self.snapshot
    if not snapshot or not snapshot.guild then
        -- No guild: show browse button always; show invite action buttons based on selection
        self.bottomButtons.browseGuilds:setVisible(true)
        local selectedItem = self:getSelectedInviteItem()
        if selectedItem then
            if selectedItem.itemKind == "invite" then
                self.bottomButtons.acceptInvite:setVisible(true)
                self.bottomButtons.rejectInvite:setVisible(true)
            elseif selectedItem.itemKind == "joinRequest" then
                self.bottomButtons.cancelInvite:setVisible(true)
            elseif selectedItem.itemKind == "guildSlot" then
                self.bottomButtons.requestJoin:setVisible(true)
            end
        end
        self:layoutActionButtons()
        return
    end

    local perms = snapshot.player and snapshot.player.permissions or {}

    if self.activeTab == "upgrades" then
        self.bottomButtons.buyHall:setVisible(perms.buyUpgrades == true)
        self.bottomButtons.buyScholarship:setVisible(perms.buyUpgrades == true)
        self.bottomButtons.buyWarcamp:setVisible(perms.buyUpgrades == true)
    elseif self.activeTab == "management" then
        -- Treasury actions
        self.bottomButtons.deposit:setVisible(true)
        self.bottomButtons.contribute:setVisible(true)
        self.bottomButtons.syncNative:setVisible(perms.syncNative == true and snapshot.config.enableNativeFactionLink == true)
        -- Invite actions based on selection (read-only list review)
        local selectedItem = self:getSelectedInviteItem()
        if selectedItem then
            if selectedItem.itemKind == "invite" then
                self.bottomButtons.acceptInvite:setVisible(true)
                self.bottomButtons.rejectInvite:setVisible(true)
            elseif selectedItem.itemKind == "joinRequest" then
                self.bottomButtons.cancelInvite:setVisible(true)
            end
        end
        -- Tax: configure rate
        local hasTax = snapshot.guild and snapshot.guild.tax ~= nil
        if hasTax then
            self.bottomButtons.payTax:setVisible(true)
        end
        self.bottomButtons.setTax:setVisible(perms.setGuildTax == true)
        -- Delete guild (owner only)
        self.bottomButtons.deleteGuild:setVisible(perms.deleteGuild == true)
    elseif self.activeTab == "benefits" then
        self.bottomButtons.xpWoodwork:setVisible(perms.activateBenefits == true)
        self.bottomButtons.xpMechanics:setVisible(perms.activateBenefits == true)
        self.bottomButtons.xpAiming:setVisible(perms.activateBenefits == true)
        self.bottomButtons.slayer:setVisible(perms.activateBenefits == true)
        self.bottomButtons.trait:setVisible(true)
    elseif self.activeTab == "members" then
        self.bottomButtons.memberToTreasurer:setVisible(perms.manageRoles == true)
        self.bottomButtons.memberToOfficer:setVisible(perms.manageRoles == true)
        self.bottomButtons.memberToMember:setVisible(perms.manageRoles == true)
        self.bottomButtons.memberRemove:setVisible(perms.removeMembers == true)
        self.bottomButtons.syncNative:setVisible(perms.syncNative == true and snapshot.config.enableNativeFactionLink == true)
    end

    self:layoutActionButtons()
end

function BF_MainPanel:refreshFromSnapshot()
    local snapshot = self.snapshot
    local hasGuild = snapshot ~= nil and snapshot.guild ~= nil
    self:updateLayout(hasGuild)
    self:updateTabStyles()
    self:updateActionOverlays()
    self:updateDynamicTooltips()

    self.createNameLabel:setVisible(not hasGuild)
    self.nameEntry:setVisible(not hasGuild)
    self.createButton:setVisible(not hasGuild)

    local showInviteEntry = self.layout.showInviteEntry == true
    self.inviteTargetLabel:setVisible(showInviteEntry)
    self.inviteEntry:setVisible(showInviteEntry)
    self.sendInviteButton:setVisible(showInviteEntry)

    -- Contribute amount entry (management tab)
    local showContributeEntry = self.layout.showContributeEntry == true
    self.contributeAmountLabel:setVisible(showContributeEntry)
    self.contributeAmountEntry:setVisible(showContributeEntry)
    if showContributeEntry and self.snapshot and self.snapshot.player then
        local money = moneyText(self.snapshot.player.moneyOnPerson or 0)
        self.contributeAmountLabel.name = getText("IGUI_BF_DepositAmountLabel") .. " (" .. money .. getText("IGUI_BF_Available") .. ")"
    end

    -- Tax entry widgets: management tab for admins
    local showTaxEntry = self.layout.showTaxEntry == true
    self.taxAmountLabel:setVisible(showTaxEntry)
    self.taxAmountEntry:setVisible(showTaxEntry)
    self.taxDaysLabel:setVisible(showTaxEntry)
    self.taxDaysEntry:setVisible(showTaxEntry)

    -- Adjust member list item height: taller when tax is active (needs status tag line)
    local hasTax = hasGuild and self.snapshot and self.snapshot.guild and self.snapshot.guild.tax ~= nil
    self.memberList.itemheight = hasTax and 36 or 24

    for _, id in ipairs(TAB_IDS) do
        self.tabButtons[id]:setVisible(hasGuild)
        self.tabButtons[id].enable = true
    end

    local showInviteList = self.layout.showInviteList == true

    if not hasGuild then
        self.memberList:setVisible(false)
        self.inviteList:setVisible(showInviteList)
        if showInviteList then
            self:populateInviteList()
        else
            self.inviteList:clear()
        end
        self:updateContentText()
        self:updateBottomButtons()
        return
    end

    local showMemberList = hasGuild and self.activeTab == "members"
    self.memberList:setVisible(showMemberList)
    if showMemberList then
        self:populateMembers()
    else
        self.memberList:clear()
    end

    self.inviteList:setVisible(showInviteList)
    if showInviteList then
        self:populateInviteList()
    else
        self.inviteList:clear()
    end

    self:updateContentText()
    self:updateBottomButtons()
end

function BF_MainPanel:hasPendingInvites()
    local invites = self.snapshot and self.snapshot.pendingInvites or nil
    if not invites then return false end
    for _ in pairs(invites) do
        return true
    end
    return false
end

function BF_MainPanel:setGuildsWithSlots(guilds)
    self.guildsWithSlots = guilds
    self:refreshFromSnapshot()
end

function BF_MainPanel:getSelectedInviteItem()
    if not self.inviteList or self.inviteList.selected <= 0 then
        return nil
    end
    local row = self.inviteList.items[self.inviteList.selected]
    return row and row.item or nil
end

function BF_MainPanel:drawInviteItem(y, item, alt)
    local data = item.item
    if self.selected == item.index then
        self:drawRect(0, y, self:getWidth(), self.itemheight - 1, 0.34, THEME.ember.r, THEME.ember.g, THEME.ember.b)
    elseif alt then
        self:drawRect(0, y, self:getWidth(), self.itemheight - 1, 0.10, THEME.frame.r, THEME.frame.g, THEME.frame.b)
    end

    if data.itemKind == "invite" then
        self:drawText(safeText(data.guildName), 10, y + 4, THEME.paragraph.r, THEME.paragraph.g, THEME.paragraph.b, 0.98, UIFont.Small)
        self:drawText(getText("IGUI_BF_InviteFrom", safeText(data.inviterUsername)), 10, y + 18, THEME.paragraphDim.r, THEME.paragraphDim.g, THEME.paragraphDim.b, 0.85, UIFont.Small)
    elseif data.itemKind == "joinRequest" then
        self:drawText(safeText(data.guildName), 10, y + 4, THEME.paragraph.r, THEME.paragraph.g, THEME.paragraph.b, 0.98, UIFont.Small)
        self:drawText(getText("IGUI_BF_InviteTo", safeText(data.guildName)), 10, y + 18, THEME.paragraphDim.r, THEME.paragraphDim.g, THEME.paragraphDim.b, 0.85, UIFont.Small)
    elseif data.itemKind == "guildSlot" then
        self:drawText(safeText(data.name), 10, y + 4, THEME.paragraph.r, THEME.paragraph.g, THEME.paragraph.b, 0.98, UIFont.Small)
        self:drawText(tostring(data.memberCount or 0) .. "/" .. tostring(data.memberCap or 0), 10, y + 18, THEME.paragraphDim.r, THEME.paragraphDim.g, THEME.paragraphDim.b, 0.85, UIFont.Small)
    end

    return y + self.itemheight
end

function BF_MainPanel:populateInviteList()
    self.inviteList:clear()
    local hasGuild = self.snapshot and self.snapshot.guild ~= nil

    if self.snapshot and self.snapshot.pendingInvites then
        for inviteId, invite in pairs(self.snapshot.pendingInvites) do
            local kind = invite.type
            if kind == BF.Invites.TYPE.GUILD_TO_PLAYER then
                self.inviteList:addItem(tostring(invite.guildName or invite.guildId), {
                    itemKind = "invite",
                    inviteId = invite.id or inviteId,
                    guildName = invite.guildName or invite.guildId,
                    inviterUsername = invite.inviterUsername,
                })
            elseif kind == BF.Invites.TYPE.PLAYER_TO_GUILD then
                self.inviteList:addItem(tostring(invite.guildName or invite.guildId), {
                    itemKind = "joinRequest",
                    inviteId = invite.id or inviteId,
                    guildName = invite.guildName or invite.guildId,
                })
            end
        end
    end

    if not hasGuild and self.guildsWithSlots then
        for _, guild in ipairs(self.guildsWithSlots) do
            self.inviteList:addItem(tostring(guild.name), {
                itemKind = "guildSlot",
                guildId = guild.id,
                name = guild.name,
                memberCount = guild.memberCount,
                memberCap = guild.memberCap,
            })
        end
    end
end

function BF_MainPanel:buildManagementText()
    local snapshot = self.snapshot
    local guild = snapshot.guild
    local contributions = guild.contributions or {}

    -- Section 1: treasury
    local lines = {
        " <H2> ",
        getText("IGUI_BF_Section_Treasury_Title"),
        " <LINE> ",
        " <TEXT> ",
        getText("IGUI_BF_TreasuryLine", tostring(guild.treasury.balance or 0)),
        " <LINE> ",
        getText("IGUI_BF_LifetimeContribLine", tostring(guild.treasury.lifetimeIn or 0)),
        " <LINE> ",
        getText("IGUI_BF_MoneyOnPerson", tostring(snapshot.player and snapshot.player.moneyOnPerson or 0)),
        " <BR> ",
        " <H2> ",
        getText("IGUI_BF_ContributionHeader"),
        " <LINE> ",
        " <TEXT> ",
    }

    for _, member in ipairs(guild.members or {}) do
        local row = contributions[member.username]
        local total = row and row.total or 0
        table.insert(lines, " <LINE> ")
        table.insert(lines, getText("IGUI_BF_ContributionLine", member.username, tostring(total)))
    end

    -- Section 2: invitations summary
    table.insert(lines, " <BR> ")
    table.insert(lines, " <H2> ")
    table.insert(lines, getText("IGUI_BF_InvitesHeader"))
    table.insert(lines, " <LINE> ")
    table.insert(lines, " <TEXT> ")
    table.insert(lines, getText("IGUI_BF_Section_Invites_Hint"))

    return table.concat(lines)
end

function BF_MainPanel:buildInvitesText()
    local lines = {
        " <H2> ",
        getText("IGUI_BF_InvitesHeader"),
        " <LINE> ",
        " <TEXT> ",
        getText("IGUI_BF_InvitesReceivedHeader"),
        " <LINE> ",
    }

    local hasAny = false
    if self.snapshot and self.snapshot.pendingInvites then
        for _, invite in pairs(self.snapshot.pendingInvites) do
            if invite.type == BF.Invites.TYPE.GUILD_TO_PLAYER then
                table.insert(lines, getText("IGUI_BF_InviteFrom", safeText(invite.guildName or invite.guildId)))
                table.insert(lines, " <LINE> ")
                hasAny = true
            end
        end
    end
    if not hasAny then
        table.insert(lines, getText("IGUI_BF_NoInvitesReceived"))
        table.insert(lines, " <LINE> ")
    end

    table.insert(lines, " <BR> ")
    table.insert(lines, " <H2> ")
    table.insert(lines, getText("IGUI_BF_InvitesSentHeader"))
    table.insert(lines, " <LINE> ")
    table.insert(lines, " <TEXT> ")

    local hasSent = false
    if self.snapshot and self.snapshot.pendingInvites then
        for _, invite in pairs(self.snapshot.pendingInvites) do
            if invite.type == BF.Invites.TYPE.PLAYER_TO_GUILD then
                table.insert(lines, getText("IGUI_BF_InviteTo", safeText(invite.guildName or invite.guildId)))
                table.insert(lines, " <LINE> ")
                hasSent = true
            end
        end
    end
    if not hasSent then
        table.insert(lines, getText("IGUI_BF_NoInvitesSent"))
    end

    return table.concat(lines)
end

function BF_MainPanel:onSendInvite()
    local target = self.inviteEntry and self.inviteEntry:getText() or ""
    if target and target ~= "" then
        BF.Client.sendInvite(target)
        self.inviteEntry:setText("")
    end
end

function BF_MainPanel:onAcceptInvite()
    local item = self:getSelectedInviteItem()
    if item and item.inviteId then
        BF.Client.acceptInvite(item.inviteId)
    end
end

function BF_MainPanel:onRejectInvite()
    local item = self:getSelectedInviteItem()
    if item and item.inviteId then
        BF.Client.rejectInvite(item.inviteId)
    end
end

function BF_MainPanel:onCancelInvite()
    local item = self:getSelectedInviteItem()
    if item and item.inviteId then
        BF.Client.cancelInvite(item.inviteId)
    end
end

function BF_MainPanel:onRequestJoin()
    local item = self:getSelectedInviteItem()
    if item and item.guildId then
        BF.Client.requestJoinGuild(item.guildId)
    end
end

function BF_MainPanel:onBrowseGuilds()
    BF.Client.listGuildsWithSlots()
end

function BF_MainPanel:onDeleteGuild()
    BF.Client.deleteGuild()
end

function BF_MainPanel:onPayTax()
    BF.Client.payGuildTax()
end

function BF_MainPanel:onSetTax()
    local amount   = tonumber(self.taxAmountEntry and self.taxAmountEntry:getText()) or 0
    local interval = tonumber(self.taxDaysEntry and self.taxDaysEntry:getText()) or 0
    BF.Client.setGuildTax(amount, interval)
end

function BF_MainPanel:buildRankingText()
    local snapshot = self.snapshot
    local guild = snapshot.guild
    local contributions = guild.contributions or {}

    -- Member ranking: sort by contribution desc then kills desc
    local rows = {}
    for _, member in ipairs(guild.members or {}) do
        local contrib = contributions[member.username] and contributions[member.username].total or 0
        table.insert(rows, {
            username = member.username,
            contrib  = contrib,
            kills    = member.kills or 0,
        })
    end
    table.sort(rows, function(a, b)
        if a.contrib ~= b.contrib then return a.contrib > b.contrib end
        return a.kills > b.kills
    end)

    local lines = {
        " <H2> ",
        getText("IGUI_BF_Ranking_Members_Title"),
        " <LINE> ",
        " <TEXT> ",
        getText("IGUI_BF_Ranking_Header_Member") .. "   |   " ..
            getText("IGUI_BF_Ranking_Header_Contrib") .. "   |   " ..
            getText("IGUI_BF_Ranking_Header_Kills"),
        " <LINE> ",
        "-------------------------------",
    }

    for i, row in ipairs(rows) do
        table.insert(lines, " <LINE> ")
        table.insert(lines, string.format("#%d  %s   $%s   %s kills",
            i, row.username, tostring(row.contrib), tostring(row.kills)
        ))
    end

    -- Guild ranking (all guilds, from snapshot)
    local guildRanking = snapshot.guildRanking or {}
    table.insert(lines, " <BR> ")
    table.insert(lines, " <H2> ")
    table.insert(lines, getText("IGUI_BF_Ranking_Guilds_Title"))
    table.insert(lines, " <LINE> ")
    table.insert(lines, " <TEXT> ")
    table.insert(lines, getText("IGUI_BF_Ranking_GuildHeader_Name") .. "   |   " ..
        getText("IGUI_BF_Ranking_GuildHeader_Level") .. "   |   " ..
        getText("IGUI_BF_Ranking_GuildHeader_Members"))
    table.insert(lines, " <LINE> ")
    table.insert(lines, "-------------------------------")

    if #guildRanking == 0 then
        table.insert(lines, " <LINE> ")
        table.insert(lines, getText("IGUI_BF_Ranking_NoGuilds"))
    else
        for i, g in ipairs(guildRanking) do
            table.insert(lines, " <LINE> ")
            table.insert(lines, string.format("#%d  %s   %s pts   Lv%s   %s/%s mbr",
                i, tostring(g.name), tostring(g.points),
                tostring(g.level), tostring(g.memberCount), tostring(g.memberCap)
            ))
        end
    end

    return table.concat(lines)
end

function BF_MainPanel:buildMissionsText()
    local lines = {
        " <H2> ",
        getText("IGUI_BF_Section_Missions_Title"),
        " <LINE> ",
        " <TEXT> ",
        getText("IGUI_BF_Missions_ComingSoon"),
    }
    return table.concat(lines)
end
