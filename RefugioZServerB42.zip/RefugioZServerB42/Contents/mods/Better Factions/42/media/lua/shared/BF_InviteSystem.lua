-- Better Factions: Invite System (Shared)
-- Sistema de convites para guilds

BF = BF or {}
BF.Invites = BF.Invites or {}

-- Constantes
BF.Invites.EXPIRE_TIME_SECONDS = 86400  -- 1 dia = 24h * 60m * 60s
BF.Invites.MAX_PENDING_PER_PLAYER = 5   -- Máximo de convites pendentes por jogador

-- Tipos de invite
BF.Invites.TYPE = {
    GUILD_TO_PLAYER = "guild_to_player",  -- Guild convida jogador
    PLAYER_TO_GUILD = "player_to_guild",  -- Jogador pede para entrar
}

-- Status de invite
BF.Invites.STATUS = {
    PENDING = "pending",
    ACCEPTED = "accepted",
    REJECTED = "rejected",
    EXPIRED = "expired",
    CANCELLED = "cancelled",
}

-- Criar estrutura de invite
function BF.Invites.create(guildId, guildName, playerUsername, inviterUsername, inviteType, timestamp)
    return {
        id = nil,  -- será gerado pelo servidor
        guildId = guildId,
        guildName = guildName,
        playerUsername = playerUsername,
        inviterUsername = inviterUsername,
        type = inviteType,
        status = BF.Invites.STATUS.PENDING,
        createdAt = timestamp or (getTimestamp and getTimestamp() or 0),
        expiresAt = (timestamp or (getTimestamp and getTimestamp() or 0)) + BF.Invites.EXPIRE_TIME_SECONDS,
    }
end

-- Verificar se convite expirou
function BF.Invites.isExpired(invite, currentTime)
    if not invite or invite.status ~= BF.Invites.STATUS.PENDING then
        return false
    end
    return (currentTime or (getTimestamp and getTimestamp() or 0)) >= invite.expiresAt
end

-- Verificar se convite está ativo
function BF.Invites.isActive(invite, currentTime)
    if not invite or invite.status ~= BF.Invites.STATUS.PENDING then
        return false
    end
    return not BF.Invites.isExpired(invite, currentTime)
end

-- Obter tempo restante em segundos
function BF.Invites.getTimeRemaining(invite, currentTime)
    if not BF.Invites.isActive(invite, currentTime) then
        return 0
    end
    return math.max(0, invite.expiresAt - (currentTime or (getTimestamp and getTimestamp() or 0)))
end

-- Formatar tempo restante para display
function BF.Invites.formatTimeRemaining(seconds)
    if seconds <= 0 then
        return getText("IGUI_BF_Invite_Expired")
    end
    
    local hours = math.floor(seconds / 3600)
    local minutes = math.floor((seconds % 3600) / 60)
    
    if hours > 0 then
        return getText("IGUI_BF_Invite_TimeHours", tostring(hours), tostring(minutes))
    else
        return getText("IGUI_BF_Invite_TimeMinutes", tostring(minutes))
    end
end
