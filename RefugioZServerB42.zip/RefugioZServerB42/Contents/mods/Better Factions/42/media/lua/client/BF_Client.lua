if isServer() and not isClient() then
    return
end

require "BF_Shared"
require "UI/BF_MainPanel"

BF = BF or {}
BF.Client = BF.Client or {}

local Client = BF.Client

Client.snapshot = nil
Client.panel = nil
Client.initialized = false
Client.guildsWithSlots = nil  -- Lista de guilds com vagas

local function getLocalPlayer()
    return getSpecificPlayer(0) or getPlayer()
end

function Client.send(command, args)
    local playerObj = getLocalPlayer()
    if not playerObj then
        return
    end
    sendClientCommand(playerObj, BF.MODULE, command, args or {})
end

function Client.requestSnapshot()
    Client.send("requestSnapshot", {})
end

function Client.translate(textKey, args)
    if not args or #args == 0 then
        return getText(textKey)
    end
    return getText(textKey, unpack(args))
end

function Client.showNotify(textKey, args, r, g, b)
    local playerObj = getLocalPlayer()
    if not playerObj then
        return
    end
    playerObj:setHaloNote(Client.translate(textKey, args), r or 1, g or 1, b or 1, 220)
end

function Client.onServerCommand(module, command, args)
    if module ~= BF.MODULE then
        return
    end

    if command == "snapshot" then
        Client.snapshot = args
        if Client.panel and Client.panel.setSnapshot then
            Client.panel:setSnapshot(args)
        end
    elseif command == "notify" then
        Client.showNotify(args.textKey, args.args or {}, args.r, args.g, args.b)
        if Client.panel and Client.panel.addFlashMessage then
            Client.panel:addFlashMessage(Client.translate(args.textKey, args.args or {}))
        end
    elseif command == "guildsWithSlots" then
        -- Recebeu lista de guilds com vagas
        Client.guildsWithSlots = args.guilds or {}
        if Client.panel and Client.panel.setGuildsWithSlots then
            Client.panel:setGuildsWithSlots(Client.guildsWithSlots)
        end
    end
end

function Client.ensurePanel()
    if Client.panel then
        return Client.panel
    end

    local core = getCore()
    local screenWidth = core and core:getScreenWidth() or 1280
    local screenHeight = core and core:getScreenHeight() or 720
    local width = math.min(1140, math.max(920, screenWidth - 90))
    local height = math.min(760, math.max(640, screenHeight - 90))
    local x = math.floor((screenWidth - width) / 2)
    local y = math.floor((screenHeight - height) / 2)

    local panel = BF_MainPanel:new(x, y, width, height, getLocalPlayer())
    panel:initialise()
    panel:instantiate()
    panel:addToUIManager()
    panel:setVisible(false)
    Client.panel = panel
    return panel
end

function Client.openPanel()
    local panel = Client.ensurePanel()
    if not panel:getIsVisible() then
        panel:setVisible(true)
        panel:addToUIManager()
    end
    panel:bringToTop()
    if Client.snapshot then
        panel:setSnapshot(Client.snapshot)
    end
    Client.requestSnapshot()
end

function Client.createGuild(name)
    Client.send("createGuild", { name = name })
end

function Client.contributeAllCash()
    Client.send("contributeAllCash", {})
end

function Client.contributeAmount(amount)
    Client.send("contributeAmount", { amount = amount })
end

function Client.buyUpgrade(upgradeId)
    Client.send("buyUpgrade", { upgradeId = upgradeId })
end

function Client.activateXPBuff(perkId)
    Client.send("activateXPBuff", { perkId = perkId })
end

function Client.activateSlayerFocus()
    Client.send("activateSlayerFocus", {})
end

function Client.syncNativeFaction()
    Client.send("syncNativeFaction", {})
end

function Client.setMemberRole(username, role)
    Client.send("setMemberRole", { username = username, role = role })
end

function Client.removeMember(username)
    Client.send("removeMember", { username = username })
end

function Client.requestTraitBoon()
    Client.send("requestTraitBoon", {})
end

-- Sistema de Convites

function Client.sendInvite(username)
    Client.send("sendInvite", { username = username })
end

function Client.requestJoinGuild(guildId)
    Client.send("requestJoinGuild", { guildId = guildId })
end

function Client.acceptInvite(inviteId)
    Client.send("acceptInvite", { inviteId = inviteId })
end

function Client.rejectInvite(inviteId)
    Client.send("rejectInvite", { inviteId = inviteId })
end

function Client.cancelInvite(inviteId)
    Client.send("cancelInvite", { inviteId = inviteId })
end

function Client.listGuildsWithSlots()
    Client.send("listGuildsWithSlots", {})
end

function Client.deleteGuild()
    Client.send("deleteGuild", {})
end

function Client.setGuildTax(amount, interval)
    Client.send("setGuildTax", { amount = amount, interval = interval })
end

function Client.payGuildTax()
    Client.send("payGuildTax", {})
end

local function addContextOption(playerIndex, context, worldObjects, test)
    if test then
        return true
    end
    local playerObj = getSpecificPlayer(playerIndex)
    if not playerObj or not context then
        return
    end

    local onOpen = function()
        Client.openPanel()
    end
    context:addOption(getText("ContextMenu_BF_OpenPanel"), onOpen, onOpen)
end

local function onCreatePlayer(playerIndex, playerObj)
    if playerIndex ~= 0 or not playerObj or Client.initialized then
        return
    end
    Client.initialized = true
    Events.OnServerCommand.Add(Client.onServerCommand)
    Client.requestSnapshot()
end

Events.OnCreatePlayer.Add(onCreatePlayer)
Events.OnPreFillWorldObjectContextMenu.Add(addContextOption)
