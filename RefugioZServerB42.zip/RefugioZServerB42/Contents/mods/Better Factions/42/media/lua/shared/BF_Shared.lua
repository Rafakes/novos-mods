BF = BF or {}
BF.UI = BF.UI or {}

BF.VERSION = 1
BF.MODULE = "BetterFactions"
BF.STATE_KEY = "BetterFactions_State"

BF.CURRENCY_VALUES = {
    ["Base.Money"] = 1,
    ["Base.MoneyBundle"] = 100,
}

BF.ROLE_ORDER = { "owner", "treasurer", "officer", "member" }
BF.ROLE_RANK = {
    owner = 1,
    treasurer = 2,
    officer = 3,
    member = 4,
}

BF.PERMISSIONS_BY_ROLE = {
    owner = {
        manageRoles = true,
        manageTreasury = true,
        buyUpgrades = true,
        activateBenefits = true,
        removeMembers = true,
        syncNative = true,
        buyTraitBoon = true,
        inviteMembers = true,
        manageInvites = true,
        deleteGuild = true,
        setGuildTax = true,
    },
    treasurer = {
        manageTreasury = true,
        buyUpgrades = true,
        activateBenefits = true,
        inviteMembers = true,
        setGuildTax = true,
    },
    officer = {
        inviteMembers = true,  -- NOVO: oficiais também podem convidar
    },
    member = {},
}

BF.UPGRADES = {
    hall = {
        id = "hall",
        labelKey = "IGUI_BF_Upgrade_Hall",
        summaryKey = "IGUI_BF_Upgrade_Hall_Summary",
        costOption = "HallUpgradeCost",
        maxLevel = 4,
        minLevel = 1,
    },
    scholarship = {
        id = "scholarship",
        labelKey = "IGUI_BF_Upgrade_Scholarship",
        summaryKey = "IGUI_BF_Upgrade_Scholarship_Summary",
        costOption = "ScholarshipUpgradeCost",
        maxLevel = 1,
        minLevel = 2,
    },
    warcamp = {
        id = "warcamp",
        labelKey = "IGUI_BF_Upgrade_Warcamp",
        summaryKey = "IGUI_BF_Upgrade_Warcamp_Summary",
        costOption = "WarcampUpgradeCost",
        maxLevel = 1,
        minLevel = 3,
    },
}

BF.XP_BUFF_OPTIONS = {
    { id = "Woodwork", labelKey = "IGUI_BF_Perk_Woodwork" },
    { id = "Mechanics", labelKey = "IGUI_BF_Perk_Mechanics" },
    { id = "Aiming", labelKey = "IGUI_BF_Perk_Aiming" },
}

BF.LEVEL_THRESHOLDS = {
    0,
    1000,
    5000,
    12000,
    25000,
    50000,
}

function BF.trimString(value)
    if type(value) ~= "string" then
        return nil
    end
    local trimmed = value:match("^%s*(.-)%s*$")
    if trimmed == "" then
        return nil
    end
    return trimmed
end

function BF.normalizeGuildName(value)
    local trimmed = BF.trimString(value)
    if not trimmed then
        return nil
    end
    if #trimmed < 3 or #trimmed > 32 then
        return nil
    end
    return trimmed
end

function BF.deepCopy(value)
    if type(value) ~= "table" then
        return value
    end
    local copy = {}
    for k, v in pairs(value) do
        copy[k] = BF.deepCopy(v)
    end
    return copy
end

function BF.shallowCopy(value)
    if type(value) ~= "table" then
        return value
    end
    local copy = {}
    for k, v in pairs(value) do
        copy[k] = v
    end
    return copy
end

function BF.clamp(value, minValue, maxValue)
    if value < minValue then
        return minValue
    end
    if value > maxValue then
        return maxValue
    end
    return value
end

function BF.floor(value)
    return math.floor((tonumber(value) or 0) + 0.00001)
end

function BF.getSandboxValue(key, defaultValue)
    local root = SandboxVars and SandboxVars.BetterFactions
    if root and root[key] ~= nil then
        return root[key]
    end
    return defaultValue
end

function BF.getCreateCost()
    return BF.floor(BF.getSandboxValue("GuildCreateCost", 500))
end

function BF.getUpgradeCost(upgradeId)
    local upgrade = BF.UPGRADES[upgradeId]
    if not upgrade then
        return 0
    end
    return BF.floor(BF.getSandboxValue(upgrade.costOption, 0))
end

function BF.getXPBuffCost()
    return BF.floor(BF.getSandboxValue("XPBuffCost", 2500))
end

function BF.getXPBuffMultiplier()
    return BF.floor(BF.getSandboxValue("XPBuffMultiplierPercent", 150)) / 100
end

function BF.getXPBuffDurationSeconds()
    return BF.floor(BF.getSandboxValue("XPBuffDurationMinutes", 60)) * 60
end

function BF.getSlayerFocusCost()
    return BF.floor(BF.getSandboxValue("SlayerFocusCost", 3000))
end

function BF.getSlayerFocusDurationSeconds()
    return BF.floor(BF.getSandboxValue("SlayerFocusDurationMinutes", 60)) * 60
end

function BF.getSlayerKillRenownBonus()
    return BF.floor(BF.getSandboxValue("SlayerKillRenownBonus", 3))
end

function BF.getTraitBoonCost()
    return BF.floor(BF.getSandboxValue("TraitBoonCost", 20000))
end

function BF.isTraitBoonEnabled()
    return BF.getSandboxValue("AllowTraitBoons", false) == true
end

function BF.isNativeFactionLinkEnabled()
    return BF.getSandboxValue("EnableNativeFactionLink", false) == true
end

function BF.getBaseMemberCap()
    return BF.floor(BF.getSandboxValue("BaseMemberCap", 8))
end

function BF.getHardMemberCap()
    return BF.floor(BF.getSandboxValue("MaxMemberCap", 16))
end

function BF.getHallUpgradeMemberBonus()
    return BF.floor(BF.getSandboxValue("HallUpgradeMemberBonus", 2))
end

function BF.getMemberCapForGuild(guild)
    local baseCap = BF.getBaseMemberCap()
    local upgradeBonus = BF.getHallUpgradeMemberBonus() * ((guild and guild.upgrades and guild.upgrades.hall) or 0)
    return math.min(BF.getHardMemberCap(), baseCap + upgradeBonus)
end

function BF.getLevelInfo(renown)
    renown = BF.floor(renown or 0)
    local thresholds = BF.LEVEL_THRESHOLDS
    local level = 1
    local nextLevelRenown = nil
    local currentFloor = thresholds[1] or 0

    for i = 1, #thresholds do
        if renown >= thresholds[i] then
            level = i
            currentFloor = thresholds[i]
            nextLevelRenown = thresholds[i + 1]
        else
            nextLevelRenown = thresholds[i]
            break
        end
    end

    if renown >= thresholds[#thresholds] then
        level = #thresholds
        currentFloor = thresholds[#thresholds]
        nextLevelRenown = nil
    end

    return {
        level = level,
        currentFloor = currentFloor,
        nextLevelRenown = nextLevelRenown,
    }
end

function BF.getXPBuffOption(perkId)
    for _, entry in ipairs(BF.XP_BUFF_OPTIONS) do
        if entry.id == perkId then
            return entry
        end
    end
    return nil
end

function BF.getRoleLabelKey(role)
    if role == "owner" then
        return "IGUI_BF_Role_Owner"
    elseif role == "treasurer" then
        return "IGUI_BF_Role_Treasurer"
    elseif role == "officer" then
        return "IGUI_BF_Role_Officer"
    end
    return "IGUI_BF_Role_Member"
end

function BF.getSortedMembers(guild)
    local members = {}
    if not guild or type(guild.members) ~= "table" then
        return members
    end

    for username, memberData in pairs(guild.members) do
        table.insert(members, {
            username = username,
            role = memberData.role or "member",
            joinedAt = memberData.joinedAt or 0,
            kills = memberData.kills or 0,
            taxPaidAt = memberData.taxPaidAt or nil,
        })
    end

    table.sort(members, function(a, b)
        local rankA = BF.ROLE_RANK[a.role or "member"] or 99
        local rankB = BF.ROLE_RANK[b.role or "member"] or 99
        if rankA ~= rankB then
            return rankA < rankB
        end
        return string.lower(a.username) < string.lower(b.username)
    end)

    return members
end

function BF.hasPermission(role, permission)
    local row = BF.PERMISSIONS_BY_ROLE[role or "member"]
    return row and row[permission] == true
end

function BF.buildPermissionMap(role)
    local map = {}
    for permissionName, _ in pairs(BF.PERMISSIONS_BY_ROLE.owner) do
        map[permissionName] = BF.hasPermission(role, permissionName)
    end
    return map
end

-- Carregar sistema de convites
require "BF_InviteSystem"
