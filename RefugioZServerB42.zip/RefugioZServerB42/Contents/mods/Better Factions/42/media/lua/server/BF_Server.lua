if not isServer() then
    return
end

require "BF_Shared"

BF = BF or {}
BF.Server = BF.Server or {}

local Server = BF.Server

Server.runtime = Server.runtime or {
    rateLimit = {},
}

local AUDIT_FILE = "/BetterFactions/audit.log"
local AUDIT_TAIL_MAX = 25

local function now()
    if getTimestamp then
        return getTimestamp()
    end
    if os and os.time then
        return os.time()
    end
    return 0
end

local function nowReadable()
    if os and os.date then
        return os.date("%Y-%m-%d %H:%M:%S")
    end
    return tostring(now())
end

local function writeAuditLine(line)
    local ok, writer = pcall(getFileWriter, AUDIT_FILE, true, true)
    if ok and writer then
        pcall(writer.write, writer, line)
        pcall(writer.write, writer, "\r\n")
        pcall(writer.close, writer)
    else
        print("[BetterFactions][ERROR] Failed to open audit log: " .. tostring(writer))
    end
    print("[BetterFactions] " .. line)
end

function Server.getState()
    if type(BF.state) ~= "table" then
        BF.state = ModData.getOrCreate(BF.STATE_KEY)
    end
    if type(BF.state) ~= "table" then
        BF.state = {}
    end
    BF.state.meta = BF.state.meta or {}
    BF.state.meta.version = BF.VERSION
    BF.state.meta.nextGuildId = BF.state.meta.nextGuildId or 1
    BF.state.meta.lastAuditId = BF.state.meta.lastAuditId or 0
    BF.state.guilds = BF.state.guilds or {}
    BF.state.playerIndex = BF.state.playerIndex or {}
    
    -- Inicializar sistema de convites
    BF.Server.Invites.initState(BF.state)
    
    return BF.state
end

function Server.persist()
    Server.getState()
    ModData.add(BF.STATE_KEY, BF.state)
end

local function safeUsername(playerObj)
    if not playerObj then
        return nil
    end
    local ok, username = pcall(function()
        return playerObj:getUsername()
    end)
    if ok then
        return username
    end
    return nil
end

function Server.forEachOnlinePlayer(callback)
    local players = getOnlinePlayers()
    if not players then
        return
    end

    if type(players) == "table" then
        for _, playerObj in ipairs(players) do
            if playerObj then
                callback(playerObj)
            end
        end
        return
    end

    if players.size and players.get then
        for i = 0, players:size() - 1 do
            local playerObj = players:get(i)
            if playerObj then
                callback(playerObj)
            end
        end
    end
end

function Server.findOnlinePlayer(username)
    local match = nil
    Server.forEachOnlinePlayer(function(playerObj)
        if not match and safeUsername(playerObj) == username then
            match = playerObj
        end
    end)
    return match
end

function Server.getGuildById(guildId)
    return Server.getState().guilds[guildId]
end

function Server.getGuildIdByPlayer(username)
    return Server.getState().playerIndex[username]
end

function Server.getGuildByPlayer(username)
    local guildId = Server.getGuildIdByPlayer(username)
    if not guildId then
        return nil
    end
    return Server.getGuildById(guildId)
end

function Server.getMemberRole(guild, username)
    if not guild or type(guild.members) ~= "table" then
        return nil
    end
    local entry = guild.members[username]
    return entry and entry.role or nil
end

function Server.countMembers(guild)
    local count = 0
    if guild and type(guild.members) == "table" then
        for _, _ in pairs(guild.members) do
            count = count + 1
        end
    end
    return count
end

function Server.updateGuildLevel(guild)
    guild.progress = guild.progress or {}
    local info = BF.getLevelInfo(guild.progress.renown or 0)
    guild.progress.level = info.level
    guild.progress.levelFloor = info.currentFloor
    guild.progress.nextLevelRenown = info.nextLevelRenown
end

function Server.appendAudit(guild, actor, action, details)
    local state = Server.getState()
    state.meta.lastAuditId = (state.meta.lastAuditId or 0) + 1

    local entry = {
        id = state.meta.lastAuditId,
        at = now(),
        actor = actor or "SERVER",
        action = action,
        details = details or "",
    }

    if guild then
        guild.auditTail = guild.auditTail or {}
        table.insert(guild.auditTail, entry)
        while #guild.auditTail > AUDIT_TAIL_MAX do
            table.remove(guild.auditTail, 1)
        end
    end

    local guildLabel = guild and ("guild=" .. tostring(guild.id) .. ":" .. tostring(guild.name)) or "guild=none"
    local line = string.format("[%s] #%s %s actor=%s action=%s details=%s",
        nowReadable(),
        tostring(entry.id),
        guildLabel,
        tostring(entry.actor),
        tostring(action),
        tostring(entry.details))
    writeAuditLine(line)
end

function Server.sendNotify(playerObj, textKey, r, g, b, args)
    if not playerObj then
        return
    end
    sendServerCommand(playerObj, BF.MODULE, "notify", {
        textKey = textKey,
        r = r or 1,
        g = g or 1,
        b = b or 1,
        args = args,
    })
end

local function lowerText(value)
    return string.lower(tostring(value or ""))
end

function Server.guildNameExists(name)
    local state = Server.getState()
    local needle = lowerText(name)
    for _, guild in pairs(state.guilds) do
        if lowerText(guild.name) == needle then
            return true
        end
    end
    return false
end

function Server.ensureMemberEntry(guild, username, role)
    guild.members = guild.members or {}
    if not guild.members[username] then
        guild.members[username] = {
            role = role or "member",
            joinedAt = now(),
        }
    else
        guild.members[username].role = guild.members[username].role or role or "member"
        guild.members[username].joinedAt = guild.members[username].joinedAt or now()
    end
end

function Server.addPlayerToGuild(guild, username, role)
    local state = Server.getState()
    if state.playerIndex[username] and state.playerIndex[username] ~= guild.id then
        return false, "busy"
    end
    if not guild.members[username] and Server.countMembers(guild) >= BF.getMemberCapForGuild(guild) then
        return false, "cap"
    end
    Server.ensureMemberEntry(guild, username, role)
    state.playerIndex[username] = guild.id
    return true
end

function Server.removePlayerFromGuild(guild, username)
    local state = Server.getState()
    if guild and guild.members then
        guild.members[username] = nil
    end
    if state.playerIndex[username] == guild.id then
        state.playerIndex[username] = nil
    end
end

function Server.collectCurrencyItems(container, out)
    if not container then
        return
    end
    local items = container:getItems()
    if not items then
        return
    end

    for i = 0, items:size() - 1 do
        local item = items:get(i)
        if item then
            local fullType = item:getFullType()
            local value = BF.CURRENCY_VALUES[fullType]
            if value then
                table.insert(out, {
                    container = container,
                    item = item,
                    value = value,
                    fullType = fullType,
                })
            end

            local inner = item.getItemContainer and item:getItemContainer() or nil
            if inner then
                Server.collectCurrencyItems(inner, out)
            end
        end
    end
end

function Server.getPlayerCurrencySummary(playerObj)
    local entries = {}
    Server.collectCurrencyItems(playerObj and playerObj:getInventory() or nil, entries)

    local summary = {
        total = 0,
        singles = {},
        bundles = {},
    }

    for _, entry in ipairs(entries) do
        summary.total = summary.total + entry.value
        if entry.value == 100 then
            table.insert(summary.bundles, entry)
        else
            table.insert(summary.singles, entry)
        end
    end

    return summary
end

function Server.planCurrencyRemoval(playerObj, amount)
    amount = BF.floor(amount or 0)
    if amount <= 0 then
        return nil, "amount"
    end

    local summary = Server.getPlayerCurrencySummary(playerObj)
    if summary.total < amount then
        return nil, "notenough"
    end

    local maxBundles = math.min(#summary.bundles, math.floor(amount / 100))
    for bundlesToTake = maxBundles, 0, -1 do
        local remainder = amount - (bundlesToTake * 100)
        if remainder <= #summary.singles then
            local plan = {}
            for i = 1, bundlesToTake do
                table.insert(plan, summary.bundles[i])
            end
            for i = 1, remainder do
                table.insert(plan, summary.singles[i])
            end
            return plan
        end
    end

    return nil, "exact"
end

function Server.removeCurrencyPlan(plan)
    for _, entry in ipairs(plan or {}) do
        local container = entry.container or (entry.item and entry.item:getContainer()) or nil
        if container and entry.item then
            container:Remove(entry.item)
            if sendRemoveItemFromContainer then
                sendRemoveItemFromContainer(container, entry.item)
            end
        end
    end
end

function Server.consumePlayerCurrency(playerObj, amount)
    local plan, err = Server.planCurrencyRemoval(playerObj, amount)
    if not plan then
        return false, err
    end
    Server.removeCurrencyPlan(plan)
    return true
end

function Server.getNativeFactionInfo(username)
    local info = {
        enabled = BF.isNativeFactionLinkEnabled(),
        name = nil,
        owner = nil,
        isOwner = false,
        memberCount = 0,
    }

    local ok, faction = pcall(function()
        return Faction.getPlayerFaction(username)
    end)
    if not ok or not faction then
        return info
    end

    info.name = faction:getName()
    info.owner = faction:getOwner()
    info.isOwner = faction:getOwner() == username

    local seen = {}
    if info.owner then
        seen[info.owner] = true
        info.memberCount = 1
    end

    local players = faction:getPlayers()
    if players then
        for i = 0, players:size() - 1 do
            local memberName = players:get(i)
            if memberName and not seen[memberName] then
                seen[memberName] = true
                info.memberCount = info.memberCount + 1
            end
        end
    end

    return info
end

function Server.importMembersFromNativeFaction(guild, ownerUsername)
    if not BF.isNativeFactionLinkEnabled() then
        return false, "disabled"
    end

    local ok, faction = pcall(function()
        return Faction.getPlayerFaction(ownerUsername)
    end)
    if not ok or not faction then
        return false, "nofaction"
    end
    if faction:getOwner() ~= ownerUsername then
        return false, "notowner"
    end

    local imported = 0
    local state = Server.getState()
    local seen = {}

    local function tryAdd(username, role)
        if not username or seen[username] then
            return
        end
        seen[username] = true
        if state.playerIndex[username] and state.playerIndex[username] ~= guild.id then
            return
        end
        if guild.members[username] then
            return
        end
        if Server.countMembers(guild) >= BF.getMemberCapForGuild(guild) then
            return
        end
        if Server.addPlayerToGuild(guild, username, role) then
            imported = imported + 1
        end
    end

    tryAdd(ownerUsername, "owner")

    local players = faction:getPlayers()
    if players then
        for i = 0, players:size() - 1 do
            tryAdd(players:get(i), "member")
        end
    end

    guild.nativeFactionName = faction:getName()
    return true, imported
end

function Server.applyXpMultiplier(playerObj, perkId, multiplier)
    local ok, perk = pcall(function()
        return Perks.FromString(perkId)
    end)
    if not ok or not perk then
        return false
    end

    local desiredMultiplier = tonumber(multiplier) or 1
    pcall(function()
        GameServer.addXpMultiplier(playerObj, perk, desiredMultiplier, 0, 10)
    end)
    return true
end

function Server.reapplyPlayerBenefits(playerObj, guild)
    if not playerObj or not guild then
        return
    end

    local currentTime = now()
    local xp = guild.activeBenefits and guild.activeBenefits.xp or nil
    if xp and xp.expiresAt and xp.expiresAt > currentTime and xp.perkId then
        Server.applyXpMultiplier(playerObj, xp.perkId, xp.multiplier or BF.getXPBuffMultiplier())
    end
end

function Server.buildEnrichedInvites(username)
    local state = Server.getState()
    local raw = BF.Server.Invites.getInvitesForPlayer(username)
    local result = {}
    for inviteId, invite in pairs(raw) do
        local enriched = BF.deepCopy(invite)
        if invite.guildId and state.guilds[invite.guildId] then
            enriched.guildName = state.guilds[invite.guildId].name
        end
        result[inviteId] = enriched
    end
    return result
end

function Server.sendSnapshot(playerObj)
    if not playerObj then
        return
    end

    local username = safeUsername(playerObj)
    local guild = Server.getGuildByPlayer(username)
    local role = guild and Server.getMemberRole(guild, username) or nil
    local levelInfo = guild and BF.getLevelInfo(guild.progress and guild.progress.renown or 0) or nil
    local nativeInfo = Server.getNativeFactionInfo(username)
    local currency = Server.getPlayerCurrencySummary(playerObj)

    local snapshot = {
        serverTime = now(),
        config = {
            createCost = BF.getCreateCost(),
            baseMemberCap = BF.getBaseMemberCap(),
            hardMemberCap = BF.getHardMemberCap(),
            hallUpgradeMemberBonus = BF.getHallUpgradeMemberBonus(),
            xpBuffCost = BF.getXPBuffCost(),
            xpBuffDurationMinutes = BF.getXPBuffDurationSeconds() / 60,
            xpBuffMultiplierPercent = BF.getXPBuffMultiplier() * 100,
            slayerFocusCost = BF.getSlayerFocusCost(),
            slayerFocusDurationMinutes = BF.getSlayerFocusDurationSeconds() / 60,
            slayerKillRenownBonus = BF.getSlayerKillRenownBonus(),
            enableNativeFactionLink = BF.isNativeFactionLinkEnabled(),
            allowTraitBoons = BF.isTraitBoonEnabled(),
            traitBoonCost = BF.getTraitBoonCost(),
        },
        xpBuffOptions = BF.deepCopy(BF.XP_BUFF_OPTIONS),
        player = {
            username = username,
            moneyOnPerson = currency.total,
            guildId = guild and guild.id or nil,
            role = role,
            permissions = BF.buildPermissionMap(role),
            pendingInvites = Server.buildEnrichedInvites(username),
        },
        nativeFaction = nativeInfo,
        guild = nil,
    }

    if guild then
        snapshot.guild = {
            id = guild.id,
            name = guild.name,
            owner = guild.owner,
            nativeFactionName = guild.nativeFactionName,
            memberCount = Server.countMembers(guild),
            memberCap = BF.getMemberCapForGuild(guild),
            treasury = BF.deepCopy(guild.treasury or {}),
            progress = {
                renown = guild.progress and guild.progress.renown or 0,
                level = levelInfo and levelInfo.level or 1,
                levelFloor = levelInfo and levelInfo.currentFloor or 0,
                nextLevelRenown = levelInfo and levelInfo.nextLevelRenown or nil,
            },
            upgrades = {},
            activeBenefits = BF.deepCopy(guild.activeBenefits or {}),
            cooldowns = BF.deepCopy(guild.cooldowns or {}),
            members = BF.getSortedMembers(guild),
            auditTail = BF.deepCopy(guild.auditTail or {}),
            contributions = BF.deepCopy(guild.contributions or {}),
            pendingRequests = BF.hasPermission(role, "manageInvites") and BF.deepCopy(BF.Server.Invites.getInvitesFromGuild(guild.id)) or nil,
            tax = guild.tax and BF.deepCopy(guild.tax) or nil,
            taxStatuses = (function()
                if not guild.tax or (guild.tax.amount or 0) == 0 then return nil end
                local t = {}
                local ts = now()
                for mUser, mData in pairs(guild.members) do
                    t[mUser] = Server.buildTaxStatus(guild, mData, ts)
                end
                return t
            end)(),
        }

        for id, def in pairs(BF.UPGRADES) do
            snapshot.guild.upgrades[id] = {
                id = id,
                level = (guild.upgrades and guild.upgrades[id]) or 0,
                maxLevel = def.maxLevel,
                minLevel = def.minLevel,
                cost = BF.getUpgradeCost(id),
                labelKey = def.labelKey,
                summaryKey = def.summaryKey,
            }
        end
    end

    -- Guild ranking: points = total contributions + total kills across all members
    local guildRanking = {}
    local allGuildsState = Server.getState()
    for _, g in pairs(allGuildsState.guilds) do
        local lInfo = BF.getLevelInfo(g.progress and g.progress.renown or 0)
        local points = 0
        if g.contributions then
            for _, cd in pairs(g.contributions) do
                points = points + (cd.total or 0)
            end
        end
        if g.members then
            for _, md in pairs(g.members) do
                points = points + (md.kills or 0)
            end
        end
        table.insert(guildRanking, {
            name        = g.name,
            level       = lInfo and lInfo.level or 1,
            points      = points,
            memberCount = Server.countMembers(g),
            memberCap   = BF.getMemberCapForGuild(g),
        })
    end
    table.sort(guildRanking, function(a, b)
        if a.points ~= b.points then return a.points > b.points end
        return a.memberCount > b.memberCount
    end)
    snapshot.guildRanking = guildRanking

    sendServerCommand(playerObj, BF.MODULE, "snapshot", snapshot)
    Server.reapplyPlayerBenefits(playerObj, guild)
end

function Server.broadcastGuild(guild)
    if not guild or not guild.members then
        return
    end
    for username, _ in pairs(guild.members) do
        local playerObj = Server.findOnlinePlayer(username)
        if playerObj then
            Server.sendSnapshot(playerObj)
        end
    end
end

function Server.isRateLimited(playerObj, command)
    local username = safeUsername(playerObj)
    if not username then
        return true
    end

    local window = 1
    if command == "requestSnapshot" then
        window = 0
    end

    local currentTime = now()
    local bucket = Server.runtime.rateLimit[username] or {}
    local lastAt = bucket[command] or 0
    if window > 0 and (currentTime - lastAt) < window then
        return true
    end
    bucket[command] = currentTime
    Server.runtime.rateLimit[username] = bucket
    return false
end

function Server.createGuild(playerObj, args)
    local username = safeUsername(playerObj)
    local state = Server.getState()
    if state.playerIndex[username] then
        Server.sendNotify(playerObj, "IGUI_BF_Err_AlreadyInGuild", 1, 0.3, 0.3)
        return
    end

    local name = BF.normalizeGuildName(args and args.name or nil)
    if not name then
        Server.sendNotify(playerObj, "IGUI_BF_Err_InvalidGuildName", 1, 0.3, 0.3)
        return
    end
    if Server.guildNameExists(name) then
        Server.sendNotify(playerObj, "IGUI_BF_Err_GuildNameTaken", 1, 0.3, 0.3)
        return
    end

    local createCost = BF.getCreateCost()
    if createCost > 0 then
        local ok, err = Server.consumePlayerCurrency(playerObj, createCost)
        if not ok then
            local key = (err == "exact") and "IGUI_BF_Err_ExactCashRequired" or "IGUI_BF_Err_NotEnoughCash"
            Server.sendNotify(playerObj, key, 1, 0.3, 0.3)
            return
        end
    end

    local guildId = state.meta.nextGuildId
    state.meta.nextGuildId = guildId + 1

    local guild = {
        id = guildId,
        name = name,
        owner = username,
        createdAt = now(),
        treasury = { balance = 0, lifetimeIn = 0 },
        progress = { renown = 0, level = 1, levelFloor = 0, nextLevelRenown = BF.LEVEL_THRESHOLDS[2] },
        upgrades = { hall = 0, scholarship = 0, warcamp = 0 },
        activeBenefits = {},
        cooldowns = {},
        members = {},
        contributions = {},
        auditTail = {},
    }

    state.guilds[guildId] = guild
    Server.addPlayerToGuild(guild, username, "owner")
    Server.updateGuildLevel(guild)

    if BF.isNativeFactionLinkEnabled() then
        Server.importMembersFromNativeFaction(guild, username)
    end

    Server.appendAudit(guild, username, "guild_create", "cost=" .. tostring(createCost))
    Server.persist()
    Server.sendNotify(playerObj, "IGUI_BF_Notify_GuildCreated", 0.5, 1, 0.5)
    Server.broadcastGuild(guild)
end

function Server.contributeAllCash(playerObj)
    local username = safeUsername(playerObj)
    local guild = Server.getGuildByPlayer(username)
    if not guild then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NoGuild", 1, 0.3, 0.3)
        return
    end

    local currency = Server.getPlayerCurrencySummary(playerObj)
    if currency.total <= 0 then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NoCashToContribute", 1, 0.3, 0.3)
        return
    end

    local ok, err = Server.consumePlayerCurrency(playerObj, currency.total)
    if not ok then
        local key = (err == "exact") and "IGUI_BF_Err_ExactCashRequired" or "IGUI_BF_Err_NotEnoughCash"
        Server.sendNotify(playerObj, key, 1, 0.3, 0.3)
        return
    end

    guild.treasury.balance = BF.floor((guild.treasury.balance or 0) + currency.total)
    guild.treasury.lifetimeIn = BF.floor((guild.treasury.lifetimeIn or 0) + currency.total)
    guild.progress.renown = BF.floor((guild.progress.renown or 0) + currency.total)
    Server.updateGuildLevel(guild)

    guild.contributions = guild.contributions or {}
    local entry = guild.contributions[username] or { total = 0, count = 0, lastAt = 0 }
    entry.total = BF.floor(entry.total + currency.total)
    entry.count = BF.floor(entry.count + 1)
    entry.lastAt = now()
    guild.contributions[username] = entry

    Server.appendAudit(guild, username, "contribute_cash", "amount=" .. tostring(currency.total))
    Server.persist()
    Server.sendNotify(playerObj, "IGUI_BF_Notify_ContributedCash", 0.5, 1, 0.5, { tostring(currency.total) })
    Server.broadcastGuild(guild)
end

function Server.contributeAmount(playerObj, args)
    local username = safeUsername(playerObj)
    local guild = Server.getGuildByPlayer(username)
    if not guild then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NoGuild", 1, 0.3, 0.3)
        return
    end

    local amount = BF.floor(tonumber(args and args.amount) or 0)
    if amount <= 0 then
        return
    end

    local currency = Server.getPlayerCurrencySummary(playerObj)
    if currency.total < amount then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NotEnoughCash", 1, 0.3, 0.3)
        return
    end

    local ok, err = Server.consumePlayerCurrency(playerObj, amount)
    if not ok then
        local key = (err == "exact") and "IGUI_BF_Err_ExactCashRequired" or "IGUI_BF_Err_NotEnoughCash"
        Server.sendNotify(playerObj, key, 1, 0.3, 0.3)
        return
    end

    guild.treasury.balance = BF.floor((guild.treasury.balance or 0) + amount)
    guild.treasury.lifetimeIn = BF.floor((guild.treasury.lifetimeIn or 0) + amount)
    guild.progress.renown = BF.floor((guild.progress.renown or 0) + amount)
    Server.updateGuildLevel(guild)

    guild.contributions = guild.contributions or {}
    local entry = guild.contributions[username] or { total = 0, count = 0, lastAt = 0 }
    entry.total = BF.floor(entry.total + amount)
    entry.count = BF.floor(entry.count + 1)
    entry.lastAt = now()
    guild.contributions[username] = entry

    Server.appendAudit(guild, username, "contribute_cash", "amount=" .. tostring(amount))
    Server.persist()
    Server.sendNotify(playerObj, "IGUI_BF_Notify_ContributedCash", 0.5, 1, 0.5, { tostring(amount) })
    Server.broadcastGuild(guild)
end

function Server.buyUpgrade(playerObj, args)
    local username = safeUsername(playerObj)
    local guild = Server.getGuildByPlayer(username)
    if not guild then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NoGuild", 1, 0.3, 0.3)
        return
    end

    local role = Server.getMemberRole(guild, username)
    if not BF.hasPermission(role, "buyUpgrades") then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NotAllowed", 1, 0.3, 0.3)
        return
    end

    local upgradeId = args and args.upgradeId or nil
    local def = BF.UPGRADES[upgradeId]
    if not def then
        Server.sendNotify(playerObj, "IGUI_BF_Err_InvalidUpgrade", 1, 0.3, 0.3)
        return
    end

    guild.upgrades[upgradeId] = guild.upgrades[upgradeId] or 0
    if guild.upgrades[upgradeId] >= def.maxLevel then
        Server.sendNotify(playerObj, "IGUI_BF_Err_UpgradeMaxed", 1, 0.8, 0.2)
        return
    end

    Server.updateGuildLevel(guild)
    if (guild.progress.level or 1) < def.minLevel then
        Server.sendNotify(playerObj, "IGUI_BF_Err_LevelTooLow", 1, 0.3, 0.3, { tostring(def.minLevel) })
        return
    end

    local cost = BF.getUpgradeCost(upgradeId)
    if (guild.treasury.balance or 0) < cost then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NotEnoughTreasury", 1, 0.3, 0.3)
        return
    end

    guild.treasury.balance = BF.floor(guild.treasury.balance - cost)
    guild.upgrades[upgradeId] = BF.floor(guild.upgrades[upgradeId] + 1)

    Server.appendAudit(guild, username, "upgrade_buy", upgradeId .. " cost=" .. tostring(cost))
    Server.persist()
    Server.sendNotify(playerObj, "IGUI_BF_Notify_UpgradeBought", 0.5, 1, 0.5, { getText(def.labelKey) })
    Server.broadcastGuild(guild)
end

function Server.activateXPBuff(playerObj, args)
    local username = safeUsername(playerObj)
    local guild = Server.getGuildByPlayer(username)
    if not guild then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NoGuild", 1, 0.3, 0.3)
        return
    end

    local role = Server.getMemberRole(guild, username)
    if not BF.hasPermission(role, "activateBenefits") then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NotAllowed", 1, 0.3, 0.3)
        return
    end
    if (guild.upgrades.scholarship or 0) <= 0 then
        Server.sendNotify(playerObj, "IGUI_BF_Err_BenefitLocked", 1, 0.3, 0.3)
        return
    end

    local perkId = args and args.perkId or nil
    if not BF.getXPBuffOption(perkId) then
        Server.sendNotify(playerObj, "IGUI_BF_Err_InvalidPerk", 1, 0.3, 0.3)
        return
    end

    local currentTime = now()
    guild.activeBenefits = guild.activeBenefits or {}
    if guild.activeBenefits.xp and guild.activeBenefits.xp.expiresAt and guild.activeBenefits.xp.expiresAt > currentTime then
        Server.sendNotify(playerObj, "IGUI_BF_Err_BenefitAlreadyActive", 1, 0.8, 0.2)
        return
    end

    local cost = BF.getXPBuffCost()
    if (guild.treasury.balance or 0) < cost then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NotEnoughTreasury", 1, 0.3, 0.3)
        return
    end

    local duration = BF.getXPBuffDurationSeconds()
    local expiresAt = currentTime + duration
    guild.treasury.balance = BF.floor(guild.treasury.balance - cost)
    guild.activeBenefits.xp = {
        perkId = perkId,
        multiplier = BF.getXPBuffMultiplier(),
        startedAt = currentTime,
        expiresAt = expiresAt,
        activatedBy = username,
    }
    guild.cooldowns = guild.cooldowns or {}
    guild.cooldowns.xp = expiresAt

    Server.forEachOnlinePlayer(function(onlinePlayer)
        local onlineUsername = safeUsername(onlinePlayer)
        if guild.members[onlineUsername] then
            Server.applyXpMultiplier(onlinePlayer, perkId, guild.activeBenefits.xp.multiplier)
        end
    end)

    Server.appendAudit(guild, username, "benefit_activate_xp", perkId .. " cost=" .. tostring(cost))
    Server.persist()
    Server.sendNotify(playerObj, "IGUI_BF_Notify_XPBuffActivated", 0.5, 1, 0.5, {
        getText(BF.getXPBuffOption(perkId).labelKey),
        tostring(BF.getXPBuffDurationSeconds() / 60),
    })
    Server.broadcastGuild(guild)
end

function Server.activateSlayerFocus(playerObj)
    local username = safeUsername(playerObj)
    local guild = Server.getGuildByPlayer(username)
    if not guild then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NoGuild", 1, 0.3, 0.3)
        return
    end

    local role = Server.getMemberRole(guild, username)
    if not BF.hasPermission(role, "activateBenefits") then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NotAllowed", 1, 0.3, 0.3)
        return
    end
    if (guild.upgrades.warcamp or 0) <= 0 then
        Server.sendNotify(playerObj, "IGUI_BF_Err_BenefitLocked", 1, 0.3, 0.3)
        return
    end

    local currentTime = now()
    guild.activeBenefits = guild.activeBenefits or {}
    if guild.activeBenefits.slayer and guild.activeBenefits.slayer.expiresAt and guild.activeBenefits.slayer.expiresAt > currentTime then
        Server.sendNotify(playerObj, "IGUI_BF_Err_BenefitAlreadyActive", 1, 0.8, 0.2)
        return
    end

    local cost = BF.getSlayerFocusCost()
    if (guild.treasury.balance or 0) < cost then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NotEnoughTreasury", 1, 0.3, 0.3)
        return
    end

    local expiresAt = currentTime + BF.getSlayerFocusDurationSeconds()
    guild.treasury.balance = BF.floor(guild.treasury.balance - cost)
    guild.activeBenefits.slayer = {
        startedAt = currentTime,
        expiresAt = expiresAt,
        activatedBy = username,
        renownBonus = BF.getSlayerKillRenownBonus(),
        kills = 0,
    }
    guild.cooldowns = guild.cooldowns or {}
    guild.cooldowns.slayer = expiresAt

    Server.appendAudit(guild, username, "benefit_activate_slayer", "cost=" .. tostring(cost))
    Server.persist()
    Server.sendNotify(playerObj, "IGUI_BF_Notify_SlayerActivated", 0.5, 1, 0.5, {
        tostring(BF.getSlayerFocusDurationSeconds() / 60),
    })
    Server.broadcastGuild(guild)
end

function Server.syncNativeFaction(playerObj)
    local username = safeUsername(playerObj)
    local guild = Server.getGuildByPlayer(username)
    if not guild then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NoGuild", 1, 0.3, 0.3)
        return
    end

    local role = Server.getMemberRole(guild, username)
    if not BF.hasPermission(role, "syncNative") then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NotAllowed", 1, 0.3, 0.3)
        return
    end

    local ok, result = Server.importMembersFromNativeFaction(guild, username)
    if not ok then
        local key = "IGUI_BF_Err_NativeSyncUnavailable"
        if result == "notowner" then
            key = "IGUI_BF_Err_NativeFactionOwnerOnly"
        elseif result == "disabled" then
            key = "IGUI_BF_Err_NativeSyncDisabled"
        end
        Server.sendNotify(playerObj, key, 1, 0.3, 0.3)
        return
    end

    Server.appendAudit(guild, username, "native_sync", "imported=" .. tostring(result))
    Server.persist()
    Server.sendNotify(playerObj, "IGUI_BF_Notify_NativeSync", 0.5, 1, 0.5, { tostring(result) })
    Server.broadcastGuild(guild)
end

function Server.setMemberRole(playerObj, args)
    local username = safeUsername(playerObj)
    local guild = Server.getGuildByPlayer(username)
    if not guild then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NoGuild", 1, 0.3, 0.3)
        return
    end

    local role = Server.getMemberRole(guild, username)
    if not BF.hasPermission(role, "manageRoles") then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NotAllowed", 1, 0.3, 0.3)
        return
    end

    local target = BF.trimString(args and args.username or nil)
    local newRole = BF.trimString(args and args.role or nil)
    if not target or not guild.members[target] then
        Server.sendNotify(playerObj, "IGUI_BF_Err_InvalidTarget", 1, 0.3, 0.3)
        return
    end
    if target == guild.owner then
        Server.sendNotify(playerObj, "IGUI_BF_Err_CannotModifyOwner", 1, 0.3, 0.3)
        return
    end
    if newRole ~= "member" and newRole ~= "officer" and newRole ~= "treasurer" then
        Server.sendNotify(playerObj, "IGUI_BF_Err_InvalidRole", 1, 0.3, 0.3)
        return
    end

    guild.members[target].role = newRole
    Server.appendAudit(guild, username, "member_role", target .. "=" .. newRole)
    Server.persist()
    Server.sendNotify(playerObj, "IGUI_BF_Notify_RoleUpdated", 0.5, 1, 0.5, { target, getText(BF.getRoleLabelKey(newRole)) })
    Server.broadcastGuild(guild)
end

function Server.removeMember(playerObj, args)
    local username = safeUsername(playerObj)
    local guild = Server.getGuildByPlayer(username)
    if not guild then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NoGuild", 1, 0.3, 0.3)
        return
    end

    local role = Server.getMemberRole(guild, username)
    if not BF.hasPermission(role, "removeMembers") then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NotAllowed", 1, 0.3, 0.3)
        return
    end

    local target = BF.trimString(args and args.username or nil)
    if not target or not guild.members[target] then
        Server.sendNotify(playerObj, "IGUI_BF_Err_InvalidTarget", 1, 0.3, 0.3)
        return
    end
    if target == guild.owner then
        Server.sendNotify(playerObj, "IGUI_BF_Err_CannotModifyOwner", 1, 0.3, 0.3)
        return
    end

    Server.removePlayerFromGuild(guild, target)
    Server.appendAudit(guild, username, "member_remove", target)
    Server.persist()
    local targetPlayer = Server.findOnlinePlayer(target)
    if targetPlayer then
        Server.sendNotify(targetPlayer, "IGUI_BF_Notify_RemovedFromGuild", 1, 0.3, 0.3)
        Server.sendSnapshot(targetPlayer)
    end
    Server.sendNotify(playerObj, "IGUI_BF_Notify_MemberRemoved", 0.5, 1, 0.5, { target })
    Server.broadcastGuild(guild)
end

function Server.deleteGuild(playerObj)
    local username = safeUsername(playerObj)
    local guild = Server.getGuildByPlayer(username)
    if not guild then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NoGuild", 1, 0.3, 0.3)
        return
    end

    if guild.owner ~= username then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NotAllowed", 1, 0.3, 0.3)
        return
    end

    local state = Server.getState()
    local guildId = guild.id
    local guildName = guild.name

    -- Collect all members before removing
    local exMembers = {}
    for memberUsername, _ in pairs(guild.members) do
        table.insert(exMembers, memberUsername)
    end

    -- Remove every member from the playerIndex
    for _, memberUsername in ipairs(exMembers) do
        Server.removePlayerFromGuild(guild, memberUsername)
    end

    -- Cancel all active invites for this guild
    if state.invites and state.invites.active then
        local toCancel = {}
        for inviteId, invite in pairs(state.invites.active) do
            if invite.guildId == guildId then
                table.insert(toCancel, inviteId)
            end
        end
        for _, inviteId in ipairs(toCancel) do
            state.invites.active[inviteId] = nil
        end
    end

    -- Remove the guild
    state.guilds[guildId] = nil
    writeAuditLine("[" .. nowReadable() .. "] Guild '" .. tostring(guildName) .. "' deleted by " .. tostring(username))
    Server.persist()

    -- Notify and refresh snapshot for every ex-member
    for _, memberUsername in ipairs(exMembers) do
        local memberPlayer = Server.findOnlinePlayer(memberUsername)
        if memberPlayer then
            Server.sendNotify(memberPlayer, "IGUI_BF_Notify_GuildDeleted", 1, 1, 0.4)
            Server.sendSnapshot(memberPlayer)
        end
    end
end

function Server.handleTraitBoon(playerObj)
    local key = BF.isTraitBoonEnabled() and "IGUI_BF_Err_TraitBoonNotImplemented" or "IGUI_BF_Err_TraitBoonsDisabled"
    Server.sendNotify(playerObj, key, 1, 0.8, 0.2)
end

-- Sistema de Convites

function Server.sendInvite(playerObj, args)
    local username = safeUsername(playerObj)
    local guild = Server.getGuildByPlayer(username)
    
    if not guild then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NoGuild", 1, 0.3, 0.3)
        return
    end
    
    local role = Server.getMemberRole(guild, username)
    if not BF.hasPermission(role, "inviteMembers") then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NotAllowed", 1, 0.3, 0.3)
        return
    end
    
    local targetUsername = BF.trimString(args and args.username or nil)
    if not targetUsername or targetUsername == username then
        Server.sendNotify(playerObj, "IGUI_BF_Err_InvalidTarget", 1, 0.3, 0.3)
        return
    end
    
    -- Verificar se target já está em uma guild
    if Server.getGuildIdByPlayer(targetUsername) then
        Server.sendNotify(playerObj, "IGUI_BF_Err_PlayerAlreadyInGuild", 1, 0.3, 0.3)
        return
    end
    
    -- Verificar se guild está cheia
    if Server.countMembers(guild) >= BF.getMemberCapForGuild(guild) then
        Server.sendNotify(playerObj, "IGUI_BF_Err_GuildFull", 1, 0.3, 0.3)
        return
    end
    
    -- Verificar se já existe convite ativo
    local hasInvite, existingInvite = BF.Server.Invites.hasActiveInvite(guild.id, targetUsername)
    if hasInvite then
        Server.sendNotify(playerObj, "IGUI_BF_Err_InviteAlreadyExists", 1, 0.8, 0.2)
        return
    end
    
    -- Verificar limite de convites pendentes do target
    if BF.Server.Invites.countPendingInvites(targetUsername) >= BF.Invites.MAX_PENDING_PER_PLAYER then
        Server.sendNotify(playerObj, "IGUI_BF_Err_TargetTooManyInvites", 1, 0.3, 0.3)
        return
    end
    
    -- Criar convite
    local invite = BF.Server.Invites.createInvite(
        guild.id,
        guild.name,
        targetUsername,
        username,
        BF.Invites.TYPE.GUILD_TO_PLAYER
    )
    
    Server.appendAudit(guild, username, "invite_send", targetUsername)
    Server.persist()
    
    -- Notificar ambos
    Server.sendNotify(playerObj, "IGUI_BF_Notify_InviteSent", 0.5, 1, 0.5, { targetUsername })
    
    local targetPlayer = Server.findOnlinePlayer(targetUsername)
    if targetPlayer then
        Server.sendNotify(targetPlayer, "IGUI_BF_Notify_InviteReceived", 0.5, 0.9, 1, { guild.name })
        Server.sendSnapshot(targetPlayer)
    end
end

function Server.requestJoinGuild(playerObj, args)
    local username = safeUsername(playerObj)
    
    -- Verificar se já está em uma guild
    if Server.getGuildIdByPlayer(username) then
        Server.sendNotify(playerObj, "IGUI_BF_Err_AlreadyInGuild", 1, 0.3, 0.3)
        return
    end
    
    local guildId = tonumber(args and args.guildId or nil)
    local guild = Server.getGuildById(guildId)
    
    if not guild then
        Server.sendNotify(playerObj, "IGUI_BF_Err_GuildNotFound", 1, 0.3, 0.3)
        return
    end
    
    -- Verificar se guild está cheia
    if Server.countMembers(guild) >= BF.getMemberCapForGuild(guild) then
        Server.sendNotify(playerObj, "IGUI_BF_Err_GuildFull", 1, 0.3, 0.3)
        return
    end
    
    -- Verificar se já existe convite ativo
    local hasInvite, existingInvite = BF.Server.Invites.hasActiveInvite(guildId, username)
    if hasInvite then
        Server.sendNotify(playerObj, "IGUI_BF_Err_RequestAlreadyExists", 1, 0.8, 0.2)
        return
    end
    
    -- Verificar limite de requests pendentes
    if BF.Server.Invites.countPendingInvites(username) >= BF.Invites.MAX_PENDING_PER_PLAYER then
        Server.sendNotify(playerObj, "IGUI_BF_Err_TooManyRequests", 1, 0.3, 0.3)
        return
    end
    
    -- Criar request (convite player→guild)
    local invite = BF.Server.Invites.createInvite(
        guild.id,
        guild.name,
        username,
        username,
        BF.Invites.TYPE.PLAYER_TO_GUILD
    )
    
    Server.appendAudit(guild, username, "join_request", "pending")
    Server.persist()
    
    -- Notificar jogador e membros da guild
    Server.sendNotify(playerObj, "IGUI_BF_Notify_JoinRequestSent", 0.5, 1, 0.5, { guild.name })
    
    -- Notificar owner/officers/treasurers da guild
    for memberUsername, memberData in pairs(guild.members) do
        if BF.hasPermission(memberData.role, "manageInvites") then
            local memberPlayer = Server.findOnlinePlayer(memberUsername)
            if memberPlayer then
                Server.sendNotify(memberPlayer, "IGUI_BF_Notify_JoinRequestReceived", 0.5, 0.9, 1, { username })
                Server.sendSnapshot(memberPlayer)
            end
        end
    end
end

function Server.acceptInviteCommand(playerObj, args)
    local username = safeUsername(playerObj)
    local inviteId = tonumber(args and args.inviteId or nil)
    
    if not inviteId then
        Server.sendNotify(playerObj, "IGUI_BF_Err_InvalidInvite", 1, 0.3, 0.3)
        return
    end
    
    local invite = BF.Server.Invites.getInviteById(inviteId)
    if not invite then
        Server.sendNotify(playerObj, "IGUI_BF_Err_InviteNotFound", 1, 0.3, 0.3)
        return
    end
    
    -- Verificar permissões baseado no tipo de convite
    if invite.type == BF.Invites.TYPE.GUILD_TO_PLAYER then
        -- Jogador aceitando convite da guild
        if invite.playerUsername ~= username then
            Server.sendNotify(playerObj, "IGUI_BF_Err_NotAllowed", 1, 0.3, 0.3)
            return
        end
    elseif invite.type == BF.Invites.TYPE.PLAYER_TO_GUILD then
        -- Guild aceitando request do jogador
        local guild = Server.getGuildById(invite.guildId)
        if not guild then
            Server.sendNotify(playerObj, "IGUI_BF_Err_GuildNotFound", 1, 0.3, 0.3)
            return
        end
        
        local role = Server.getMemberRole(guild, username)
        if not BF.hasPermission(role, "manageInvites") then
            Server.sendNotify(playerObj, "IGUI_BF_Err_NotAllowed", 1, 0.3, 0.3)
            return
        end
    end
    
    local guild = Server.getGuildById(invite.guildId)
    if not guild then
        Server.sendNotify(playerObj, "IGUI_BF_Err_GuildNotFound", 1, 0.3, 0.3)
        return
    end
    
    -- Verificar se player já está em guild
    if Server.getGuildIdByPlayer(invite.playerUsername) then
        BF.Server.Invites.cancelInvite(inviteId)
        Server.persist()
        Server.sendNotify(playerObj, "IGUI_BF_Err_PlayerAlreadyInGuild", 1, 0.3, 0.3)
        return
    end
    
    -- Verificar se guild está cheia
    if Server.countMembers(guild) >= BF.getMemberCapForGuild(guild) then
        BF.Server.Invites.cancelInvite(inviteId)
        Server.persist()
        Server.sendNotify(playerObj, "IGUI_BF_Err_GuildFull", 1, 0.3, 0.3)
        return
    end
    
    -- Aceitar convite
    local ok, result = BF.Server.Invites.acceptInvite(inviteId)
    if not ok then
        local errorKey = "IGUI_BF_Err_InviteError"
        if result == "expired" then
            errorKey = "IGUI_BF_Err_InviteExpired"
        end
        Server.sendNotify(playerObj, errorKey, 1, 0.3, 0.3)
        return
    end
    
    -- Adicionar player à guild
    local addOk, addErr = Server.addPlayerToGuild(guild, invite.playerUsername, "member")
    if not addOk then
        Server.sendNotify(playerObj, "IGUI_BF_Err_CannotAddPlayer", 1, 0.3, 0.3)
        return
    end
    
    -- Cancelar todos os outros convites do player
    BF.Server.Invites.cancelAllPlayerInvites(invite.playerUsername, inviteId)
    
    Server.appendAudit(guild, username, "invite_accept", invite.playerUsername)
    Server.persist()
    
    -- Notificar todos
    Server.sendNotify(playerObj, "IGUI_BF_Notify_InviteAccepted", 0.5, 1, 0.5, { invite.playerUsername, guild.name })
    
    local newMemberPlayer = Server.findOnlinePlayer(invite.playerUsername)
    if newMemberPlayer then
        Server.sendNotify(newMemberPlayer, "IGUI_BF_Notify_JoinedGuild", 0.3, 1, 0.3, { guild.name })
        Server.sendSnapshot(newMemberPlayer)
    end
    
    Server.broadcastGuild(guild)
end

function Server.rejectInviteCommand(playerObj, args)
    local username = safeUsername(playerObj)
    local inviteId = tonumber(args and args.inviteId or nil)
    
    if not inviteId then
        Server.sendNotify(playerObj, "IGUI_BF_Err_InvalidInvite", 1, 0.3, 0.3)
        return
    end
    
    local invite = BF.Server.Invites.getInviteById(inviteId)
    if not invite then
        Server.sendNotify(playerObj, "IGUI_BF_Err_InviteNotFound", 1, 0.3, 0.3)
        return
    end
    
    -- Verificar permissões
    if invite.type == BF.Invites.TYPE.GUILD_TO_PLAYER then
        if invite.playerUsername ~= username then
            Server.sendNotify(playerObj, "IGUI_BF_Err_NotAllowed", 1, 0.3, 0.3)
            return
        end
    elseif invite.type == BF.Invites.TYPE.PLAYER_TO_GUILD then
        local guild = Server.getGuildById(invite.guildId)
        if not guild then
            Server.sendNotify(playerObj, "IGUI_BF_Err_GuildNotFound", 1, 0.3, 0.3)
            return
        end
        
        local role = Server.getMemberRole(guild, username)
        if not BF.hasPermission(role, "manageInvites") then
            Server.sendNotify(playerObj, "IGUI_BF_Err_NotAllowed", 1, 0.3, 0.3)
            return
        end
    end
    
    local ok, result = BF.Server.Invites.rejectInvite(inviteId)
    if not ok then
        Server.sendNotify(playerObj, "IGUI_BF_Err_InviteError", 1, 0.3, 0.3)
        return
    end
    
    Server.persist()
    Server.sendNotify(playerObj, "IGUI_BF_Notify_InviteRejected", 0.8, 0.8, 0.3)
    Server.sendSnapshot(playerObj)
end

function Server.cancelInviteCommand(playerObj, args)
    local username = safeUsername(playerObj)
    local inviteId = tonumber(args and args.inviteId or nil)
    
    if not inviteId then
        Server.sendNotify(playerObj, "IGUI_BF_Err_InvalidInvite", 1, 0.3, 0.3)
        return
    end
    
    local invite = BF.Server.Invites.getInviteById(inviteId)
    if not invite then
        Server.sendNotify(playerObj, "IGUI_BF_Err_InviteNotFound", 1, 0.3, 0.3)
        return
    end
    
    -- Apenas quem enviou pode cancelar
    if invite.inviterUsername ~= username then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NotAllowed", 1, 0.3, 0.3)
        return
    end
    
    local ok, result = BF.Server.Invites.cancelInvite(inviteId)
    if not ok then
        Server.sendNotify(playerObj, "IGUI_BF_Err_InviteError", 1, 0.3, 0.3)
        return
    end
    
    Server.persist()
    Server.sendNotify(playerObj, "IGUI_BF_Notify_InviteCancelled", 0.8, 0.8, 0.3)
    Server.sendSnapshot(playerObj)
end

function Server.listGuildsWithSlots(playerObj)
    local guildsWithSlots = BF.Server.Invites.getGuildsWithOpenSlots()
    
    sendServerCommand(playerObj, BF.MODULE, "guildsWithSlots", {
        guilds = guildsWithSlots
    })
end

function Server.processBenefitExpirations()
    local state = Server.getState()
    local currentTime = now()

    for _, guild in pairs(state.guilds) do
        local changed = false

        if guild.activeBenefits and guild.activeBenefits.xp and guild.activeBenefits.xp.expiresAt and guild.activeBenefits.xp.expiresAt <= currentTime then
            local perkId = guild.activeBenefits.xp.perkId
            Server.forEachOnlinePlayer(function(playerObj)
                local username = safeUsername(playerObj)
                if guild.members[username] then
                    Server.applyXpMultiplier(playerObj, perkId, 1.0)
                    Server.sendNotify(playerObj, "IGUI_BF_Notify_XPBuffExpired", 1, 0.9, 0.3)
                end
            end)
            guild.activeBenefits.xp = nil
            Server.appendAudit(guild, "SERVER", "benefit_expire_xp", perkId or "unknown")
            changed = true
        end

        if guild.activeBenefits and guild.activeBenefits.slayer and guild.activeBenefits.slayer.expiresAt and guild.activeBenefits.slayer.expiresAt <= currentTime then
            guild.activeBenefits.slayer = nil
            Server.appendAudit(guild, "SERVER", "benefit_expire_slayer", "")
            changed = true
        end

        if changed then
            Server.persist()
            Server.broadcastGuild(guild)
        end
    end
end

function Server.onZombieDead(zombie)
    local ok, attacker = pcall(function()
        return zombie and zombie:getAttackedBy() or nil
    end)
    if not ok or not attacker then
        return
    end
    local isPlayer = false
    local instanceOk = pcall(function()
        isPlayer = instanceof(attacker, "IsoPlayer")
    end)
    if not instanceOk or not isPlayer then
        return
    end

    local username = safeUsername(attacker)
    local guild = Server.getGuildByPlayer(username)
    if not guild then
        return
    end

    -- Always track kills per member for ranking
    if guild.members[username] then
        guild.members[username].kills = BF.floor((guild.members[username].kills or 0) + 1)
    end

    local slayer = guild.activeBenefits and guild.activeBenefits.slayer or nil
    if not slayer or not slayer.expiresAt or slayer.expiresAt <= now() then
        -- No active slayer: persist kills every 10 kills to avoid excessive I/O
        local totalKills = guild.members[username] and guild.members[username].kills or 0
        if totalKills % 10 == 0 then
            Server.persist()
        end
        return
    end

    local bonus = slayer.renownBonus or BF.getSlayerKillRenownBonus()
    if bonus <= 0 then
        Server.persist()
        return
    end

    local oldLevel = guild.progress.level or 1
    guild.progress.renown = BF.floor((guild.progress.renown or 0) + bonus)
    slayer.kills = BF.floor((slayer.kills or 0) + 1)
    Server.updateGuildLevel(guild)
    Server.persist()

    if (slayer.kills % 10) == 0 or (guild.progress.level or 1) ~= oldLevel then
        Server.broadcastGuild(guild)
    end
end

-- ============================================================
-- Sistema de Taxa da Guild
-- ============================================================

local SECONDS_PER_DAY = 86400
local TAX_GRACE_DAYS   = 3   -- dias extras antes do kick

function Server.setGuildTax(playerObj, args)
    local username = safeUsername(playerObj)
    local guild = Server.getGuildByPlayer(username)
    if not guild then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NoGuild", 1, 0.3, 0.3)
        return
    end

    local role = Server.getMemberRole(guild, username)
    if not BF.hasPermission(role, "setGuildTax") then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NotAllowed", 1, 0.3, 0.3)
        return
    end

    local amount   = tonumber(args and args.amount) or 0
    local interval = tonumber(args and args.interval) or 0
    if amount < 0 or interval < 1 then
        Server.sendNotify(playerObj, "IGUI_BF_Err_TaxInvalidAmount", 1, 0.3, 0.3)
        return
    end

    if amount == 0 then
        -- Disable tax
        guild.tax = nil
    else
        guild.tax = {
            amount   = BF.floor(amount),
            interval = BF.floor(interval),
        }
        -- Reset due dates for all members when tax is (re)configured
        local currentTime = now()
        for _, memberData in pairs(guild.members) do
            memberData.taxPaidAt = currentTime
        end
    end

    Server.appendAudit(guild, username, "tax_set", tostring(amount) .. "/" .. tostring(interval))
    Server.persist()
    Server.broadcastGuild(guild)
    Server.sendNotify(playerObj, "IGUI_BF_Notify_TaxSet", 0.5, 1, 0.5, { tostring(BF.floor(amount)), tostring(BF.floor(interval)) })
end

function Server.payGuildTax(playerObj)
    local username = safeUsername(playerObj)
    local guild = Server.getGuildByPlayer(username)
    if not guild then
        Server.sendNotify(playerObj, "IGUI_BF_Err_NoGuild", 1, 0.3, 0.3)
        return
    end

    if not guild.tax or (guild.tax.amount or 0) == 0 then
        Server.sendNotify(playerObj, "IGUI_BF_Err_TaxNotConfigured", 1, 0.3, 0.3)
        return
    end

    local memberData = guild.members[username]
    local currentTime = now()
    local intervalSec = (guild.tax.interval or 1) * SECONDS_PER_DAY
    local lastPaid = memberData and memberData.taxPaidAt or 0
    if lastPaid + intervalSec > currentTime then
        Server.sendNotify(playerObj, "IGUI_BF_Err_TaxAlreadyPaid", 1, 0.8, 0.3)
        return
    end

    local ok, err = Server.consumePlayerCurrency(playerObj, guild.tax.amount)
    if not ok then
        local key = err == "exact" and "IGUI_BF_Err_ExactCashRequired" or "IGUI_BF_Err_NotEnoughCash"
        Server.sendNotify(playerObj, key, 1, 0.3, 0.3)
        return
    end

    guild.treasury.balance = BF.floor((guild.treasury.balance or 0) + guild.tax.amount)
    guild.treasury.lifetimeIn = BF.floor((guild.treasury.lifetimeIn or 0) + guild.tax.amount)
    if memberData then
        memberData.taxPaidAt = currentTime
    end

    Server.appendAudit(guild, username, "tax_paid", tostring(guild.tax.amount))
    Server.persist()
    Server.broadcastGuild(guild)
    Server.sendNotify(playerObj, "IGUI_BF_Notify_TaxPaid", 0.5, 1, 0.5, { tostring(guild.tax.amount) })
end

function Server.processTaxDelinquents()
    local state = Server.getState()
    local currentTime = now()

    for _, guild in pairs(state.guilds) do
        if guild.tax and (guild.tax.amount or 0) > 0 then
            local intervalSec = (guild.tax.interval or 1) * SECONDS_PER_DAY
            local graceSec    = TAX_GRACE_DAYS * SECONDS_PER_DAY
            local toKick      = {}

            for username, memberData in pairs(guild.members) do
                if username ~= guild.owner then
                    local lastPaid = memberData.taxPaidAt or 0
                    if lastPaid + intervalSec + graceSec < currentTime then
                        table.insert(toKick, username)
                    end
                end
            end

            for _, username in ipairs(toKick) do
                Server.removePlayerFromGuild(guild, username)
                Server.appendAudit(guild, "SERVER", "tax_kick", username)
                local memberPlayer = Server.findOnlinePlayer(username)
                if memberPlayer then
                    Server.sendNotify(memberPlayer, "IGUI_BF_Notify_TaxKicked", 1, 1, 0.3)
                    Server.sendSnapshot(memberPlayer)
                end
                for adminUser, adminData in pairs(guild.members) do
                    if BF.hasPermission(adminData.role or "member", "manageRoles") then
                        local adminPlayer = Server.findOnlinePlayer(adminUser)
                        if adminPlayer then
                            Server.sendNotify(adminPlayer, "IGUI_BF_Notify_TaxKickedAdmin", 0.9, 0.6, 0.2, { username })
                        end
                    end
                end
            end

            if #toKick > 0 then
                Server.persist()
                Server.broadcastGuild(guild)
            end
        end
    end
end

function Server.buildTaxStatus(guild, memberData, currentTime)
    if not guild.tax or (guild.tax.amount or 0) == 0 then
        return nil
    end
    local intervalSec = (guild.tax.interval or 1) * SECONDS_PER_DAY
    local graceSec    = TAX_GRACE_DAYS * SECONDS_PER_DAY
    local lastPaid    = memberData and memberData.taxPaidAt or 0
    local dueAt       = lastPaid + intervalSec
    local kickAt      = dueAt + graceSec
    local daysLeft    = math.floor((dueAt - currentTime) / SECONDS_PER_DAY)
    local daysOverdue = math.floor((currentTime - dueAt) / SECONDS_PER_DAY)

    if currentTime < dueAt then
        return { status = "paid", daysLeft = daysLeft }
    elseif currentTime < kickAt then
        return { status = "overdue", daysOverdue = daysOverdue, daysUntilKick = math.floor((kickAt - currentTime) / SECONDS_PER_DAY) }
    else
        return { status = "kick_pending", daysOverdue = daysOverdue }
    end
end

function Server.onClientCommand(module, command, playerObj, args)
    if module ~= BF.MODULE or not playerObj then
        return
    end
    if Server.isRateLimited(playerObj, command) then
        return
    end

    args = args or {}

    if command == "requestSnapshot" then
        Server.sendSnapshot(playerObj)
    elseif command == "createGuild" then
        Server.createGuild(playerObj, args)
    elseif command == "contributeAllCash" then
        Server.contributeAllCash(playerObj)
    elseif command == "contributeAmount" then
        Server.contributeAmount(playerObj, args)
    elseif command == "buyUpgrade" then
        Server.buyUpgrade(playerObj, args)
    elseif command == "activateXPBuff" then
        Server.activateXPBuff(playerObj, args)
    elseif command == "activateSlayerFocus" then
        Server.activateSlayerFocus(playerObj)
    elseif command == "syncNativeFaction" then
        Server.syncNativeFaction(playerObj)
    elseif command == "setMemberRole" then
        Server.setMemberRole(playerObj, args)
    elseif command == "removeMember" then
        Server.removeMember(playerObj, args)
    elseif command == "requestTraitBoon" then
        Server.handleTraitBoon(playerObj)
    elseif command == "sendInvite" then
        Server.sendInvite(playerObj, args)
    elseif command == "requestJoinGuild" then
        Server.requestJoinGuild(playerObj, args)
    elseif command == "acceptInvite" then
        Server.acceptInviteCommand(playerObj, args)
    elseif command == "rejectInvite" then
        Server.rejectInviteCommand(playerObj, args)
    elseif command == "cancelInvite" then
        Server.cancelInviteCommand(playerObj, args)
    elseif command == "listGuildsWithSlots" then
        Server.listGuildsWithSlots(playerObj)
    elseif command == "deleteGuild" then
        Server.deleteGuild(playerObj)
    elseif command == "setGuildTax" then
        Server.setGuildTax(playerObj, args)
    elseif command == "payGuildTax" then
        Server.payGuildTax(playerObj)
    end
end

function Server.init()
    Server.getState()
    Server.persist()
    writeAuditLine("[" .. nowReadable() .. "] Better Factions initialized.")
    -- Register invite cleanup here, after all Lua files have loaded
    Events.EveryOneMinute.Add(BF.Server.Invites.cleanExpiredInvites)
end

Events.OnInitGlobalModData.Add(Server.init)
Events.OnClientCommand.Add(Server.onClientCommand)
Events.EveryOneMinute.Add(Server.processBenefitExpirations)
Events.EveryOneMinute.Add(Server.processTaxDelinquents)
Events.OnZombieDead.Add(Server.onZombieDead)
