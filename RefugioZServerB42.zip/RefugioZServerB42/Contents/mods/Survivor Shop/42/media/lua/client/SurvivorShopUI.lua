-- SurvivorShopUI.lua (B42.13.1) - Tabs + fixed list rendering (no spam errors)
require "ISUI/ISPanel"
require "ISUI/ISTabPanel"
require "ISUI/ISButton"
require "ISUI/ISLabel"
require "ISUI/ISTextEntryBox"
require "ISUI/ISComboBox"
require "ISUI/ISScrollingListBox"
require "SurvivorShopShared"
require "SurvivorShopClient"
require "SurvivorShopUITheme"
require "SurvivorShopBankOverlayV2"

-- ===== Translation helper (B42) =====
local function SS_T(key, fallback, ...)
    local v = getText(key, ...)
    if not v or v == key then return fallback or key end
    return v
end

local function SS_stripUnknownPrefix(s)
    if s == nil then return "" end
    if type(s) ~= "string" then s = tostring(s) end
    -- remove leading spaces + odd prefix chars that sometimes appear on unknown names
    s = s:gsub("^%s*", "")
    s = s:gsub("^[%?]+%s*", "")
    s = s:gsub("^[^%w%.]+", "")
    return s
end

local function SS_formatOneArg(text, value)
    text = tostring(text or "")
    local val = tostring(value or "")
    -- Supports common localization placeholder styles used across mods/translations.
    text = text:gsub("%%1%$s", val)
    text = text:gsub("%%1", val)
    text = text:gsub("{1}", val)
    return text
end



local function _setPagerText(widget, txt)
    if not widget then return end
    if widget.setTitle then widget:setTitle(txt)
    elseif widget.setName then widget:setName(txt)
    else widget.title = txt end
end

-- Favorites stock helpers (sync with current market listings)
local function _ss_isListingExpired(l)
    if SurvivorShopUI and SurvivorShopUI.isListingExpired then
        return SurvivorShopUI.isListingExpired(l)
    end
    return false
end

local function _ss_favHasStock(fullType)
    if not fullType or fullType == "" then return false end
    for _, l in ipairs(SurvivorShopClient.listings or {}) do
        if l and tostring(l.itemType or "") == tostring(fullType) then
            local qty = math.floor(tonumber(l.quantity) or 0)
            if qty > 0 and (not _ss_isListingExpired(l)) then
                return true
            end
        end
    end
    return false
end

local function _ss_favCheapestListing(fullType)
    if not fullType or fullType == "" then return nil end
    local best = nil
    for _, l in ipairs(SurvivorShopClient.listings or {}) do
        if l and tostring(l.itemType or "") == tostring(fullType) then
            local qty = math.floor(tonumber(l.quantity) or 0)
            if qty > 0 and (not _ss_isListingExpired(l)) then
                if not best then best = l
                else
                    local pa, pb = tonumber(l.price) or 0, tonumber(best.price) or 0
                    if pa < pb then best = l end
                end
            end
        end
    end
    return best
end

local function _ss_buyCheapestListing(fullType, qty, ui)
    local cheapest = _ss_favCheapestListing(fullType)
    if not cheapest or not cheapest.id then
        local msg = SS_T("IGUI_SS_NoListingsForItem","No listings available for this item right now.")
        if ui and ui.showToast then
            ui.showToast(msg)
        elseif SurvivorShopUI.instance and SurvivorShopUI.instance.showToast then
            SurvivorShopUI.instance.showToast(msg)
        end
        return false
    end

    local maxQty = math.max(1, math.floor(tonumber(cheapest.quantity) or 1))
    local buyQty = math.floor(tonumber(qty) or 1)
    if buyQty < 1 then buyQty = 1 end
    if buyQty > maxQty then buyQty = maxQty end
    local price = math.max(0, tonumber(cheapest.price) or 0)
    local balance = math.max(0, tonumber(SurvivorShopClient and SurvivorShopClient.balance) or 0)
    local totalCost = price * buyQty
    if balance < totalCost then
        local msg = SS_T("IGUI_SS_NoFunds","No funds")
        if ui and ui.showToast then
            ui.showToast(msg)
        elseif SurvivorShopUI.instance and SurvivorShopUI.instance.showToast then
            SurvivorShopUI.instance.showToast(msg)
        end
        return false
    end

    SurvivorShopClient.buy(cheapest.id, buyQty)
    return true
end

local function SS_onPagerNoop() end

-- Listing fee (sandbox-configured). Client-side read; server remains authoritative.
local function SS_getListingFeePercent()
    local v = 0
    if SandboxVars and SandboxVars.SurvivorShop and SandboxVars.SurvivorShop.ListingFeePercent ~= nil then
        v = tonumber(SandboxVars.SurvivorShop.ListingFeePercent) or 0
    elseif getSandboxOptions then
        local so = getSandboxOptions()
        if so and so.getOptionByName then
            local opt = so:getOptionByName("SurvivorShop.ListingFeePercent")
            if opt and opt.getValue then
                v = tonumber(opt:getValue()) or 0
            end
        end
    end
    if v < 0 then v = 0 end
    if v > 100 then v = 100 end
    return math.floor(v + 0.5)
end

local function SS_calcListingFee(totalPrice)
    local gross = math.max(0, math.floor(tonumber(totalPrice) or 0))
    local feePct = SS_getListingFeePercent()
    if feePct <= 0 or gross <= 0 then return 0 end
    local fee = math.floor(gross * (feePct / 100.0))
    if fee < 1 then fee = 1 end
    return fee
end

local function SS_clampInt(value, minValue, maxValue)
    local n = math.floor(tonumber(value) or 0)
    if minValue ~= nil and n < minValue then n = minValue end
    if maxValue ~= nil and n > maxValue then n = maxValue end
    return n
end

local function SS_setLabelColor(lbl, color)
    if not lbl or not color then return end
    lbl:setColor(color.r or 1, color.g or 1, color.b or 1, color.a or 1)
end

local function SS_styleField(entry)
    SurvivorShopUITheme.styleTextEntry(entry)
    if entry and entry.setMasked then entry:setMasked(false) end
end

local function SS_styleNumericField(entry, opts)
    SS_styleField(entry)
    if not entry then return end
    opts = opts or {}
    entry.font = UIFont.Small
    if entry.javaObject then
        if entry.javaObject.setFont then
            entry.javaObject:setFont(UIFont.Small)
        end
        if entry.javaObject.setCentreVertically then
            entry.javaObject:setCentreVertically(true)
        elseif entry.javaObject.setCenterVertically then
            entry.javaObject:setCenterVertically(true)
        end
    end
    if opts.centerWhenBlurred and not entry._ssNumericCenterPatched then
        -- B42 UITextBox2 doesn't expose a safe writable backing text field to Lua.
        -- The previous render hook mutated javaObject.internalText/text and caused
        -- runtime errors in the client render loop. Keep native rendering here.
        entry._ssNumericCenterPatched = true
    end
end

local function SS_drawListViewChrome(panel, listY)
    local w = panel.width
    local pad = panel._pad or 10
    local topH = (listY and listY > 28) and math.max(44, listY - 4) or 0
    SurvivorShopUITheme.drawSoftPanel(panel, 0, 0, w, panel.height)
    if topH > 18 then
        SurvivorShopUITheme.drawSoftPanel(panel, 6, 6, w - 12, topH - 6)
    end

    local listStartY = math.max(0, listY or 0)
    local listH = panel.height - listStartY
    if listH > 20 then
        SurvivorShopUITheme.drawSoftPanel(panel, 6, listStartY, w - 12, listH - 6)
        panel:drawRect(8, listStartY + 1, w - 16, 22, 0.04, 1, 1, 1)
    end

    if topH > 18 then
        panel:drawRect(pad, topH - 8, w - pad * 2, 1, 0.05, 1, 1, 1)
    end
end










-- ===== SurvivorShopUI helpers (UI-only) =====
local function SS_stripUnknownPrefix(s)
    if not s then return "" end
    if type(s) ~= "string" then s = tostring(s) end
    -- Alguns itens chegam como "? Nome" ou com espaços antes do "?".
    s = s:gsub("^%s*", "")
    s = s:gsub("^[%?]+%s*", "")
    s = s:gsub("^[^%w%.]+", "")
    return s
end

SurvivorShopUI = ISPanel:derive("SurvivorShopUI")
-- ===== Expiration helpers (client/UI) =====
local function SS_formatRemaining(sec)
    sec = math.max(0, math.floor(tonumber(sec) or 0))
    local d = math.floor(sec / 86400); sec = sec % 86400
    local h = math.floor(sec / 3600);  sec = sec % 3600
    local m = math.floor(sec / 60)
    return tostring(d) .. "d " .. string.format("%02dh %02dm", h, m)
end

local function SS_getExpiresAt(l)
    if not l then return nil end
    local ex = tonumber(l.expiresAt)
    if ex and ex > 0 then return ex end
    -- Fallback:if expiresAt wasn't copied into UI rows, compute from created.
    local cr = tonumber(l.created)
    if cr and cr > 0 then
        return cr + (7 * 24 * 60 * 60)
    end
    return nil
end

function SurvivorShopUI.isListingExpired(l)
    if not l then return false end
    if l.expired == true then return true end
    local ex = SS_getExpiresAt(l)
    return ex and ex > 0 and os.time() >= ex
end

function SurvivorShopUI.getListingRemainingText(l)
    if not l then return "" end
    local ex = SS_getExpiresAt(l)
    if not ex or ex <= 0 then return "" end
    local rem = ex - os.time()
    if rem <= 0 or l.expired == true then
        return SS_T("IGUI_SS_Expired","EXPIRADO")
    end
    return SS_formatOneArg(SS_T("IGUI_SS_ExpiresIn","Expira em:%1"), SS_formatRemaining(rem))
end

function SurvivorShopUI.getListingRemainingShort(l)
    if not l then return "" end
    local ex = SS_getExpiresAt(l)
    if not ex or ex <= 0 then return "" end
    local rem = ex - os.time()
    if rem <= 0 or l.expired == true then
        return SS_T("IGUI_SS_Expired","EXPIRADO")
    end
    return SS_formatRemaining(rem)
end

SurvivorShopUI.instance = nil

-- Stable internal tab keys (do NOT localize)
SurvivorShopUI.TAB_BROWSE = "browse"
SurvivorShopUI.TAB_SELL   = "sell"
SurvivorShopUI.TAB_MY     = "my"
SurvivorShopUI.TAB_FAV    = "fav"



-- ========= UI helpers (icons, clipping, equipped filter) =========
SurvivorShopUI._texCache = SurvivorShopUI._texCache or {}
SurvivorShopUI._scriptCatCache = SurvivorShopUI._scriptCatCache or { categories=nil, typeToCat={} }

local function _ss_drawTextClipped(self, str, x, y, maxW, r,g,b,a, font)
    if not str then return end
    if maxW <= 0 then return end
    if self.drawTextClipped then
        self:drawTextClipped(str, x, y, maxW, r,g,b,a, font)
        return
    end
    -- fallback:truncate
    local s = tostring(str)
    local tm = getTextManager()
    local f = font or UIFont.Small
    if tm and tm.MeasureStringX then
        if tm:MeasureStringX(f, s) <= maxW then
            self:drawText(s, x, y, r,g,b,a, f)
            return
        end
        local t = s
        while #t > 0 and tm:MeasureStringX(f, t .. "...") > maxW do
            t = string.sub(t, 1, #t-1)
        end
        if #t > 0 and t ~= s then t = t .. "..." end
        self:drawText(t, x, y, r,g,b,a, f)
        return
    end
    self:drawText(s, x, y, r,g,b,a, f)
end

function SurvivorShopUI.getItemTex(fullType)
    if not fullType then return nil end
    local key = tostring(fullType)
    local cached = SurvivorShopUI._texCache[key]
    if cached ~= nil then return (cached ~= false) and cached or nil end

    local tex = nil
    if InventoryItemFactory and InventoryItemFactory.CreateItem then
        local it = InventoryItemFactory.CreateItem(key)
        if it then
            if it.getTex then tex = it:getTex() end
            if (not tex) and it.getTexture then tex = it:getTexture() end
        end
    end
    if (not tex) and getScriptManager then
        local sm = getScriptManager()
        if sm and sm.FindItem then
            local script = sm:FindItem(key)
            if script and script.getNormalTexture then tex = script:getNormalTexture() end
        end
    end
    SurvivorShopUI._texCache[key] = tex or false
    return tex
end

function SurvivorShopUI.isEquippedByPlayer(playerObj, invItem)
    if (not playerObj) or (not invItem) then return false end

    if playerObj.getPrimaryHandItem and playerObj:getPrimaryHandItem() == invItem then return true end
    if playerObj.getSecondaryHandItem and playerObj:getSecondaryHandItem() == invItem then return true end

    if playerObj.getWornItems then
        local worn = playerObj:getWornItems()
        if worn and worn.size then
            for i=0, worn:size()-1 do
                local wi = worn:get(i)
                if wi and wi.getItem and wi:getItem() == invItem then return true end
            end
        end
    end

    if playerObj.getAttachedItems then
        local att = playerObj:getAttachedItems()
        if att and att.size then
            for i=0, att:size()-1 do
                local ai = att:get(i)
                if ai and ai.getItem and ai:getItem() == invItem then return true end
            end
        end
    end

    -- Check for B42 applied medical items (virtual items representing limb dressings)
    if invItem.getFullType then
        local ft = invItem:getFullType()
        if ft:find("Bandage_") or ft:find("AlcoholBandage_") or ft:find("DenimStripBandage_") or ft:find("LeatherStripBandage_") or ft:find("Splint_") then
            return true
        end
    end

    return false
end


local function _ss_isBannedSellType(fullType)
    if not fullType then return false end
    return string.lower(tostring(fullType)) == "base.keyring"
end



-- ==== Helpers (UI) ====
local function _setBtnEnabled(btn, enabled)
    if not btn then return end
    enabled = enabled and true or false
    -- ISButton in B42 supports setEnable(); keep fallback for safety
    if btn.setEnable then btn:setEnable(enabled) end
    btn.enable = enabled
    -- visual:slightly dim when disabled (safe no-op if fields missing)
    if btn.backgroundColor then
        btn.backgroundColor.a = enabled and (btn.backgroundColor.a or 1) or 0.2
    end
end

-- ==== DisplayCategory helpers (B42) ====
SurvivorShopUI._displayCatCache = SurvivorShopUI._displayCatCache or { categories = nil, byType = {} }

function SurvivorShopUI.getItemDisplayCategory(itemType)
    if not itemType then return "" end
    itemType = tostring(itemType)
    local cache = SurvivorShopUI._displayCatCache
    if cache.byType[itemType] ~= nil then return cache.byType[itemType] end

    local cat = ""
    local sm = getScriptManager()
    local script = nil
    if sm then
        if sm.FindItem then script = sm:FindItem(itemType)
        elseif sm.findItem then script = sm:findItem(itemType)
        end
    end
    if script then
        if script.getDisplayCategory then cat = script:getDisplayCategory() end
        if (not cat or cat == "") and script.getCategory then cat = script:getCategory() end
    end
    cat = tostring(cat or "")
    cache.byType[itemType] = cat
    return cat
end

function SurvivorShopUI.getAllDisplayCategories()
    local cache = SurvivorShopUI._displayCatCache
    if cache.categories then return cache.categories end

    local seen, out = {}, {}
    local sm = getScriptManager()
    local all = sm and sm.getAllItems and sm:getAllItems()

    local function addCat(cat)
        cat = tostring(cat or "")
        if cat ~= "" and not seen[cat] then
            seen[cat] = true
            out[#out+1] = cat
        end
    end

    if all then
        if type(all) == "table" then
            for _, it in pairs(all) do
                if it and it.getDisplayCategory then addCat(it:getDisplayCategory()) end
            end
        elseif all.size and all.get then
            for i = 0, all:size()-1 do
                local it = all:get(i)
                if it and it.getDisplayCategory then addCat(it:getDisplayCategory()) end
            end
        end
    end

    table.sort(out, function(a,b) return tostring(a) < tostring(b) end)
    cache.categories = out
    return out
end


function SurvivorShopUI:new(x, y, width, height)
    local o = ISPanel:new(x, y, width, height)
    setmetatable(o, self)
    self.__index = self

    o.backgroundColor = SurvivorShopUITheme.Colors.panelBg
    o.borderColor = SurvivorShopUITheme.Colors.panelBorder
    o.moveWithMouse = true
    o.headerH = 56
    o._theme = SurvivorShopUITheme

    return o
end


local function safeGetPlayerFromArg(arg)
    if arg and type(arg) == "userdata" then return arg end
    local idx = tonumber(arg)
    if idx ~= nil then
        local p = getSpecificPlayer(idx)
        if p then return p end
    end
    return getPlayer()
end

local function invCollect(container, out)
    if not container then return end
    local items = container:getItems()
    for i=0, items:size()-1 do
        local it = items:get(i)
        if it then
            out[#out+1] = it
            if it.getInventory and it:getInventory() then
                invCollect(it:getInventory(), out)
            end
        end
    end
end

-- FIX CRÍTICO:
-- ISScrollingListBox exige que doDrawItem RETORNE o próximo y (senão dá __sub spam no prerender).
function SurvivorShopUI.doDrawItem(self, y, row, alt)
local h = tonumber(row.height) or tonumber(self.itemheight) or 24
local w = self:getWidth()
local vscrollW = ((self.vscroll and self.vscroll.width) or 0)
local usableW = w - vscrollW
local kind = row.item and row.item.kind or nil

local c = SurvivorShopUITheme.Colors

-- hover row detection (safe)
    local isHover = false
    if self and self.isMouseOver and self.rowAt and getMouseX and getMouseY then
        if self:isMouseOver() then
            local mx = getMouseX() - self:getAbsoluteX()
            local my = getMouseY() - self:getAbsoluteY()
            local r = self:rowAt(mx, my)
            if r == row.index then isHover = true end
        end
    end

local bg = alt and c.listAltBg or c.listBg
if isHover then bg = c.listHover end
if self.selected == row.index then bg = c.listSelected end

local cardX = 4
local cardY = y + 2
local cardW = usableW - 8
local cardH = h - 4
local accent = c.headerLine
if kind == "group" then accent = c.headerAccent end
if kind == "listing" then accent = c.btnSuccessBorder end
if kind == "sell" then accent = c.headerAccentSoft end
if kind == "my" then accent = c.btnInfoOver end

self:drawRect(cardX + 2, cardY + 3, cardW, cardH, 0.10, 0, 0, 0)
self:drawRect(cardX, cardY, cardW, cardH, bg.a, bg.r, bg.g, bg.b)
self:drawRectBorder(cardX, cardY, cardW, cardH, 0.55, c.panelBorder.r, c.panelBorder.g, c.panelBorder.b)
self:drawRect(cardX, cardY, 3, cardH, 0.95, accent.r, accent.g, accent.b)

    local text = SS_stripUnknownPrefix(tostring(row.text or ""))
    local sub = ""
    local subTimeSuffix = ""
    local groupActionText = nil
    local groupQuickBuy = nil
    local groupControlW = 0

    if row.item and type(row.item) == "table" then
        if kind == "group" then
            local g = row.item
            groupActionText = (g.expanded == true) and SS_T("IGUI_SS_ClickCollapse","Clique para recolher") or SS_T("IGUI_SS_ClickExpand","Clique para expandir")
            groupQuickBuy = _ss_favCheapestListing(tostring(g.itemType or ""))
            groupControlW = 132
            sub = SS_T("IGUI_SS_Total","Total") .. ": " .. tostring(g.quantity or 0) .. " | A partir de $" .. tostring(g.minPrice or 0)
        else
            local it = row.item
            sub = SS_T("IGUI_SS_Qty","Qtd") .. ": " .. tostring(it.quantity or 0)

            if it.sellerName and it.sellerName ~= "" then
                local sellerTxt = tostring(it.sellerName)
                local remShort = SurvivorShopUI.getListingRemainingShort(it)
                if remShort and remShort ~= "" then
                    subTimeSuffix = " (" .. remShort .. ")"
                end
                sub = sub .. " | " .. SS_T("IGUI_SS_Seller","Vendedor") .. ": " .. sellerTxt
            end
        end
    end

        -- Indent + icons + clipping
    local isCompact = (kind == "sell" or kind == "my")
    local iconSize = isCompact and 22 or 28
    if kind == "group" then iconSize = 26 end
    if kind == "listing" then iconSize = 24 end

    local xIcon = 8
    if kind == "listing" then xIcon = 14 end
    local xText = 10

    local itemType = (row.item and row.item.itemType) or row.itemType or row.fullType or nil
    local tex = SurvivorShopUI.getItemTex(itemType)

    if tex then
        local iy = y + (h - iconSize) / 2
        if self.drawTextureScaledAspect then
            self:drawTextureScaledAspect(tex, xIcon, iy, iconSize, iconSize, 1, 1, 1, 1)
        elseif self.drawTextureScaled then
            self:drawTextureScaled(tex, xIcon, iy, iconSize, iconSize, 1, 1, 1, 1)
        else
            self:drawTexture(tex, xIcon, iy, 1, 1, 1, 1)
        end
        xText = xIcon + iconSize + 8
    end
    -- Favorite star (Browse/Favorites):click to add/remove favorite
    if (kind == "group" or kind == "listing" or kind == "fav") and row.item and row.item.itemType and SurvivorShopUI.instance then
        local ft = tostring(row.item.itemType)
        local starW, starH = 18, 18
        local sx = xText
        local sy = y + math.floor((h - starH) / 2)

        SurvivorShopUI._texStarOn  = SurvivorShopUI._texStarOn  or getTexture("media/ui/SurvivorShop_star_on.png")
        SurvivorShopUI._texStarOff = SurvivorShopUI._texStarOff or getTexture("media/ui/SurvivorShop_star_off.png")

        local isFav = SurvivorShopUI.instance:isFavorite(ft)
        local texStar = isFav and SurvivorShopUI._texStarOn or SurvivorShopUI._texStarOff
        if texStar then
            self:drawTextureScaled(texStar, sx, sy, starW, starH, 1)
        end

        row.item._ui = row.item._ui or {}
        row.item._ui.star = { x = sx, y = sy, w = starW, h = starH }

        -- shift text to the right so it doesn't overlap the star
        xText = sx + starW + 8
    end

    if row.item and type(row.item) == "table" then
        row.item._ui = row.item._ui or {}
        row.item._ui.quickBuy = nil
    end

    -- compact layout for Sell/My:put Qtd beside the name to reduce row height
    if isCompact then
        local qty = (row.item and row.item.quantity) or 0
        local nm = SS_stripUnknownPrefix(tostring((row.item and row.item.name) or row.text or ""))
        text = nm .. "  " .. SS_T("IGUI_SS_Qty","Qty") .. ": " .. tostring(qty)
        if kind == "my" and row.item and row.item.price ~= nil then
            text = text .. "  $" .. tostring(row.item.price)
        end
        sub = ""
    end

    -- reserve space on the right for inline controls (listing)
    local clipW = usableW - xText - 14
    if kind == "listing" and row.item and row.item.price then
        local priceStr = "$" .. tostring(row.item.price)
        local priceW = 60
        if getTextManager then
            local tm = getTextManager()
            if tm and tm.MeasureStringX then
                priceW = tm:MeasureStringX(UIFont.Medium, priceStr) + 12
            end
        end
        local reservedRight = (120 + 8 + priceW) + 18
        clipW = usableW - xText - reservedRight
        if clipW < 60 then clipW = usableW - xText - 14 end
    end
    if kind == "group" and groupControlW > 0 then
        local reservedRight = groupControlW + 14
        clipW = usableW - xText - reservedRight
        if clipW < 80 then clipW = usableW - xText - 14 end
    end

    local titleColor = c.normalText
    if kind == "group" then titleColor = c.titleText end
    _ss_drawTextClipped(self, SS_stripUnknownPrefix(text), xText, y + 7, clipW, titleColor.r, titleColor.g, titleColor.b, titleColor.a, UIFont.Medium)
    if sub ~= "" and not isCompact then
        local topPad, bottomPad = 8, 14
        local mediumH = getTextManager():getFontHeight(UIFont.Medium)
        local smallH  = getTextManager():getFontHeight(UIFont.Small)
        local subY = y + h - smallH - bottomPad
        local minSubY = y + topPad + mediumH + 2
        if subY < minSubY then subY = minSubY end
        local maxSubY = y + h - smallH - 2
        if subY > maxSubY then subY = maxSubY end
        local subW = clipW
        local suffix = (kind == "listing") and (subTimeSuffix or "") or ""
        local suffixW = 0
        if suffix ~= "" and getTextManager then
            local tm = getTextManager()
            if tm and tm.MeasureStringX then
                suffixW = tm:MeasureStringX(UIFont.Small, suffix)
            end
        end
        if suffixW > 0 and (suffixW + 10) < clipW then
            subW = clipW - suffixW - 10
            if subW < 80 then subW = clipW end
        end

        _ss_drawTextClipped(self, sub, xText, subY, subW, c.dimText.r, c.dimText.g, c.dimText.b, c.dimText.a, UIFont.Small)

        if kind == "group" and row.item and groupActionText and groupActionText ~= "" then
            local groupBuyLabel = SS_T("IGUI_SS_Buy","Buy")
            local buyW = 72
            local buyH = 20
            local columnX = usableW - 10 - groupControlW
            local actionY = y + 8
            local buyX = usableW - 10 - buyW
            local buyY = subY - 2
            if buyY < (y + 4) then buyY = y + 4 end

            local isAvailable = groupQuickBuy ~= nil
            local fill = isAvailable and c.btnSuccess or c.btnDark
            local border = isAvailable and c.btnSuccessBorder or c.panelBorder
            local alpha = isAvailable and 0.88 or 0.36
            self:drawRect(buyX + 1, buyY + 1, buyW, buyH, 0.10, 0, 0, 0)
            self:drawRect(buyX, buyY, buyW, buyH, alpha, fill.r, fill.g, fill.b)
            self:drawRectBorder(buyX, buyY, buyW, buyH, 0.78, border.r, border.g, border.b)
            self:drawTextCentre(groupBuyLabel, buyX + (buyW / 2), buyY + math.floor((buyH - getTextManager():getFontHeight(UIFont.Small)) / 2), 1, 1, 1, isAvailable and 1 or 0.75, UIFont.Small)

            row.item._ui.quickBuy = { x = buyX, y = buyY, w = buyW, h = buyH, enabled = isAvailable }

            _ss_drawTextClipped(self, groupActionText, columnX, actionY, groupControlW, c.dimText.r, c.dimText.g, c.dimText.b, c.dimText.a, UIFont.Small)
        end

        if suffixW > 0 and subW < clipW then
            local sx = xText + subW + 10
            local sw = clipW - subW - 10
            if sw < 10 then sw = 10 end
            -- vermelho (timer)
            _ss_drawTextClipped(self, suffix, sx, subY, sw, 0.95, 0.25, 0.25, 1, UIFont.Small)
        end
    end

if row.item and row.item.price and kind == "listing" then
        local it = row.item

        -- qty (per-row) para compra via +/-
        local maxQty = math.max(1, math.floor(tonumber(it.quantity) or 1))
        it.buyQty = math.max(1, math.floor(tonumber(it.buyQty) or 1))
        if it.buyQty > maxQty then it.buyQty = maxQty end

        -- layout (2 linhas):topo = [Comprar] [$Preço]; baixo = [-][Qtd][+]
        local pad = 6
        local gap = 8

        local buyW, buyH = 120, 28
        local qtyH = 22
        local minusW, plusW = 24, 24
        local qtyW = 44

        local priceStr = "$" .. tostring(it.price)
        local priceFont = UIFont.Large
        local priceW = 70
        if getTextManager then
            local tm = getTextManager()
            if tm and tm.MeasureStringX then
                priceW = tm:MeasureStringX(priceFont, priceStr) + 14
            end
        end

        local topY = y + pad
        local qtyY = topY + buyH + 6

        -- right aligned price
        local px = usableW - 10 - priceW
        local bx = px - gap - buyW

        -- BUY button state (UI only):verde quando tem saldo, vermelho quando não tem
        local bal = tonumber(SurvivorShopClient and SurvivorShopClient.balance) or 0
        local totalCost = (tonumber(it.price) or 0) * (tonumber(it.buyQty) or 1)
        local canBuy = bal >= totalCost

        -- draw helpers
        local function drawBtn(rx, label, enabled, r, g, b, a)
            local aa = a or 0.55
            if not enabled then aa = 0.25 end
            self:drawRect(rx + 1, topY + 2, buyW, buyH, 0.10, 0, 0, 0)
            self:drawRect(rx, topY, buyW, buyH, aa, r, g, b)
            self:drawRectBorder(rx, topY, buyW, buyH, 0.55, c.panelBorder.r, c.panelBorder.g, c.panelBorder.b)
            self:drawTextCentre(label, rx + buyW/2, topY + (buyH - getTextManager():getFontHeight(UIFont.Medium))/2, 1,1,1,1, UIFont.Medium)
        end

        -- price box
        self:drawRect(px + 1, topY + 2, priceW, buyH, 0.08, 0, 0, 0)
        self:drawRect(px, topY, priceW, buyH, 0.26, c.btnDark.r, c.btnDark.g, c.btnDark.b)
        self:drawRectBorder(px, topY, priceW, buyH, 0.65, c.panelBorder.r, c.panelBorder.g, c.panelBorder.b)
        self:drawTextCentre(priceStr, px + priceW/2, topY + (buyH - getTextManager():getFontHeight(priceFont))/2, 1,1,1,1, priceFont)

        -- buy button
        if canBuy then
            drawBtn(bx, SS_T("IGUI_SS_Buy","Comprar"), true, 0.18, 0.45, 0.25, 0.85)
        else
            drawBtn(bx, SS_T("IGUI_SS_NoFunds","No funds"), false, 0.55, 0.18, 0.18, 0.85)
        end

        -- qty controls (bottom line)
        local qx = bx
        -- minus
        self:drawRect(qx, qtyY, minusW, qtyH, 0.22, c.btnDark.r, c.btnDark.g, c.btnDark.b)
        self:drawRectBorder(qx, qtyY, minusW, qtyH, 0.8, c.panelBorder.r, c.panelBorder.g, c.panelBorder.b)
        self:drawTextCentre("-", qx + minusW/2, qtyY + (qtyH - getTextManager():getFontHeight(UIFont.Medium))/2, 1,1,1,1, UIFont.Medium)

        -- qty box
        local qtyStr = tostring(it.buyQty)
        local qbx = qx + minusW + 4
        self:drawRect(qbx, qtyY, qtyW, qtyH, 0.20, c.searchBg.r, c.searchBg.g, c.searchBg.b)
        self:drawRectBorder(qbx, qtyY, qtyW, qtyH, 0.8, 1,1,1)
        self:drawTextCentre(qtyStr, qbx + qtyW/2, qtyY + (qtyH - getTextManager():getFontHeight(UIFont.Medium))/2, 1,1,1,1, UIFont.Medium)

        -- plus
        local pbx = qbx + qtyW + 4
        self:drawRect(pbx, qtyY, plusW, qtyH, 0.22, c.btnDark.r, c.btnDark.g, c.btnDark.b)
        self:drawRectBorder(pbx, qtyY, plusW, qtyH, 0.8, c.panelBorder.r, c.panelBorder.g, c.panelBorder.b)
        self:drawTextCentre("+", pbx + plusW/2, qtyY + (qtyH - getTextManager():getFontHeight(UIFont.Medium))/2, 1,1,1,1, UIFont.Medium)

        -- hitboxes p/ clique (coords locais do listbox)
        it._ui = it._ui or {}
        it._ui.rowY = y
        it._ui.rowH = h
        it._ui.minus = { x=qx, y=qtyY, w=minusW, h=qtyH }
        it._ui.qtyBox = { x=qbx, y=qtyY, w=qtyW, h=qtyH }
        it._ui.plus  = { x=pbx, y=qtyY, w=plusW, h=qtyH }
        it._ui.buy   = { x=bx, y=topY, w=buyW, h=buyH }
    end

    return y + h
end


local DetailsPanel = ISPanel:derive("SurvivorShopDetailsPanel")

function DetailsPanel:initialise() ISPanel.initialise(self) end

function DetailsPanel:createChildren()
    ISPanel.createChildren(self)
    local pad = 12

    self._iconSize = 44
    local topY = pad + self._iconSize + 6
    -- Action buttons positioned below stats label (which can now have ~8 lines)
    -- statsLabel starts at topY+84, height=160 → bottom at topY+244 → buttons at topY+252
    local actionY = topY + 252

    self.title = ISLabel:new(pad, topY, 20, SS_T("IGUI_SS_SelectItem","Selecione um item"), 1,1,1,1, UIFont.Medium, true)
    self:addChild(self.title)
    self._rawTitle = SS_T("IGUI_SS_SelectItem","Selecione um item")

    self.sub = ISLabel:new(pad, topY + 28, 20, "", 0.75,0.75,0.75,1, UIFont.Small, true)
    self:addChild(self.sub)
    self._rawSub = ""

    self.timer = ISLabel:new(pad, topY + 54, 20, "", 0.95,0.25,0.25,1, UIFont.Small, true)
    self:addChild(self.timer)

    -- Stats labels (multi-cor por linha: cada linha é um ISLabel separado)
    -- Criados dinamicamente em updateDetails(); aqui apenas reservamos o espaço.
    -- _statsLineHeight: altura em px por linha de UIFont.Small (~16px)
    self._statsStartY    = topY + 84
    self._statsLineH     = 18
    self._statsMaxLines  = 12
    self._statsLineCount = 0
    self._statsLabels    = {}   -- tabela de ISLabel reutilizáveis
    self._statsPad       = pad
    for i = 1, self._statsMaxLines do
        local lbl = ISLabel:new(pad, self._statsStartY + (i-1)*self._statsLineH, self._statsLineH, "", 1,1,1,1, UIFont.Small, true)
        lbl:setVisible(false)
        self:addChild(lbl)
        self._statsLabels[i] = lbl
    end

    -- Labels for input fields (Quantity/Price) using theme colors
    local c = SurvivorShopUITheme.Colors
    self.qtyLabel = ISLabel:new(pad, actionY - 18, 16, SS_T("IGUI_SS_Quantity_Label", "Quantity"), c.dimText.r, c.dimText.g, c.dimText.b, c.dimText.a, UIFont.Small, true)
    self:addChild(self.qtyLabel)
    self.priceLabel = ISLabel:new(pad + 112, actionY - 18, 16, SS_T("IGUI_SS_UnitPrice_Label", "Unit price ($)"), c.dimText.r, c.dimText.g, c.dimText.b, c.dimText.a, UIFont.Small, true)
    self:addChild(self.priceLabel)
    self.actionCaption = ISLabel:new(pad, actionY - 42, 18, "", c.dimText.r, c.dimText.g, c.dimText.b, 0.95, UIFont.Small, true)
    self:addChild(self.actionCaption)

    -- Botão X (fecha o painel do Bank quando aberto)
    self.bankCloseBtn = ISButton:new(self.width - pad - 24, pad, 24, 24, "X", self, DetailsPanel.onCloseBank)
    self.bankCloseBtn:initialise(); self.bankCloseBtn:instantiate(); self:addChild(self.bankCloseBtn)
    SurvivorShopUITheme.styleButton(self.bankCloseBtn, "dangerTiny")

    -- Browse
    self.buyQty = ISTextEntryBox:new("1", pad, actionY, 60, 22); self:addChild(self.buyQty)
    -- numeric qty entry (also used when editing inline qty in Browse list)
if self.buyQty and self.buyQty.setOnlyNumbers then self.buyQty:setOnlyNumbers(true) end
if self.buyQty and self.buyQty.setMaxChars then self.buyQty:setMaxChars(3) end
    self.buyQty.onTextChange = function()
        local v = tonumber(self.buyQty:getText()) or 1
        v = math.floor(v)
        if v < 1 then v = 1 end
        -- update inline listing qty if we are editing one
        if SurvivorShopUI.instance and SurvivorShopUI.instance._inlineQtyEditingItem then
            local it = SurvivorShopUI.instance._inlineQtyEditingItem
            local maxQty = math.max(1, math.floor(tonumber(it.quantity) or 1))
            if v > maxQty then v = maxQty end
            it.buyQty = v
            -- keep entry clamped
            if tostring(v) ~= self.buyQty:getText() then
                self.buyQty:setText(tostring(v))
            end
        end
    end
    self.buyBtn = ISButton:new(pad + 70, actionY, 120, 22, SS_T("IGUI_SS_Buy","Comprar"), self, DetailsPanel.onBuy); self:addChild(self.buyBtn)
    SS_styleNumericField(self.buyQty, { centerWhenBlurred = true })
    SurvivorShopUITheme.styleButton(self.buyBtn, "success")

    -- My Listings
    self.cancelBtn = ISButton:new(pad, actionY, 180, 22, SS_T("IGUI_SS_CancelListing","Cancelar anúncio"), self, DetailsPanel.onCancel); self:addChild(self.cancelBtn)

    SurvivorShopUITheme.styleButton(self.cancelBtn, "warning")

    -- Sell
    self.sellQtyDec = ISButton:new(pad, actionY, 24, 22, "-", self, DetailsPanel.onSellQtyDec); self:addChild(self.sellQtyDec)
    self.sellQty = ISTextEntryBox:new("1", pad + 28, actionY, 24, 22); self:addChild(self.sellQty)
    self.sellQtyInc = ISButton:new(pad + 56, actionY, 24, 22, "+", self, DetailsPanel.onSellQtyInc); self:addChild(self.sellQtyInc)
    if self.sellQty and self.sellQty.setOnlyNumbers then self.sellQty:setOnlyNumbers(true) end
    if self.sellQty and self.sellQty.setMaxChars then self.sellQty:setMaxChars(3) end
    self.sellPrice = ISTextEntryBox:new("10", pad + 96, actionY, 84, 22); self:addChild(self.sellPrice)
    if self.sellPrice and self.sellPrice.setOnlyNumbers then self.sellPrice:setOnlyNumbers(true) end
    if self.sellPrice and self.sellPrice.setMaxChars then self.sellPrice:setMaxChars(9) end
    self.sellBtn = ISButton:new(pad, actionY + 30, self.width - pad*2, 24, SS_T("IGUI_SS_Sell","Anunciar"), self, DetailsPanel.onSell); self:addChild(self.sellBtn)
    SurvivorShopUITheme.styleButton(self.sellQtyDec, "default")
    SurvivorShopUITheme.styleButton(self.sellQtyInc, "default")
    SurvivorShopUITheme.styleButton(self.sellBtn, "success")
    SS_styleNumericField(self.sellQty, { centerWhenBlurred = true })
    SS_styleNumericField(self.sellPrice)

    self.sellPreviewGross = ISLabel:new(pad, actionY + 60, 18, "", 0.9,0.9,0.9,1, UIFont.Small, true); self:addChild(self.sellPreviewGross)
    self.feeWarn1 = ISLabel:new(pad, actionY + 76, 18, "", c.dangerText.r, c.dangerText.g, c.dangerText.b, 1, UIFont.Small, true); self:addChild(self.feeWarn1)
    self.feeWarn2 = ISLabel:new(pad, actionY + 94, 18, "", c.successText.r, c.successText.g, c.successText.b, 1, UIFont.Small, true); self:addChild(self.feeWarn2)
    self.sellQty.onTextChange = function() if self.updateSellPreview then self:updateSellPreview() end end
    self.sellPrice.onTextChange = function() if self.updateSellPreview then self:updateSellPreview() end end
    -- Bank (fica no “painel da direita”, que é onde o Server Shop mostra veículos)
    self.bankBal = ISLabel:new(pad, actionY, 20, SS_T("IGUI_SS_Balance","Saldo:$%1"):gsub("%%1","0"), 1,1,1,1, UIFont.Medium, true); self:addChild(self.bankBal)
    self.depEntry = ISTextEntryBox:new("100", pad, pad + 92, 80, 22); self:addChild(self.depEntry)
    self.depBtn   = ISButton:new(pad + 90, pad + 92, 120, 22, SS_T("IGUI_SS_Deposit","Depositar"), self, DetailsPanel.onDeposit); self:addChild(self.depBtn)
    self.wdEntry = ISTextEntryBox:new("100", pad, pad + 124, 80, 22); self:addChild(self.wdEntry)
    self.wdBtn   = ISButton:new(pad + 90, pad + 124, 120, 22, SS_T("IGUI_SS_Withdraw","Sacar"), self, DetailsPanel.onWithdraw); self:addChild(self.wdBtn)

    self:refreshLayout()
    self:syncVisible()
end

function DetailsPanel:refreshLayout()
    local pad = 12
    local innerW = self.width - pad * 2
    local iconSize = self._iconSize or 44
    local tab = self.parentUI and self.parentUI.getActiveTabKey and self.parentUI:getActiveTabKey() or SurvivorShopUI.TAB_BROWSE
    local isSell = (tab == SurvivorShopUI.TAB_SELL)
    local isMy = (tab == SurvivorShopUI.TAB_MY)
    local statsLines = math.max(0, math.min(self._statsLineCount or 0, self._statsMaxLines or 12))
    local intelContentH = 18 + (statsLines * (self._statsLineH or 18)) + 18

    local L = {
        iconX = pad,
        iconY = 18,
        iconSize = iconSize,
        textX = pad + iconSize + 12,
        titleY = 20,
        subY = 50,
        intelTitleY = 104,
        intelCardY = 124,
        intelCardH = math.max(118, intelContentH),
    }

    L.timerY = 76
    L.statsStartY = L.intelCardY + 16
    L.actionTitleY = L.intelCardY + L.intelCardH + 18
    L.actionCardY = L.actionTitleY + 22
    L.actionCardH = math.max(isSell and 178 or (isMy and 118 or 132), self.height - L.actionCardY - 10)

    if isSell then
        L.actionCaptionY = L.actionCardY + 14
        L.labelY = L.actionCardY + 42
        L.controlY = L.actionCardY + 64
        L.buttonY = L.actionCardY + 102
        L.previewY = L.actionCardY + 142
    elseif isMy then
        L.actionCaptionY = L.actionCardY + 10
        L.labelY = L.actionCardY + 14
        L.controlY = L.actionCardY + 38
        L.buttonY = L.actionCardY + 70
        L.previewY = L.actionCardY + 100
    else
        L.actionCaptionY = L.actionCardY + 10
        L.labelY = L.actionCardY + 14
        L.controlY = L.actionCardY + 38
        L.buttonY = L.actionCardY + 72
        L.previewY = L.actionCardY + 102
    end

    self._layout = L

    if self.title then self.title:setX(L.textX); self.title:setY(L.titleY) end
    if self.sub then self.sub:setX(L.textX); self.sub:setY(L.subY) end
    if self.timer then self.timer:setX(pad); self.timer:setY(L.timerY) end
    if self.actionCaption then self.actionCaption:setX(pad); self.actionCaption:setY(L.actionCaptionY) end
    if self.qtyLabel then self.qtyLabel:setX(pad); self.qtyLabel:setY(L.labelY) end
    if self.priceLabel then self.priceLabel:setX(pad + 96); self.priceLabel:setY(L.labelY) end

    if self._statsLabels then
        for i, lbl in ipairs(self._statsLabels) do
            lbl:setX(pad)
            lbl:setY(L.statsStartY + (i - 1) * self._statsLineH)
        end
    end

    if self.buyQty then
        self.buyQty:setX(pad)
        self.buyQty:setY(L.controlY)
        self.buyQty:setWidth(34)
        SS_styleNumericField(self.buyQty, { centerWhenBlurred = true })
    end
    if self.buyBtn then
        self.buyBtn:setX(pad + 46)
        self.buyBtn:setY(L.controlY)
        self.buyBtn:setWidth(math.max(110, innerW - 46))
    end

    if self.cancelBtn then
        self.cancelBtn:setX(pad)
        self.cancelBtn:setY(L.controlY)
        self.cancelBtn:setWidth(innerW)
    end

    if self.sellQtyDec then self.sellQtyDec:setX(pad); self.sellQtyDec:setY(L.controlY); self.sellQtyDec:setWidth(24) end
    if self.sellQty then
        self.sellQty:setX(pad + 28)
        self.sellQty:setY(L.controlY)
        self.sellQty:setWidth(24)
        SS_styleNumericField(self.sellQty, { centerWhenBlurred = true })
    end
    if self.sellQtyInc then self.sellQtyInc:setX(pad + 56); self.sellQtyInc:setY(L.controlY); self.sellQtyInc:setWidth(24) end
    if self.sellPrice then
        self.sellPrice:setX(pad + 96)
        self.sellPrice:setY(L.controlY)
        self.sellPrice:setWidth(math.max(72, innerW - 96))
        SS_styleNumericField(self.sellPrice)
    end
    if self.sellBtn then
        self.sellBtn:setX(pad)
        self.sellBtn:setY(L.buttonY)
        self.sellBtn:setWidth(innerW)
    end
    if self.sellPreviewGross then self.sellPreviewGross:setX(pad); self.sellPreviewGross:setY(L.previewY) end
    if self.feeWarn1 then self.feeWarn1:setX(pad); self.feeWarn1:setY(L.previewY + 20) end
    if self.feeWarn2 then self.feeWarn2:setX(pad); self.feeWarn2:setY(L.previewY + 40) end
end

function DetailsPanel:setHeaderText(title, sub)
    self._rawTitle = tostring(title or "")
    self._rawSub = tostring(sub or "")
    if self.title then self.title:setName(self._rawTitle) end
    if self.sub then self.sub:setName(self._rawSub) end
    if self.refreshHeaderText then self:refreshHeaderText() end
end

function DetailsPanel:refreshHeaderText()
    local maxW = math.max(80, (self.width - (self._layout and self._layout.textX or 68) - 18))
    if self.title and SurvivorShopUITheme and SurvivorShopUITheme.truncateText then
        local rawTitle = tostring(self._rawTitle or self.title.name or "")
        self.title:setName(SurvivorShopUITheme.truncateText(rawTitle, maxW, self.title.font or UIFont.Medium))
    end
    if self.sub and SurvivorShopUITheme and SurvivorShopUITheme.truncateText then
        local rawSub = tostring(self._rawSub or self.sub.name or "")
        self.sub:setName(SurvivorShopUITheme.truncateText(rawSub, maxW, self.sub.font or UIFont.Small))
    end
end

function DetailsPanel:syncVisible()
    self:refreshLayout()
    local tab = self.parentUI:getActiveTabKey()
    local isSell = (tab == SurvivorShopUI.TAB_SELL)
    local isMy = (tab == SurvivorShopUI.TAB_MY)
    local isBrowse = (tab == SurvivorShopUI.TAB_BROWSE)
    local c = SurvivorShopUITheme.Colors


    -- Sell fee warning labels
    if self.sellPreviewGross then self.sellPreviewGross:setVisible(isSell) end
    if self.feeWarn1 then self.feeWarn1:setVisible(isSell) end
    if self.feeWarn2 then self.feeWarn2:setVisible(isSell) end
    -- Browse
    self.buyQty:setVisible(isBrowse)
    self.buyBtn:setVisible(isBrowse)

    if self.timer then self.timer:setVisible(isBrowse or isMy) end

    -- My Listings
    self.cancelBtn:setVisible(isMy)

    -- Sell
    if self.sellQtyDec then self.sellQtyDec:setVisible(isSell) end
    self.sellQty:setVisible(isSell)
    if self.sellQtyInc then self.sellQtyInc:setVisible(isSell) end
    self.sellPrice:setVisible(isSell)
    self.sellBtn:setVisible(isSell)

    -- Shared Labels (Quantity / Price)
    if self.qtyLabel then self.qtyLabel:setVisible(isSell or isBrowse) end
    if self.priceLabel then self.priceLabel:setVisible(isSell) end
    if self.qtyLabel and isBrowse then self.qtyLabel:setName(SS_T("IGUI_SS_Qty", "Qty")) end
    if self.priceLabel and (not isSell) then self.priceLabel:setName(SS_T("IGUI_SS_UnitPrice_Label", "Unit price ($)")) end
    if self.actionCaption then self.actionCaption:setVisible(isSell) end
    if self.actionCaption then
        if isSell then
            self.actionCaption:setName(SS_T("IGUI_SS_SellActionCaption", "Available: -"))
            SS_setLabelColor(self.actionCaption, c.accentText)
        else
            self.actionCaption:setName("")
        end
    end

    -- Bank saiu do painel da direita (agora é um painel separado à direita da tela)
    self.bankBal:setVisible(false)
    self.depEntry:setVisible(false)
    self.depBtn:setVisible(false)
    self.wdEntry:setVisible(false)
    self.wdBtn:setVisible(false)
    if self.bankCloseBtn then self.bankCloseBtn:setVisible(false) end
end

function DetailsPanel.onCloseBank(self, btn)
    if self.parentUI and self.parentUI.closeBank then
        self.parentUI:closeBank()
    end
end

function DetailsPanel:onBuy()
    local row = self.parentUI.selectedRow
    if not row or not row.id then return end
    SurvivorShopClient.buy(row.id, self.buyQty:getText())
end

function DetailsPanel:onCancel()
    local row = self.parentUI.selectedRow
    if not row or not row.id then return end
    SurvivorShopClient.cancel(row.id)
end

function DetailsPanel:onSell()
    local row = self.parentUI.selectedRow
    if not row or not row.itemType then return end
    self:updateSellPreview()
    local qty = self:getSellQtyValue()
    local price = self:getSellUnitPriceValue()
    self:setSellQtyValue(qty)
    if self.sellPrice and tostring(price) ~= tostring(self.sellPrice:getText() or "") then
        self.sellPrice:setText(tostring(price))
    end
    SurvivorShopClient.listItem(row.itemType, qty, price, row.variantKey)
end

function DetailsPanel:getSellMaxQty()
    local row = self.parentUI and self.parentUI.selectedRow or nil
    return math.max(1, math.floor(tonumber(row and row.quantity) or 1))
end

function DetailsPanel:getSellQtyValue()
    local qty = SS_clampInt(self.sellQty and self.sellQty:getText() or 1, 1, self:getSellMaxQty())
    return qty
end

function DetailsPanel:getSellUnitPriceValue()
    local price = SS_clampInt(self.sellPrice and self.sellPrice:getText() or 0, 0, SurvivorShop.MAX_PRICE or 1000000)
    return price
end

function DetailsPanel:setSellQtyValue(value)
    local qty = SS_clampInt(value, 1, self:getSellMaxQty())
    if self.sellQty then
        if tostring(qty) ~= tostring(self.sellQty:getText() or "") then
            self.sellQty:setText(tostring(qty))
        end
    end
    return qty
end

function DetailsPanel:updateSellPreview()
    local row = self.parentUI and self.parentUI.selectedRow or nil
    local isSell = self.parentUI and self.parentUI.getActiveTabKey and self.parentUI:getActiveTabKey() == SurvivorShopUI.TAB_SELL
    if not isSell then return end

    if not row or not row.itemType then
        if self.qtyLabel then self.qtyLabel:setName(SS_T("IGUI_SS_Qty", "Qty")) end
        if self.priceLabel then self.priceLabel:setName(SS_T("IGUI_SS_UnitPrice_Label", "Unit price ($)")) end
        if self.sellPreviewGross then self.sellPreviewGross:setName("") end
        if self.feeWarn1 then self.feeWarn1:setName("") end
        if self.feeWarn2 then self.feeWarn2:setName("") end
        if self.actionCaption then
            self.actionCaption:setName(SS_T("IGUI_SS_SellActionCaption", "Available: -"))
            SS_setLabelColor(self.actionCaption, SurvivorShopUITheme.Colors.accentText)
        end
        if self.sellBtn and self.sellBtn.setTitle then
            self.sellBtn:setTitle(SS_T("IGUI_SS_Sell", "List"))
        elseif self.sellBtn then
            self.sellBtn.title = SS_T("IGUI_SS_Sell", "List")
        end
        return
    end

    local qty = self:setSellQtyValue(self.sellQty and self.sellQty:getText() or 1)
    local unitPrice = self:getSellUnitPriceValue()
    if self.sellPrice and tostring(unitPrice) ~= tostring(self.sellPrice:getText() or "") then
        self.sellPrice:setText(tostring(unitPrice))
    end

    local feePct = SS_getListingFeePercent()
    local gross = qty * unitPrice
    local fee = SS_calcListingFee(gross)
    local net = math.max(0, gross - fee)
    local available = math.max(1, math.floor(tonumber(row and row.quantity) or 1))

    if self.qtyLabel then
        self.qtyLabel:setName(SS_T("IGUI_SS_Qty", "Qty"))
    end

    if self.priceLabel then
        self.priceLabel:setName(SS_T("IGUI_SS_UnitPrice_Label", "Unit price ($)"))
    end

    if self.actionCaption then
        self.actionCaption:setName(SS_T("IGUI_SS_SellActionCaptionLive", "Available: %1")
            :gsub("%%1", tostring(available)))
        SS_setLabelColor(self.actionCaption, SurvivorShopUITheme.Colors.accentText)
    end

    if self.sellPreviewGross then
        self.sellPreviewGross:setName(SS_T("IGUI_SS_SellGrossPreviewShort", "Gross: $%1")
            :gsub("%%1", tostring(gross)))
        SS_setLabelColor(self.sellPreviewGross, SurvivorShopUITheme.Colors.normalText)
    end

    if self.feeWarn1 then
        self.feeWarn1:setName(SS_T("IGUI_SS_SellFeePreviewShort", "Listing fee (%1%%): -$%2")
            :gsub("%%1", tostring(feePct))
            :gsub("%%2", tostring(fee)))
        SS_setLabelColor(self.feeWarn1, SurvivorShopUITheme.Colors.dangerText)
    end

    if self.feeWarn2 then
        self.feeWarn2:setName(SS_T("IGUI_SS_SellNetPreviewShort", "You receive: $%1")
            :gsub("%%1", tostring(net)))
        SS_setLabelColor(self.feeWarn2, SurvivorShopUITheme.Colors.successText)
    end

    if self.sellBtn and self.sellBtn.setTitle then
        self.sellBtn:setTitle(SS_T("IGUI_SS_SellActionPreview", "List x%1"):gsub("%%1", tostring(qty)))
    elseif self.sellBtn then
        self.sellBtn.title = SS_T("IGUI_SS_SellActionPreview", "List x%1"):gsub("%%1", tostring(qty))
    end
end

function DetailsPanel:onSellQtyDec()
    self:setSellQtyValue(self:getSellQtyValue() - 1)
    self:updateSellPreview()
end

function DetailsPanel:onSellQtyInc()
    self:setSellQtyValue(self:getSellQtyValue() + 1)
    self:updateSellPreview()
end

function DetailsPanel:onDeposit()
    SurvivorShopClient.deposit(self.depEntry:getText())
end

function DetailsPanel:onWithdraw()
    SurvivorShopClient.withdraw(self.wdEntry:getText())
end

function DetailsPanel:prerender()
    ISPanel.prerender(self)
    local c = SurvivorShopUITheme.Colors
    local pad = 12
    local tab = self.parentUI and self.parentUI.getActiveTabKey and self.parentUI:getActiveTabKey() or SurvivorShopUI.TAB_BROWSE
    self:refreshLayout()
    local L = self._layout or {}

    SurvivorShopUITheme.drawSoftPanel(self, 0, 0, self.width, self.height)

    local cardX = 8
    local cardW = self.width - 16

    -- Top item summary card
    self:drawRect(cardX, 8, cardW, 92, 0.94, c.panelInset.r, c.panelInset.g, c.panelInset.b)
    self:drawRectBorder(cardX, 8, cardW, 92, 0.70, c.panelBorder.r, c.panelBorder.g, c.panelBorder.b)

    -- Intel section
    local intelTitleY = L.intelTitleY or 90
    local intelY = L.intelCardY or 112
    local intelH = L.intelCardH or 142
    self:drawText(SS_T("IGUI_SS_DetailSection", "Item details"), pad, intelTitleY, c.dimText.r, c.dimText.g, c.dimText.b, 0.95, UIFont.Small)
    self:drawRect(cardX, intelY, cardW, intelH, 0.92, c.listBg.r, c.listBg.g, c.listBg.b)
    self:drawRectBorder(cardX, intelY, cardW, intelH, 0.62, c.panelBorder.r, c.panelBorder.g, c.panelBorder.b)

    -- Action section
    local actionTitleY = L.actionTitleY or 264
    local actionY = L.actionCardY or 280
    local actionH = L.actionCardH or 150
    self:drawText(SS_T("IGUI_SS_ActionSection", "Actions"), pad, actionTitleY, c.dimText.r, c.dimText.g, c.dimText.b, 0.95, UIFont.Small)
    self:drawRect(cardX, actionY, cardW, actionH, 0.92, c.listBg.r, c.listBg.g, c.listBg.b)
    self:drawRectBorder(cardX, actionY, cardW, actionH, 0.62, c.panelBorder.r, c.panelBorder.g, c.panelBorder.b)

    -- item icon (above title)
    local tex = self._iconTex
    if tex then
        local size = L.iconSize or self._iconSize or 44
        local iy = L.iconY or (pad + 8)
        local ix = L.iconX or pad
        if self.drawTextureScaledAspect then
            self:drawTextureScaledAspect(tex, ix, iy, size, size, 1, 1, 1, 1)
        elseif self.drawTextureScaled then
            self:drawTextureScaled(tex, ix, iy, size, size, 1, 1, 1, 1)
        else
            self:drawTexture(tex, ix, iy, 1, 1, 1, 1)
        end
    else
        local ix = L.iconX or pad
        local iy = L.iconY or (pad + 8)
        local size = L.iconSize or self._iconSize or 44
        self:drawRect(ix, iy, size, size, 0.10, c.headerAccent.r, c.headerAccent.g, c.headerAccent.b)
        self:drawRectBorder(ix, iy, size, size, 0.28, c.headerAccent.r, c.headerAccent.g, c.headerAccent.b)
    end

    self:syncVisible()
    self:refreshHeaderText()

    -- Expiration countdown (updates live)
    if self.timer then
        local row = self.parentUI and self.parentUI.selectedRow or nil
        local txt = ""

        -- Browse/My:expiration countdown for the selected listing
        if (tab == SurvivorShopUI.TAB_BROWSE or tab == SurvivorShopUI.TAB_MY) and row and row.expiresAt then
            txt = SurvivorShopUI.getListingRemainingText(row)
        end
        -- Sell preview
        if tab == SurvivorShopUI.TAB_SELL then
            if self.updateSellPreview then self:updateSellPreview() end
            txt = "" -- keep timer empty on Sell
        end
        self.timer:setName(txt or "")
        self.timer:setVisible((txt ~= nil and txt ~= "") and (tab == SurvivorShopUI.TAB_BROWSE or tab == SurvivorShopUI.TAB_MY))
        -- My Listings:change button label when expired => reclaim
        if tab == SurvivorShopUI.TAB_MY and self.cancelBtn then
            if row and SurvivorShopUI.isListingExpired(row) then
                if self.cancelBtn.setTitle then self.cancelBtn:setTitle(SS_T("IGUI_SS_Reclaim","Resgatar itens")) else self.cancelBtn.title = SS_T("IGUI_SS_Reclaim","Resgatar itens") end
            else
                if self.cancelBtn.setTitle then self.cancelBtn:setTitle(SS_T("IGUI_SS_CancelListing","Cancelar anúncio")) else self.cancelBtn.title = SS_T("IGUI_SS_CancelListing","Cancelar anúncio") end
            end
        end
    end

    if self.bankBal:isVisible() then
        self.bankBal:setName(SS_T("IGUI_SS_Balance","Saldo:$%1"):gsub("%%1", tostring(SurvivorShopClient.balance or 0)))
    end
end


--========================================================
-- Bank Overlay (painel separado, à direita da tela)
--========================================================
local BankOverlay = ISPanel:derive("SurvivorShopBankOverlay")

function BankOverlay:new(ownerUI)
    local sw = getCore():getScreenWidth()
    local sh = getCore():getScreenHeight()
    local pad = 12
    local w = 420
    local h = ownerUI and ownerUI.height or 300
    h = math.min(h, sh - 2*pad)
    local x = sw - w - pad
    local y = pad
    if ownerUI and ownerUI.y then y = math.max(pad, math.min(ownerUI.y, sh - h - pad)) end

    local o = ISPanel:new(x, y, w, h)
    setmetatable(o, self)
    self.__index = self

    o.ownerUI = ownerUI
    o.backgroundColor = SurvivorShopUITheme.Colors.panelBg
    o.borderColor = SurvivorShopUITheme.Colors.panelBorder
    o.moveWithMouse = false

    return o
end

function BankOverlay:initialise()
    ISPanel.initialise(self)
end

function BankOverlay:createChildren()
    ISPanel.createChildren(self)
    local pad = 14

    self.title = ISLabel:new(pad, pad, 20, SS_T("IGUI_SS_Bank","Banco"), 1,1,1,1, UIFont.Large, true)
    self.title:setVisible(false) -- title is drawn by premium header
    self:addChild(self.title)

    self.btnClose = ISButton:new(self.width - pad - 24, pad, 24, 24, "X", self, BankOverlay.onClose)
    self.btnClose:initialise(); self.btnClose:instantiate(); self:addChild(self.btnClose)
    SurvivorShopUITheme.styleButton(self.btnClose, "dangerTiny")

    self.bankBal = ISLabel:new(pad, pad + 48, 20, SS_T("IGUI_SS_Balance","Saldo:$%1"):gsub("%%1","0"), 1,1,1,1, UIFont.Medium, true)
    self:addChild(self.bankBal)

    self.depEntry = ISTextEntryBox:new("100", pad, pad + 84, 100, 24)
    self:addChild(self.depEntry)
    SurvivorShopUITheme.styleTextEntry(self.depEntry)
    self.depBtn   = ISButton:new(pad + 112, pad + 84, 140, 24, SS_T("IGUI_SS_Deposit","Depositar"), self, BankOverlay.onDeposit)
    self.depBtn:initialise(); self.depBtn:instantiate(); self:addChild(self.depBtn)

    SurvivorShopUITheme.styleButton(self.depBtn, "success")
    self.wdEntry = ISTextEntryBox:new("100", pad, pad + 116, 100, 24)
    self:addChild(self.wdEntry)
    SurvivorShopUITheme.styleTextEntry(self.wdEntry)
    self.wdBtn   = ISButton:new(pad + 112, pad + 116, 140, 24, SS_T("IGUI_SS_Withdraw","Sacar"), self, BankOverlay.onWithdraw)
    self.wdBtn:initialise(); self.wdBtn:instantiate(); self:addChild(self.wdBtn)

    SurvivorShopUITheme.styleButton(self.wdBtn, "info")
    -- Transfer to other online players
    local y0 = pad + 154
    self.trTitle = ISLabel:new(pad, y0, 20, SS_T("IGUI_SS_TransferTitle","Transferencia"), 1,1,1,1, UIFont.Medium, true)
    self:addChild(self.trTitle)
    local tm = getTextManager()
    local labelTo = SS_T("IGUI_SS_To","Para:")
    local labelAmt = SS_T("IGUI_SS_Amount","Valor:")
    local labelW = 52
    if tm and tm.MeasureStringX then
        local w1 = tm:MeasureStringX(UIFont.Small, labelTo) + 10
        local w2 = tm:MeasureStringX(UIFont.Small, labelAmt) + 10
        labelW = math.max(labelW, w1, w2)
    end

    local gap = 8
    local btnW = 110
    local rightEdge = self.width - pad
    local btnX = rightEdge - btnW

    self.trToLbl = ISLabel:new(pad, y0 + 32, 20, labelTo, 1,1,1,1, UIFont.Small, true)
    self:addChild(self.trToLbl)

    local comboX = pad + labelW
    local comboW = math.max(120, btnX - gap - comboX)
    self.trToCombo = ISComboBox:new(comboX, y0 + 28, comboW, 24, self, BankOverlay.onSelectTransferTarget)
    self.trToCombo:initialise()
    self:addChild(self.trToCombo)

    SurvivorShopUITheme.styleComboBox(self.trToCombo)
    self.trRefreshBtn = ISButton:new(btnX, y0 + 28, btnW, 24, SS_T("IGUI_SS_Refresh","Atualizar"), self, BankOverlay.onRefreshPlayers)
    self.trRefreshBtn:initialise(); self.trRefreshBtn:instantiate(); self:addChild(self.trRefreshBtn)
    SurvivorShopUITheme.styleButton(self.trRefreshBtn, "default")

    self.trAmtLbl = ISLabel:new(pad, y0 + 64, 20, labelAmt, 1,1,1,1, UIFont.Small, true)
    self:addChild(self.trAmtLbl)

    self.trAmount = ISTextEntryBox:new("100", comboX, y0 + 60, comboW, 24)
    if self.trAmount and self.trAmount.initialise then self.trAmount:initialise() end
    if self.trAmount and self.trAmount.instantiate then self.trAmount:instantiate() end
    if self.trAmount then
        pcall(function() if self.trAmount.setOnlyNumbers then self.trAmount:setOnlyNumbers(true) end end)
        pcall(function() if self.trAmount.setMaxChars then self.trAmount:setMaxChars(9) end end)
    end
    self:addChild(self.trAmount)

    SurvivorShopUITheme.styleTextEntry(self.trAmount)
    -- Transfer button same size as Refresh for a cleaner layout
    self.trBtn = ISButton:new(btnX, y0 + 60, btnW, 24, SS_T("IGUI_SS_Transfer","Transferir"), self, BankOverlay.onTransfer)
    self.trBtn:initialise(); self.trBtn:instantiate(); self:addChild(self.trBtn)
    SurvivorShopUITheme.styleButton(self.trBtn, "success")
    self._transferCooldownUntil = 0
    self:setOnlinePlayers(SurvivorShopClient.onlinePlayers or {})
end


function BankOverlay:updateTransferCooldown()
    local now = SurvivorShopClient.nowMs and SurvivorShopClient.nowMs() or (os.time()*1000)
    if self.trBtn and self.trBtn.setEnable then
        if self._transferCooldownUntil and now >= self._transferCooldownUntil then
            self.trBtn:setEnable(true)
        end
    end
    if self.trRefreshBtn and self.trRefreshBtn.setEnable then
        if self._refreshCooldownUntil and now >= self._refreshCooldownUntil then
            self.trRefreshBtn:setEnable(true)
        end
    end
end

function BankOverlay:prerender()
    ISPanel.prerender(self)
    SurvivorShopUITheme.drawSoftPanel(self, 0, 0, self.width, self.height)
    SurvivorShopUITheme.drawSoftPanel(self, 8, 62, self.width - 16, self.height - 70)

    local hh = 54
    local title = SS_T("IGUI_SS_Bank","Banco")
    -- icon removed (was causing duplicate/overdraw issues)
    SurvivorShopUITheme.drawPremiumHeader(self, 0, 0, self.width, hh, title, nil)

    self:refreshBalance()
    self:updateTransferCooldown()

end

function BankOverlay:refreshBalance()
    if self.bankBal then
        self.bankBal:setName(SS_T("IGUI_SS_Balance","Saldo:$%1"):gsub("%%1", tostring(SurvivorShopClient.balance or 0)))
    end
end

function BankOverlay:alignToShop()
    local sw = getCore():getScreenWidth()
    local sh = getCore():getScreenHeight()
    local pad = 12
    local gap = 6

    -- Cola no lado da janela da loja (preferência:direita). Se não houver espaço, cola à esquerda.
    local ox = (self.ownerUI and self.ownerUI.x) or pad
    local oy = (self.ownerUI and self.ownerUI.y) or pad
    local oh = (self.ownerUI and self.ownerUI.height) or self.height

    -- acompanha a altura da loja
    if oh and oh > 100 then
        self:setHeight(oh)
    end

    local xRight = ox + ((self.ownerUI and self.ownerUI.width) or 0) + gap
    local xLeft  = ox - self.width - gap

    local x
    if (xRight + self.width) <= (sw - pad) then
        x = xRight
    elseif xLeft >= pad then
        x = xLeft
    else
        -- fallback:mantém dentro da tela
        x = sw - self.width - pad
    end

    local y = math.max(pad, math.min(oy, sh - self.height - pad))

    self:setX(x)
    self:setY(y)
end

function BankOverlay.onClose(self)
    if self.ownerUI and self.ownerUI.closeBank then
        self.ownerUI:closeBank()
    else
        self:setVisible(false)
    end
end

function BankOverlay:onDeposit()
    SurvivorShopClient.deposit(self.depEntry:getText())
end

function BankOverlay:onWithdraw()
    SurvivorShopClient.withdraw(self.wdEntry:getText())
end

function BankOverlay:setOnlinePlayers(players)
    if not self.trToCombo then return end
    self.trToCombo:clear()
    local me = (getPlayer() and getPlayer().getUsername) and tostring(getPlayer():getUsername()) or ""
    local added = 0
    players = players or {}
    for _,info in ipairs(players) do
        local name = tostring(info.name or "")
        if name ~= "" and name ~= me then
            self.trToCombo:addOption(name)
            added = added + 1
        end
    end
    if added == 0 then
        self.trToCombo:addOption(SS_T("IGUI_SS_NoOnline","(no players online)"))
        self.trToCombo.selected = 1
    end
end

function BankOverlay:onRefreshPlayers()
    local now = SurvivorShopClient.nowMs and SurvivorShopClient.nowMs() or (os.time()*1000)
    self._refreshCooldownUntil = self._refreshCooldownUntil or 0
    if now < self._refreshCooldownUntil then return end
    self._refreshCooldownUntil = now + 1000
    SurvivorShopClient.requestOnlinePlayers()
end

function BankOverlay:onSelectTransferTarget()
    -- no-op (kept for future)
end

function BankOverlay:onTransfer()
    if not self.trToCombo or not self.trAmount then return end
    local now = SurvivorShopClient.nowMs and SurvivorShopClient.nowMs() or (os.time()*1000)
    self._transferCooldownUntil = self._transferCooldownUntil or 0
    if now < self._transferCooldownUntil then return end

    local toName = self.trToCombo:getOptionText(self.trToCombo.selected) or ""
    if toName == "" or toName:find("%(no players") then
        if SurvivorShopUI and SurvivorShopUI.showToast then
            SurvivorShopUI.showToast(SS_T("IGUI_SS_NoPlayersOnline","No players online."))
        end
        return
    end

    local amount = math.floor(tonumber(self.trAmount:getText()) or 0)
    if amount <= 0 then
        if SurvivorShopUI and SurvivorShopUI.showToast then
            SurvivorShopUI.showToast(SS_T("IGUI_SS_InvalidAmount","Invalid amount."))
        end
        return
    end

    -- client-side anti-spam (server also rate-limits)
    self._transferCooldownUntil = now + 1200
    if self.trBtn and self.trBtn.setEnable then self.trBtn:setEnable(false) end

    SurvivorShopClient.bankTransfer(toName, amount)
end



--========================================================
-- Auction Overlay (Leilão)
--========================================================
AuctionOverlay = ISPanel:derive("SurvivorShopAuctionOverlay")

local function _ss_nowMs()
    if getTimestampMs then return getTimestampMs() end
    return os.time() * 1000
end

local function _ss_fmtTimeLeft(sec)
    sec = math.max(0, math.floor(tonumber(sec) or 0))
    local d = math.floor(sec / 86400); sec = sec % 86400
    local h = math.floor(sec / 3600); sec = sec % 3600
    local m = math.floor(sec / 60)
    if d > 0 then return string.format("%dd %02dh %02dm", d, h, m) end
    return string.format("%02dh %02dm", h, m)
end

local function _ss_collectTypeCounts(container, out)
    if not container then return end
    local items = container:getItems()
    if not items then return end
    for i=0,items:size()-1 do
        local it = items:get(i)
        if it then
            local t = it:getFullType()
            out[t] = (out[t] or 0) + 1
            if instanceof(it, "InventoryContainer") and it:getInventory() then
                _ss_collectTypeCounts(it:getInventory(), out)
            end
        end
    end
end

-- Resolve display name from fullType (B42:DisplayName removed in scripts; translation comes from Module.ItemId)
local _ss_auctionNameCache = {}
local function _ss_itemName(fullType)
    if not fullType then return "" end
    fullType = tostring(fullType)
    if fullType == "" then return "" end
    if _ss_auctionNameCache[fullType] then return _ss_auctionNameCache[fullType] end

    local name = nil

    if getItemNameFromFullType then
        local n = getItemNameFromFullType(fullType)
        if n and n ~= "" and n ~= fullType then
            name = SS_stripUnknownPrefix(n)
        end
    end

    if not name or name == "" then
        local it = (InventoryItemFactory and InventoryItemFactory.CreateItem) and InventoryItemFactory.CreateItem(fullType) or nil
        if it and it.getDisplayName then
            name = SS_stripUnknownPrefix(it:getDisplayName())
        end
    end

    if not name or name == "" then name = fullType end
    _ss_auctionNameCache[fullType] = name
    return name
end


function AuctionOverlay:new(ownerUI)
    local sw = getCore():getScreenWidth()
    local sh = getCore():getScreenHeight()
    local pad = 12

    local w = 420
    local h = (ownerUI and ownerUI.height) or 520
    h = math.min(h, sh - 2*pad)

    local x = sw - w - pad
    local y = pad
    if ownerUI and ownerUI.y then
        y = math.max(pad, math.min(ownerUI.y, sh - h - pad))
    end

    local o = ISPanel:new(x, y, w, h)
    setmetatable(o, self)
    self.__index = self

    o.ownerUI = ownerUI
    o.isAdmin = false
    o.lastRefresh = 0
    o.selectedAuctionId = nil
    o._origY = nil

    o.backgroundColor = SurvivorShopUITheme.Colors.panelBg
    o.borderColor = SurvivorShopUITheme.Colors.panelBorder
    o.moveWithMouse = false
    return o
end

function AuctionOverlay:alignToShop()
    local sw = getCore():getScreenWidth()
    local sh = getCore():getScreenHeight()
    local pad = 12
    local gap = 6

    local ox = (self.ownerUI and self.ownerUI.x) or pad
    local oy = (self.ownerUI and self.ownerUI.y) or pad
    local oh = (self.ownerUI and self.ownerUI.height) or self.height

    if oh and oh > 100 and oh ~= self.height then
        self:setHeight(oh)
    end

    local xRight = ox + ((self.ownerUI and self.ownerUI.width) or 0) + gap
    local xLeft  = ox - self.width - gap

    local x
    if (xRight + self.width) <= (sw - pad) then
        x = xRight
    elseif xLeft >= pad then
        x = xLeft
    else
        x = sw - self.width - pad
    end

    local y = math.max(pad, math.min(oy, sh - self.height - pad))

    self:setX(x)
    self:setY(y)
end


function AuctionOverlay:createChildren()
    ISPanel.createChildren(self)
    local c = SurvivorShopUITheme.Colors
    local pad = 12
    local x = pad
    local y = pad + 54

    -- Admin create section
    self.lblAdmin = ISLabel:new(x, y, 18, SS_T("IGUI_SS_AuctionCreate","Criar leilão"), 0.95,0.95,0.95,0.95, UIFont.Medium, true)
    self.lblAdmin:initialise(); self:addChild(self.lblAdmin)
    y = y + 22

    self.itemCombo = ISComboBox:new(x, y, self.width - pad*2, 20, self, nil)
    self.itemCombo:initialise(); self:addChild(self.itemCombo)
    y = y + 26

    self.qtyEntry = ISTextEntryBox:new("1", x, y, 80, 20)
    self.qtyEntry:initialise(); self:addChild(self.qtyEntry)
    pcall(function() if self.qtyEntry.setOnlyNumbers then self.qtyEntry:setOnlyNumbers(true) end end)

    self.minBidEntry = ISTextEntryBox:new("0", x + 90, y, 110, 20)
    self.minBidEntry:initialise(); self:addChild(self.minBidEntry)
    pcall(function() if self.minBidEntry.setOnlyNumbers then self.minBidEntry:setOnlyNumbers(true) end end)

    self.btnAdd = ISButton:new(self.width - pad - 110, y, 110, 20, SS_T("IGUI_SS_AuctionAdd","Adicionar"), self, AuctionOverlay.onAddAuction)
    self.btnAdd:initialise(); self:addChild(self.btnAdd)
    self.btnAdd.backgroundColor = {r=0.10,g=0.25,b=0.16,a=0.85}
    self.btnAdd.backgroundColorMouseOver = {r=0.14,g=0.35,b=0.22,a=1.0}
    y = y + 34

    -- List
    self.auctionList = ISScrollingListBox:new(x, y, self.width - pad*2, 170)
    self.auctionList:initialise(); self:addChild(self.auctionList)
    self.auctionList.itemheight = math.max(24, (getTextManager():getFontHeight(UIFont.Small) or 16) + 8)
    self.auctionList.drawBorder = true

    -- Better row layout:no text over the row lines (centered + clipped + right-aligned price)
    self.auctionList.doDrawItem = function(list, yy, it, alt)
        return self:doDrawAuctionRow(list, yy, it, alt)
    end
    self.auctionList.onMouseDown = function(list, bx, by)
        ISScrollingListBox.onMouseDown(list, bx, by)
        local item = list.items[list.selected]
        if item and item.item and item.item.id and tostring(item.item.id) ~= "" then
            self.selectedAuctionId = tostring(item.item.id)
            self:refreshDetails()
        end
        return true
    end
    y = y + 180

    self.detailName = ISLabel:new(x, y, 22, "", 1,1,1,1, UIFont.Medium, true)
    self.detailName:initialise(); self:addChild(self.detailName)
    y = y + 22

    self.detailBid = ISLabel:new(x, y, 18, "", 0.9,0.9,0.9,0.9, UIFont.Small, true)
    self.detailBid:initialise(); self:addChild(self.detailBid)
    y = y + 18

    self.detailEnds = ISLabel:new(x, y, 18, "", 0.9,0.9,0.9,0.9, UIFont.Small, true)
    self.detailEnds:initialise(); self:addChild(self.detailEnds)
    y = y + 24

    self.bidEntry = ISTextEntryBox:new("0", x, y, 120, 20)
    self.bidEntry:initialise(); self:addChild(self.bidEntry)
    pcall(function() if self.bidEntry.setOnlyNumbers then self.bidEntry:setOnlyNumbers(true) end end)

    self.btnBid = ISButton:new(x + 130, y, self.width - pad*2 - 130, 20, SS_T("IGUI_SS_AuctionBid","Dar lance"), self, AuctionOverlay.onBid)
    self.btnBid:initialise(); self:addChild(self.btnBid)
    self.btnBid.backgroundColor = {r=0.10,g=0.25,b=0.16,a=0.85}
    self.btnBid.backgroundColorMouseOver = {r=0.14,g=0.35,b=0.22,a=1.0}
    y = y + 34

    local feePct = SurvivorShop.getSandboxInt and SurvivorShop.getSandboxInt("AuctionBidFeePercent", 0) or 0
    self.lblFee = ISLabel:new(x, y, 18, SS_T("IGUI_SS_AuctionBidFee","Taxa do lance") .. ": " .. tostring(feePct) .. "%", 0.95,0.35,0.35,0.95, UIFont.Small, true)
    self.lblFee:initialise(); self:addChild(self.lblFee)
    y = y + 26

    self.lblHistory = ISLabel:new(x, y, 18, SS_T("IGUI_SS_AuctionBidHistory","Histórico de lances"), 0.85,0.85,0.85,1.0, UIFont.Small, true)
    self.lblHistory:initialise(); self:addChild(self.lblHistory)
    y = y + 18

    self.bidHistoryList = ISScrollingListBox:new(x, y, self.width - pad*2, 100)
    self.bidHistoryList:initialise(); self:addChild(self.bidHistoryList)
    self.bidHistoryList.itemheight = 20
    self.bidHistoryList.drawBorder = true
    self.bidHistoryList.doDrawItem = function(list, yy, it, alt)
        return self:doDrawBidRow(list, yy, it, alt)
    end
    y = y + 110

    self.claimLbl = ISLabel:new(x, y, 18, "", 0.95,0.95,0.95,0.95, UIFont.Small, true)
    self.claimLbl:initialise(); self:addChild(self.claimLbl)

    self.btnClaim = ISButton:new(x + 130, y-2, self.width - pad*2 - 130, 20, SS_T("IGUI_SS_AuctionClaim","Resgatar prêmio"), self, AuctionOverlay.onClaim)
    self.btnClaim:initialise(); self:addChild(self.btnClaim)
    self.btnClaim.backgroundColor = {r=0.20,g=0.20,b=0.20,a=0.65}
    self.btnClaim.backgroundColorMouseOver = {r=0.28,g=0.28,b=0.28,a=0.85}
    self.btnClaim:setVisible(false)
    self.claimLbl:setVisible(false)

    -- store original layout Y's so we can collapse admin section for non-admins
    self._origY = {
        auctionList = self.auctionList:getY(),
        detailName = self.detailName:getY(),
        detailBid = self.detailBid:getY(),
        detailEnds = self.detailEnds:getY(),
        bidEntry = self.bidEntry:getY(),
        btnBid = self.btnBid:getY(),
        lblFee = self.lblFee:getY(),
        claimLbl = self.claimLbl:getY(),
        btnClaim = self.btnClaim:getY(),
        lblHistory = self.lblHistory:getY(),
        bidHistoryList = self.bidHistoryList:getY(),
        auctionListH = self.auctionList:getHeight(),
    }

    -- Layout metrics used to collapse the admin section without pushing the list into the header
    self._pad = pad
    self._headerH = 54
    self._collapseShift = math.max(0, (self._origY.auctionList or 0) - (pad + self._headerH))

    self:setAdminUI(false)
end


function AuctionOverlay:doDrawAuctionRow(list, y, item, alt)
    local c = SurvivorShopUITheme.Colors
    local h = list.itemheight or 24

    -- background / selection
    local index = item.index or item.listIndex
    local isSel = (index ~= nil) and (list.selected == index) or false
    if isSel then
        list:drawRect(0, y, list.width, h, c.listSelected.a, c.listSelected.r, c.listSelected.g, c.listSelected.b)
    else
        local bg = alt and c.listAltBg or c.listBg
        list:drawRect(0, y, list.width, h, bg.a, bg.r, bg.g, bg.b)
    end

    local padX = 8
    local font = UIFont.Small
    local fontH = (getTextManager() and getTextManager():getFontHeight(font)) or 16
    local ty = y + math.floor((h - fontH) / 2)

    local vscrollW = ((list.vscroll and list.vscroll.width) or 0)
    local rightEdge = list.width - padX - vscrollW - 2

    local row = item and item.item or nil
    if row and tostring(row.id or "") == "" then
        _ss_drawTextClipped(list, item.text or "", padX, ty, rightEdge - padX, c.normalText.r, c.normalText.g, c.normalText.b, c.normalText.a, font)
        return y + h
    end

    local fullType = row and row.itemType or nil
    local name = fullType and _ss_itemName(fullType) or (item.text or "")
    local bid = row and (tonumber(row.currentBid) or 0) or 0
    local ended = row and ((row.ended == true) or ((tonumber(row.endAt) or 0) <= os.time())) or false

    local bidText = string.format("$%d", bid)
    if ended then bidText = bidText .. " " .. SS_T("IGUI_SS_AuctionEndedSuffix","(ended)") end

    local bidW = (getTextManager() and getTextManager():MeasureStringX(font, bidText)) or 60
    local bx = rightEdge - bidW
    local nameW = (bx - 10) - padX
    if nameW < 40 then nameW = rightEdge - padX end

    _ss_drawTextClipped(list, name, padX, ty, nameW, c.normalText.r, c.normalText.g, c.normalText.b, c.normalText.a, font)
    list:drawText(bidText, bx, ty, c.normalText.r, c.normalText.g, c.normalText.b, c.normalText.a, font)

    -- row separator (helps readability and avoids "floating" text look)
    list:drawRect(0, y + h - 1, list.width, 1, 0.18, 1, 1, 1)

    return y + h
end

function AuctionOverlay:doDrawBidRow(list, y, item, alt)
    local c = SurvivorShopUITheme.Colors
    local h = list.itemheight or 20
    local bg = alt and c.listAltBg or c.listBg
    list:drawRect(0, y, list.width, h, bg.a, bg.r, bg.g, bg.b)

    local row = item and item.item or nil
    if not row then return y + h end

    local font = UIFont.Small
    local padX = 6
    local fontH = (getTextManager() and getTextManager():getFontHeight(font)) or 14
    local ty = y + math.floor((h - fontH) / 2)

    local timeStr = os.date("%H:%M", row.time or os.time())
    local amountStr = string.format("$%d", row.amount or 0)
    local name = tostring(row.bidderName or "???")

    local timeW = (getTextManager() and getTextManager():MeasureStringX(font, timeStr)) or 30
    -- draw helper for right align
    local amountW = (getTextManager() and getTextManager():MeasureStringX(font, amountStr)) or 40

    list:drawText(timeStr, padX, ty, 0.6, 0.6, 0.6, 1, font)
    list:drawText(name, padX + timeW + 8, ty, c.normalText.r, c.normalText.g, c.normalText.b, c.normalText.a, font)
    list:drawText(amountStr, list.width - amountW - 24, ty, 0.4, 0.8, 0.4, 1, font)

    return y + h
end


function AuctionOverlay:setAdminUI(isAdmin)
    self.isAdmin = isAdmin and true or false
    self.lblAdmin:setVisible(self.isAdmin)
    self.itemCombo:setVisible(self.isAdmin)
    self.qtyEntry:setVisible(self.isAdmin)
    self.minBidEntry:setVisible(self.isAdmin)
    self.btnAdd:setVisible(self.isAdmin)

    if not self._origY then return end

    local collapseShift = self._collapseShift or 0

    if self.isAdmin then
        self.auctionList:setY(self._origY.auctionList)
        self.auctionList:setHeight(self._origY.auctionListH)

        self.detailName:setY(self._origY.detailName)
        self.detailBid:setY(self._origY.detailBid)
        self.detailEnds:setY(self._origY.detailEnds)
        self.bidEntry:setY(self._origY.bidEntry)
        self.btnBid:setY(self._origY.btnBid)
        self.lblFee:setY(self._origY.lblFee)
        self.claimLbl:setY(self._origY.claimLbl)
        self.btnClaim:setY(self._origY.btnClaim)
        self.lblHistory:setY(self._origY.lblHistory)
        self.bidHistoryList:setY(self._origY.bidHistoryList)
    else
        -- Clamp so the list never invades the header (prevents row text overlapping the title)
        local pad = self._pad or 12
        local hh  = self._headerH or 54
        local minY = pad + hh

        local newY = (self._origY.auctionList or 0) - collapseShift
        if newY < minY then
            collapseShift = (self._origY.auctionList or 0) - minY
            newY = minY
        end

        self.auctionList:setY(newY)
        -- IMPORTANT:keep the list height the same, otherwise details will overlap the list.
        self.auctionList:setHeight(self._origY.auctionListH)

        self.detailName:setY(self._origY.detailName - collapseShift)
        self.detailBid:setY(self._origY.detailBid - collapseShift)
        self.detailEnds:setY(self._origY.detailEnds - collapseShift)
        self.bidEntry:setY(self._origY.bidEntry - collapseShift)
        self.btnBid:setY(self._origY.btnBid - collapseShift)
        self.lblFee:setY(self._origY.lblFee - collapseShift)
        self.claimLbl:setY(self._origY.claimLbl - collapseShift)
        self.btnClaim:setY(self._origY.btnClaim - collapseShift)
        self.lblHistory:setY(self._origY.lblHistory - collapseShift)
        self.bidHistoryList:setY(self._origY.bidHistoryList - collapseShift)
    end
end

function AuctionOverlay:onHello(isAdmin)
    self:setAdminUI(isAdmin)
    if self.isAdmin then self:refreshInventory() end
end

function AuctionOverlay:refreshInventory()
    if not self.isAdmin then return end
    self.itemCombo:clear()
    self.itemCombo.optionsData = {}

    local player = getPlayer()
    if not player then return end
    local inv = player:getInventory()
    if not inv then return end

    local counts = {}
    _ss_collectTypeCounts(inv, counts)

    local n = 0
    for fullType,count in pairs(counts) do
        n = n + 1
        local name = _ss_itemName(fullType)
        self.itemCombo:addOption(string.format("%s  (x%d)", name, count))
        self.itemCombo.optionsData[#self.itemCombo.options] = { fullType=fullType, count=count }
        if n > 250 then break end
    end

    if #self.itemCombo.options == 0 then
        self.itemCombo:addOption(SS_T("IGUI_SS_AuctionNoAuctions","(sem leilões ativos)"))
    end
end

function AuctionOverlay:onAddAuction()
    if not self.isAdmin then return end
    local idx = self.itemCombo.selected
    local data = self.itemCombo.optionsData and self.itemCombo.optionsData[idx]
    if not data or not data.fullType then return end

    local qty = math.max(1, math.floor(tonumber(self.qtyEntry:getText()) or 1))
    local minBid = math.max(0, math.floor(tonumber(self.minBidEntry:getText()) or 0))
    SurvivorShopClient.createAuction(data.fullType, qty, minBid)
end

function AuctionOverlay:refreshAuctions()
    self.auctionList:clear()
    local list = SurvivorShopClient and SurvivorShopClient.auctions or {}
    if not list or #list == 0 then
        self.auctionList:addItem(SS_T("IGUI_SS_AuctionNoAuctions","(sem leilões ativos)"), { id="", itemType="", quantity=0 })
        return
    end

    table.sort(list, function(a,b)
        local ae = (a.ended == true) and 1 or 0
        local be = (b.ended == true) and 1 or 0
        if ae ~= be then return ae < be end
        return (tonumber(a.endAt) or 0) < (tonumber(b.endAt) or 0)
    end)

    for i=1,#list do
        local a = list[i]
        if a and a.itemType and (a.claimed ~= true) then
            local name = _ss_itemName(a.itemType)
            local bid = tonumber(a.currentBid) or 0
            local ended = (a.ended == true) or ((tonumber(a.endAt) or 0) <= os.time())
            local label = string.format("%s  |  $%d%s", name, bid, ended and ("  " .. SS_T("IGUI_SS_AuctionEndedSuffix","(ended)")) or "")
            self.auctionList:addItem(label, a)
        end
    end

    -- keep selection by id
    if self.selectedAuctionId then
        for i=1,#self.auctionList.items do
            local item = self.auctionList.items[i]
            if item and item.item and tostring(item.item.id) == tostring(self.selectedAuctionId) then
                self.auctionList.selected = i
                break
            end
        end
    end

    self:refreshDetails()
end

function AuctionOverlay:refreshClaims()
    self:refreshDetails()
end

function AuctionOverlay:refreshDetails()
    local item = self.auctionList.items[self.auctionList.selected]
    if not item or not item.item or not item.item.id or tostring(item.item.id) == "" then
        self.detailName:setName("")
        self.detailBid:setName("")
        self.detailEnds:setName("")
        self.btnBid:setEnable(false)
        self.claimLbl:setVisible(false)
        self.btnClaim:setVisible(false)
        self.lblHistory:setVisible(false)
        self.bidHistoryList:setVisible(false)
        return
    end

    local a = item.item
    self.selectedAuctionId = tostring(a.id)

    local name = _ss_itemName(a.itemType)
    self.detailName:setName(name)

    local bid = tonumber(a.currentBid) or 0
    local minBid = tonumber(a.minBid) or 0
    self.detailBid:setName(string.format("%s:$%d   (%s:$%d)", SS_T("IGUI_SS_AuctionCurrentBid","Lance atual"), bid, SS_T("IGUI_SS_AuctionMinBid","Lance mínimo"), minBid))

    local left = (tonumber(a.endAt) or 0) - os.time()
    local ended = (a.ended == true) or left <= 0
    if ended then
        self.detailEnds:setName(SS_T("IGUI_SS_AuctionEndsIn","Termina em") .. ": 00h 00m")
        self.btnBid:setEnable(false)
    else
        self.detailEnds:setName(SS_T("IGUI_SS_AuctionEndsIn","Termina em") .. ": " .. _ss_fmtTimeLeft(left))
        self.btnBid:setEnable(true)
    end

    local claimable = false
    local claims = SurvivorShopClient and SurvivorShopClient.auctionClaims or {}
    for i=1,#claims do
        if tostring(claims[i].id) == tostring(a.id) then
            claimable = true
            break
        end
    end

    self.claimLbl:setVisible(claimable)
    self.btnClaim:setVisible(claimable)
    if claimable then
        self.claimLbl:setName(SS_T("IGUI_SS_AuctionClaim","Resgatar prêmio") .. ": " .. name .. " x" .. tostring(tonumber(a.quantity) or 1))
    end

    -- Bid History
    self.lblHistory:setVisible(not claimable)
    self.bidHistoryList:setVisible(not claimable)
    if not claimable then
        self.bidHistoryList:clear()
        local bids = a.bids or {}
        if #bids == 0 then
            self.bidHistoryList:addItem("(" .. SS_T("IGUI_SS_NoSalesYet","Nenhuma venda realizada ainda") .. ")", nil) -- Reuse existing "no sales" key or use blank
        else
            for i=1,#bids do
                self.bidHistoryList:addItem(tostring(bids[i].amount), bids[i])
            end
        end
    end
end

function AuctionOverlay:onBid()
    local item = self.auctionList.items[self.auctionList.selected]
    if not item or not item.item or not item.item.id or tostring(item.item.id) == "" then return end
    local amount = math.max(0, math.floor(tonumber(self.bidEntry:getText()) or 0))
    if amount <= 0 then return end
    SurvivorShopClient.placeBid(tostring(item.item.id), amount)
end

function AuctionOverlay:onClaim()
    local item = self.auctionList.items[self.auctionList.selected]
    if not item or not item.item or not item.item.id or tostring(item.item.id) == "" then return end
    SurvivorShopClient.claimAuction(tostring(item.item.id))
end

function AuctionOverlay:prerender()
    if self.alignToShop then self:alignToShop() end
    ISPanel.prerender(self)
    SurvivorShopUITheme.drawSoftPanel(self, 0, 0, self.width, self.height)
    SurvivorShopUITheme.drawSoftPanel(self, 8, 62, self.width - 16, self.height - 70)

    local hh = 54
    SurvivorShopUITheme.drawPremiumHeader(self, 0, 0, self.width, hh, SS_T("IGUI_SS_AuctionTitle","Leilão"), nil)

    local n = _ss_nowMs()
    if (n - (self.lastRefresh or 0)) > 1000 then
        self.lastRefresh = n
        self:refreshAuctions()
    end
end

function SurvivorShopUI:initialise() ISPanel.initialise(self) end

function SurvivorShopUI:createChildren()
    ISPanel.createChildren(self)
    local pad = 12

    self.headerH = 52
    local bodyY = self.headerH + pad
    -- compute body height from footer buttons to avoid overflow on different UI scales
    local footerBtnH = 26
    local footerY = self.height - pad - footerBtnH
    local bodyH = footerY - pad - bodyY
    local listW = math.floor(self.width * 0.66)
    local detailsX = pad + listW + pad
    local detailsW = self.width - detailsX - pad

    self.tabPanel = ISTabPanel:new(pad, bodyY, listW, bodyH)
    self.tabPanel:initialise()
    self:addChild(self.tabPanel)

    self.browse = self:_makeListView(true, true, true)

    -- Click a group row to expand/collapse
    do
        local oldMouseDown = self.browse.list.onMouseDown
        function self.browse.list:onMouseDown(x, y)
            if oldMouseDown then oldMouseDown(self, x, y) end

            local sel = self.selected
            local it = sel and self.items and self.items[sel] and self.items[sel].item
            if not it then return end
            if SurvivorShopUI.instance then SurvivorShopUI.instance._inlineQtyEditingItem = nil end

            -- Clique nos controles inline (listing):[-] [+] [Comprar]
            if it.kind == "listing" and it._ui then
                local u = it._ui
                local function inRect(r)
                    return r and x >= r.x and x <= (r.x + r.w) and y >= r.y and y <= (r.y + r.h)
                end

                if inRect(u.star) and SurvivorShopUI.instance then
                    SurvivorShopUI.instance:toggleFavorite(tostring(it.itemType))
                    return
                end

                if inRect(u.minus) then
                    it.buyQty = math.max(1, math.floor(tonumber(it.buyQty) or 1) - 1)
                    if SurvivorShopUI.instance and SurvivorShopUI.instance._inlineQtyEditingItem == it and SurvivorShopUI.instance.details and SurvivorShopUI.instance.details.buyQty then
                        SurvivorShopUI.instance.details.buyQty:setText(tostring(it.buyQty))
                    end
                    return
                elseif inRect(u.plus) then
                    local maxQty = math.max(1, math.floor(tonumber(it.quantity) or 1))
                    it.buyQty = math.min(maxQty, math.floor(tonumber(it.buyQty) or 1) + 1)
                    if SurvivorShopUI.instance and SurvivorShopUI.instance._inlineQtyEditingItem == it and SurvivorShopUI.instance.details and SurvivorShopUI.instance.details.buyQty then
                        SurvivorShopUI.instance.details.buyQty:setText(tostring(it.buyQty))
                    end
                    return
                elseif inRect(u.qtyBox) then
                    -- allow typing qty:reuse DetailsPanel entry (if available) or just set focus
                    it.buyQty = math.max(1, math.floor(tonumber(it.buyQty) or 1))
                    if SurvivorShopUI.instance and SurvivorShopUI.instance.details and SurvivorShopUI.instance.details.buyQty then
                        local entry = SurvivorShopUI.instance.details.buyQty
                        entry:setText(tostring(it.buyQty))
                        if entry and entry.focus then entry:focus() end
                        if entry and entry.selectAll then entry:selectAll() end
                        SurvivorShopUI.instance._inlineQtyEditingItem = it
                    end
                    return
                elseif inRect(u.buy) then
                    local qty = math.max(1, math.floor(tonumber(it.buyQty) or 1))
                    local bal = tonumber(SurvivorShopClient and SurvivorShopClient.balance) or 0
                    local totalCost = (tonumber(it.price) or 0) * qty
                    if bal < totalCost then
                        if SurvivorShopUI.instance and SurvivorShopUI.instance.showToast then
                            SurvivorShopUI.instance:showToast(SS_T("IGUI_SS_NoFunds","No funds"))
                        end
                        return
                    end
                    SurvivorShopClient.buy(it.id, qty)
                    return
                end
            end

            -- Clique no grupo:expand/collapse
            if it.kind == "group" and SurvivorShopUI.instance then
                if it._ui and it._ui.quickBuy and x >= it._ui.quickBuy.x and x <= (it._ui.quickBuy.x + it._ui.quickBuy.w) and y >= it._ui.quickBuy.y and y <= (it._ui.quickBuy.y + it._ui.quickBuy.h) then
                    if it._ui.quickBuy.enabled ~= false then
                        _ss_buyCheapestListing(tostring(it.itemType or ""), 1, SurvivorShopUI.instance)
                    else
                        SurvivorShopUI.instance.showToast(SS_T("IGUI_SS_NoListingsForItem","No listings available for this item right now."))
                    end
                    return
                end
                SurvivorShopUI.instance:toggleBrowseGroup(tostring(it.itemType))
            end
        end
    end

    self.sell = self:_makeListView(false)
    self.my = self:_makeListView(false)
    
    -- [NEW B42.13.2] Add sales history panel to MY tab with sub-tabs
    do
        local pad = 10
        local historyInset = 8
        local dividerY = math.floor(self.my.list.height * 0.55)
        self.my.list:setHeight(dividerY)
        self.my.list:setAnchorBottom(false)

        local labelY = self.my.list.y + dividerY + 4
        self.my.historyLabel = ISLabel:new(pad + historyInset, labelY, 20, SS_T("IGUI_SS_SalesHistory", "Histórico"), 1, 1, 1, 1, UIFont.Medium, true)
        self.my.historyLabel:initialise()
        self.my.historyLabel:instantiate()
        self.my:addChild(self.my.historyLabel)

        -- Create tab panel for Sales vs Listings history
        -- Increased spacing from labelY + 24 to labelY + 32 for better readability
        local tabY = labelY + 32
        local tabH = self.my.height - tabY - historyInset
        local historyW = self.my.width - historyInset * 2
        self.my.historyTabs = ISTabPanel:new(historyInset, tabY, historyW, tabH)
        self.my.historyTabs:initialise()
        self.my.historyTabs:instantiate()
        self.my.historyTabs.borderColor = {r=0, g=0, b=0, a=0}
        self.my.historyTabs.tabHeight = 24
        self.my:addChild(self.my.historyTabs)

        -- Create Sales list (actual sales only)
        -- Increased bottom padding from 4 to 8 for better spacing
        local salesListH = tabH - self.my.historyTabs.tabHeight - 8
        self.my.salesList = ISScrollingListBox:new(0, 0, historyW, salesListH)
        self.my.salesList:initialise()
        self.my.salesList:instantiate()
        self.my.salesList.itemheight = 28
        self.my.salesList.drawBorder = false
        self.my.salesList.backgroundColor = {r=0, g=0, b=0, a=0}
        self.my.salesList.doDrawItem = function(self, y, item, alt)
            if not item then return y end

            -- Safe color access
            local c = SurvivorShopUITheme and SurvivorShopUITheme.Colors or {}
            local listRowAlt = c.listRowAlt or {r=0.15, g=0.15, b=0.15, a=1.0}
            local listRowEven = c.listRowEven or {r=0.1, g=0.1, b=0.1, a=1.0}
            local normalText = c.normalText or {r=0.9, g=0.9, b=0.9, a=1.0}

            if alt then
                self:drawRect(0, y, self:getWidth(), self.itemheight, listRowAlt.a, listRowAlt.r, listRowAlt.g, listRowAlt.b)
            else
                self:drawRect(0, y, self:getWidth(), self.itemheight, listRowEven.a, listRowEven.r, listRowEven.g, listRowEven.b)
            end

            local pad = 8
            local textY = y + math.floor((self.itemheight - getTextManager():getFontHeight(UIFont.Small)) / 2)
            local text = item.text or ""

            -- Color based on sale type
            local textR, textG, textB = normalText.r, normalText.g, normalText.b
            if item.item and item.item.saleType then
                if item.item.saleType == "[ANUNCIADO]" then
                    textR, textG, textB = 0.5, 0.8, 1.0  -- Light blue for listings
                elseif item.item.saleType == "[CANCELADO]" then
                    textR, textG, textB = 1.0, 0.5, 0.3  -- Orange for cancellations
                else
                    textR, textG, textB = 0.3, 1.0, 0.3  -- Green for actual sales
                end
            end

            local maxW = self:getWidth() - pad * 2 - ((self.vscroll and self.vscroll.width) or 0)
            _ss_drawTextClipped(self, text, pad, textY, maxW, textR, textG, textB, normalText.a, UIFont.Small)
            return y + self.itemheight
        end

        -- Create Listings list (listings and cancellations)
        self.my.listingsList = ISScrollingListBox:new(0, 0, historyW, salesListH)
        self.my.listingsList:initialise()
        self.my.listingsList:instantiate()
        self.my.listingsList.itemheight = 28
        self.my.listingsList.drawBorder = false
        self.my.listingsList.backgroundColor = {r=0, g=0, b=0, a=0}
        self.my.listingsList.doDrawItem = function(self, y, item, alt)
            if not item then return y end

            -- Safe color access
            local c = SurvivorShopUITheme and SurvivorShopUITheme.Colors or {}
            local listRowAlt = c.listRowAlt or {r=0.15, g=0.15, b=0.15, a=1.0}
            local listRowEven = c.listRowEven or {r=0.1, g=0.1, b=0.1, a=1.0}
            local normalText = c.normalText or {r=0.9, g=0.9, b=0.9, a=1.0}

            if alt then
                self:drawRect(0, y, self:getWidth(), self.itemheight, listRowAlt.a, listRowAlt.r, listRowAlt.g, listRowAlt.b)
            else
                self:drawRect(0, y, self:getWidth(), self.itemheight, listRowEven.a, listRowEven.r, listRowEven.g, listRowEven.b)
            end

            local pad = 8
            local textY = y + math.floor((self.itemheight - getTextManager():getFontHeight(UIFont.Small)) / 2)
            local text = item.text or ""

            -- Color based on sale type
            local textR, textG, textB = normalText.r, normalText.g, normalText.b
            if item.item and item.item.saleType then
                if item.item.saleType == "[ANUNCIADO]" then
                    textR, textG, textB = 0.5, 0.8, 1.0  -- Light blue for listings
                elseif item.item.saleType == "[CANCELADO]" then
                    textR, textG, textB = 1.0, 0.5, 0.3  -- Orange for cancellations
                end
            end

            local maxW = self:getWidth() - pad * 2 - ((self.vscroll and self.vscroll.width) or 0)
            _ss_drawTextClipped(self, text, pad, textY, maxW, textR, textG, textB, normalText.a, UIFont.Small)
            return y + self.itemheight
        end

        -- Add tabs
        self.my.historyTabs:addView(SS_T("IGUI_SS_TabSales", "Vendas"), self.my.salesList)
        self.my.historyTabs:addView(SS_T("IGUI_SS_TabListings", "Anúncios"), self.my.listingsList)

        -- For backwards compatibility, keep historyList pointing to salesList
        self.my.historyList = self.my.salesList
    end
    
    self.tabPanel:addView(SS_T("IGUI_SS_Tab_Browse","Browse Listings"), self.browse)
    self.tabPanel:addView(SS_T("IGUI_SS_Tab_Sell","Sell Item"), self.sell)
    self.tabPanel:addView(SS_T("IGUI_SS_Tab_MyListings","My Listings"), self.my)

    -- Internal tab keys (avoid relying on localized tab titles)
    self.browse._ssTabKey = SurvivorShopUI.TAB_BROWSE
    self.sell._ssTabKey   = SurvivorShopUI.TAB_SELL
    self.my._ssTabKey     = SurvivorShopUI.TAB_MY
    if self.tabPanel.viewList then
        for _, e in ipairs(self.tabPanel.viewList) do
            if e and e.view == self.browse then e._ssTabKey = SurvivorShopUI.TAB_BROWSE end
            if e and e.view == self.sell then e._ssTabKey = SurvivorShopUI.TAB_SELL end
            if e and e.view == self.my then e._ssTabKey = SurvivorShopUI.TAB_MY end
        end
    end


    -- Slightly taller tabs
    self.tabPanel.tabHeight = 30
    -- Favorites (placeholder)
    local favPanel = self:_makeFavoritesView()
    if favPanel then
        self.favorites = favPanel
        self.tabPanel:addView(SS_T("IGUI_SS_Tab_Favorites","Favorites"), self.favorites)

        self.favorites._ssTabKey = SurvivorShopUI.TAB_FAV
        if self.tabPanel.viewList then
            for _, e in ipairs(self.tabPanel.viewList) do
                if e and e.view == self.favorites then e._ssTabKey = SurvivorShopUI.TAB_FAV end
            end
        end

    end
    self:_applyTabStyle()
    -- Botão Bank (no header, canto superior direito) - abre/fecha painel do Bank na direita
    self.bankOpen = false
    local bankBtnW, bankBtnH = 40, 40
-- Auction (Leilão) - abre/fecha painel do Leilão na direita (só 1 painel por vez)
self.auctionOpen = false
local aucBtnW, aucBtnH = 40, 40

-- Position buttons INSIDE the window, near the top-right corner of the header
local btnY = 8  -- 8px from top
local btnRightMargin = pad + 10  -- margin from right edge
self.btnBank = ISButton:new(self.width - btnRightMargin - bankBtnW, btnY, bankBtnW, bankBtnH, "", self, SurvivorShopUI.onBankToggle)
self.btnBank:initialise(); self.btnBank:instantiate(); self:addChild(self.btnBank)
local bankTex = getTexture("media/ui/SS_Bank.png")
if bankTex then self.btnBank:setImage(bankTex) end
-- center the 32x32 icon inside the square button
self.btnBank.imageX = math.floor((bankBtnW - 28) / 2)
self.btnBank.imageY = math.floor((bankBtnH - 28) / 2)
if self.btnBank.setTooltip then self.btnBank:setTooltip(SS_T("IGUI_SS_Bank","Banco")) else self.btnBank.tooltip = SS_T("IGUI_SS_Bank","Banco") end
SurvivorShopUITheme.styleButton(self.btnBank, "success")

self.btnAuction = ISButton:new(self.btnBank.x - 6 - aucBtnW, btnY, aucBtnW, aucBtnH, "", self, SurvivorShopUI.onAuctionToggle)
self.btnAuction:initialise(); self.btnAuction:instantiate(); self:addChild(self.btnAuction)
local aucTex = getTexture("media/ui/SS_AuctionHammer.png")
if aucTex then self.btnAuction:setImage(aucTex) end
-- center the 32x32 icon inside the square button
self.btnAuction.imageX = math.floor((aucBtnW - 28) / 2)
self.btnAuction.imageY = math.floor((aucBtnH - 28) / 2)
SurvivorShopUITheme.styleButton(self.btnAuction, "warning")
-- image stays B/W; tint makes it yellow on the interface
self.btnAuction.imageColor = {r=1.0, g=0.84, b=0.18, a=1.0}
self.btnAuction:setTooltip(SS_T("IGUI_SS_Auction","Leilão"))

self.details = DetailsPanel:new(detailsX, bodyY, detailsW, bodyH)
    self.details.parentUI = self
    self.details:initialise()
    self.details:instantiate()
    self:addChild(self.details)

    local btnH = 26
    local by = self.height - pad - btnH
    self.btnClose = ISButton:new(self.width - pad - 160, by, 160, btnH, SS_T("IGUI_SS_Close","FECHAR"), self, SurvivorShopUI.onClose)
    self.btnClose:initialise(); self.btnClose:instantiate(); self:addChild(self.btnClose)
    SurvivorShopUITheme.styleButton(self.btnClose, "dangerTiny")

    self.btnRefresh = ISButton:new(self.btnClose.x - pad - 160, by, 160, btnH, SS_T("IGUI_SS_Update","ATUALIZAR"), self, SurvivorShopUI.onRefresh)
    self.btnRefresh:initialise(); self.btnRefresh:instantiate(); self:addChild(self.btnRefresh)
    SurvivorShopUITheme.styleButton(self.btnRefresh, "success")


    self:refreshAll()
end

-- Modern green tab styling (visual-only)
function SurvivorShopUI:_applyTabStyle()
    if not self.tabPanel then return end
    local c = SurvivorShopUITheme.Colors
    local active = self:getActiveTabName()

    local function styleTab(btn, isActive)
        if not btn then return end
        btn.font = UIFont.Medium

        if isActive then
            btn.backgroundColor = {r=c.headerAccent.r, g=c.headerAccent.g, b=c.headerAccent.b, a=0.72}
            btn.backgroundColorMouseOver = {r=c.headerAccent.r, g=c.headerAccent.g, b=c.headerAccent.b, a=0.88}
            btn.borderColor = {r=c.headerAccent.r, g=c.headerAccent.g, b=c.headerAccent.b, a=1.00}
            btn.textColor = {r=0.08, g=0.07, b=0.06, a=1}
        else
            btn.backgroundColor = {r=c.panelInset.r, g=c.panelInset.g, b=c.panelInset.b, a=0.82}
            btn.backgroundColorMouseOver = {r=c.btnDefaultOver.r, g=c.btnDefaultOver.g, b=c.btnDefaultOver.b, a=0.78}
            btn.borderColor = {r=c.panelBorderSoft.r, g=c.panelBorderSoft.g, b=c.panelBorderSoft.b, a=0.95}
            btn.textColor = {r=c.normalText.r, g=c.normalText.g, b=c.normalText.b, a=1}
        end

        -- slightly roomier title spacing (safe if field exists)
        btn.titlepad = 12
    end

    -- Try common ISTabPanel structures
    if self.tabPanel.tabs then
        for k, t in pairs(self.tabPanel.tabs) do
            local name = t.name or t.text or t.title or (type(k) == "string" and k or nil)
            local btn = t.button or t.tabButton or t.btn
            if btn then styleTab(btn, name == active) end
        end
    end

    if self.tabPanel.buttons then
        for _, btn in pairs(self.tabPanel.buttons) do
            local name = btn.name or btn.title or btn.text
            styleTab(btn, name == active)
        end
    end

    -- Fallback:style any ISButton child in the tabPanel
    if self.tabPanel.children then
        for _, child in pairs(self.tabPanel.children) do
            if instanceof and instanceof(child, "ISButton") then
                local nm = child.title or child.name or child.text
                styleTab(child, nm == active)
            end
        end
    end
end

function SurvivorShopUI:_makeListView(withSearch, withCategory, withPager)
    local panel = ISPanel:new(0, 0, self.tabPanel.width, self.tabPanel.height - self.tabPanel.tabHeight)
    panel:initialise()
    panel:instantiate()
    panel.backgroundColor = {r=0, g=0, b=0, a=0}
    panel.borderColor = {r=0, g=0, b=0, a=0}

    local pad = 10
    local y = 0
    local searchH = 24
    local clearSize = 16
    panel.searchQuery = ""
    panel.searchPendingRefresh = false
    panel.searchEntry = nil
    panel.searchClearBtn = nil
    panel.searchLastText = ""
    local uiSelf = self
    panel._pad = pad
    panel._clearSize = clearSize
    panel._searchH = searchH

    if withSearch then
        local entryW = panel.width - pad * 2 - clearSize - 4
        panel.searchEntry = ISTextEntryBox:new("", pad, pad, entryW, searchH)
        panel.searchEntry.font = UIFont.Small
        panel.searchEntry:initialise()
        panel.searchEntry:instantiate()
                SurvivorShopUITheme.styleTextEntry(panel.searchEntry)
        local tip = (getText and getText("UI_Search")) or "Search..."
        if panel.searchEntry.setTooltip then
            panel.searchEntry:setTooltip(tip)
        else
            panel.searchEntry.tooltip = tip
        end
        panel:addChild(panel.searchEntry)

        panel.searchClearBtn = ISButton:new(pad + entryW + 4, pad + (searchH - clearSize) / 2, clearSize, clearSize, "X", self, SurvivorShopUI.onSearchClearClick)
        panel.searchClearBtn:initialise()
        panel.searchClearBtn:instantiate()
        SurvivorShopUITheme.styleButton(panel.searchClearBtn, "dangerTiny")
        panel.searchClearBtn._ownerView = panel
        panel:addChild(panel.searchClearBtn)

        panel.searchEntry._ownerView = panel
        panel.searchEntry.onTextChange = function()
            local v = panel.searchEntry and panel.searchEntry._ownerView
            if v then v.searchPendingRefresh = true end
        end
        local origOnOtherKey = panel.searchEntry.onOtherKey
        panel.searchEntry.onOtherKey = function(entry, key)
            if origOnOtherKey then origOnOtherKey(entry, key) end
            local v = entry and entry._ownerView
            if v then v.searchPendingRefresh = true end
        end

        y = pad + searchH + 8
    end


    -- Extra controls (Browse):Category + Pagination
    if withCategory then
        local comboH = 22
        panel.selectedCategory = panel.selectedCategory or "ALL"
        panel.catCombo = ISComboBox:new(pad, y, math.floor((panel.width - pad * 2) * 0.5), comboH, nil, nil)
        panel.catCombo:initialise()
        panel.catCombo:instantiate()
        panel.catCombo.font = UIFont.Small
        SurvivorShopUITheme.styleComboBox(panel.catCombo)
        panel.catData = panel.catData or {}
        panel.catCombo:addOption(SS_T("IGUI_SS_Category_All","ALL"))
        panel.catData[#panel.catCombo.options] = "ALL"
        for _, cat in ipairs(SurvivorShopUI.getAllDisplayCategories()) do
            if cat and cat ~= "" and cat ~= "ALL" then
                panel.catCombo:addOption(cat)
            panel.catData[#panel.catCombo.options] = cat
            end
        end
        -- select current
        for i=1, #panel.catCombo.options do
            if panel.catCombo.options[i] == panel.selectedCategory then
                panel.catCombo.selected = i
                break
            end
        end
        panel.catCombo.onChange = function()
            local idx = panel.catCombo.selected or 1
            local internal = (panel.catData and panel.catData[idx]) or panel.catCombo.options[idx]
            panel.selectedCategory = internal or "ALL"
            panel.page = 1
            panel.searchPendingRefresh = false
            if uiSelf and uiSelf.browse == panel then uiSelf.browseForcedItemType = nil end
            if uiSelf and uiSelf.refreshBrowse then uiSelf:refreshBrowse() end
        end
        panel:addChild(panel.catCombo)
        y = y + comboH + 6
    end

    if withCategory or withPager then
        local rowH = 22
        panel.modeLabel = ISLabel:new(pad, y + 3, 20, SS_T("IGUI_SS_Sort_Cheapest","Mais recentes"), 0.75,0.75,0.75,1, UIFont.Small, true)
        panel:addChild(panel.modeLabel)

        if withPager then
            panel.perPage = panel.perPage or 20
            panel.page = panel.page or 1
            panel.totalPages = panel.totalPages or 1

            local btnW, btnH = 26, 22
            local labelW = 70
            panel._pagerLabelW = labelW
            local rightX = panel.width - pad - (btnW + 4 + labelW + 4 + btnW)

            panel.btnPrev = ISButton:new(rightX, y, btnW, btnH, "<", uiSelf, SurvivorShopUI.onBrowsePrevPage)
            panel.btnPrev:initialise()
            panel.btnPrev:instantiate()
            SurvivorShopUITheme.styleButton(panel.btnPrev)
            panel.btnPrev._ownerView = panel
            panel:addChild(panel.btnPrev)

            panel.pageLabel = ISButton:new(rightX + btnW + 4, y, labelW, btnH, "1/1", uiSelf, SS_onPagerNoop)
            panel.pageLabel:initialise()
            panel.pageLabel:instantiate()
            SurvivorShopUITheme.styleButton(panel.pageLabel)
            if panel.pageLabel.setEnable then panel.pageLabel:setEnable(false) else panel.pageLabel.enable = false end
            panel:addChild(panel.pageLabel)

            panel.btnNext = ISButton:new(rightX + btnW + 4 + labelW + 4, y, btnW, btnH, ">", uiSelf, SurvivorShopUI.onBrowseNextPage)
            panel.btnNext:initialise()
            panel.btnNext:instantiate()
            SurvivorShopUITheme.styleButton(panel.btnNext)
            panel.btnNext._ownerView = panel
            panel:addChild(panel.btnNext)

                        -- layout:categoria alinhada à esquerda; paginação alinhada à direita na mesma linha.
            if panel.catCombo then
                panel.catCombo:setX(pad)
                panel.catCombo:setWidth(math.floor((panel.width - pad * 2) * 0.5))
            end

            local pagerW = (btnW + 4 + labelW + 4 + btnW)
            local pagerX = panel.width - pad - pagerW
            local pagerY = (panel.catCombo and panel.catCombo:getY()) or y

            panel.btnPrev:setX(pagerX)
            panel.btnPrev:setY(pagerY)
            panel.pageLabel:setX(pagerX + btnW + 4)
            panel.pageLabel:setY(pagerY)
            panel.btnNext:setX(pagerX + btnW + 4 + labelW + 4)
            panel.btnNext:setY(pagerY)
        end

        y = y + rowH + 6
    end

    panel.list = ISScrollingListBox:new(0, y, panel.width, panel.height - y)
    panel.list:initialise()
    panel.list.drawBorder = false
    panel.list.backgroundColor = {r=0, g=0, b=0, a=0}
    panel._isBrowseView = (withCategory == true) or (withPager == true)
    -- Dynamic height so 2-line rows never overlap with UI scale/font changes
    local mediumH = getTextManager():getFontHeight(UIFont.Medium)
    local smallH  = getTextManager():getFontHeight(UIFont.Small)
    local browseH = 8 + mediumH + 4 + smallH + 22
    if browseH < 74 then browseH = 74 end
    panel.list.itemheight = panel._isBrowseView and browseH or 36
    panel.list.doDrawItem = SurvivorShopUI.doDrawItem
    panel.list._ownerView = panel
    panel:addChild(panel.list)
    SurvivorShopUITheme.styleListBox(panel.list)

    local _origPrerender = panel.prerender
    function panel:prerender()
        if _origPrerender then _origPrerender(self) else ISPanel.prerender(self) end
        SS_drawListViewChrome(self, y)
    end

    return panel
end

function SurvivorShopUI:_makeFavoritesView()
    -- Favorites tab:keep the same header layout as "Browse Listings"
    -- (Search row + Category row with pager aligned to the right + label row)
    local panel = ISPanel:new(0, 0, self.tabPanel.width, self.tabPanel.height - self.tabPanel.tabHeight)
    panel:initialise()
    panel:instantiate()
    panel.backgroundColor = {r=0, g=0, b=0, a=0}
    panel.borderColor = {r=0, g=0, b=0, a=0}

    local pad = 10
    local y = 0
    local searchH = 24
    local clearSize = 16


    local uiSelf = self

    panel.page = 1
    panel.perPage = 50
    panel.totalPages = 1

    -- Search (same as Browse)
    local entryW = panel.width - pad * 2 - clearSize - 4
    panel.searchEntry = ISTextEntryBox:new("", pad, pad, entryW, searchH)
    panel.searchEntry.font = UIFont.Small
    panel.searchEntry:initialise()
    panel.searchEntry:instantiate()
    SS_styleField(panel.searchEntry)
    local tip = SS_T("IGUI_SS_FavSearchTip","Buscar item para favoritar...")
    if panel.searchEntry.setTooltip then panel.searchEntry:setTooltip(tip) else panel.searchEntry.tooltip = tip end
    panel:addChild(panel.searchEntry)

    panel.searchClearBtn = ISButton:new(pad + entryW + 4, pad + (searchH - clearSize)/2, clearSize, clearSize, "X", self, function()
        if panel.searchEntry then panel.searchEntry:setText("") end
        panel.page = 1
        self:refreshFavorites()
    end)
    panel.searchClearBtn:initialise()
    panel.searchClearBtn:instantiate()
    SurvivorShopUITheme.styleButton(panel.searchClearBtn)
    panel:addChild(panel.searchClearBtn)

    -- Debounced search handling (favorites scans can be heavy)
    panel.searchEntry.onTextChange = function()
        self:onFavSearchChanged()
    end
    local origOnOtherKey = panel.searchEntry.onOtherKey
    panel.searchEntry.onOtherKey = function(entry, key)
        if origOnOtherKey then origOnOtherKey(entry, key) end
        self:onFavSearchChanged()
    end

    y = pad + searchH + 8

    -- Category combo (left) + Pager (right) aligned like Browse
    local comboH = 22
    panel.catCombo = ISComboBox:new(pad, y, math.floor((panel.width - pad * 2) * 0.5), comboH, nil, nil)
    panel.catCombo:initialise()
    panel.catCombo:instantiate()
    panel.catCombo.font = UIFont.Small
    SurvivorShopUITheme.styleComboBox(panel.catCombo)
    panel.catData = panel.catData or {}

    panel.catCombo:addOption(SS_T("IGUI_SS_Category_All","ALL"))
    panel.catData[#panel.catCombo.options] = "ALL"
    for _, cat in ipairs(SurvivorShopUI.getAllDisplayCategories()) do
        if cat and cat ~= "" and cat ~= "ALL" then
            panel.catCombo:addOption(cat)
            panel.catData[#panel.catCombo.options] = cat
        end
    end
    panel.catCombo.selected = 1
    panel.catCombo.onChange = function()
        self:onFavCategoryChanged()
    end
    panel:addChild(panel.catCombo)

    -- Label row (below category row, same as Browse's "Mais baratos")
    y = y + comboH + 6
    local rowH = 22
    panel.modeLabel = ISLabel:new(pad, y + 3, 20, SS_T("IGUI_SS_FavoritesHeader","Favoritos"), 0.75,0.75,0.75,1, UIFont.Small, true)
    panel:addChild(panel.modeLabel)

    -- Pager buttons styled and aligned to the right (same spacing as Browse)
    local btnW, btnH = 26, 22
    local labelW = 70
    local pagerW = (btnW + 4 + labelW + 4 + btnW)
    local pagerX = panel.width - pad - pagerW
    local pagerY = panel.catCombo:getY()

    panel.btnPrev = ISButton:new(pagerX, pagerY, btnW, btnH, "<", self, function()
        panel.page = math.max(1, (tonumber(panel.page) or 1) - 1)
        self:refreshFavorites()
    end)
    panel.btnPrev:initialise()
    panel.btnPrev:instantiate()
    SurvivorShopUITheme.styleButton(panel.btnPrev)
    panel:addChild(panel.btnPrev)

    -- Use a disabled button as label so it stays perfectly centered between < >
    panel.pagerLabel = ISButton:new(pagerX + btnW + 4, pagerY, labelW, btnH, "1/1", self, SS_onPagerNoop)
    panel.pagerLabel:initialise()
    panel.pagerLabel:instantiate()
    SurvivorShopUITheme.styleButton(panel.pagerLabel)
    if panel.pagerLabel.setEnable then panel.pagerLabel:setEnable(false) else panel.pagerLabel.enable = false end
    panel:addChild(panel.pagerLabel)

    panel.btnNext = ISButton:new(pagerX + btnW + 4 + labelW + 4, pagerY, btnW, btnH, ">", self, function()
        panel.page = (tonumber(panel.page) or 1) + 1
        self:refreshFavorites()
    end)
    panel.btnNext:initialise()
    panel.btnNext:instantiate()
    SurvivorShopUITheme.styleButton(panel.btnNext)
    panel:addChild(panel.btnNext)

    
    -- Keep header aligned if the panel is resized / UI scale changes
    local function _reflowHeader()
        local w = panel.width
        local entryW2 = w - pad * 2 - clearSize - 4
        if panel.searchEntry then panel.searchEntry:setWidth(entryW2) end
        if panel.searchClearBtn then panel.searchClearBtn:setX(pad + entryW2 + 4) end

        if panel.catCombo then
            panel.catCombo:setX(pad)
            panel.catCombo:setWidth(math.floor((w - pad * 2) * 0.5))
        end

        local pagerX2 = w - pad - pagerW
        local pagerY2 = panel.catCombo and panel.catCombo:getY() or pagerY
        if panel.btnPrev then panel.btnPrev:setX(pagerX2); panel.btnPrev:setY(pagerY2) end
        if panel.pagerLabel then panel.pagerLabel:setX(pagerX2 + btnW + 4); panel.pagerLabel:setY(pagerY2) end
        if panel.btnNext then panel.btnNext:setX(pagerX2 + btnW + 4 + labelW + 4); panel.btnNext:setY(pagerY2) end
    end

    local _origPrerender = panel.prerender
    function panel:prerender()
        if _origPrerender then _origPrerender(self) else ISPanel.prerender(self) end
        _reflowHeader()
        SS_drawListViewChrome(self, y)
    end
    _reflowHeader()
y = y + rowH + 6

    -- List
    panel.list = ISScrollingListBox:new(0, y, panel.width, panel.height - y)
    panel.list:initialise()
    panel.list.drawBorder = false
    panel.list.backgroundColor = {r=0, g=0, b=0, a=0}
    panel.list.itemheight = 56
    panel:addChild(panel.list)
    SurvivorShopUITheme.styleListBox(panel.list)

    -- Click star/buy to toggle favorite or jump to Browse
    do
        local oldMouseDown = panel.list.onMouseDown
        function panel.list:onMouseDown(x, y)
            if oldMouseDown then oldMouseDown(self, x, y) end
            local sel = self.selected
            local row = sel and self.items and self.items[sel] and self.items[sel].item
            if not row then return end
            local u = row._ui or (row.item and row.item._ui)

            -- Star toggle
            local r = u and u.star
            if r and x >= r.x and x <= r.x + r.w and y >= r.y and y <= r.y + r.h then
                local ft = row.fullType or row.itemType or (row.item and row.item.itemType)
                if ft and uiSelf and uiSelf.toggleFavorite then
                    uiSelf:toggleFavorite(tostring(ft))
                elseif SurvivorShopUI and SurvivorShopUI.instance and SurvivorShopUI.instance.toggleFavorite and ft then
                    SurvivorShopUI.instance:toggleFavorite(tostring(ft))
                end
                panel.page = panel.page or 1
                uiSelf:refreshFavorites()
                return
            end

            -- Buy / Out-of-stock button (only active favorites)
            local b = u and u.buy
            if b and x >= b.x and x <= b.x + b.w and y >= b.y and y <= b.y + b.h then
                if b.enabled then
                    local ft2 = row.fullType or row.itemType or (row.item and row.item.itemType)
                    if ft2 and uiSelf and uiSelf.jumpToBrowseItem then
                        uiSelf:jumpToBrowseItem(tostring(ft2))
                    end
                end
                return
            end
        end
    end

-- first fill
    self:refreshFavorites()

    return panel
end



--========================================================
-- Layout helper:quando Bank estiver aberto, escondemos o painel de detalhes da loja
-- e expandimos a lista para ocupar a largura toda (o Bank fica fora, colado na loja).
--========================================================
function SurvivorShopUI:_resizeTabViews(newW)
    if not self.tabPanel or not self.tabPanel.viewList then return end
    for _, v in ipairs(self.tabPanel.viewList) do
        local p = v.view
        if p then
            p:setWidth(newW)

            local pad = p._pad or 10
            local clearSize = p._clearSize or 16
            local searchH = p._searchH or 24

            if p.searchEntry then
                local entryW = newW - pad * 2 - clearSize - 4
                if entryW < 40 then entryW = 40 end
                p.searchEntry:setWidth(entryW)
                if p.searchClearBtn then
                    p.searchClearBtn:setX(pad + entryW + 4)
                    p.searchClearBtn:setY(pad + (searchH - clearSize) / 2)
                end
            end

            if p.catCombo then
                p.catCombo:setWidth(math.floor((newW - pad * 2) * 0.5))
            end

            if p.btnPrev and p.btnNext then
                local btnW = p.btnPrev.width or 26
                local labelW = p._pagerLabelW or 70
                local rightX = newW - pad - (btnW + 4 + labelW + 4 + btnW)
                p.btnPrev:setX(rightX)
                if p.pageLabel then p.pageLabel:setX(rightX + btnW + 4) end
                p.btnNext:setX(rightX + btnW + 4 + labelW + 4)
            end

            if p.list then
                p.list:setWidth(newW)
            end
        end
    end
end

function SurvivorShopUI:_cacheLayoutForBank()
    if self._bankLayoutCached then return end
    self._bankLayoutCached = true
    self._bankLayout = {
        pad = 12,
        tabX = self.tabPanel and self.tabPanel.x or 12,
        tabW = self.tabPanel and self.tabPanel.width or 0,
        detailsW = self.details and self.details.width or 0,
        detailsX = self.details and self.details.x or 0,
        detailsVisible = self.details and self.details:getIsVisible() or true,
    }
end

function SurvivorShopUI:applyBankLayout(isOpen)
    self:_cacheLayoutForBank()
    local L = self._bankLayout
    if not L or not self.tabPanel then return end

    if isOpen then
        -- esconde o painel da direita (onde aparece nome do item / ações da loja)
        if self.details then
            self.details:setVisible(false)
        end

        -- expande a lista para preencher a janela da loja
        local newW = self.width - (L.tabX * 2)
        self.tabPanel:setWidth(newW)
        self:_resizeTabViews(newW)
    else
        -- restaura largura original
        self.tabPanel:setWidth(L.tabW)
        self:_resizeTabViews(L.tabW)

        if self.details then
            self.details:setX(self.tabPanel.x + self.tabPanel.width + L.pad)
            self.details:setWidth(L.detailsW)
            self.details:setVisible(L.detailsVisible ~= false)
            if self.details.syncVisible then self.details:syncVisible()

-- Search:refresh list when query changes (active tab)
local activeKey = self:getActiveTabKey()
local view = (activeKey == SurvivorShopUI.TAB_BROWSE and self.browse) or (activeKey == SurvivorShopUI.TAB_SELL and self.sell) or (activeKey == SurvivorShopUI.TAB_MY and self.my) or (activeKey == SurvivorShopUI.TAB_FAV and self.favorites) or nil
if view and view.searchEntry and view.searchPendingRefresh then
    view.searchPendingRefresh = false
    local txt = view.searchEntry:getText() or ""
    if txt ~= view.searchLastText then
        view.searchLastText = txt
        view.searchQuery = txt
        if activeKey == SurvivorShopUI.TAB_BROWSE then
            if not self._browseForceLock then self.browseForcedItemType = nil end
            
            if self.browse then self.browse.page = 1 end
            self:refreshBrowse()
        elseif activeKey == SurvivorShopUI.TAB_SELL then
            self:refreshSell()
        elseif activeKey == SurvivorShopUI.TAB_MY then
            self:refreshMyListings()
            SurvivorShopClient.requestSalesHistory()
            self:refreshSalesHistory()
        elseif activeKey == SurvivorShopUI.TAB_FAV then
            if SurvivorShopClient and SurvivorShopClient.requestFavorites then SurvivorShopClient.requestFavorites() end
            self:refreshFavorites()
        end
    end
end
 end
        end
    end
end

function SurvivorShopUI:getActiveTabName()
    if not self.tabPanel then return "Browse Listings" end
    local av = self.tabPanel.activeView
    -- B42 ISTabPanel may store either the view panel or an entry table {name=..., view=...}
    if type(av) == "table" then
        if av.name then return av.name end
        if av.view and av.view.name then return av.view.name end
    end
    return (av and av.name) or "Browse Listings"
end


function SurvivorShopUI:getActiveTabKey()
    if not self.tabPanel then return SurvivorShopUI.TAB_BROWSE end
    local av = self.tabPanel.activeView
    local view = av
    -- B42 ISTabPanel can store activeView as an entry table {name=..., view=...}
    if type(av) == "table" and av.view then view = av.view end

    -- Prefer explicit key when available
    if type(av) == "table" and av._ssTabKey then return av._ssTabKey end
    if view and view._ssTabKey then return view._ssTabKey end

    if view == self.browse then return SurvivorShopUI.TAB_BROWSE end
    if view == self.sell then return SurvivorShopUI.TAB_SELL end
    if view == self.my then return SurvivorShopUI.TAB_MY end
    if view == self.favorites then return SurvivorShopUI.TAB_FAV end
    return SurvivorShopUI.TAB_BROWSE
end





function SurvivorShopUI:onBrowsePrevPage()
    if not self.browse then return end
    self.browse.page = math.max(1, (tonumber(self.browse.page) or 1) - 1)
    self:refreshBrowse()
end

function SurvivorShopUI:onBrowseNextPage()
    if not self.browse then return end
    local tp = tonumber(self.browse.totalPages) or 1
    self.browse.page = math.min(tp, (tonumber(self.browse.page) or 1) + 1)
    self:refreshBrowse()
end

function SurvivorShopUI.onSearchClearClick(target, btn)
    local view = btn and btn._ownerView or nil
    if not view or not view.searchEntry then return end
    view.searchEntry:setText("")
    view.searchQuery = ""
    view.searchLastText = ""
    if view.page then view.page = 1 end

    if target and target.getActiveTabName then
        local activeKey = target:getActiveTabKey()
        if activeKey == SurvivorShopUI.TAB_BROWSE then
            target.browseForcedItemType = nil
            target:refreshBrowse()
        elseif activeKey == SurvivorShopUI.TAB_SELL then
            target:refreshSell()
        elseif activeKey == SurvivorShopUI.TAB_MY then
            target:refreshMyListings()
        end
    end
end

function SurvivorShopUI:isBankOpen()
    return self.bankOpen == true
end

function SurvivorShopUI:onBankToggle()
    if self.auctionOpen then self:closeAuction() end
    if self.bankOpen then
        self:closeBank()
    else
        self:openBank()
    end
end

function SurvivorShopUI:openBank()
    self.bankOpen = true
    self:applyBankLayout(true)
    if not self.bankOverlay then
        self.bankOverlay = SurvivorShopBankOverlayV2:new(self)
        self.bankOverlay:initialise()
        self.bankOverlay:instantiate()
        self.bankOverlay:addToUIManager()
    end

    self.bankOverlay.ownerUI = self
    self.bankOverlay:setVisible(true)
    self.bankOverlay:bringToTop()
    self.bankOverlay:alignToShop()

    if SurvivorShopClient.requestBankSnapshot then
        SurvivorShopClient.requestBankSnapshot()
    else
        SurvivorShopClient.requestBalance()
        if SurvivorShopClient.requestOnlinePlayers then SurvivorShopClient.requestOnlinePlayers() end
    end
    if SurvivorShopClient.requestFavorites then SurvivorShopClient.requestFavorites() end
end

function SurvivorShopUI:closeBank()
    self.bankOpen = false
    self:applyBankLayout(false)
    if self.bankOverlay then
        self.bankOverlay:setVisible(false)
    end
end

function SurvivorShopUI:onAuctionToggle()
    if self.bankOpen then self:closeBank() end
    if self.auctionOpen then
        self:closeAuction()
    else
        self:openAuction()
    end
end

function SurvivorShopUI:openAuction()
    if self.auctionOpen then return end
    self.auctionOpen = true

    if self.auctionOverlay then
        self.auctionOverlay:setVisible(true)
    else
        self.auctionOverlay = AuctionOverlay:new(self)
        self.auctionOverlay:initialise()
        self.auctionOverlay:instantiate()
        self.auctionOverlay:addToUIManager()
    end

    if self.auctionOverlay then
        if self.auctionOverlay.bringToTop then self.auctionOverlay:bringToTop() end
        if self.auctionOverlay.alignToShop then self.auctionOverlay:alignToShop() end
    end

    self:applyBankLayout(true)

    if SurvivorShopClient and SurvivorShopClient.requestAuctionHello then
        SurvivorShopClient.requestAuctionHello()
    end
end

function SurvivorShopUI:closeAuction()
    if not self.auctionOpen then return end
    self.auctionOpen = false
    if self.auctionOverlay then
        self.auctionOverlay:setVisible(false)
    end
    if not self.bankOpen then
        self:applyBankLayout(false)
    end
end


function SurvivorShopUI:refreshBalance()
    if self.bankOverlay and self.bankOverlay:getIsVisible() then
        self.bankOverlay:refreshBalance()
    end
end

function SurvivorShopUI:toggleBrowseGroup(itemType)
    self.browseExpanded = self.browseExpanded or {}

    local q = SurvivorShopUITheme.normQuery(self.browse.searchQuery)


    local forceType = self.browseForcedItemType
    self.browseExpanded[itemType] = not self.browseExpanded[itemType]
    self:refreshBrowse()
    self:updateSelected()
end


function SurvivorShopUI:getActiveListBox()
    local tab = self:getActiveTabKey()
    if tab == SurvivorShopUI.TAB_BROWSE then return self.browse.list end
    if tab == SurvivorShopUI.TAB_SELL then return self.sell.list end
    if tab == SurvivorShopUI.TAB_MY then return self.my.list end
    if tab == SurvivorShopUI.TAB_FAV then return self.favorites and self.favorites.list end
    return nil
end

function SurvivorShopUI:updateSelected()
    if self.bankOpen then
        if self.details then
            self.details:setHeaderText(SS_T("IGUI_SS_Bank","Banco"), "")
            self.details._iconTex = nil
        end
        return
    end
    local list = self:getActiveListBox()
    if not list then self.selectedRow = nil; return end

    local i = list.selected
    local row = (i and list.items[i]) and list.items[i].item or nil
    if not row then
        self.selectedRow = nil
        self.details:setHeaderText(SS_T("IGUI_SS_SelectItem","Selecione um item"), "")
        self.details._iconTex = nil
        self.details._statsLineCount = 0
        -- Clear stats label when no item selected
        if self.details._statsLabels then
            for _,_lbl in ipairs(self.details._statsLabels) do _lbl:setName(""); _lbl:setVisible(false) end
        end
        if self.details and self.details.updateSellPreview then
            self.details:updateSellPreview()
        end
        return
    end

    if row.kind == "group" then self.selectedRow = nil else self.selectedRow = row end
    local selectedTitle = SS_stripUnknownPrefix(tostring(row.name or row.itemType or "Item"))
    local selectedItemType = row.itemType or row.fullType or (row.item and row.item.itemType) or nil
    self.details._iconTex = SurvivorShopUI.getItemTex(selectedItemType)

    -- Build details subtitle with stats
    local detailsParts = {}
    table.insert(detailsParts, SS_T("IGUI_SS_Qty","Qtd") .. ": " .. tostring(row.quantity or 0))

    -- Add seller info to subtitle
    if row.sellerName and row.sellerName ~= "" then
        local sellerTxt = tostring(row.sellerName)
        table.insert(detailsParts, SS_T("IGUI_SS_Seller","Vendedor") .. ": " .. sellerTxt)
    end

    self.details:setHeaderText(selectedTitle, table.concat(detailsParts, " | "))

    -- ── Painel de detalhe multi-cor ───────────────────────────────────────────
    -- Cada entrada: { text, r, g, b }
    -- Verde  (0.3,1,0.3)  = bom para o jogador
    -- Vermelho (1,0.4,0.4) = mau / alerta
    -- Amarelo (1,1,0.3)   = neutro / intermediário
    -- Branco  (1,1,1)     = informação neutra
    -- Cinza   (0.6,0.6,0.6) = informação secundária

    local CG = {0.3, 1.0, 0.3}   -- verde
    local CR = {1.0, 0.4, 0.4}   -- vermelho
    local CY = {1.0, 1.0, 0.3}   -- amarelo
    local CW = {1.0, 1.0, 1.0}   -- branco
    local CS = {0.6, 0.6, 0.6}   -- cinza

    local lines = {}  -- {text, r, g, b}

    local function add(text, col)
        col = col or CW
        table.insert(lines, {text=text, r=col[1], g=col[2], b=col[3]})
    end

    local function fmtSign(v)
        if v == nil then return "?" end
        if v < 0 then return tostring(v) else return "+" .. tostring(v) end
    end

    if row.itemStats and type(row.itemStats) == "table" then
        local s   = row.itemStats
        local isN = s.isNew

        -- Estado geral
        local tagKey = isN and "IGUI_SS_StateNew" or "IGUI_SS_StateUsed"
        local tag    = SS_T(tagKey, isN and "NOVO" or "USADO")
        add(SS_T("IGUI_SS_ItemState","ESTADO") .. ":  " .. tag, isN and CG or CR)

        -- Condição (ferramentas, armas, roupas)
        if s.minCondition ~= nil then
            local col = s.minCondition >= 75 and CG or (s.minCondition >= 40 and CY or CR)
            add(SS_T("IGUI_SS_ItemCondition","Condição") .. ":  " .. tostring(s.minCondition) .. "%", col)
        end

        -- Usos restantes (isqueiro, vareta, tocha)
        if s.minUses ~= nil then
            local col = s.minUses > 75 and CG or (s.minUses > 30 and CY or CR)
            if s.minUses <= 0 then
                add(SS_T("IGUI_SS_ItemEmpty","Usos:  VAZIO"), CR)
            else
                add(SS_T("IGUI_SS_ItemUses","Usos restantes") .. ":  " .. tostring(s.minUses) .. "%", col)
            end
        end

        -- Líquido (garrafa, botijão, etc.)
        if s.fluidAmount ~= nil then
            local fluidTxt
            if (s.fluidAmount or 0) <= 0 then
                add(SS_T("IGUI_SS_FluidLabel","Líquido") .. ":  " .. SS_T("IGUI_SS_FluidEmpty","VAZIO"), CR)
            else
                if s.fluidPercent ~= nil and s.fluidMax ~= nil and s.fluidMax > 0 then
                    fluidTxt = SS_T("IGUI_SS_FluidLabel","Líquido") .. ":  "
                        .. string.format("%.2fL / %.2fL", s.fluidAmount, s.fluidMax)
                        .. "  (" .. tostring(s.fluidPercent) .. "%)"
                    local col = s.fluidPercent >= 75 and CG or (s.fluidPercent >= 30 and CY or CR)
                    if s.fluidLabel and s.fluidLabel ~= "" and s.fluidLabel ~= "?" then
                        fluidTxt = fluidTxt .. "  [" .. tostring(s.fluidLabel) .. "]"
                    end
                    add(fluidTxt, col)
                else
                    fluidTxt = SS_T("IGUI_SS_FluidLabel","Líquido") .. ":  "
                        .. string.format("%.2fL", s.fluidAmount)
                    if s.fluidLabel and s.fluidLabel ~= "" and s.fluidLabel ~= "?" then
                        fluidTxt = fluidTxt .. "  [" .. tostring(s.fluidLabel) .. "]"
                    end
                    add(fluidTxt, CW)
                end
            end
        end

        -- ── Comida ────────────────────────────────────────────────────────────
        if s.foodHunger ~= nil or s.foodWeightPct ~= nil then

            -- Quanto resta
            if s.foodWeightPct ~= nil then
                local baseStr = s.foodBaseWeight ~= nil
                    and ("  (base " .. string.format("%.2f", s.foodBaseWeight) .. " kg)") or ""
                local col = s.foodWeightPct >= 90 and CW or (s.foodWeightPct >= 50 and CY or CR)
                add(SS_T("IGUI_SS_FoodWeight","Restante") .. ":  "
                    .. tostring(s.foodWeightPct) .. "%" .. baseStr, col)
            end

            if s.foodFreshnessPct ~= nil then
                local col = s.foodFreshnessPct >= 75 and CG or (s.foodFreshnessPct >= 40 and CY or CR)
                add("Frescor:  " .. tostring(s.foodFreshnessPct) .. "%", col)
            end

            -- Fome: negativo = reduz fome = VERDE; positivo = aumenta fome = VERMELHO
            if s.foodHunger ~= nil then
                local col = s.foodHunger < 0 and CG or CR
                add(SS_T("IGUI_SS_FoodHunger","Fome") .. ":  " .. fmtSign(s.foodHunger), col)
            end

            -- Tristeza: positivo = aumenta tristeza = VERMELHO; negativo = reduz = VERDE
            if s.foodUnhappy ~= nil then
                local col = s.foodUnhappy > 0 and CR or CG
                add(SS_T("IGUI_SS_FoodUnhappy","Tristeza") .. ":  " .. fmtSign(s.foodUnhappy), col)
            end

            -- Tédio: positivo = aumenta tédio = VERMELHO; negativo = reduz = VERDE; zero = cinza
            if s.foodBoredom ~= nil then
                local col = s.foodBoredom > 0 and CR or (s.foodBoredom < 0 and CG or CS)
                add(SS_T("IGUI_SS_FoodBoredom","Tédio") .. ":  " .. fmtSign(s.foodBoredom), col)
            end

            -- Dias frescos (branco) / dias podre (vermelho) — em linhas separadas
            if s.foodDaysTotal ~= nil then
                add(SS_T("IGUI_SS_FoodFresh","Frescos") .. ":  " .. tostring(s.foodDaysTotal) .. "d", CW)
            end
            if s.foodDaysBad ~= nil then
                add(SS_T("IGUI_SS_FoodBad","Podre") .. ":  " .. tostring(s.foodDaysBad) .. "d", CR)
            end
            -- "(congelado na loja)" em linha separada cinza
            if s.foodDaysTotal ~= nil or s.foodDaysBad ~= nil then
                add(SS_T("IGUI_SS_FoodFrozen","(congelado na loja)"), CS)
            end

            -- Estado de cozimento
            if s.foodBurnt then
                add("⚠ " .. SS_T("IGUI_SS_FoodBurnt","QUEIMADO"), CR)
            elseif s.foodCooked then
                add(SS_T("IGUI_SS_FoodCooked","Cozido"), CW)
            end
        end
    end

    -- Atualiza os ISLabel reutilizáveis (um por linha)
    local lbls = self.details._statsLabels or {}
    self.details._statsLineCount = math.min(#lines, #lbls)
    for i = 1, #lbls do
        local lbl = lbls[i]
        local ln  = lines[i]
        if ln then
            lbl:setName(ln.text)
            lbl:setColor(ln.r, ln.g, ln.b, 1.0)
            lbl:setVisible(true)
        else
            lbl:setName("")
            lbl:setVisible(false)
        end
    end
    -- Compatibilidade retroativa: hide old statsLabel se ainda existir
    if self.details.statsLabel then
        self.details.statsLabel:setName("")
        self.details.statsLabel:setVisible(false)
    end
    if self.details and self.details.updateSellPreview then
        self.details:updateSellPreview()
    end
end

function SurvivorShopUI:refreshBrowse()
    local list = self.browse.list
    list:clear()

    -- Clear details panel when refreshing browse list
    if self.details and self.details._statsLabels then
        for _,_lbl in ipairs(self.details._statsLabels) do _lbl:setName(""); _lbl:setVisible(false) end
    end

    self.browseExpanded = self.browseExpanded or {}
    local q = SurvivorShopUITheme.normQuery(self.browse.searchQuery)


    local forceType = self.browseForcedItemType
    local cat = (self.browse and self.browse.selectedCategory) or "ALL"
    local perPage = (self.browse and tonumber(self.browse.perPage)) or 20
    local page = (self.browse and tonumber(self.browse.page)) or 1

    -- Group by itemType; clicking a group expands/collapses to show all listings for that item.
    local groups = {}
    for _, l in ipairs(SurvivorShopClient.listings or {}) do
        -- Clean up any old "?" prefix from listing name
        if l and l.name then
            l.name = SS_stripUnknownPrefix(l.name)
        end

        local okSearch = true
        if SurvivorShopUI.isListingExpired(l) then okSearch = false end
        if forceType and forceType ~= "" and l.itemType ~= forceType then okSearch = false end
        if okSearch and q then
            local nameTxt = SS_stripUnknownPrefix(tostring(l.name or l.itemType or ""))
            local typeTxt = tostring(l.itemType or "")
            okSearch = SurvivorShopUITheme.matchesSearch(q, nameTxt) or SurvivorShopUITheme.matchesSearch(q, typeTxt)
        end

        if okSearch then
            local itemType = tostring(l.itemType or "")
            if itemType ~= "" then
                local g = groups[itemType]
                if not g then
                    g = {
                        itemType = itemType,
                        name = SS_stripUnknownPrefix(l.name or itemType),
                        totalQty = 0,
                        minPrice = nil,
                        latestCreated = nil,
                        listings = {},
                    }
                    groups[itemType] = g
                end

                local qty = math.floor(tonumber(l.quantity) or 0)
                local price = math.floor(tonumber(l.price) or 0)
                local created = tonumber(l.created) or 0
                g.totalQty = g.totalQty + qty
                if g.minPrice == nil or price < g.minPrice then g.minPrice = price end
                if g.latestCreated == nil or created > g.latestCreated then g.latestCreated = created end
                table.insert(g.listings, l)
            end
        end
    end

    local keys = {}
    for k,_ in pairs(groups) do
        if cat == "ALL" or SurvivorShopUI.getItemDisplayCategory(k) == cat then
            keys[#keys+1] = k
        end
    end
    table.sort(keys, function(a,b)
        local ga, gb = groups[a], groups[b]
        local ca, cb = tonumber(ga.latestCreated) or 0, tonumber(gb.latestCreated) or 0
        if ca ~= cb then return ca > cb end
        local pa, pb = tonumber(ga.minPrice) or 0, tonumber(gb.minPrice) or 0
        if pa ~= pb then return pa < pb end
        return tostring(ga.name) < tostring(gb.name)
    end)


    local total = #keys
    local totalPages = math.max(1, math.ceil(total / perPage))
    page = math.min(math.max(1, page), totalPages)

    if self.browse then
        self.browse.page = page
        self.browse.totalPages = totalPages
        self.browse.perPage = perPage
        self.browse.selectedCategory = cat
        _setPagerText(self.browse.pageLabel, tostring(page) .. "/" .. tostring(totalPages))
        if self.browse.btnPrev then _setBtnEnabled(self.browse.btnPrev, page > 1) end
        if self.browse.btnNext then _setBtnEnabled(self.browse.btnNext, page < totalPages) end

        if self.browse.modeLabel then
            local label = SS_T("IGUI_SS_Sort_Cheapest","Mais recentes")
            if cat ~= "ALL" then
                label = SS_T("IGUI_SS_CategoryLabel","Category:%1"):gsub("%%1", tostring(cat))
            end
            if q and q ~= "" then
                local s = tostring(self.browse.searchQuery or "")
                local searchLabel = SS_T("IGUI_SS_SearchLabel","Search:%1"):gsub("%%1", s)
                if cat ~= "ALL" then label = label .. " | " .. searchLabel else label = searchLabel end
            end
            self.browse.modeLabel:setName(label)
        end
    end

    local startIndex = (page - 1) * perPage + 1
    local endIndex = math.min(page * perPage, total)

    for idx = startIndex, endIndex do
        local itemType = keys[idx]
        local g = groups[itemType]
        local expanded = (forceType and forceType ~= "") and true or (self.browseExpanded[itemType] == true)
        local arrow = expanded and "▼" or "▶"

        local groupItem = {
            kind = "group",
            itemType = itemType,
            name = SS_stripUnknownPrefix(g.name or ""),
            quantity = g.totalQty,
            sellerName = SS_T("IGUI_SS_MultipleSellers","Multiple sellers"),
            minPrice = g.minPrice or 0,
            expanded = expanded,
            arrow = arrow,
        }

        local groupRow = list:addItem(arrow .. " " .. SS_stripUnknownPrefix(tostring(groupItem.name)), groupItem)
        groupRow.height = 62

        if expanded then
            table.sort(g.listings, function(a,b)
                local ca, cb = tonumber(a.created) or 0, tonumber(b.created) or 0
                if ca ~= cb then return ca > cb end
                local pa, pb = tonumber(a.price) or 0, tonumber(b.price) or 0
                if pa ~= pb then return pa < pb end
                return tostring(a.id) < tostring(b.id)
            end)

            for _, l in ipairs(g.listings) do
                local child = {
                    kind = "listing",
                    id = l.id,
                    itemType = l.itemType,
                    name = SS_stripUnknownPrefix(l.name or l.itemType),
                    quantity = l.quantity,
                    price = l.price,
                    sellerName = l.sellerName,
                    created = l.created,
                    expiresAt = l.expiresAt,
                    expired = l.expired,
                    expiredAt = l.expiredAt,
                    itemStats = l.itemStats,  -- CRITICAL:Copy itemStats from listing!
                }
                local childRow = list:addItem("    " .. SS_stripUnknownPrefix(tostring(child.name)), child)
                childRow.height = list.itemheight
            end
        end
    end
end

function SurvivorShopUI:refreshMyListings()
    local list = self.my.list
    list:clear()

    -- Clear details panel when refreshing my listings
    if self.details and self.details._statsLabels then
        for _,_lbl in ipairs(self.details._statsLabels) do _lbl:setName(""); _lbl:setVisible(false) end
    end

    local q = SurvivorShopUITheme.normQuery(self.my.searchQuery)

    local p = getPlayer()
    local uname = (p and p.getUsername and p:getUsername()) or ""
    for _, l in ipairs(SurvivorShopClient.listings or {}) do
        -- Clean up any old "?" prefix from listing name
        if l and l.name then
            l.name = SS_stripUnknownPrefix(l.name)
        end

        if tostring(l.sellerName or "") == uname then
            local okSearch = true
            if q then
                local nameTxt = SS_stripUnknownPrefix(tostring(l.name or l.itemType or ""))
                local typeTxt = tostring(l.itemType or "")
                okSearch = SurvivorShopUITheme.matchesSearch(q, nameTxt) or SurvivorShopUITheme.matchesSearch(q, typeTxt)
            end

            if okSearch then
                local item = {
                    kind = "my",
                    id = l.id,
                    itemType = l.itemType,
                    name = SS_stripUnknownPrefix(l.name or l.itemType),
                    quantity = l.quantity,
                    price = l.price,
                    created = l.created,
                    expiresAt = l.expiresAt,
                    expired = l.expired,
                    expiredAt = l.expiredAt,
                    itemStats = l.itemStats,  -- CRITICAL:Copy itemStats from listing!
                }
                local row = list:addItem(SS_stripUnknownPrefix(tostring(item.name)), item)
                row.height = list.itemheight
            end
        end
    end
end

-- [NEW B42.13.2] Refresh sales history
function SurvivorShopUI:refreshSalesHistory()
    -- DEBUG
    print("[SurvivorShop UI] refreshSalesHistory() called")

    if not self.my or not self.my.salesList or not self.my.listingsList then
        print("[SurvivorShop UI] ERROR:history lists not found!")
        print("[SurvivorShop UI]   self.my exists:" .. tostring(self.my ~= nil))
        if self.my then
            print("[SurvivorShop UI]   self.my.salesList exists:" .. tostring(self.my.salesList ~= nil))
            print("[SurvivorShop UI]   self.my.listingsList exists:" .. tostring(self.my.listingsList ~= nil))
        end
        return
    end

    local salesList = self.my.salesList
    local listingsList = self.my.listingsList

    salesList:clear()
    listingsList:clear()

    local history = SurvivorShopClient.salesHistory or {}
    print("[SurvivorShop UI] Processing " .. tostring(#history) .. " sales records")

    local salesCount = 0
    local listingsCount = 0
    local seenListingAnnouncementIds = {}
    local seenListingAnnouncementKeys = {}

    local function historyListingKey(itemType, qty, unitPrice, stamp)
        return table.concat({
            tostring(itemType or ""),
            tostring(qty or ""),
            tostring(unitPrice or ""),
            tostring(stamp or ""),
        }, "|")
    end

    for i, sale in ipairs(history) do
        local dateStr = ""
        if sale.soldAt then
            local timestamp = tonumber(sale.soldAt)
            if timestamp then
                dateStr = os.date("%d/%m %H:%M", timestamp)
            end
        end

        local itemName = sale.itemName or sale.itemType or "Item"
        local qty = tostring(sale.quantity or 1)
        local payout = tostring(sale.totalPayout or 0)
        local buyer = sale.buyerName or "Unknown"

        -- Format differently based on action type
        local text
        local targetList

        if buyer == "[ANUNCIADO]" then
            text = string.format("[+] %s x%s - $%s cada - %s", itemName, qty, tostring(sale.unitPrice or 0), dateStr)
            targetList = listingsList
            listingsCount = listingsCount + 1
            if sale.listingId ~= nil then
                seenListingAnnouncementIds[tostring(sale.listingId)] = true
            end
            seenListingAnnouncementKeys[historyListingKey(sale.itemType, sale.quantity, sale.unitPrice, sale.soldAt)] = true
        elseif buyer == "[CANCELADO]" then
            text = string.format("[-] %s x%s - Cancelado - %s", itemName, qty, dateStr)
            targetList = listingsList
            listingsCount = listingsCount + 1
        else
            -- Actual sale
            text = string.format("[$$] %s x%s - $%s - %s - %s", itemName, qty, payout, buyer, dateStr)
            targetList = salesList
            salesCount = salesCount + 1
        end

        print("[SurvivorShop UI] Adding row:" .. text)

        local row = targetList:addItem(text, { text = text, saleType = buyer })
        row.height = targetList.itemheight
    end

    local p = getPlayer()
    local uname = (p and p.getUsername and p:getUsername()) or ""
    for _, listing in ipairs(SurvivorShopClient.listings or {}) do
        if listing and tostring(listing.sellerName or "") == uname then
            local listingId = tostring(listing.id or "")
            local listingKey = historyListingKey(listing.itemType, listing.quantity, listing.price, listing.created)
            local alreadyTracked = false
            if listingId ~= "" and seenListingAnnouncementIds[listingId] then
                alreadyTracked = true
            elseif seenListingAnnouncementKeys[listingKey] then
                alreadyTracked = true
            end

            if not alreadyTracked then
                local createdAt = tonumber(listing.created)
                local dateStr = ""
                if createdAt then
                    dateStr = os.date("%d/%m %H:%M", createdAt)
                end
                local itemName = listing.name or listing.itemType or "Item"
                local qty = tostring(listing.quantity or 1)
                local text = string.format("[+] %s x%s - $%s cada - %s", itemName, qty, tostring(listing.price or 0), dateStr)
                print("[SurvivorShop UI] Backfilling active listing row:" .. text)
                local row = listingsList:addItem(text, { text = text, saleType = "[ANUNCIADO]" })
                row.height = listingsList.itemheight
                listingsCount = listingsCount + 1
            end
        end
    end

    -- Add empty messages if needed
    if salesCount == 0 then
        local emptyMsg = "Nenhuma venda realizada ainda"
        print("[SurvivorShop UI] No sales - showing empty message")
        salesList:addItem(emptyMsg, { text = emptyMsg })
    end

    if listingsCount == 0 then
        local emptyMsg = SS_T("IGUI_SS_NoListingsCreated", "Nenhum anúncio criado ainda")
        print("[SurvivorShop UI] No listings - showing empty message")
        listingsList:addItem(emptyMsg, { text = emptyMsg })
    end
end



local _ss_sellScriptCache = {}

local function _ss_sellClampPct(value)
    if value == nil then return nil end
    return math.floor(math.max(0, math.min(100, tonumber(value) or 0)))
end

local function _ss_sellRoundMillis(value)
    return math.floor(((tonumber(value) or 0) * 1000) + 0.5)
end

local function _ss_sellHasMeaningfulUses(maxUses)
    maxUses = tonumber(maxUses)
    return maxUses ~= nil and maxUses > 1
end

local function _ss_sellGetScriptItem(fullType)
    if not fullType or fullType == "" then return nil end
    local cached = _ss_sellScriptCache[fullType]
    if cached ~= nil then
        return cached or nil
    end
    local scriptItem = nil
    pcall(function()
        scriptItem = getScriptManager():FindItem(fullType)
    end)
    _ss_sellScriptCache[fullType] = scriptItem or false
    return scriptItem
end

local function _ss_sellFreshnessPercent(age, daysBad)
    age = tonumber(age)
    daysBad = tonumber(daysBad)
    if not age or not daysBad or daysBad <= 0 then return nil end
    return _ss_sellClampPct((1.0 - (age / daysBad)) * 100)
end

local function _ss_buildSellVariantMeta(it)
    if not it or not it.getFullType then
        return { key = "ft:", label = "", stats = { isNew = true, tag = "NOVO" } }
    end

    local fullType = tostring(it:getFullType() or "")
    local scriptItem = _ss_sellGetScriptItem(fullType)
    local stats = { isNew = true, tag = "NOVO" }
    local keyParts = { "ft:" .. fullType }
    local labelParts = {}
    local hasStableUseVariant = false

    local function addKey(name, value)
        keyParts[#keyParts + 1] = tostring(name) .. ":" .. tostring(value)
    end

    local function addLabel(text)
        if text and text ~= "" then
            labelParts[#labelParts + 1] = text
        end
    end

    if it.getCondition and it.getConditionMax then
        local okMax, maxCond = pcall(it.getConditionMax, it)
        local okCur, curCond = pcall(it.getCondition, it)
        if okMax and okCur and maxCond and maxCond > 0 and curCond ~= nil then
            local pct = _ss_sellClampPct((tonumber(curCond) / tonumber(maxCond)) * 100)
            stats.minCondition = pct
            if pct < 100 then
                addKey("cond", pct)
                stats.isNew = false
                addLabel("Cond " .. tostring(pct) .. "%")
            end
        end
    end

    do
        local usesPct = nil
        local maxUsesNum = nil
        if it.getMaxUses then
            local okMax, maxUses = pcall(it.getMaxUses, it)
            if okMax and maxUses ~= nil then
                maxUsesNum = tonumber(maxUses)
            end
        end
        if it.getUsedDelta then
            local ok, usedDelta = pcall(it.getUsedDelta, it)
            if ok and usedDelta ~= nil and _ss_sellHasMeaningfulUses(maxUsesNum) then
                usesPct = _ss_sellClampPct((1.0 - tonumber(usedDelta or 0)) * 100)
            end
        end
        if usesPct == nil and _ss_sellHasMeaningfulUses(maxUsesNum) and it.getCurrentUses and it.getMaxUses then
            local okCur, currentUses = pcall(it.getCurrentUses, it)
            if okCur and maxUsesNum and maxUsesNum > 0 then
                usesPct = _ss_sellClampPct((tonumber(currentUses or 0) / maxUsesNum) * 100)
            end
        end
        if usesPct ~= nil then
            stats.minUses = usesPct
            hasStableUseVariant = true
            if usesPct < 100 then
                addKey("uses", usesPct)
                stats.isNew = false
                addLabel("Usos " .. tostring(usesPct) .. "%")
            end
        end
    end

    if it.getFluidContainer and type(it.getFluidContainer) == "function" then
        local okFC, fc = pcall(it.getFluidContainer, it)
        if okFC and fc then
            local amount = nil
            local maxAmount = nil
            local fluidLabel = nil

            if fc.getAmount then
                local ok, value = pcall(fc.getAmount, fc)
                if ok and value ~= nil then amount = value end
            end
            if amount == nil and fc.getAmountLitres then
                local ok, value = pcall(fc.getAmountLitres, fc)
                if ok and value ~= nil then amount = value end
            end
            if fc.getCapacity then
                local ok, value = pcall(fc.getCapacity, fc)
                if ok and value ~= nil then maxAmount = value end
            end
            if maxAmount == nil and fc.getMaxAmount then
                local ok, value = pcall(fc.getMaxAmount, fc)
                if ok and value ~= nil then maxAmount = value end
            end
            if fc.getPrimaryFluid then
                local ok, fluid = pcall(fc.getPrimaryFluid, fc)
                if ok and fluid then
                    if type(fluid) == "string" then
                        fluidLabel = fluid
                    elseif fluid.getName then
                        local okName, name = pcall(fluid.getName, fluid)
                        if okName and name ~= nil then fluidLabel = name end
                    end
                    fluidLabel = fluidLabel or tostring(fluid)
                end
            end

            amount = tonumber(amount) or 0
            stats.fluidAmount = amount
            stats.fluidMax = tonumber(maxAmount)
            stats.fluidLabel = fluidLabel

            if stats.fluidMax and stats.fluidMax > 0 then
                local pct = _ss_sellClampPct((amount / stats.fluidMax) * 100)
                stats.fluidPercent = pct
                if pct < 100 then
                    addKey("fluidPct", pct)
                    stats.isNew = false
                    addLabel("Liq " .. tostring(pct) .. "%")
                end
            else
                if amount > 0 then
                    addLabel(string.format("Liq %.2fL", amount))
                else
                    addKey("fluidAmt", _ss_sellRoundMillis(amount))
                    stats.isNew = false
                    addLabel("Liq vazio")
                end
            end

            if fluidLabel and fluidLabel ~= "" then
                addKey("fluidType", tostring(fluidLabel))
            end
        end
    end

    if it.isFood and type(it.isFood) == "function" and it:isFood() then
        local weight = nil
        local baseWeight = nil
        local daysTotal = nil
        local daysBad = nil
        local age = nil

        if it.getWeight then
            local ok, value = pcall(it.getWeight, it)
            if ok and value ~= nil then weight = tonumber(value) end
        end
        if it.getAge then
            local ok, value = pcall(it.getAge, it)
            if ok and value ~= nil then age = tonumber(value) end
        end
        if it.getHungChange then
            local ok, value = pcall(it.getHungChange, it)
            if ok and value ~= nil then stats.foodHunger = math.floor((tonumber(value) or 0) * 100 + 0.5) end
        end
        if it.getUnhappyChange then
            local ok, value = pcall(it.getUnhappyChange, it)
            if ok and value ~= nil then stats.foodUnhappy = math.floor(tonumber(value) or 0) end
        end
        if it.getBoredomChange then
            local ok, value = pcall(it.getBoredomChange, it)
            if ok and value ~= nil then stats.foodBoredom = math.floor(tonumber(value) or 0) end
        end
        if it.isCooked then
            local ok, value = pcall(it.isCooked, it)
            if ok and value then stats.foodCooked = true end
        end
        if it.isBurnt then
            local ok, value = pcall(it.isBurnt, it)
            if ok and value then stats.foodBurnt = true end
        end

        if scriptItem then
            if scriptItem.getWeight then
                local ok, value = pcall(scriptItem.getWeight, scriptItem)
                if ok and value ~= nil then baseWeight = tonumber(value) end
            end
            if scriptItem.getDaysFresh then
                local ok, value = pcall(scriptItem.getDaysFresh, scriptItem)
                if ok and value ~= nil then daysTotal = tonumber(value) end
            end
            if scriptItem.getDaysTotallyRotten then
                local ok, value = pcall(scriptItem.getDaysTotallyRotten, scriptItem)
                if ok and value ~= nil then daysBad = tonumber(value) end
            end
        end

        stats.foodBaseWeight = baseWeight
        stats.foodDaysTotal = daysTotal
        stats.foodDaysBad = daysBad

        local weightPct = 100
        if weight ~= nil and baseWeight ~= nil and baseWeight > 0 then
            weightPct = _ss_sellClampPct((weight / baseWeight) * 100)
            stats.foodWeightPct = weightPct
        end
        if weightPct < 100 and not hasStableUseVariant then
            addKey("foodWeight", weightPct)
            stats.isNew = false
            addLabel("Restante " .. tostring(weightPct) .. "%")
        end

        local freshnessPct = _ss_sellFreshnessPercent(age, daysBad)
        if freshnessPct ~= nil then
            stats.foodFreshnessPct = freshnessPct
            if freshnessPct < 100 then
                addLabel("Frescor " .. tostring(freshnessPct) .. "%")
            end
        end

        if stats.foodCooked then
            addKey("cooked", 1)
            stats.isNew = false
            addLabel("Cozido")
        end
        if stats.foodBurnt then
            addKey("burnt", 1)
            stats.isNew = false
            addLabel("Queimado")
        end
    end

    stats.tag = stats.isNew and "NOVO" or "USADO"
    return {
        key = table.concat(keyParts, "|"),
        label = table.concat(labelParts, " | "),
        stats = stats,
    }
end

function SurvivorShopUI:refreshSell()
    local list = self.sell.list
    list:clear()

    -- Clear details panel when refreshing sell list
    if self.details and self.details._statsLabels then
        for _,_lbl in ipairs(self.details._statsLabels) do _lbl:setName(""); _lbl:setVisible(false) end
    end

    local q = SurvivorShopUITheme.normQuery(self.sell.searchQuery)

    local p = getPlayer()
    if not p then return end

    local all = {}
    invCollect(p:getInventory(), all)

    local byType = {}
    for _, it in ipairs(all) do
        if it and it.getFullType then
            local ft = it:getFullType()
            if ft and (not _ss_isBannedSellType(ft)) and (not SurvivorShopUI.isEquippedByPlayer(p, it)) then
                local baseName = SS_stripUnknownPrefix((it.getDisplayName and it:getDisplayName()) or ft)
                local variant = _ss_buildSellVariantMeta(it)
                local variantName = baseName
                if variant.label ~= nil and variant.label ~= "" then
                    variantName = baseName .. " [" .. variant.label .. "]"
                end
                byType[variant.key] = byType[variant.key] or {
                    count = 0,
                    name = variantName,
                    itemType = ft,
                    variantKey = variant.key,
                    variantLabel = variant.label,
                    itemStats = variant.stats,
                }
                byType[variant.key].count = byType[variant.key].count + 1
            end
        end
    end

    local keys = {}
    for ft,_ in pairs(byType) do keys[#keys+1] = ft end
    table.sort(keys, function(a,b) return tostring(byType[a].name) < tostring(byType[b].name) end)

    for _, ft in ipairs(keys) do
        local d = byType[ft]
        local okSearch = true
        if q then
            local nameTxt = tostring(d.name or "")
            local typeTxt = tostring(d.itemType or ft or "")
            okSearch = SurvivorShopUITheme.matchesSearch(q, nameTxt) or SurvivorShopUITheme.matchesSearch(q, typeTxt)
        end

        if okSearch then
            local item = {
                kind = "sell",
                itemType = d.itemType or ft,
                name = d.name,
                quantity = d.count,
                variantKey = d.variantKey,
                variantLabel = d.variantLabel,
                itemStats = d.itemStats,
            }
            local row = list:addItem(SS_stripUnknownPrefix(tostring(d.name)), item)
            row.height = list.itemheight
        end
    end
end



function SurvivorShopUI:refreshAll()
    self:refreshBrowse()
    self:refreshMyListings()
    self:refreshSalesHistory()
    self:refreshSell()
    if self.favorites then self:refreshFavorites() end
    self:updateSelected()
end

function SurvivorShopUI:onRefresh()
    SurvivorShopClient.sync()
    SurvivorShopClient.requestBalance()
    SurvivorShopClient.requestSalesHistory()
    self:refreshAll()
end

function SurvivorShopUI:onClose()
    self:setVisible(false)
    self:removeFromUIManager()

    if self.auctionOverlay then
        self.auctionOverlay:setVisible(false)
        self.auctionOverlay:removeFromUIManager()
        self.auctionOverlay = nil
    end

    if self.bankOverlay then
        self.bankOverlay:setVisible(false)
        self.bankOverlay:removeFromUIManager()
        self.bankOverlay = nil
    end

    SurvivorShopUI.instance = nil

-- Stable internal tab keys (do NOT localize)
SurvivorShopUI.TAB_BROWSE = "browse"
SurvivorShopUI.TAB_SELL   = "sell"
SurvivorShopUI.TAB_MY     = "my"
SurvivorShopUI.TAB_FAV    = "fav"

end


-- Auction button visuals:yellow hammer icon + gentle blink when there is any active auction
function SurvivorShopUI:_hasAnyActiveAuction()
    local list = SurvivorShopClient and SurvivorShopClient.auctions or nil
    if not list or #list == 0 then return false end
    local now = os.time()
    for i=1,#list do
        local a = list[i]
        if a and a.ended ~= true and (tonumber(a.endAt) or 0) > now then
            return true
        end
    end
    return false
end

function SurvivorShopUI:_updateAuctionButtonVisual()
    if not self.btnAuction then return end
    -- image stays B/W; we tint it yellow in the interface
    local baseR, baseG, baseB = 1.0, 0.84, 0.18
    local alpha = 1.0
    local pulse = 0.0

    if self:_hasAnyActiveAuction() and not self.auctionOpen then
        local t = (os.time() or 0) + ((os.clock and os.clock()) or 0)
        pulse = math.abs(math.sin(t * 2.8)) -- gentle blink
        alpha = 0.65 + 0.35 * pulse
    end

    -- Tint the icon (if ISButton supports imageColor in your B42 build)
    self.btnAuction.imageColor = {r=baseR, g=baseG, b=baseB, a=alpha}

    -- Also pulse the border/background alpha so the blink is visible even if imageColor isn't supported
    if not self.btnAuction.borderColor then self.btnAuction.borderColor = {r=baseR, g=baseG, b=baseB, a=0.95} end
    self.btnAuction.borderColor.r = baseR
    self.btnAuction.borderColor.g = baseG
    self.btnAuction.borderColor.b = baseB
    self.btnAuction.borderColor.a = 0.80 + 0.20 * pulse

    if self.btnAuction.backgroundColor and self.btnAuction.backgroundColor.a then
        self.btnAuction.backgroundColor.a = 0.80 + 0.10 * pulse
    end
end


function SurvivorShopUI:prerender()
    ISPanel.prerender(self)
    local c = SurvivorShopUITheme.Colors

    SurvivorShopUITheme.drawSoftPanel(self, 0, 0, self.width, self.height)

    -- premium header
    local hh = self.headerH or 56
    local title = SS_T("IGUI_SS_Title","Survivor Shop")
    SurvivorShopUITheme.drawPremiumHeader(self, 0, 0, self.width, hh, title, nil)

    local bodyY = hh + 8
    local footerTop = self.height - 52
    SurvivorShopUITheme.drawSoftPanel(self, 8, bodyY, self.width - 16, footerTop - bodyY)
    self:drawRect(10, footerTop, self.width - 20, 36, 0.05, 1, 1, 1)
    self:drawRect(10, hh + 2, self.width - 20, 4, 0.08, 0, 0, 0)

end


function SurvivorShopUI:update()
    ISPanel.update(self)

    local activeKey = self:getActiveTabKey()

    -- Refresh when switching tabs
    if self._lastTabKey ~= activeKey then
        self._lastTabKey = activeKey
        self:_applyTabStyle()
        if activeKey == SurvivorShopUI.TAB_BROWSE then
            self:refreshBrowse()
        elseif activeKey == SurvivorShopUI.TAB_SELL then
            self:refreshSell()
        elseif activeKey == SurvivorShopUI.TAB_MY then
            self:refreshMyListings()
            SurvivorShopClient.requestSalesHistory()
            self:refreshSalesHistory()
        elseif activeKey == SurvivorShopUI.TAB_FAV then
            if SurvivorShopClient and SurvivorShopClient.requestFavorites then SurvivorShopClient.requestFavorites() end
            self:refreshFavorites()
            -- SS_ResetSelectionsForFavorites:evita herdar seleção/painel de outras abas
            if self.browse and self.browse.list then self.browse.list.selected = 0 end
            if self.sell and self.sell.list then self.sell.list.selected = 0 end
            if self.my and self.my.list then self.my.list.selected = 0 end
            if self.favorites and self.favorites.list then self.favorites.list.selected = 0 end
            self:updateSelected()
        end
        if self.details and self.details.syncVisible then
            self.details:syncVisible()
        end
    end

    -- Search:refresh list when query changes (active tab)
    local view = (activeKey == SurvivorShopUI.TAB_BROWSE and self.browse)
        or (activeKey == SurvivorShopUI.TAB_SELL and self.sell)
        or (activeKey == SurvivorShopUI.TAB_MY and self.my)
        or (activeKey == SurvivorShopUI.TAB_FAV and self.favorites)
        or nil

    if view and view.searchEntry and view.searchPendingRefresh then
        view.searchPendingRefresh = false
        local q = view.searchEntry:getText() or ""
        if q ~= (view.searchLastText or "") then
            view.searchLastText = q
            view.searchQuery = q
            if view.page then view.page = 1 end -- reset pagination on search
            if activeKey == SurvivorShopUI.TAB_BROWSE then
                self:refreshBrowse()
            elseif activeKey == SurvivorShopUI.TAB_SELL then
                self:refreshSell()
            elseif activeKey == SurvivorShopUI.TAB_MY then
                self:refreshMyListings()
                SurvivorShopClient.requestSalesHistory()
                self:refreshSalesHistory()
            end
        end
    end


    -- Favorites:debounce refresh while typing
    if self._favSearchPending and self.favorites then
        local now = (getTimestampMs and getTimestampMs()) or 0
        if now >= (self._favSearchNextAt or 0) then
            self._favSearchPending = false
            self:refreshFavorites()
            -- SS_ResetSelectionsForFavorites:evita herdar seleção/painel de outras abas
            if self.browse and self.browse.list then self.browse.list.selected = 0 end
            if self.sell and self.sell.list then self.sell.list.selected = 0 end
            if self.my and self.my.list then self.my.list.selected = 0 end
            if self.favorites and self.favorites.list then self.favorites.list.selected = 0 end
            self:updateSelected()
        end
    end

    -- Keep bank overlay aligned to the shop window when visible
    if self.bankOverlay and self.bankOverlay.getIsVisible and self.bankOverlay:getIsVisible() then
        self.bankOverlay.ownerUI = self
        if self.bankOverlay.alignToShop then
            self.bankOverlay:alignToShop()
        end
    end

    self:updateSelected()
end




-- =========================================================
-- Favorites (MP-safe)
-- =========================================================
function SurvivorShopUI:setFavorites(favs)
    self.favSet = {}
    if type(favs) == "table" then
        for k,v in pairs(favs) do
            if v == true then self.favSet[tostring(k)] = true end
        end
    end
    if self.favorites and self.favorites.page then
        -- keep page but refresh content
        self:refreshFavorites()
    end

    -- keep auction icon color/blink in sync
    self:_updateAuctionButtonVisual()
end

function SurvivorShopUI:_buildAllItemsIndex()
    if self._allItemsIndex then return end
    self._allItemsIndex = {}
    local sm = getScriptManager()
    if not sm or not sm.getAllItems then return end
    local items = sm:getAllItems()
    if not items then return end

    for i=0, items:size()-1 do
        local it = items:get(i)
        if it then
            local ft = nil
            if it.getFullName then ft = it:getFullName() end
            if (not ft or ft == "") and it.getFullType then ft = it:getFullType() end
            if ft and ft ~= "" then
                local dn = SS_stripUnknownPrefix((it.getDisplayName and it:getDisplayName()) or ft)
                local cat = (it.getDisplayCategory and it:getDisplayCategory()) or "Other"
                table.insert(self._allItemsIndex, {
                    fullType = ft,
                    name = dn,
                    nameLower = string.lower(tostring(dn)),
                    cat = cat,
                })
            end
        end
    end
end

function SurvivorShopUI:_getFavSearchText()
    if not self.favorites or not self.favorites.searchEntry then return "" end
    local t = tostring(self.favorites.searchEntry:getText() or "")
    t = string.gsub(t, "^%s+", "")
    t = string.gsub(t, "%s+$", "")
    return t
end

function SurvivorShopUI:_getFavSelectedCategory()
    if not self.favorites or not self.favorites.catCombo then return "ALL" end
    local idx = self.favorites.catCombo.selected or 1
    if self.favorites.catData and self.favorites.catData[idx] then
        return self.favorites.catData[idx]
    end
    local opt = self.favorites.catCombo:getOptionText(idx)
    -- Fallback:best-effort detect the localized 'ALL'
    if opt == SS_T("IGUI_SS_Category_All","ALL") then return "ALL" end
    return opt or "ALL"
end

function SurvivorShopUI:onFavSearchChanged()
    if not self.favorites then return end
    self.favorites.page = 1
    -- debounce to avoid scanning all items each keystroke
    self._favSearchPending = true
    local now = (getTimestampMs and getTimestampMs()) or 0
    self._favSearchNextAt = now + 120
end

function SurvivorShopUI:onFavCategoryChanged()
    if not self.favorites then return end
    self.favorites.page = 1
    self:refreshFavorites()
end

function SurvivorShopUI:isFavorite(fullType)
    if not self.favSet then self.favSet = {} end
    return self.favSet[tostring(fullType)] == true
end

function SurvivorShopUI:toggleFavorite(fullType)
    if not fullType or fullType == "" then return end
    local ft = tostring(fullType)
    local newVal = not self:isFavorite(ft)

    -- Update local immediately for snappy UI
    if newVal then self.favSet[ft] = true else self.favSet[ft] = nil end

    if SurvivorShopClient and SurvivorShopClient.setFavorite then
        SurvivorShopClient.setFavorite(ft, newVal)
    end

    self:refreshFavorites()
end


function SurvivorShopUI:jumpToBrowseItem(fullType)
    if not fullType or fullType == "" then return end
    local ft = tostring(fullType)

    -- check if there is any active listing for this itemType
    local has = false
    for _, l in ipairs(SurvivorShopClient.listings or {}) do
        if tostring(l.itemType or "") == ft then
            has = true
            break
        end
    end
    if not has then
        local msg = SS_T("IGUI_SS_NoListingsForItem","No listings available for this item right now.")
        if self.showToast then self:showToast(msg) elseif SurvivorShopUI.instance and SurvivorShopUI.instance.showToast then SurvivorShopUI.instance:showToast(msg) end
    end

    -- Reset browse inputs WITHOUT clearing the forced filter (lock prevents auto-clear)
    self._browseForceLock = true
    if self.browse then
        self.browse.page = 1
        self.browse.searchQuery = ""
        self.browse.searchLastText = ""
        if self.browse.searchEntry then
            self.browse.searchEntry:setText("")
        end
        self.browse.selectedCategory = "ALL"
        if self.browse.catCombo then
            self.browse.catCombo.selected = 1
        end
    end
    self._browseForceLock = false

    -- Force Browse Listings to show ONLY this itemType
    self.browseForcedItemType = ft
    self.browseExpanded = self.browseExpanded or {}
    self.browseExpanded[ft] = true

    -- Switch tab to Browse Listings (robust:find the browse view entry in ISTabPanel)
    if self.tabPanel and self.tabPanel.viewList then
        for idx, e in ipairs(self.tabPanel.viewList) do
            local v = e
            if type(e) == "table" and e.view then v = e.view end
            if v == self.browse or (type(e) == "table" and e._ssTabKey == SurvivorShopUI.TAB_BROWSE) or (v and v._ssTabKey == SurvivorShopUI.TAB_BROWSE) then
                local name = (type(e) == "table" and e.name) or (v and v.name)
                if name and self.tabPanel.activateView then
                    self.tabPanel:activateView(name)
                elseif name and self.tabPanel.setActiveView then
                    self.tabPanel:setActiveView(name)
                elseif self.tabPanel.setActiveViewIndex then
                    self.tabPanel:setActiveViewIndex(idx)
                end
                break
            end
        end
    elseif self.tabPanel and self.tabPanel.setActiveViewIndex then
        -- fallback:first tab is usually Browse
        self.tabPanel:setActiveViewIndex(1)
    end

    self:refreshBrowse()
end

function SurvivorShopUI:refreshFavorites()
    if not self.favorites or not self.favorites.list then return end

    -- Ensure we have favorites loaded
    if not self.favSet and SurvivorShopClient and SurvivorShopClient.favorites then
        self:setFavorites(SurvivorShopClient.favorites)
    end

    local query = string.lower(self:_getFavSearchText())
    local cat = self:_getFavSelectedCategory()

    self:_buildAllItemsIndex()

    local rows = {}
    local isSearching = query ~= nil and query ~= ""

    if not isSearching then
        if cat == "ALL" then
            -- show ONLY favorites when search is empty + category ALL
            for ft,_ in pairs(self.favSet or {}) do
                local it = getScriptManager():FindItem(ft)
                if it then
                    local dn = SS_stripUnknownPrefix((it.getDisplayName and it:getDisplayName()) or ft)
                    local dc = (it.getDisplayCategory and it:getDisplayCategory()) or "Other"
                    table.insert(rows, { fullType = ft, itemType = ft, name = dn, cat = dc })
                else
                    table.insert(rows, { fullType = ft, itemType = ft, name = ft, cat = "Other" })
                end
            end
        else
            -- category selected:show ALL items in this category (so player can add favorites without typing)
            local maxResults = 800 -- safety cap
            for _,it in ipairs(self._allItemsIndex or {}) do
                if it.cat == cat then
                    table.insert(rows, { fullType = it.fullType, itemType = it.fullType, name = it.name, cat = it.cat })
                    if #rows >= maxResults then break end
                end
            end
        end
        table.sort(rows, function(a,b) return tostring(a.name) < tostring(b.name) end)
    else
        -- Search all items, mark favorites with star
        local maxResults = 800 -- safety cap
        for _,it in ipairs(self._allItemsIndex or {}) do
            if (cat == "ALL" or it.cat == cat) then
                if string.find(it.nameLower, query, 1, true) then
                    table.insert(rows, { fullType = it.fullType, itemType = it.fullType, name = it.name, cat = it.cat })
                    if #rows >= maxResults then break end
                end
            end
        end
        table.sort(rows, function(a,b) return tostring(a.name) < tostring(b.name) end)
    end


    -- Stock status for active favorites (sync with current market listings)
    for _, r in ipairs(rows) do
        local fav = (self:isFavorite(r.fullType) == true)
        r.isFav = fav
        if fav then
            r.hasStock = _ss_favHasStock(r.fullType)
        else
            r.hasStock = nil
        end
    end

    -- Pagination
    local p = self.favorites
    local perPage = tonumber(p.perPage) or 50
    local total = #rows
    local pages = math.max(1, math.ceil(total / perPage))
    if p.page < 1 then p.page = 1 end
    if p.page > pages then p.page = pages end

    local startIndex = (p.page - 1) * perPage + 1
    local endIndex = math.min(total, startIndex + perPage - 1)

    p.list:clear()

    -- Clear details panel when refreshing favorites list
    if self.details and self.details._statsLabels then
        for _,_lbl in ipairs(self.details._statsLabels) do _lbl:setName(""); _lbl:setVisible(false) end
    end

    for i=startIndex, endIndex do
        local r = rows[i]
        p.list:addItem(SS_stripUnknownPrefix(r.name), r)
    end

    if p.pagerLabel and p.pagerLabel.setName then
        p.pagerLabel:setName(tostring(p.page) .. "/" .. tostring(pages))
    end

    -- enable/disable buttons
    if p.btnPrev and p.btnPrev.setEnable then p.btnPrev:setEnable(p.page > 1) end
    if p.btnNext and p.btnNext.setEnable then p.btnNext:setEnable(p.page < pages) end

    p.list.doDrawItem = function(list, y, item, alt)
        return self:doDrawFavoriteRow(list, y, item, alt)
    end
end

function SurvivorShopUI:doDrawFavoriteRow(list, y, item, alt)
    local a = 0.85
    if alt then a = 0.75 end
    list:drawRect(0, y, list.width, list.itemheight, a, 0,0,0)

    local row = item.item
    local pad = 8
    local h = list.itemheight
    local iconSize = 28
    local x = pad
    local yy = y + math.floor((h - iconSize)/2)

    -- icon
    local tex = nil
    if self.getItemTex then tex = self.getItemTex(row.fullType) end
    if tex then
        list:drawTextureScaled(tex, x, yy, iconSize, iconSize, 1)
    end
    x = x + iconSize + 10

    local name = row.name or row.fullType or ""
    local cat  = row.cat or ""

    -- Star + Buy button geometry (manual drawing inside ISScrollingListBox)
    SurvivorShopUI._texStarOn  = SurvivorShopUI._texStarOn  or getTexture("media/ui/SurvivorShop_star_on.png")
    SurvivorShopUI._texStarOff = SurvivorShopUI._texStarOff or getTexture("media/ui/SurvivorShop_star_off.png")

    local isFav = (row.isFav ~= nil) and row.isFav or ((SurvivorShopUI.instance and SurvivorShopUI.instance:isFavorite(row.fullType)) and true or false)

    local vscrollW = ((list.vscroll and list.vscroll.width) or 0)
    local rightEdge = list.width - pad - vscrollW - 2

    local starW, starH = 24, 24
    local sx = rightEdge - starW
    local sy = y + math.floor((h - starH)/2)

    local buyW, buyH = 132, 24
    local gap = 8
    local bx = nil
    local by = y + math.floor((h - buyH)/2)

    if isFav then
        bx = sx - gap - buyW
        local minX = x + 60
        if bx < minX then bx = minX end
        -- Clamp so the button never crosses into the star/scrollbar area
        if bx + buyW > (sx - gap) then
            bx = math.max(minX, (sx - gap) - buyW)
        end
    end

    -- draw star
    list:drawRect(sx, sy, starW, starH, 0.25, 1,1,1)
    list:drawRectBorder(sx, sy, starW, starH, 0.6, 1,1,1)
    local st = isFav and SurvivorShopUI._texStarOn or SurvivorShopUI._texStarOff
    if st then
        list:drawTextureScaled(st, sx + 3, sy + 3, 16, 16, 1)
    else
        list:drawTextCentre(isFav and "*" or "+", sx + starW/2, sy + 3, 1,1,1,1, UIFont.Small)
    end

    -- reset click zones
    row._ui = row._ui or {}
    row._ui.buy = nil

    -- Buy / Out-of-stock button (only for active favorites)
    if isFav and bx then
        local hasStock = (row.hasStock == true)
        local label = hasStock and SS_T("IGUI_SS_Buy","Comprar") or SS_T("IGUI_SS_OutOfStock","Sem estoque")

        local aFill = 0.18
        if hasStock then
            -- green (Comprar)
            list:drawRect(bx, by, buyW, buyH, aFill, 0.25, 0.75, 0.25)
            list:drawRectBorder(bx, by, buyW, buyH, 0.85, 0.25, 0.75, 0.25)
        else
            -- weak red (Sem estoque)
            list:drawRect(bx, by, buyW, buyH, aFill, 0.75, 0.25, 0.25)
            list:drawRectBorder(bx, by, buyW, buyH, 0.85, 0.75, 0.25, 0.25)
        end

        -- label centered + clipped (prevents overflow on UI scale)
        local tm = getTextManager()
        local fh = (tm and tm.getFontHeight) and tm:getFontHeight(UIFont.Small) or 12
        local ty = by + math.floor((buyH - fh)/2) - 1
        local padX = 8
        local tw = (tm and tm.MeasureStringX) and tm:MeasureStringX(UIFont.Small, label) or 0
        local tx = bx + math.floor((buyW - tw)/2)
        if tx < bx + padX then tx = bx + padX end
        _ss_drawTextClipped(list, label, tx, ty, buyW - padX*2, 1,1,1,1, UIFont.Small)

        row._ui.buy = { x = bx, y = by, w = buyW, h = buyH, enabled = hasStock }
    end

    -- text (keep consistent spacing)
    local textMaxW = rightEdge - x - 10
    if bx then
        textMaxW = math.min(textMaxW, bx - x - 12)
    else
        textMaxW = math.min(textMaxW, sx - x - 10)
    end
    if textMaxW < 40 then textMaxW = 40 end
    _ss_drawTextClipped(list, SS_stripUnknownPrefix(name), x, y + 6, textMaxW, 1,1,1,1, UIFont.Medium)
    if cat ~= "" then
        _ss_drawTextClipped(list, cat, x, y + 32, textMaxW, 0.7,0.7,0.7,1, UIFont.Small)
    end

    row._ui.star = { x = sx, y = sy, w = starW, h = starH }
    if row.item then
        row.item._ui = row.item._ui or {}
        row.item._ui.star = row._ui.star
    end

    return y + h
end


function SurvivorShopUI.open(playerArg)
    local p = safeGetPlayerFromArg(playerArg)
    if not p then return end

    if SurvivorShopUI.instance then
        SurvivorShopUI.instance:setVisible(true)
        SurvivorShopUI.instance:addToUIManager()
        SurvivorShopClient.sync()
        SurvivorShopClient.requestBalance()
        if SurvivorShopClient.requestFavorites then SurvivorShopClient.requestFavorites() end
        return
    end

    local sw, sh = getCore():getScreenWidth(), getCore():getScreenHeight()
    local w = math.min(1180, math.floor(sw * 0.94))
    local h = math.min(760,  math.floor(sh * 0.90))
    local x = (getCore():getScreenWidth()/2) - (w/2)
    local y = (getCore():getScreenHeight()/2) - (h/2)

    local ui = SurvivorShopUI:new(x, y, w, h)
    ui:initialise()
    ui:instantiate()
    ui:addToUIManager()
    ui:setVisible(true)

    SurvivorShopUI.instance = ui
    SurvivorShopClient.sync()
    SurvivorShopClient.requestBalance()
    if SurvivorShopClient.requestFavorites then SurvivorShopClient.requestFavorites() end
end

_G.SurvivorShopUI = SurvivorShopUI


-- Simple local toast helper (client-side)
function SurvivorShopUI.showToast(msg)
    msg = tostring(msg or "")
    if msg == "" then return end
    local p = getPlayer()
    if HaloTextHelper and HaloTextHelper.addText and p then
        -- B42:HaloTextHelper.addText(player, text)
        HaloTextHelper.addText(p, msg)
    elseif p and p.Say then
        p:Say(msg)
    else
        print("[SurvivorShop] " .. msg)
    end
end
