-- SurvivorShopClient.lua (B42.13.2)
require "SurvivorShopShared"

local function stripUnknownPrefix(s)
    if not s then return "" end
    if type(s) ~= "string" then s = tostring(s) end
    s = s:gsub("^%s*", "")
    s = s:gsub("^%?%s*", "")
    return s
end

local function resolveLocalItemName(fullType, fallback)
    fullType = tostring(fullType or "")
    if fullType ~= "" then
        if getItemNameFromFullType then
            local ok, value = pcall(getItemNameFromFullType, fullType)
            if ok and value and value ~= "" and value ~= fullType then
                return stripUnknownPrefix(value)
            end
        end

        if InventoryItemFactory and InventoryItemFactory.CreateItem then
            local okItem, item = pcall(InventoryItemFactory.CreateItem, fullType)
            if okItem and item and item.getDisplayName then
                local okName, value = pcall(item.getDisplayName, item)
                if okName and value and value ~= "" and value ~= fullType then
                    return stripUnknownPrefix(value)
                end
            end
        end
    end

    return stripUnknownPrefix(fallback or fullType)
end

SurvivorShopClient = SurvivorShopClient or {}
SurvivorShopClient.listings = SurvivorShopClient.listings or {}
SurvivorShopClient.auctions = SurvivorShopClient.auctions or {}
SurvivorShopClient.balance = SurvivorShopClient.balance or 0
SurvivorShopClient.savings = SurvivorShopClient.savings or 0
SurvivorShopClient.bankTotal = SurvivorShopClient.bankTotal or 0
SurvivorShopClient.lastError = nil

SurvivorShopClient.favorites = SurvivorShopClient.favorites or {}
SurvivorShopClient.auctionClaims = SurvivorShopClient.auctionClaims or {}
SurvivorShopClient.isAdmin = SurvivorShopClient.isAdmin or false
SurvivorShopClient.onlinePlayers = SurvivorShopClient.onlinePlayers or {}
SurvivorShopClient.salesHistory = SurvivorShopClient.salesHistory or {}
SurvivorShopClient.bankLedger = SurvivorShopClient.bankLedger or {}
SurvivorShopClient.bankInvoices = SurvivorShopClient.bankInvoices or {}

local function _me()
    return getPlayer()
end

local function SS_TRPayload(args, fallback, ...)
    if args and type(args) == "table" and args.key then
        local p = args.p
        if p and type(p) == "table" then
            local ok, v = pcall(getText, args.key, unpack(p))
            if ok and v and v ~= args.key then return v end
        else
            local v = getText(args.key, ...)
            if v and v ~= args.key then return v end
        end
        return fallback or tostring(args.message or args.key)
    end

    if type(args) == "string" and string.find(args, "IGUI_") == 1 then
        local v = getText(args, ...)
        if v and v ~= args then return v end
        return fallback or args
    end

    return fallback or tostring((args and args.message) or "")
end

function SurvivorShopClient.nowMs()
    if getTimestampMs then return getTimestampMs() end
    return os.time() * 1000
end

function SurvivorShopClient.send(command, args)
    local p = _me()
    if not p then return end
    sendClientCommand(p, SurvivorShop.MODULE, command, args or {})
end

SurvivorShopClient._pendingRefresh = SurvivorShopClient._pendingRefresh or nil

local function _ss_doRefreshNow(flags)
    local ui = SurvivorShopUI and SurvivorShopUI.instance
    if not ui then return end
    if flags.refreshBrowse and ui.refreshBrowse then ui:refreshBrowse() end
    if flags.refreshMy and ui.refreshMyListings then ui:refreshMyListings() end
    if flags.refreshSell and ui.refreshSell then ui:refreshSell() end
    if flags.refreshBalance and ui.refreshBalance then ui:refreshBalance() end
    if flags.refreshBank and ui.refreshBalance then ui:refreshBalance() end
end

function SurvivorShopClient._onTickRefresh()
    local pr = SurvivorShopClient._pendingRefresh
    if not pr then
        Events.OnTick.Remove(SurvivorShopClient._onTickRefresh)
        return
    end
    pr.ticks = (pr.ticks or 0) - 1
    if pr.ticks <= 0 then
        Events.OnTick.Remove(SurvivorShopClient._onTickRefresh)
        SurvivorShopClient._pendingRefresh = nil
        _ss_doRefreshNow(pr.flags or {})
    end
end

function SurvivorShopClient.deferUIRefresh(flags, ticks)
    if not flags then return end
    local pr = SurvivorShopClient._pendingRefresh
    if not pr then
        pr = { ticks = 0, flags = {} }
        SurvivorShopClient._pendingRefresh = pr
        Events.OnTick.Add(SurvivorShopClient._onTickRefresh)
    end
    pr.ticks = math.max(pr.ticks or 0, tonumber(ticks) or 2)
    for k, v in pairs(flags) do
        if v then pr.flags[k] = true end
    end
end

local function _ss_refreshBankOverlay()
    local ui = SurvivorShopUI and SurvivorShopUI.instance
    if not ui or not ui.bankOverlay then return end
    if ui.bankOverlay.refreshBalance then ui.bankOverlay:refreshBalance() end
    if ui.bankOverlay.refreshLedger then ui.bankOverlay:refreshLedger() end
    if ui.bankOverlay.refreshInvoices then ui.bankOverlay:refreshInvoices() end
end

local function onServerCommand(module, command, args)
    if module ~= SurvivorShop.MODULE then return end
    args = args or {}

    if command == "listings" then
        local listings = (args and args.listings) or {}
        print("[SurvivorShop DEBUG] CLIENT received 'listings' | count=" .. tostring(#listings))
        for i, listing in ipairs(listings) do
            if listing then
                listing.name = resolveLocalItemName(listing.itemType, listing.name)
            end
        end
        SurvivorShopClient.listings = listings
        SurvivorShopClient.auctions = (args and args.auctions) or {}
        if SurvivorShopUI and SurvivorShopUI.instance and SurvivorShopUI.instance.refreshAll then
            print("[SurvivorShop DEBUG] CLIENT calling refreshAll()")
            SurvivorShopUI.instance:refreshAll()
        else
            print("[SurvivorShop DEBUG] CLIENT UI instance not found, skipping refreshAll()")
        end

    elseif command == "balance" then
        SurvivorShopClient.balance = tonumber(args.balance) or 0
        SurvivorShopClient.savings = tonumber(args.savings) or 0
        SurvivorShopClient.bankTotal = tonumber(args.total) or (SurvivorShopClient.balance + SurvivorShopClient.savings)
        if SurvivorShopUI and SurvivorShopUI.instance and SurvivorShopUI.instance.refreshBalance then
            SurvivorShopUI.instance:refreshBalance()
        end
        _ss_refreshBankOverlay()

    elseif command == "bankLedger" then
        SurvivorShopClient.bankLedger = (args and args.entries) or {}
        _ss_refreshBankOverlay()

    elseif command == "bankInvoices" then
        SurvivorShopClient.bankInvoices = (args and args.invoices) or {}
        _ss_refreshBankOverlay()

    elseif command == "toast" then
        if SurvivorShopUI and SurvivorShopUI.showToast then
            SurvivorShopUI.showToast(SS_TRPayload(args, tostring(args.message or "")))
        end
        if args.refreshSell or args.refreshMy or args.refreshBrowse or args.refreshBalance or args.refreshBank then
            SurvivorShopClient.deferUIRefresh({
                refreshSell = args.refreshSell,
                refreshMy = args.refreshMy,
                refreshBrowse = args.refreshBrowse,
                refreshBalance = args.refreshBalance,
                refreshBank = args.refreshBank,
            }, 2)
        end

    elseif command == "error" then
        SurvivorShopClient.lastError = SS_TRPayload(args, getText("IGUI_SS_Generic_UnknownError") or "Unknown error")
        if SurvivorShopUI and SurvivorShopUI.showToast then
            SurvivorShopUI.showToast(SurvivorShopClient.lastError)
        end

    elseif command == "onlinePlayers" then
        SurvivorShopClient.onlinePlayers = (args and args.players) or {}
        if SurvivorShopUI and SurvivorShopUI.instance and SurvivorShopUI.instance.bankOverlay and SurvivorShopUI.instance.bankOverlay.setOnlinePlayers then
            SurvivorShopUI.instance.bankOverlay:setOnlinePlayers(SurvivorShopClient.onlinePlayers)
        end

    elseif command == "bankTransferNotify" then
        local fromName = tostring(args.from or SS_TRPayload({ key = "IGUI_SS_Generic_Someone" }, "Someone"))
        local amount = math.floor(tonumber(args.amount) or 0)
        if amount > 0 then
            local msg = SS_TRPayload({ key = "IGUI_SS_Toast_BankTransferIn", p = { fromName, tostring(amount) } }, fromName .. " transferred $" .. tostring(amount) .. " to your bank.")
            if SurvivorShopUI and SurvivorShopUI.showToast then
                SurvivorShopUI.showToast(msg)
            end
        end
        if args.refreshSell or args.refreshMy or args.refreshBrowse or args.refreshBalance or args.refreshBank then
            SurvivorShopClient.deferUIRefresh({
                refreshSell = args.refreshSell,
                refreshMy = args.refreshMy,
                refreshBrowse = args.refreshBrowse,
                refreshBalance = args.refreshBalance,
                refreshBank = args.refreshBank,
            }, 2)
        end

    elseif command == "favorites" then
        SurvivorShopClient.favorites = (args and args.favorites) or {}
        if SurvivorShopUI and SurvivorShopUI.instance and SurvivorShopUI.instance.setFavorites then
            SurvivorShopUI.instance:setFavorites(SurvivorShopClient.favorites)
        end

    elseif command == "announceSold" then
        local qty = math.max(0, math.floor(tonumber(args.quantity) or 0))
        local payout = math.max(0, math.floor(tonumber(args.payout) or 0))
        local itemName = resolveLocalItemName(args.itemType, args.itemName)
        local text = SS_TRPayload({ key = "IGUI_SS_AboveHead_Sold", p = { itemName, tostring(qty), tostring(payout) } }, itemName)
        local me = _me()
        if me and me.Say then
            me:Say(text)
        end

    elseif command == "auctionHello" then
        SurvivorShopClient.isAdmin = (args and args.isAdmin) and true or false
        if SurvivorShopUI and SurvivorShopUI.instance and SurvivorShopUI.instance.auctionOverlay and SurvivorShopUI.instance.auctionOverlay.onHello then
            SurvivorShopUI.instance.auctionOverlay:onHello(SurvivorShopClient.isAdmin)
        end

    elseif command == "auctionClaims" then
        SurvivorShopClient.auctionClaims = (args and args.claims) or {}
        if SurvivorShopUI and SurvivorShopUI.instance and SurvivorShopUI.instance.auctionOverlay and SurvivorShopUI.instance.auctionOverlay.refreshClaims then
            SurvivorShopUI.instance.auctionOverlay:refreshClaims()
        end

    elseif command == "salesHistory" then
        local history = (args and args.history) or {}
        for i, sale in ipairs(history) do
            if sale then
                sale.itemName = resolveLocalItemName(sale.itemType, sale.itemName)
            end
        end
        SurvivorShopClient.salesHistory = history
        print("[SurvivorShop CLIENT] Received sales history")
        print("[SurvivorShop CLIENT]   Total records: " .. tostring(#SurvivorShopClient.salesHistory))
        for i, sale in ipairs(SurvivorShopClient.salesHistory) do
            print("[SurvivorShop CLIENT]   " .. tostring(i) .. ": " .. tostring(sale.itemName) .. " x" .. tostring(sale.quantity))
        end
        if SurvivorShopUI and SurvivorShopUI.instance and SurvivorShopUI.instance.refreshSalesHistory then
            print("[SurvivorShop CLIENT] Calling refreshSalesHistory()")
            SurvivorShopUI.instance:refreshSalesHistory()
        else
            print("[SurvivorShop CLIENT] WARNING: Cannot refresh - UI not ready")
        end
    end
end

Events.OnServerCommand.Add(onServerCommand)

function SurvivorShopClient.sync()
    SurvivorShopClient.send("sync", {})
end

function SurvivorShopClient.requestBalance()
    SurvivorShopClient.send("getBalance", {})
end

function SurvivorShopClient.requestBankSnapshot()
    SurvivorShopClient.send("getBankSnapshot", {})
end

function SurvivorShopClient.requestBankLedger()
    SurvivorShopClient.send("getBankLedger", {})
end

function SurvivorShopClient.requestBankInvoices()
    SurvivorShopClient.send("getBankInvoices", {})
end

function SurvivorShopClient.deposit(amount)
    SurvivorShopClient.send("deposit", { amount = tonumber(amount) })
end

function SurvivorShopClient.depositAll()
    SurvivorShopClient.send("depositAll", {})
end

function SurvivorShopClient.withdraw(amount)
    SurvivorShopClient.send("withdraw", { amount = tonumber(amount) })
end

function SurvivorShopClient.reserveDeposit(amount)
    SurvivorShopClient.send("reserveDeposit", { amount = tonumber(amount) })
end

function SurvivorShopClient.reserveWithdraw(amount)
    SurvivorShopClient.send("reserveWithdraw", { amount = tonumber(amount) })
end

function SurvivorShopClient.requestOnlinePlayers()
    SurvivorShopClient.send("getOnlinePlayers", {})
end

function SurvivorShopClient.bankTransfer(toName, amount)
    SurvivorShopClient.send("bankTransfer", { to = tostring(toName or ""), amount = tonumber(amount) })
end

function SurvivorShopClient.createInvoice(toName, amount, note)
    SurvivorShopClient.send("bankInvoiceCreate", {
        to = tostring(toName or ""),
        amount = tonumber(amount),
        note = tostring(note or ""),
    })
end

function SurvivorShopClient.payInvoice(id)
    SurvivorShopClient.send("bankInvoicePay", { id = tostring(id or "") })
end

function SurvivorShopClient.declineInvoice(id)
    SurvivorShopClient.send("bankInvoiceDecline", { id = tostring(id or "") })
end

function SurvivorShopClient.cancelInvoice(id)
    SurvivorShopClient.send("bankInvoiceCancel", { id = tostring(id or "") })
end

function SurvivorShopClient.listItem(itemType, qty, price, variantKey)
    SurvivorShopClient.send("list", {
        itemType = itemType,
        quantity = tonumber(qty),
        price = tonumber(price),
        variantKey = variantKey and tostring(variantKey) or nil,
    })
end

function SurvivorShopClient.buy(id, qty)
    SurvivorShopClient.send("buy", { id = tostring(id), quantity = tonumber(qty) })
end

function SurvivorShopClient.cancel(id)
    SurvivorShopClient.send("cancel", { id = tostring(id) })
end

function SurvivorShopClient.requestFavorites()
    SurvivorShopClient.send("favGet", {})
end

function SurvivorShopClient.setFavorite(itemType, fav)
    SurvivorShopClient.send("favSet", { itemType = tostring(itemType), fav = (fav and true or false) })
end

function SurvivorShopClient.requestAuctionHello()
    SurvivorShopClient.send("auctionHello", {})
end

function SurvivorShopClient.requestAuctionClaims()
    SurvivorShopClient.send("auctionGetClaims", {})
end

function SurvivorShopClient.createAuction(itemType, quantity, minBid)
    SurvivorShopClient.send("auctionCreate", { itemType = itemType, quantity = quantity, minBid = minBid })
end

function SurvivorShopClient.placeBid(auctionId, amount)
    SurvivorShopClient.send("auctionBid", { id = auctionId, amount = amount })
end

function SurvivorShopClient.claimAuction(auctionId)
    SurvivorShopClient.send("auctionClaim", { id = auctionId })
end

function SurvivorShopClient.requestSalesHistory()
    print("[SurvivorShop CLIENT] Requesting sales history from server")
    SurvivorShopClient.send("getSalesHistory", {})
end
