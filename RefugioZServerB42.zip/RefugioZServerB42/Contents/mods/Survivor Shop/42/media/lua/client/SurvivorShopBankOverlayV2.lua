require "ISUI/ISPanel"
require "ISUI/ISButton"
require "ISUI/ISLabel"
require "ISUI/ISTextEntryBox"
require "ISUI/ISComboBox"
require "ISUI/ISScrollingListBox"
require "SurvivorShopClient"
require "SurvivorShopUITheme"

local function SSB_T(key, fallback, ...)
    local value = getText(key, ...)
    if not value or value == key then return fallback or key end
    return value
end

local function SSB_stripUnknownPrefix(s)
    if not s then return "" end
    if type(s) ~= "string" then s = tostring(s) end
    s = s:gsub("^%s*", "")
    s = s:gsub("^%?%s*", "")
    return s
end

local function SSB_resolveName(fullType, fallback)
    fullType = tostring(fullType or "")
    if fullType ~= "" and getItemNameFromFullType then
        local ok, value = pcall(getItemNameFromFullType, fullType)
        if ok and value and value ~= "" and value ~= fullType then
            return SSB_stripUnknownPrefix(value)
        end
    end
    return SSB_stripUnknownPrefix(fallback or fullType)
end

local function SSB_money(value)
    return "$" .. tostring(math.max(0, math.floor(tonumber(value) or 0)))
end

local function SSB_formatText(key, fallback, ...)
    local args = { ... }
    local value = getText(key, unpack(args))
    if value and value ~= key then
        return value
    end

    local template = fallback or key
    if #args == 0 then
        return template
    end

    template = tostring(template)
    template = template:gsub("%%1%$s", "%%s")
    template = template:gsub("%%1", "%%s")
    local ok, formatted = pcall(string.format, template, unpack(args))
    if ok and formatted then
        return formatted
    end
    return template
end

local function SSB_date(value)
    local ts = tonumber(value)
    if not ts or ts <= 0 then return "--/-- --:--" end
    return os.date("%d/%m %H:%M", ts)
end

local function SSB_drawTextClipped(panel, text, x, y, maxW, r, g, b, a, font)
    if panel.drawTextClipped then
        panel:drawTextClipped(text, x, y, maxW, r, g, b, a, font or UIFont.Small)
        return
    end
    panel:drawText(text, x, y, r, g, b, a, font or UIFont.Small)
end

local function SSB_styleField(entry)
    SurvivorShopUITheme.styleTextEntry(entry)
    if entry and entry.setMasked then entry:setMasked(false) end
end

local function SSB_styleNumericField(entry, maxChars)
    SSB_styleField(entry)
    if not entry then return end
    pcall(function() if entry.setOnlyNumbers then entry:setOnlyNumbers(true) end end)
    pcall(function() if entry.setMaxChars then entry:setMaxChars(maxChars or 9) end end)
end

local function SSB_createSubPanel(parent)
    local panel = ISPanel:new(0, 0, 100, 100)
    panel.backgroundColor = { r = 0, g = 0, b = 0, a = 0 }
    panel.borderColor = { r = 0, g = 0, b = 0, a = 0 }
    panel.noBackground = true
    panel:initialise()
    panel:instantiate()
    parent:addChild(panel)
    return panel
end

local function SSB_ledgerLabel(entry)
    local kind = tostring((entry and entry.kind) or "")
    if kind == "deposit" then return SSB_T("IGUI_SS_Ledger_Deposit", "Cash deposit"), 1 end
    if kind == "withdraw" then return SSB_T("IGUI_SS_Ledger_Withdraw", "Cash withdraw"), -1 end
    if kind == "transfer_out" then return SSB_T("IGUI_SS_Ledger_TransferOut", "Transfer sent"), -1 end
    if kind == "transfer_in" then return SSB_T("IGUI_SS_Ledger_TransferIn", "Transfer received"), 1 end
    if kind == "vault_in" then return SSB_T("IGUI_SS_Ledger_VaultIn", "Moved to vault"), -1 end
    if kind == "vault_out" then return SSB_T("IGUI_SS_Ledger_VaultOut", "Moved from vault"), 1 end
    if kind == "listing_fee" then return SSB_T("IGUI_SS_Ledger_ListingFee", "Listing fee"), -1 end
    if kind == "listing_fee_refund" then return SSB_T("IGUI_SS_Ledger_ListingFeeRefund", "Listing fee refund"), 1 end
    if kind == "sale_payout" then return SSB_T("IGUI_SS_Ledger_SalePayout", "Sale payout"), 1 end
    if kind == "purchase" then return SSB_T("IGUI_SS_Ledger_Purchase", "Purchase"), -1 end
    if kind == "invoice_paid_out" then return SSB_T("IGUI_SS_Ledger_InvoicePaidOut", "Invoice paid"), -1 end
    if kind == "invoice_paid_in" then return SSB_T("IGUI_SS_Ledger_InvoicePaidIn", "Invoice received"), 1 end
    if kind == "auction_payout" then return SSB_T("IGUI_SS_Ledger_AuctionPayout", "Auction payout"), 1 end
    return SSB_T("IGUI_SS_Ledger_Generic", "Bank entry"), 0
end

local function SSB_buildLedgerRow(entry)
    local title, sign = SSB_ledgerLabel(entry)
    local details = {}
    if entry and entry.otherName and entry.otherName ~= "" then
        table.insert(details, tostring(entry.otherName))
    end
    if entry and entry.itemName and entry.itemName ~= "" then
        local itemName = SSB_resolveName("", entry.itemName)
        local qty = math.floor(tonumber(entry.quantity) or 0)
        if qty > 0 then itemName = itemName .. " x" .. tostring(qty) end
        table.insert(details, itemName)
    end
    if entry and entry.note and entry.note ~= "" then
        table.insert(details, tostring(entry.note))
    end
    table.insert(details, SSB_date(entry and entry.createdAt))
    table.insert(details, SSB_T("IGUI_SS_AvailableShort", "Avail.") .. " " .. SSB_money(entry and entry.balanceAfter))
    table.insert(details, SSB_T("IGUI_SS_VaultShort", "Vault") .. " " .. SSB_money(entry and entry.savingsAfter))

    local amount = math.max(0, math.floor(tonumber(entry and entry.amount) or 0))
    local amountText = SSB_money(amount)
    if sign < 0 then
        amountText = "-" .. amountText
    elseif sign > 0 then
        amountText = "+" .. amountText
    end

    return {
        title = title,
        subtitle = table.concat(details, " | "),
        amountText = amountText,
        sign = sign,
        _entry = entry,
    }
end

local function SSB_buildInvoiceRow(invoice)
    local direction = tostring((invoice and invoice.direction) or "incoming")
    local incoming = direction == "incoming"
    local targetName = incoming and tostring(invoice and invoice.fromName or "") or tostring(invoice and invoice.toName or "")
    local status = tostring((invoice and invoice.status) or "pending")
    local statusKey = "IGUI_SS_InvoiceStatus_Pending"
    local statusFallback = "Pending"
    if status == "paid" then
        statusKey = "IGUI_SS_InvoiceStatus_Paid"
        statusFallback = "Paid"
    elseif status == "declined" then
        statusKey = "IGUI_SS_InvoiceStatus_Declined"
        statusFallback = "Declined"
    elseif status == "canceled" then
        statusKey = "IGUI_SS_InvoiceStatus_Canceled"
        statusFallback = "Canceled"
    end

    local prefix = incoming and SSB_T("IGUI_SS_InvoiceIncomingShort", "From") or SSB_T("IGUI_SS_InvoiceOutgoingShort", "To")
    local details = {
        SSB_T(statusKey, statusFallback),
        SSB_date(invoice and invoice.createdAt),
    }
    if invoice and invoice.note and invoice.note ~= "" then
        table.insert(details, tostring(invoice.note))
    end

    return {
        title = prefix .. ": " .. (targetName ~= "" and targetName or SSB_T("IGUI_SS_Generic_Someone", "Someone")),
        subtitle = table.concat(details, " | "),
        amountText = SSB_money(invoice and invoice.amount),
        incoming = incoming,
        status = status,
        _invoice = invoice,
    }
end

SurvivorShopBankOverlayV2 = ISPanel:derive("SurvivorShopBankOverlayV2")

function SurvivorShopBankOverlayV2:new(ownerUI)
    local sw = getCore():getScreenWidth()
    local sh = getCore():getScreenHeight()
    local pad = 12
    local w = 460
    local h = ownerUI and ownerUI.height or 300
    h = math.min(h, sh - (2 * pad))
    local x = sw - w - pad
    local y = pad
    if ownerUI and ownerUI.y then
        y = math.max(pad, math.min(ownerUI.y, sh - h - pad))
    end

    local o = ISPanel:new(x, y, w, h)
    setmetatable(o, self)
    self.__index = self
    o.ownerUI = ownerUI
    o.backgroundColor = SurvivorShopUITheme.Colors.panelBg
    o.borderColor = SurvivorShopUITheme.Colors.panelBorder
    o.moveWithMouse = false
    o.currentTab = "overview"
    o._transferCooldownUntil = 0
    o._refreshCooldownUntil = 0
    return o
end

function SurvivorShopBankOverlayV2:initialise()
    ISPanel.initialise(self)
end

function SurvivorShopBankOverlayV2:createChildren()
    ISPanel.createChildren(self)
    local pad = 14
    local tabW = math.floor((self.width - (pad * 2) - 12) / 3)

    self.title = ISLabel:new(pad, pad, 20, SSB_T("IGUI_SS_Bank", "Bank"), 1, 1, 1, 1, UIFont.Large, true)
    self.title:setVisible(false)
    self:addChild(self.title)

    self.btnClose = ISButton:new(self.width - pad - 24, pad, 24, 24, "X", self, SurvivorShopBankOverlayV2.onClose)
    self.btnClose:initialise()
    self.btnClose:instantiate()
    self:addChild(self.btnClose)
    SurvivorShopUITheme.styleButton(self.btnClose, "dangerTiny")

    self.btnOverview = ISButton:new(pad, 62, tabW, 24, SSB_T("IGUI_SS_BankTab_Overview", "Summary"), self, SurvivorShopBankOverlayV2.onTabOverview)
    self.btnOverview:initialise()
    self.btnOverview:instantiate()
    self:addChild(self.btnOverview)

    self.btnInvoices = ISButton:new(pad + tabW + 6, 62, tabW, 24, SSB_T("IGUI_SS_BankTab_Invoices", "Invoices"), self, SurvivorShopBankOverlayV2.onTabInvoices)
    self.btnInvoices:initialise()
    self.btnInvoices:instantiate()
    self:addChild(self.btnInvoices)

    self.btnLedger = ISButton:new(pad + ((tabW + 6) * 2), 62, tabW, 24, SSB_T("IGUI_SS_BankTab_Ledger", "Ledger"), self, SurvivorShopBankOverlayV2.onTabLedger)
    self.btnLedger:initialise()
    self.btnLedger:instantiate()
    self:addChild(self.btnLedger)

    self.contentPanel = SSB_createSubPanel(self)
    self.summaryPanel = SSB_createSubPanel(self.contentPanel)
    self.invoicePanel = SSB_createSubPanel(self.contentPanel)
    self.ledgerPanel = SSB_createSubPanel(self.contentPanel)

    self.bankBal = ISLabel:new(0, 0, 20, "", 1, 1, 1, 1, UIFont.Medium, true)
    self.summaryPanel:addChild(self.bankBal)
    self.savingsBal = ISLabel:new(0, 22, 20, "", 1, 1, 1, 1, UIFont.Small, true)
    self.summaryPanel:addChild(self.savingsBal)
    self.totalBal = ISLabel:new(0, 42, 20, "", 1, 1, 1, 1, UIFont.Small, true)
    self.summaryPanel:addChild(self.totalBal)

    self.depEntry = ISTextEntryBox:new("100", 0, 78, 110, 24)
    self.summaryPanel:addChild(self.depEntry)
    SSB_styleNumericField(self.depEntry, 9)
    self.depBtn = ISButton:new(122, 78, 120, 24, SSB_T("IGUI_SS_Deposit", "Deposit"), self, SurvivorShopBankOverlayV2.onDeposit)
    self.depBtn:initialise()
    self.depBtn:instantiate()
    self.summaryPanel:addChild(self.depBtn)
    SurvivorShopUITheme.styleButton(self.depBtn, "success")
    self.depAllBtn = ISButton:new(248, 78, 120, 24, SSB_T("IGUI_SS_DepositAll", "Deposit All"), self, SurvivorShopBankOverlayV2.onDepositAll)
    self.depAllBtn:initialise()
    self.depAllBtn:instantiate()
    self.summaryPanel:addChild(self.depAllBtn)
    SurvivorShopUITheme.styleButton(self.depAllBtn, "warning")

    self.wdEntry = ISTextEntryBox:new("100", 0, 110, 110, 24)
    self.summaryPanel:addChild(self.wdEntry)
    SSB_styleNumericField(self.wdEntry, 9)
    self.wdBtn = ISButton:new(122, 110, 120, 24, SSB_T("IGUI_SS_Withdraw", "Withdraw"), self, SurvivorShopBankOverlayV2.onWithdraw)
    self.wdBtn:initialise()
    self.wdBtn:instantiate()
    self.summaryPanel:addChild(self.wdBtn)
    SurvivorShopUITheme.styleButton(self.wdBtn, "info")

    self.vaultTitle = ISLabel:new(0, 150, 20, SSB_T("IGUI_SS_VaultTitle", "Vault"), 1, 1, 1, 1, UIFont.Medium, true)
    self.summaryPanel:addChild(self.vaultTitle)
    self.reserveEntry = ISTextEntryBox:new("100", 0, 178, 110, 24)
    self.summaryPanel:addChild(self.reserveEntry)
    SSB_styleNumericField(self.reserveEntry, 9)
    self.reserveInBtn = ISButton:new(122, 178, 120, 24, SSB_T("IGUI_SS_VaultDeposit", "Store"), self, SurvivorShopBankOverlayV2.onReserveDeposit)
    self.reserveInBtn:initialise()
    self.reserveInBtn:instantiate()
    self.summaryPanel:addChild(self.reserveInBtn)
    SurvivorShopUITheme.styleButton(self.reserveInBtn, "warning")
    self.reserveOutBtn = ISButton:new(248, 178, 120, 24, SSB_T("IGUI_SS_VaultWithdraw", "Retrieve"), self, SurvivorShopBankOverlayV2.onReserveWithdraw)
    self.reserveOutBtn:initialise()
    self.reserveOutBtn:instantiate()
    self.summaryPanel:addChild(self.reserveOutBtn)
    SurvivorShopUITheme.styleButton(self.reserveOutBtn, "default")

    self.trTitle = ISLabel:new(0, 222, 20, SSB_T("IGUI_SS_TransferTitle", "Transfer"), 1, 1, 1, 1, UIFont.Medium, true)
    self.summaryPanel:addChild(self.trTitle)
    self.trToEntry = ISTextEntryBox:new("", 0, 250, 250, 24)
    self.summaryPanel:addChild(self.trToEntry)
    SSB_styleField(self.trToEntry)
    self.trRefreshBtn = ISButton:new(258, 250, 110, 24, SSB_T("IGUI_SS_Refresh", "Refresh"), self, SurvivorShopBankOverlayV2.onRefreshPlayers)
    self.trRefreshBtn:initialise()
    self.trRefreshBtn:instantiate()
    self.summaryPanel:addChild(self.trRefreshBtn)
    SurvivorShopUITheme.styleButton(self.trRefreshBtn, "default")
    self.trToCombo = ISComboBox:new(0, 282, 368, 24, self, SurvivorShopBankOverlayV2.onSelectTransferTarget)
    self.trToCombo:initialise()
    self.summaryPanel:addChild(self.trToCombo)
    SurvivorShopUITheme.styleComboBox(self.trToCombo)
    self.trAmount = ISTextEntryBox:new("100", 0, 314, 250, 24)
    self.summaryPanel:addChild(self.trAmount)
    SSB_styleNumericField(self.trAmount, 9)
    self.trBtn = ISButton:new(258, 314, 110, 24, SSB_T("IGUI_SS_Transfer", "Transfer"), self, SurvivorShopBankOverlayV2.onTransfer)
    self.trBtn:initialise()
    self.trBtn:instantiate()
    self.summaryPanel:addChild(self.trBtn)
    SurvivorShopUITheme.styleButton(self.trBtn, "success")

    self.invoiceTitle = ISLabel:new(0, 0, 20, SSB_T("IGUI_SS_InvoiceTitle", "Invoices"), 1, 1, 1, 1, UIFont.Medium, true)
    self.invoicePanel:addChild(self.invoiceTitle)
    self.invToEntry = ISTextEntryBox:new("", 0, 28, 250, 24)
    self.invoicePanel:addChild(self.invToEntry)
    SSB_styleField(self.invToEntry)
    self.invRefreshBtn = ISButton:new(258, 28, 110, 24, SSB_T("IGUI_SS_Refresh", "Refresh"), self, SurvivorShopBankOverlayV2.onRefreshPlayers)
    self.invRefreshBtn:initialise()
    self.invRefreshBtn:instantiate()
    self.invoicePanel:addChild(self.invRefreshBtn)
    SurvivorShopUITheme.styleButton(self.invRefreshBtn, "default")
    self.invToCombo = ISComboBox:new(0, 60, 368, 24, self, SurvivorShopBankOverlayV2.onSelectInvoiceTarget)
    self.invToCombo:initialise()
    self.invoicePanel:addChild(self.invToCombo)
    SurvivorShopUITheme.styleComboBox(self.invToCombo)
    self.invAmount = ISTextEntryBox:new("100", 0, 92, 110, 24)
    self.invoicePanel:addChild(self.invAmount)
    SSB_styleNumericField(self.invAmount, 9)
    self.invNote = ISTextEntryBox:new("", 122, 92, 246, 24)
    self.invoicePanel:addChild(self.invNote)
    SSB_styleField(self.invNote)
    pcall(function() if self.invNote.setMaxChars then self.invNote:setMaxChars(80) end end)
    self.invCreateBtn = ISButton:new(0, 124, 140, 24, SSB_T("IGUI_SS_InvoiceCreate", "Create invoice"), self, SurvivorShopBankOverlayV2.onCreateInvoice)
    self.invCreateBtn:initialise()
    self.invCreateBtn:instantiate()
    self.invoicePanel:addChild(self.invCreateBtn)
    SurvivorShopUITheme.styleButton(self.invCreateBtn, "warning")

    self.invoiceList = ISScrollingListBox:new(0, 164, 368, 180)
    self.invoiceList:initialise()
    self.invoiceList:instantiate()
    self.invoiceList.itemheight = 42
    SurvivorShopUITheme.styleListBox(self.invoiceList)
    self.invoiceList.doDrawItem = function(list, y, item, alt)
        local rowH = item.height or list.itemheight
        local data = item.item or {}
        local c = SurvivorShopUITheme.Colors
        local bg = alt and c.listRowAlt or c.listRowEven
        list:drawRect(0, y, list.width, rowH, 0.92, bg.r, bg.g, bg.b)
        if list.items[list.selected] == item then
            list:drawRect(0, y, list.width, rowH, c.listSelected.a, c.listSelected.r, c.listSelected.g, c.listSelected.b)
        end
        local amountColor = data.incoming and c.successText or c.accentText
        if data.status == "declined" or data.status == "canceled" then
            amountColor = c.dimText
        end
        SSB_drawTextClipped(list, data.title or "", 10, y + 5, list.width - 110, c.normalText.r, c.normalText.g, c.normalText.b, c.normalText.a, UIFont.Small)
        SSB_drawTextClipped(list, data.subtitle or "", 10, y + 22, list.width - 20, c.dimText.r, c.dimText.g, c.dimText.b, c.dimText.a, UIFont.Small)
        local amountText = tostring(data.amountText or "")
        local width = getTextManager():MeasureStringX(UIFont.Small, amountText)
        list:drawText(amountText, list.width - width - 12, y + 11, amountColor.r, amountColor.g, amountColor.b, 1, UIFont.Small)
        return y + rowH
    end
    self.invoiceList.onMouseDown = function(list, x, y)
        ISScrollingListBox.onMouseDown(list, x, y)
        self:updateInvoiceButtons()
    end
    self.invoicePanel:addChild(self.invoiceList)

    self.invPayBtn = ISButton:new(0, 352, 112, 24, SSB_T("IGUI_SS_InvoicePay", "Pay"), self, SurvivorShopBankOverlayV2.onPayInvoice)
    self.invPayBtn:initialise()
    self.invPayBtn:instantiate()
    self.invoicePanel:addChild(self.invPayBtn)
    SurvivorShopUITheme.styleButton(self.invPayBtn, "success")
    self.invDeclineBtn = ISButton:new(128, 352, 112, 24, SSB_T("IGUI_SS_InvoiceDecline", "Decline"), self, SurvivorShopBankOverlayV2.onDeclineInvoice)
    self.invDeclineBtn:initialise()
    self.invDeclineBtn:instantiate()
    self.invoicePanel:addChild(self.invDeclineBtn)
    SurvivorShopUITheme.styleButton(self.invDeclineBtn, "dangerTiny")
    self.invCancelBtn = ISButton:new(256, 352, 112, 24, SSB_T("IGUI_SS_InvoiceCancel", "Cancel"), self, SurvivorShopBankOverlayV2.onCancelInvoice)
    self.invCancelBtn:initialise()
    self.invCancelBtn:instantiate()
    self.invoicePanel:addChild(self.invCancelBtn)
    SurvivorShopUITheme.styleButton(self.invCancelBtn, "default")

    self.ledgerList = ISScrollingListBox:new(0, 0, 368, 300)
    self.ledgerList:initialise()
    self.ledgerList:instantiate()
    self.ledgerList.itemheight = 42
    SurvivorShopUITheme.styleListBox(self.ledgerList)
    self.ledgerList.doDrawItem = function(list, y, item, alt)
        local rowH = item.height or list.itemheight
        local data = item.item or {}
        local c = SurvivorShopUITheme.Colors
        local bg = alt and c.listRowAlt or c.listRowEven
        list:drawRect(0, y, list.width, rowH, 0.92, bg.r, bg.g, bg.b)
        if list.items[list.selected] == item then
            list:drawRect(0, y, list.width, rowH, c.listSelected.a, c.listSelected.r, c.listSelected.g, c.listSelected.b)
        end
        local amountColor = c.accentText
        if tonumber(data.sign or 0) > 0 then amountColor = c.successText end
        if tonumber(data.sign or 0) < 0 then amountColor = c.dangerText end
        SSB_drawTextClipped(list, data.title or "", 10, y + 5, list.width - 110, c.normalText.r, c.normalText.g, c.normalText.b, c.normalText.a, UIFont.Small)
        SSB_drawTextClipped(list, data.subtitle or "", 10, y + 22, list.width - 20, c.dimText.r, c.dimText.g, c.dimText.b, c.dimText.a, UIFont.Small)
        local amountText = tostring(data.amountText or "")
        local width = getTextManager():MeasureStringX(UIFont.Small, amountText)
        list:drawText(amountText, list.width - width - 12, y + 11, amountColor.r, amountColor.g, amountColor.b, 1, UIFont.Small)
        return y + rowH
    end
    self.ledgerPanel:addChild(self.ledgerList)

    self:layoutContent()
    self:setOnlinePlayers(SurvivorShopClient.onlinePlayers or {})
    self:setTab("overview")
    self:refreshBalance()
    self:refreshInvoices()
    self:refreshLedger()
end

function SurvivorShopBankOverlayV2:layoutContent()
    local pad = 14
    local innerW = self.width - 16
    local innerH = self.height - 100
    local panelW = innerW - (pad * 2)
    local panelH = innerH - pad
    local fieldW = math.max(160, panelW - 118)
    local btnX = math.max(258, panelW - 110)

    if self.contentPanel then
        self.contentPanel:setX(8)
        self.contentPanel:setY(92)
        self.contentPanel:setWidth(innerW)
        self.contentPanel:setHeight(innerH)
    end

    local panels = { self.summaryPanel, self.invoicePanel, self.ledgerPanel }
    for _, panel in ipairs(panels) do
        if panel then
            panel:setX(pad)
            panel:setY(0)
            panel:setWidth(panelW)
            panel:setHeight(panelH)
        end
    end

    if self.trToEntry then self.trToEntry:setWidth(fieldW) end
    if self.trRefreshBtn then self.trRefreshBtn:setX(btnX) end
    if self.trToCombo then self.trToCombo:setWidth(panelW) end
    if self.trAmount then self.trAmount:setWidth(fieldW) end
    if self.trBtn then self.trBtn:setX(btnX) end

    if self.invToEntry then self.invToEntry:setWidth(fieldW) end
    if self.invRefreshBtn then self.invRefreshBtn:setX(btnX) end
    if self.invToCombo then self.invToCombo:setWidth(panelW) end
    if self.invNote then
        self.invNote:setX(122)
        self.invNote:setWidth(math.max(140, panelW - 122))
    end
    if self.invoiceList then
        self.invoiceList:setWidth(panelW)
        self.invoiceList:setHeight(math.max(120, panelH - 212))
    end
    local actionsY = panelH - 28
    if self.invPayBtn then self.invPayBtn:setY(actionsY) end
    if self.invDeclineBtn then self.invDeclineBtn:setY(actionsY) end
    if self.invCancelBtn then self.invCancelBtn:setY(actionsY) end

    if self.ledgerList then
        self.ledgerList:setWidth(panelW)
        self.ledgerList:setHeight(math.max(160, panelH - 8))
    end
end

function SurvivorShopBankOverlayV2:setTab(tab)
    self.currentTab = tab or "overview"
    if self.summaryPanel then self.summaryPanel:setVisible(self.currentTab == "overview") end
    if self.invoicePanel then self.invoicePanel:setVisible(self.currentTab == "invoices") end
    if self.ledgerPanel then self.ledgerPanel:setVisible(self.currentTab == "ledger") end
    SurvivorShopUITheme.styleButton(self.btnOverview, self.currentTab == "overview" and "warning" or "default")
    SurvivorShopUITheme.styleButton(self.btnInvoices, self.currentTab == "invoices" and "warning" or "default")
    SurvivorShopUITheme.styleButton(self.btnLedger, self.currentTab == "ledger" and "warning" or "default")
end

function SurvivorShopBankOverlayV2:onTabOverview()
    self:setTab("overview")
end

function SurvivorShopBankOverlayV2:onTabInvoices()
    self:setTab("invoices")
end

function SurvivorShopBankOverlayV2:onTabLedger()
    self:setTab("ledger")
end

function SurvivorShopBankOverlayV2:prerender()
    ISPanel.prerender(self)
    SurvivorShopUITheme.drawSoftPanel(self, 0, 0, self.width, self.height)
    SurvivorShopUITheme.drawSoftPanel(self, 8, 62, self.width - 16, self.height - 70)
    SurvivorShopUITheme.drawPremiumHeader(self, 0, 0, self.width, 54, SSB_T("IGUI_SS_Bank", "Bank"), nil)
    self:layoutContent()
    self:refreshBalance()
    self:updateCooldowns()
end

function SurvivorShopBankOverlayV2:updateCooldowns()
    local now = SurvivorShopClient.nowMs and SurvivorShopClient.nowMs() or (os.time() * 1000)
    if self.trBtn and self.trBtn.setEnable and now >= (self._transferCooldownUntil or 0) then
        self.trBtn:setEnable(true)
    end
    if self.trRefreshBtn and self.trRefreshBtn.setEnable and now >= (self._refreshCooldownUntil or 0) then
        self.trRefreshBtn:setEnable(true)
    end
    if self.invRefreshBtn and self.invRefreshBtn.setEnable and now >= (self._refreshCooldownUntil or 0) then
        self.invRefreshBtn:setEnable(true)
    end
end

function SurvivorShopBankOverlayV2:refreshBalance()
    if self.bankBal then
        self.bankBal:setName(SSB_formatText("IGUI_SS_AvailableBalance", "Available: %s", SSB_money(SurvivorShopClient.balance or 0)))
    end
    if self.savingsBal then
        self.savingsBal:setName(SSB_formatText("IGUI_SS_SavingsBalance", "Vault: %s", SSB_money(SurvivorShopClient.savings or 0)))
    end
    if self.totalBal then
        self.totalBal:setName(SSB_formatText("IGUI_SS_TotalBalance", "Total: %s", SSB_money(SurvivorShopClient.bankTotal or 0)))
    end
end

function SurvivorShopBankOverlayV2:refreshLedger()
    if not self.ledgerList then return end
    self.ledgerList:clear()
    local entries = SurvivorShopClient.bankLedger or {}
    if #entries == 0 then
        local row = self.ledgerList:addItem("", {
            title = SSB_T("IGUI_SS_NoLedger", "No bank history yet."),
            subtitle = "",
            amountText = "",
            sign = 0,
        })
        row.height = self.ledgerList.itemheight
        return
    end
    for _, entry in ipairs(entries) do
        local row = self.ledgerList:addItem("", SSB_buildLedgerRow(entry))
        row.height = self.ledgerList.itemheight
    end
end

function SurvivorShopBankOverlayV2:updateInvoiceButtons()
    local selected = self.invoiceList and self.invoiceList.items and self.invoiceList.items[self.invoiceList.selected] or nil
    local invoice = selected and selected.item and selected.item._invoice or nil
    local canPay = false
    local canDecline = false
    local canCancel = false
    if invoice and tostring(invoice.status or "") == "pending" then
        if tostring(invoice.direction or "") == "incoming" then
            canPay = true
            canDecline = true
        else
            canCancel = true
        end
    end
    if self.invPayBtn and self.invPayBtn.setEnable then self.invPayBtn:setEnable(canPay) end
    if self.invDeclineBtn and self.invDeclineBtn.setEnable then self.invDeclineBtn:setEnable(canDecline) end
    if self.invCancelBtn and self.invCancelBtn.setEnable then self.invCancelBtn:setEnable(canCancel) end
end

function SurvivorShopBankOverlayV2:refreshInvoices()
    if not self.invoiceList then return end
    self.invoiceList:clear()
    local invoices = SurvivorShopClient.bankInvoices or {}
    if #invoices == 0 then
        local row = self.invoiceList:addItem("", {
            title = SSB_T("IGUI_SS_NoInvoices", "No invoices."),
            subtitle = "",
            amountText = "",
            incoming = true,
            status = "empty",
        })
        row.height = self.invoiceList.itemheight
        self:updateInvoiceButtons()
        return
    end
    for _, invoice in ipairs(invoices) do
        local row = self.invoiceList:addItem("", SSB_buildInvoiceRow(invoice))
        row.height = self.invoiceList.itemheight
    end
    self:updateInvoiceButtons()
end

function SurvivorShopBankOverlayV2:alignToShop()
    local sw = getCore():getScreenWidth()
    local sh = getCore():getScreenHeight()
    local pad = 12
    local gap = 6
    local ox = (self.ownerUI and self.ownerUI.x) or pad
    local oy = (self.ownerUI and self.ownerUI.y) or pad
    local oh = (self.ownerUI and self.ownerUI.height) or self.height
    if oh and oh > 100 then self:setHeight(oh) end

    local xRight = ox + ((self.ownerUI and self.ownerUI.width) or 0) + gap
    local xLeft = ox - self.width - gap
    local x
    if (xRight + self.width) <= (sw - pad) then
        x = xRight
    elseif xLeft >= pad then
        x = xLeft
    else
        x = sw - self.width - pad
    end

    local y = math.max(pad, math.min(oy, sh - self.height - pad))
    self:setX(x)
    self:setY(y)
    self:layoutContent()
end

function SurvivorShopBankOverlayV2.onClose(self)
    if self.ownerUI and self.ownerUI.closeBank then
        self.ownerUI:closeBank()
    else
        self:setVisible(false)
    end
end

function SurvivorShopBankOverlayV2:onDeposit()
    SurvivorShopClient.deposit(self.depEntry:getText())
end

function SurvivorShopBankOverlayV2:onDepositAll()
    SurvivorShopClient.depositAll()
end

function SurvivorShopBankOverlayV2:onWithdraw()
    SurvivorShopClient.withdraw(self.wdEntry:getText())
end

function SurvivorShopBankOverlayV2:onReserveDeposit()
    SurvivorShopClient.reserveDeposit(self.reserveEntry:getText())
end

function SurvivorShopBankOverlayV2:onReserveWithdraw()
    SurvivorShopClient.reserveWithdraw(self.reserveEntry:getText())
end

function SurvivorShopBankOverlayV2:setOnlinePlayers(players)
    players = players or {}
    local me = (getPlayer() and getPlayer().getUsername) and tostring(getPlayer():getUsername()) or ""

    local function fillCombo(combo)
        if not combo then return end
        combo:clear()
        local added = 0
        for _, info in ipairs(players) do
            local name = tostring(info.name or "")
            if name ~= "" and name ~= me then
                combo:addOption(name)
                added = added + 1
            end
        end
        if added == 0 then
            combo:addOption(SSB_T("IGUI_SS_NoOnline", "(no players online)"))
            combo.selected = 1
        end
    end

    fillCombo(self.trToCombo)
    fillCombo(self.invToCombo)
end

function SurvivorShopBankOverlayV2:onRefreshPlayers()
    local now = SurvivorShopClient.nowMs and SurvivorShopClient.nowMs() or (os.time() * 1000)
    if now < (self._refreshCooldownUntil or 0) then return end
    self._refreshCooldownUntil = now + 1000
    if self.trRefreshBtn and self.trRefreshBtn.setEnable then self.trRefreshBtn:setEnable(false) end
    if self.invRefreshBtn and self.invRefreshBtn.setEnable then self.invRefreshBtn:setEnable(false) end
    SurvivorShopClient.requestOnlinePlayers()
end

function SurvivorShopBankOverlayV2:onSelectTransferTarget()
    if not self.trToCombo or not self.trToEntry then return end
    local value = self.trToCombo:getOptionText(self.trToCombo.selected) or ""
    if value ~= "" and not value:find("%(no players") then
        self.trToEntry:setText(value)
    end
end

function SurvivorShopBankOverlayV2:onSelectInvoiceTarget()
    if not self.invToCombo or not self.invToEntry then return end
    local value = self.invToCombo:getOptionText(self.invToCombo.selected) or ""
    if value ~= "" and not value:find("%(no players") then
        self.invToEntry:setText(value)
    end
end

function SurvivorShopBankOverlayV2:onTransfer()
    local now = SurvivorShopClient.nowMs and SurvivorShopClient.nowMs() or (os.time() * 1000)
    if now < (self._transferCooldownUntil or 0) then return end
    local toName = tostring(self.trToEntry and self.trToEntry:getText() or "")
    toName = toName:gsub("^%s+", ""):gsub("%s+$", "")
    if toName == "" then
        if SurvivorShopUI and SurvivorShopUI.showToast then
            SurvivorShopUI.showToast(SSB_T("IGUI_SS_Err_SelectPlayer", "Select a player."))
        end
        return
    end

    local amount = math.floor(tonumber(self.trAmount and self.trAmount:getText() or 0) or 0)
    if amount <= 0 then
        if SurvivorShopUI and SurvivorShopUI.showToast then
            SurvivorShopUI.showToast(SSB_T("IGUI_SS_InvalidAmount", "Invalid amount."))
        end
        return
    end

    self._transferCooldownUntil = now + 1200
    if self.trBtn and self.trBtn.setEnable then self.trBtn:setEnable(false) end
    SurvivorShopClient.bankTransfer(toName, amount)
end

function SurvivorShopBankOverlayV2:onCreateInvoice()
    local toName = tostring(self.invToEntry and self.invToEntry:getText() or "")
    toName = toName:gsub("^%s+", ""):gsub("%s+$", "")
    local amount = math.floor(tonumber(self.invAmount and self.invAmount:getText() or 0) or 0)
    local note = tostring(self.invNote and self.invNote:getText() or "")
    if toName == "" then
        if SurvivorShopUI and SurvivorShopUI.showToast then
            SurvivorShopUI.showToast(SSB_T("IGUI_SS_Err_SelectPlayer", "Select a player."))
        end
        return
    end
    if amount <= 0 then
        if SurvivorShopUI and SurvivorShopUI.showToast then
            SurvivorShopUI.showToast(SSB_T("IGUI_SS_InvalidAmount", "Invalid amount."))
        end
        return
    end
    SurvivorShopClient.createInvoice(toName, amount, note)
end

function SurvivorShopBankOverlayV2:onPayInvoice()
    local selected = self.invoiceList and self.invoiceList.items and self.invoiceList.items[self.invoiceList.selected] or nil
    local invoice = selected and selected.item and selected.item._invoice or nil
    if invoice and invoice.id then
        SurvivorShopClient.payInvoice(invoice.id)
    end
end

function SurvivorShopBankOverlayV2:onDeclineInvoice()
    local selected = self.invoiceList and self.invoiceList.items and self.invoiceList.items[self.invoiceList.selected] or nil
    local invoice = selected and selected.item and selected.item._invoice or nil
    if invoice and invoice.id then
        SurvivorShopClient.declineInvoice(invoice.id)
    end
end

function SurvivorShopBankOverlayV2:onCancelInvoice()
    local selected = self.invoiceList and self.invoiceList.items and self.invoiceList.items[self.invoiceList.selected] or nil
    local invoice = selected and selected.item and selected.item._invoice or nil
    if invoice and invoice.id then
        SurvivorShopClient.cancelInvoice(invoice.id)
    end
end
