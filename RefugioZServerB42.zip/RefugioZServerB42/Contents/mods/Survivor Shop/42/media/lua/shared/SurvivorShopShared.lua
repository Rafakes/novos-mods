-- SurvivorShopShared.lua (B42.13.2)
SurvivorShop = SurvivorShop or {}
SurvivorShop.ID = "SurvivorShop"
SurvivorShop.MODULE = "SurvivorShop"

SurvivorShop.CURRENCY = "Base.Money"
SurvivorShop.COMMISSION_RATE = 0.10
SurvivorShop.MAX_QTY_PER_LISTING = 200
SurvivorShop.MAX_PRICE = 1000000
SurvivorShop.ALLOW_FOOD = true

SurvivorShop.MODDATA_PUBLIC = "SurvivorShop_Data"
SurvivorShop.MODDATA_INTERNAL = "SurvivorShop_Internal"
SurvivorShop.MODDATA_BALANCES = "SurvivorShop_Balances"
SurvivorShop.MODDATA_SALES_HISTORY = "SurvivorShop_SalesHistory"
SurvivorShop.MODDATA_BANK_LEDGER = "SurvivorShop_BankLedger"
SurvivorShop.MODDATA_BANK_DIRECTORY = "SurvivorShop_BankDirectory"
SurvivorShop.MODDATA_BANK_INVOICES = "SurvivorShop_BankInvoices"

SurvivorShop.MAX_SALES_HISTORY_PER_PLAYER = 50
SurvivorShop.MAX_BANK_LEDGER_PER_PLAYER = 60
SurvivorShop.MAX_BANK_INVOICES_PER_ACCOUNT = 40

function SurvivorShop.getAccountKey(player)
    -- Persistent per-account key (does NOT reset on death). Prefer SteamID when available, fallback to username.
    if player and player.getSteamIDString then
        local sid = player:getSteamIDString()
        if sid and sid ~= "" then return "steam:" .. tostring(sid) end
    end
    if player and player.getSteamID then
        local sid = player:getSteamID()
        if sid and sid ~= 0 then return "steam:" .. tostring(sid) end
    end
    if player and player.getUsername then
        return "user:" .. tostring(player:getUsername())
    end
    return "user:unknown"
end

function SurvivorShop.getAccountName(player)
    if player and player.getUsername then return tostring(player:getUsername()) end
    return "Unknown"
end

local function copySafe(val, depth)
    depth = depth or 0
    if depth > 5 then return nil end
    local tv = type(val)
    if tv == "number" or tv == "string" or tv == "boolean" or val == nil then
        return val
    end
    if tv == "table" then
        local out = {}
        for k, v in pairs(val) do
            local ck = copySafe(k, depth + 1)
            local cv = copySafe(v, depth + 1)
            if ck ~= nil then out[ck] = cv end
        end
        return out
    end
    return nil
end

function SurvivorShop.copyModDataSafe(item)
    if not item or not item.getModData then return nil end
    return copySafe(item:getModData(), 0)
end

-- Auction (Leilao)
SurvivorShop.AUCTION_DURATION_HOURS = 24
SurvivorShop.AUCTION_MIN_INCREMENT = 1
SurvivorShop.AUCTION_BID_FEE_PERCENT = 0

function SurvivorShop.getSandboxInt(key, defaultVal)
    local sv = SandboxVars and SandboxVars.SurvivorShop
    if sv and sv[key] ~= nil then
        local n = tonumber(sv[key])
        if n ~= nil then return math.floor(n) end
    end
    return defaultVal
end

function SurvivorShop.isAdminPlayer(player)
    if not player then return false end
    local ok = false
    pcall(function()
        local al = player.getAccessLevel and player:getAccessLevel() or nil
        if al then
            al = tostring(al):lower()
            if al == "admin" then ok = true end
        end
    end)
    return ok
end
