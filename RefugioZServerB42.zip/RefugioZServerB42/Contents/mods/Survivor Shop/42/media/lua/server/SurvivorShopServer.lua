-- SurvivorShopServer.lua (B42.14.1) - Dedicated, MP-safe global marketplace + bank
require "SurvivorShopShared"

-- Helper function to remove "?" prefix from item names
local function stripUnknownPrefix(s)
    if not s then return "" end
    if type(s) ~= "string" then s = tostring(s) end
    s = s:gsub("^%s*", "")
    s = s:gsub("^%?%s*", "")
    return s
end

-- Sandbox helpers (B42: options defined in media/sandbox-options.txt)
local function _sb()
    return SandboxVars and SandboxVars.SurvivorShop or nil
end
local function sbInt(key, def)
    local s = _sb()
    local v = s and s[key]
    v = tonumber(v)
    if v == nil then return def end
    return math.floor(v)
end
local function getListingFeePercent()
    return sbInt("ListingFeePercent", 0) -- upfront fee % of (price*qty)
end
-- SurvivorShop Logging Utility (B42-ready)
local function ss_log_raw(name, key, action, details)
    if not name or name == "" then return end
    local safeName = name:gsub("[^%w%-%.%s]", "_")
    if safeName == "" then safeName = "Unknown" end
    local fileName = safeName .. ".txt"

    -- Writes to Zomboid/Lua/<modID>/<fileName>
    local writer = getModFileWriter(SurvivorShop.ID, fileName, true, true)
    if writer then
        local timestamp = os.date("%Y-%m-%d %H:%M:%S")
        local curBal = 0
        if getBalances and getBalanceForKey then
            local ok, balObj = pcall(getBalances)
            if ok and balObj then
                local ok2, bal = pcall(getBalanceForKey, balObj, key)
                if ok2 and type(bal) == "number" then curBal = bal end
            end
        end
        local line = string.format("[%s] [%s] %s | Saldo: $%d\n", timestamp, action, details, curBal)
        writer:write(line)
        writer:close()
    end
end

local function ss_log(player, action, details)
    if not player then return end
    ss_log_raw(SurvivorShop.getAccountName(player), SurvivorShop.getAccountKey(player), action, details)
end


local function getCommissionRate()
    local pct = sbInt("CommissionPercent", math.floor((SurvivorShop.COMMISSION_RATE or 0.10) * 100))
    if pct < 0 then pct = 0 end
    if pct > 90 then pct = 90 end
    return pct / 100.0
end

local function getMaxListingsPerPlayer()
    local v = sbInt("MaxListingsPerPlayer", 10)
    if v < 0 then v = 0 end
    if v > 200 then v = 200 end
    return v
end


local function getListingExpireDays()
    local d = sbInt("ListingExpireDays", 7) -- real days
    if d < 1 then d = 1 end
    if d > 365 then d = 365 end
    return d
end

local function getListingExpireSeconds()
    return getListingExpireDays() * 24 * 60 * 60
end

-- ===== Auction sandbox settings =====
local function getAuctionDurationSeconds()
    local hours = sbInt("AuctionDurationHours", SurvivorShop.AUCTION_DURATION_HOURS or 24)
    if hours < 1 then hours = 1 end
    if hours > 24*30 then hours = 24*30 end -- clamp 30d
    return hours * 3600
end

local function getAuctionMinIncrement()
    local inc = sbInt("AuctionMinIncrement", SurvivorShop.AUCTION_MIN_INCREMENT or 1)
    if inc < 1 then inc = 1 end
    if inc > 1000000 then inc = 1000000 end
    return inc
end

local function getAuctionBidFeePercent()
    local pct = sbInt("AuctionBidFeePercent", SurvivorShop.AUCTION_BID_FEE_PERCENT or 0)
    if pct < 0 then pct = 0 end
    if pct > 50 then pct = 50 end
    return pct
end


local function countActiveListingsForKey(internal, key)
    internal = internal or {}
    internal.sellerById = internal.sellerById or {}
    local n = 0
    for _,info in pairs(internal.sellerById) do
        if info and info.key == key and not info.expired then n = n + 1 end
    end
    return n
end


-- MP inventory sync helpers (ServerShop pattern)
local function syncRemove(container, item)
    if not container or not item then return end
    container:Remove(item)
    if sendRemoveItemFromContainer then
        sendRemoveItemFromContainer(container, item)
    end
end
-- Sync helper (B42 MP): depois de criar/modificar item no servidor, empurre campos/stats pros clientes
-- IMPORTANT (B42): algumas assinaturas Java mudaram (ex.: syncItemModData agora pode exigir "player").
local function ss_syncItemAll(item, player)
    if not item then return end

    -- B42: InventoryItem tem syncItemFields(); mantenha fallbacks por patch
    pcall(function()
        if item.syncItemFields then item:syncItemFields()
        elseif syncItemFields then syncItemFields(item) end
    end)

    -- Baseado no decompilado B42: syncItemModData(player, item) é o caminho seguro.
    if player then
        pcall(function()
            if item.syncItemModData and player then
                pcall(item.syncItemModData, item, player)
            elseif syncItemModData and player then
                pcall(syncItemModData, player, item)
            end
        end)
    end

    -- Armas: attachments/ammo/jam/etc
    pcall(function()
        if instanceof and instanceof(item, "HandWeapon") then
            if item.syncHandWeaponFields then item:syncHandWeaponFields()
            elseif syncHandWeaponFields then syncHandWeaponFields(item) end
        end
    end)

    -- Stats (usos/usedDelta/fluido/food etc)
    pcall(function()
        if sendItemStats then sendItemStats(item) end
    end)
end


local function syncAdd(container, item)
    if not container or not item then return end
    if sendAddItemToContainer then
        sendAddItemToContainer(container, item)
    end

    -- Tente descobrir o player "dono" do container (inventário) para chamadas B42 que exigem player.
    local owner = nil
    if container.getParent then
        local okP, parent = pcall(container.getParent, container)
        if okP and parent and instanceof and instanceof(parent, "IsoPlayer") then
            owner = parent
        end
    end

    ss_syncItemAll(item, owner)
end


-- Smart server-side item creation (avoids nil from AddItem(fullType) for some items on dedicated)
-- IMPORTANT (B42 MP): We prefer InventoryItemFactory.CreateItem + AddItem(obj) over AddItem(string)
-- because the string version on some B42 dedicated patches triggers immediate client sync with the
-- default (full/new) item state BEFORE we can call applySerialized. Using the factory, we create
-- the object first, apply all state, then add+sync — ensuring clients receive the correct state.
local function ss_addItemSmart(container, fullType)
    if not container or not fullType then return nil end

    -- 1) Factory path: create object first so applySerialized runs before the item reaches the client
    if InventoryItemFactory and InventoryItemFactory.CreateItem then
        local created = nil
        do
            local ok, it = pcall(InventoryItemFactory.CreateItem, fullType)
            if ok and it then created = it end
        end
        if not created then
            local ok, it = pcall(InventoryItemFactory.CreateItem, InventoryItemFactory, fullType)
            if ok and it then created = it end
        end

        if created and container.AddItem then
            pcall(container.AddItem, container, created)

            -- verify it ended up in this container (best-effort)
            if created.getContainer then
                local okC, c = pcall(created.getContainer, created)
                if okC and c == container then return created end
                return nil
            end

            -- if no getter, assume ok
            return created
        end
    end

    -- 2) Fallback: string path (applySerialized + syncAdd will correct any default-state sync)
    if container.AddItem then
        local ok, it = pcall(container.AddItem, container, fullType)
        if ok and it then return it end
    end

    return nil
end


-- Handle signature changes across B42 patches:
local function isInCharInv(container, player)
    if not container or not container.isInCharacterInventory then return false end
    local ok, res = pcall(container.isInCharacterInventory, container, player)
    if ok then return res == true end
    ok, res = pcall(container.isInCharacterInventory, container) -- older signature
    if ok then return res == true end
    return false
end


local RATE_LIMIT_MS = 250
local lastCmdAt = {}

local function nowMs()
    if getTimestampMs then return getTimestampMs() end
    return os.time() * 1000
end

local function rateLimitOK(player, command)
    local key = (player and player.getOnlineID and tostring(player:getOnlineID()))
        or (player and player.getUsername and player:getUsername()) or "unknown"
    lastCmdAt[key] = lastCmdAt[key] or {}
    local t = lastCmdAt[key][command] or 0
    local n = nowMs()
    if n - t < RATE_LIMIT_MS then return false end
    lastCmdAt[key][command] = n
    return true
end

local function getPublic()   return ModData.getOrCreate(SurvivorShop.MODDATA_PUBLIC) end
local function getInternal() return ModData.getOrCreate(SurvivorShop.MODDATA_INTERNAL) end
local function getBalances() return ModData.getOrCreate(SurvivorShop.MODDATA_BALANCES) end
local function getBankLedger() return ModData.getOrCreate(SurvivorShop.MODDATA_BANK_LEDGER) end
local function getBankDirectory() return ModData.getOrCreate(SurvivorShop.MODDATA_BANK_DIRECTORY) end
local function getBankInvoices() return ModData.getOrCreate(SurvivorShop.MODDATA_BANK_INVOICES) end
-- transmitPublic() removido: cliente não lê MODDATA_PUBLIC via ModData,
-- recebe dados diretamente via sendServerCommand (command "listings").

-- ===== Sales History System (B42.13.2) =====
local function getSalesHistory() 
    return ModData.getOrCreate(SurvivorShop.MODDATA_SALES_HISTORY) 
end

local function normalizeSalesHistoryStore()
    local history = getSalesHistory()
    local wrapped = history.history
    if type(wrapped) == "table" then
        for sellerKey, sellerHistory in pairs(wrapped) do
            if history[sellerKey] == nil then
                history[sellerKey] = sellerHistory
            end
        end
        history.history = nil
    end
    return history
end

local function getSellerHistory(sellerKey)
    local history = normalizeSalesHistoryStore()
    history[sellerKey] = history[sellerKey] or {}
    return history[sellerKey]
end

local function addSaleRecord(sellerKey, saleData)
    local history = getSellerHistory(sellerKey)
    local record = {
        listingId = saleData.listingId,
        itemType = saleData.itemType,
        itemName = saleData.itemName,
        quantity = saleData.quantity,
        unitPrice = saleData.unitPrice,
        totalPayout = saleData.totalPayout,
        buyerName = saleData.buyerName,
        soldAt = saleData.soldAt or os.time(),
    }
    table.insert(history, 1, record)
    while #history > SurvivorShop.MAX_SALES_HISTORY_PER_PLAYER do
        table.remove(history)
    end
    normalizeSalesHistoryStore()[sellerKey] = history

    -- DEBUG
    print("[SurvivorShop] Sale recorded for " .. tostring(sellerKey))
    print("[SurvivorShop]   Item: " .. tostring(saleData.itemName) .. " x" .. tostring(saleData.quantity))
    print("[SurvivorShop]   Buyer: " .. tostring(saleData.buyerName) .. ", Payout: $" .. tostring(saleData.totalPayout))
    print("[SurvivorShop]   Total sales in history: " .. tostring(#history))
end

local function sendSalesHistory(player)
    if not player then return end
    local key = SurvivorShop.getAccountKey(player)
    local history = getSellerHistory(key)
    local clientHistory = {}
    for i = 1, math.min(#history, SurvivorShop.MAX_SALES_HISTORY_PER_PLAYER) do
        local sale = history[i]
        table.insert(clientHistory, {
            listingId = sale.listingId,
            itemType = sale.itemType,
            itemName = sale.itemName,
            quantity = sale.quantity,
            unitPrice = sale.unitPrice,
            totalPayout = sale.totalPayout,
            buyerName = sale.buyerName,
            soldAt = sale.soldAt,
        })
    end

    -- DEBUG
    print("[SurvivorShop] Sending sales history to " .. tostring(SurvivorShop.getAccountName(player)))
    print("[SurvivorShop]   Total records: " .. tostring(#clientHistory))
    for i, sale in ipairs(clientHistory) do
        print("[SurvivorShop]   " .. tostring(i) .. ": " .. tostring(sale.itemName) .. " x" .. tostring(sale.quantity) .. " -> " .. tostring(sale.buyerName))
    end

    sendServerCommand(player, SurvivorShop.MODULE, "salesHistory", { history = clientHistory })
end

local _ss_registerKnownAccount
local _ss_registerPlayerAccount

local function _ss_seedAccountDirectoryFromState()
    local internal = getInternal()
    internal.sellerById = internal.sellerById or {}
    for _, info in pairs(internal.sellerById) do
        if info and info.key and info.name then
            _ss_registerKnownAccount(info.key, info.name)
        end
    end

    local auctions = internal.auctions or {}
    for i = 1, #auctions do
        local a = auctions[i]
        if a and a.sellerKey and a.sellerName then
            _ss_registerKnownAccount(a.sellerKey, a.sellerName)
        end
    end
end

local ACCOUNT_DIRECTORY_SWEEP_MS = 30000
local _lastAccountDirectorySweep = 0

local function _ss_accountDirectorySweep()
    local now = nowMs()
    if (now - _lastAccountDirectorySweep) < ACCOUNT_DIRECTORY_SWEEP_MS then return end
    _lastAccountDirectorySweep = now

    if not getOnlinePlayers then return end
    local ok, players = pcall(getOnlinePlayers)
    if not ok or not players then return end
    for i = 0, players:size() - 1 do
        local onlinePlayer = players:get(i)
        if onlinePlayer then
            _ss_registerPlayerAccount(onlinePlayer)
        end
    end
end

Events.OnTick.Add(_ss_accountDirectorySweep)

-- =========================================================
-- Auctions (Leilão) - server-authoritative
-- Public list contains no player identity.
-- =========================================================
local function getPublicAuctions(pub)
    pub.auctions = pub.auctions or {}
    return pub.auctions
end
local function setPublicAuctions(pub, list)
    pub.auctions = list or {}
end
local function getInternalAuctions(internal)
    internal.auctions = internal.auctions or {}
    internal.nextAuctionId = internal.nextAuctionId or 1
    return internal.auctions
end

local function _ss_rebuildPublicAuctions()
    local internal = getInternal()
    local pub = getPublic()
    local auctions = getInternalAuctions(internal)

    local out = {}
    for i=1,#auctions do
        local a = auctions[i]
        if a and a.id then
            table.insert(out, {
                id = tostring(a.id),
                itemType = tostring(a.itemType or ""),
                quantity = tonumber(a.quantity) or 1,
                minBid = tonumber(a.minBid) or 0,
                currentBid = tonumber(a.currentBid) or 0,
                bids = a.bids or {},
                endAt = tonumber(a.endAt) or 0,
                ended = (a.ended == true) and true or false,
                claimed = (a.claimed == true) and true or false,
            })
        end
    end

    setPublicAuctions(pub, out)
end

local function _ss_getAuctionById(internal, id)
    id = tostring(id or "")
    if id == "" then return nil end
    local auctions = getInternalAuctions(internal)
    for i=1,#auctions do
        local a = auctions[i]
        if a and tostring(a.id) == id then
            return a
        end
    end
    return nil
end

local function _ss_sendAuctionClaims(player)
    if not player then return end
    local internal = getInternal()
    local auctions = getInternalAuctions(internal)
    local key = SurvivorShop.getAccountKey(player)

    local out = {}
    for i=1,#auctions do
        local a = auctions[i]
        if a and a.ended == true and a.claimed ~= true and tostring(a.winnerKey or "") == tostring(key) then
            table.insert(out, { id=tostring(a.id), itemType=tostring(a.itemType or ""), quantity=tonumber(a.quantity) or 1, currentBid=tonumber(a.currentBid) or 0 })
        end
        if a and a.ended == true and a.claimed ~= true and (a.winnerKey == nil or tostring(a.winnerKey) == "") and tostring(a.sellerKey or "") == tostring(key) then
            table.insert(out, { id=tostring(a.id), itemType=tostring(a.itemType or ""), quantity=tonumber(a.quantity) or 1, currentBid=0, unsold=true })
        end
    end

    sendServerCommand(player, SurvivorShop.MODULE, "auctionClaims", { claims = out })
end

local function _ss_isAdmin(player)
    if not player then return false end
    local al = nil
    pcall(function()
        if player.getAccessLevel then al = player:getAccessLevel() end
    end)
    al = tostring(al or ""):lower()
    return al == "admin"
end

local function _ss_findOnlinePlayerByName(name)
    name = tostring(name or "")
    if name == "" then return nil end
    local target = nil
    if getPlayerFromUsername then
        local ok, res = pcall(getPlayerFromUsername, name)
        if ok and res then return res end
    end
    if getOnlinePlayers then
        local ok, list = pcall(getOnlinePlayers)
        if ok and list then
            local nameLower = string.lower(name)
            for i=0, list:size()-1 do
                local p = list:get(i)
                if p and p.getUsername then
                    local uname = tostring(p:getUsername())
                    if string.lower(uname) == nameLower then
                        target = p
                        break
                    end
                end
            end
        end
    end
    return target
end

local function _ss_findOnlinePlayerByKey(key)
    key = tostring(key or "")
    if key == "" or not getOnlinePlayers then return nil end

    local ok, list = pcall(getOnlinePlayers)
    if not ok or not list then return nil end

    for i=0, list:size()-1 do
        local p = list:get(i)
        if p and tostring(SurvivorShop.getAccountKey(p) or "") == key then
            return p
        end
    end
    return nil
end



local function getBalanceForKey(bal, key)
    bal.balances = bal.balances or {}
    return tonumber(bal.balances[key]) or 0
end

local function setBalanceForKey(bal, key, amount)
    bal.balances = bal.balances or {}
    bal.balances[key] = math.floor(tonumber(amount) or 0)
end

local function getSavingsForKey(bal, key)
    bal.savings = bal.savings or {}
    return tonumber(bal.savings[key]) or 0
end

local function setSavingsForKey(bal, key, amount)
    bal.savings = bal.savings or {}
    bal.savings[key] = math.floor(tonumber(amount) or 0)
end

local function _ss_trimmedName(name)
    name = tostring(name or "")
    name = name:gsub("^%s+", ""):gsub("%s+$", "")
    return name
end

local function _ss_normalizeAccountDirectory()
    local dir = getBankDirectory()
    dir.names = dir.names or {}
    dir.displayNames = dir.displayNames or {}
    return dir
end

_ss_registerKnownAccount = function(key, name)
    key = tostring(key or "")
    name = _ss_trimmedName(name)
    if key == "" or name == "" then return end

    local dir = _ss_normalizeAccountDirectory()
    dir.names[string.lower(name)] = key
    dir.displayNames[key] = name
end

_ss_registerPlayerAccount = function(player)
    if not player then return end
    _ss_registerKnownAccount(SurvivorShop.getAccountKey(player), SurvivorShop.getAccountName(player))
end

local function _ss_getKnownNameForKey(key, fallback)
    key = tostring(key or "")
    if key == "" then return tostring(fallback or "") end

    local online = _ss_findOnlinePlayerByKey(key)
    if online then
        local onlineName = SurvivorShop.getAccountName(online)
        _ss_registerKnownAccount(key, onlineName)
        return onlineName
    end

    local dir = _ss_normalizeAccountDirectory()
    local known = dir.displayNames[key]
    if known and tostring(known) ~= "" then
        return tostring(known)
    end
    return tostring(fallback or "")
end

local function _ss_resolveAccountByName(name)
    name = _ss_trimmedName(name)
    if name == "" then return nil end

    local online = _ss_findOnlinePlayerByName(name)
    if online then
        local key = SurvivorShop.getAccountKey(online)
        local displayName = SurvivorShop.getAccountName(online)
        _ss_registerKnownAccount(key, displayName)
        return {
            key = key,
            name = displayName,
            player = online,
        }
    end

    local dir = _ss_normalizeAccountDirectory()
    local key = dir.names[string.lower(name)]
    if not key or tostring(key) == "" then
        return nil
    end

    return {
        key = tostring(key),
        name = _ss_getKnownNameForKey(tostring(key), name),
        player = nil,
    }
end

local function _ss_normalizeLedgerStore()
    local store = getBankLedger()
    store.nextId = tonumber(store.nextId) or 1
    store.entries = store.entries or {}
    return store
end

local function _ss_getLedgerEntriesForKey(key)
    local store = _ss_normalizeLedgerStore()
    store.entries[key] = store.entries[key] or {}
    return store.entries[key]
end

local function _ss_addLedgerEntryForKey(key, data)
    key = tostring(key or "")
    if key == "" then return nil end

    local bal = getBalances()
    local store = _ss_normalizeLedgerStore()
    local list = _ss_getLedgerEntriesForKey(key)
    local entry = {
        id = tostring(store.nextId),
        kind = tostring((data and data.kind) or "entry"),
        amount = math.max(0, math.floor(tonumber((data and data.amount) or 0) or 0)),
        otherName = tostring((data and data.otherName) or ""),
        note = tostring((data and data.note) or ""),
        itemName = tostring((data and data.itemName) or ""),
        quantity = math.max(0, math.floor(tonumber((data and data.quantity) or 0) or 0)),
        status = tostring((data and data.status) or ""),
        createdAt = tonumber((data and data.createdAt) or os.time()) or os.time(),
        balanceAfter = getBalanceForKey(bal, key),
        savingsAfter = getSavingsForKey(bal, key),
    }

    store.nextId = store.nextId + 1
    table.insert(list, 1, entry)
    while #list > (SurvivorShop.MAX_BANK_LEDGER_PER_PLAYER or 60) do
        table.remove(list)
    end
    store.entries[key] = list
    return entry
end

local function _ss_sendLedger(player)
    if not player then return end
    local key = SurvivorShop.getAccountKey(player)
    local entries = _ss_getLedgerEntriesForKey(key)
    local out = {}
    local maxEntries = SurvivorShop.MAX_BANK_LEDGER_PER_PLAYER or 60
    for i = 1, math.min(#entries, maxEntries) do
        local entry = entries[i]
        out[i] = {
            id = tostring(entry.id or ""),
            kind = tostring(entry.kind or "entry"),
            amount = math.max(0, math.floor(tonumber(entry.amount) or 0)),
            otherName = tostring(entry.otherName or ""),
            note = tostring(entry.note or ""),
            itemName = tostring(entry.itemName or ""),
            quantity = math.max(0, math.floor(tonumber(entry.quantity) or 0)),
            status = tostring(entry.status or ""),
            createdAt = tonumber(entry.createdAt) or 0,
            balanceAfter = math.max(0, math.floor(tonumber(entry.balanceAfter) or 0)),
            savingsAfter = math.max(0, math.floor(tonumber(entry.savingsAfter) or 0)),
        }
    end
    sendServerCommand(player, SurvivorShop.MODULE, "bankLedger", { entries = out })
end

local function _ss_normalizeInvoiceStore()
    local store = getBankInvoices()
    store.nextId = tonumber(store.nextId) or 1
    store.byRecipient = store.byRecipient or {}
    return store
end

local function _ss_getInvoicesForRecipient(key)
    local store = _ss_normalizeInvoiceStore()
    store.byRecipient[key] = store.byRecipient[key] or {}
    return store.byRecipient[key]
end

local function _ss_trimInvoicesForRecipient(key)
    local list = _ss_getInvoicesForRecipient(key)
    while #list > (SurvivorShop.MAX_BANK_INVOICES_PER_ACCOUNT or 40) do
        table.remove(list)
    end
end

local function _ss_cloneInvoiceForClient(invoice, key)
    return {
        id = tostring(invoice.id or ""),
        direction = (tostring(invoice.toKey or "") == tostring(key)) and "incoming" or "outgoing",
        status = tostring(invoice.status or "pending"),
        fromName = tostring(invoice.fromName or ""),
        toName = tostring(invoice.toName or ""),
        amount = math.max(0, math.floor(tonumber(invoice.amount) or 0)),
        note = tostring(invoice.note or ""),
        createdAt = tonumber(invoice.createdAt) or 0,
        resolvedAt = tonumber(invoice.resolvedAt) or 0,
    }
end

local function _ss_collectInvoicesForKey(key)
    local store = _ss_normalizeInvoiceStore()
    local out = {}
    for _, list in pairs(store.byRecipient) do
        for i = 1, #list do
            local invoice = list[i]
            if invoice and (tostring(invoice.toKey or "") == tostring(key) or tostring(invoice.fromKey or "") == tostring(key)) then
                table.insert(out, _ss_cloneInvoiceForClient(invoice, key))
            end
        end
    end
    table.sort(out, function(a, b)
        local ta = tonumber(a.createdAt) or 0
        local tb = tonumber(b.createdAt) or 0
        if ta == tb then
            return tostring(a.id or "") > tostring(b.id or "")
        end
        return ta > tb
    end)
    while #out > (SurvivorShop.MAX_BANK_INVOICES_PER_ACCOUNT or 40) do
        table.remove(out)
    end
    return out
end

local function _ss_findInvoiceById(id)
    id = tostring(id or "")
    if id == "" then return nil end

    local store = _ss_normalizeInvoiceStore()
    for recipientKey, list in pairs(store.byRecipient) do
        for i = 1, #list do
            local invoice = list[i]
            if invoice and tostring(invoice.id or "") == id then
                return invoice, list, i, recipientKey
            end
        end
    end
    return nil
end

local function _ss_sendInvoices(player)
    if not player then return end
    local key = SurvivorShop.getAccountKey(player)
    sendServerCommand(player, SurvivorShop.MODULE, "bankInvoices", {
        invoices = _ss_collectInvoicesForKey(key),
    })
end

local function sendBalance(player, balance)
    if not player then return end
    local key = SurvivorShop.getAccountKey(player)
    local bal = getBalances()
    local available = tonumber(balance)
    if available == nil then
        available = getBalanceForKey(bal, key)
    end
    local savings = getSavingsForKey(bal, key)
    sendServerCommand(player, SurvivorShop.MODULE, "balance", {
        balance = math.max(0, math.floor(available or 0)),
        savings = math.max(0, math.floor(savings or 0)),
        total = math.max(0, math.floor((available or 0) + (savings or 0))),
    })
end

local function _ss_sendOnlinePlayers(player)
    if not player then return end
    local out = {}
    if getOnlinePlayers then
        local ps = getOnlinePlayers()
        for i = 0, ps:size() - 1 do
            local p = ps:get(i)
            if p and p.getUsername then
                local name = tostring(p:getUsername())
                if name ~= "" then
                    _ss_registerPlayerAccount(p)
                    table.insert(out, { name = name })
                end
            end
        end
    end
    sendServerCommand(player, SurvivorShop.MODULE, "onlinePlayers", { players = out })
end

local function _ss_sendBankSnapshot(player, includePlayers)
    if not player then return end
    _ss_registerPlayerAccount(player)
    sendBalance(player)
    _ss_sendLedger(player)
    _ss_sendInvoices(player)
    if includePlayers then
        _ss_sendOnlinePlayers(player)
    end
end

local function _ss_pushBalanceAndAuctionClaims(key)
    local target = _ss_findOnlinePlayerByKey(key)
    if not target then return nil end
    sendBalance(target)
    _ss_sendLedger(target)
    _ss_sendAuctionClaims(target)
    return target
end

local function _ss_payload(key, params, fallback)
    local t = {}
    if key then t.key = key end
    if params then t.p = params end

    -- Provide a server-locale fallback message for older clients (they only read args.message).
    if (not fallback) and key and getText then
        local ok, v
        if params and type(params) == "table" then
            ok, v = pcall(getText, key, unpack(params))
        else
            ok, v = pcall(getText, key)
        end
        if ok and v and v ~= key then
            fallback = v
        end
    end

    if fallback then t.message = fallback end
    return t
end

-- ===== Network messages: send translation key + params (client translates per locale) =====
local function sendErrorK(player, key, params, fallback)
    if not player then return end
    sendServerCommand(player, SurvivorShop.MODULE, "error", _ss_payload(key, params, fallback))
end

local function sendToastK(player, key, params, extra, fallback)
    if not player then return end
    local payload = _ss_payload(key, params, fallback)
    if extra then
        for k,v in pairs(extra) do payload[k] = v end
    end
    sendServerCommand(player, SurvivorShop.MODULE, "toast", payload)
end

-- Backward compatible helpers (avoid hard errors if any call site was missed)
local function sendError(player, msg)
    sendErrorK(player, nil, nil, tostring(msg))
end
local function sendToast(player, msg, extra)
    sendToastK(player, nil, nil, extra, tostring(msg))
end

-- Inventory helpers
local function countInContainerRecursive(container, fullType)
    if not container then return 0 end
    local items = container:getItems()
    local count = 0
    for i=0, items:size()-1 do
        local it = items:get(i)
        if it and it.getFullType and it:getFullType() == fullType then
            count = count + 1
        end
        if it and it.getInventory and it:getInventory() then
            count = count + countInContainerRecursive(it:getInventory(), fullType)
        end
    end
    return count
end

local function countInContainerRecursiveCharacterInventory(container, fullType, player)
    if not container then return 0 end
    local items = container:getItems()
    local count = 0
    for i=0, items:size()-1 do
        local it = items:get(i)
        if it and it.getFullType and it:getFullType() == fullType then
            local parent = it.getContainer and it:getContainer() or nil
            if parent and isInCharInv(parent, player) then
                count = count + 1
            end
        end
        if it and it.getInventory and it:getInventory() then
            count = count + countInContainerRecursiveCharacterInventory(it:getInventory(), fullType, player)
        end
    end
    return count
end



-- Prevent listing equipped/worn/attached items (server authoritative)
local function isEquippedByPlayer(player, item)
    if not player or not item then return false end
    if player.getPrimaryHandItem and player:getPrimaryHandItem() == item then return true end
    if player.getSecondaryHandItem and player:getSecondaryHandItem() == item then return true end

    if item.isEquipped then
        local ok, v = pcall(function() return item:isEquipped() end)
        if ok and v then return true end
    end

    local worn = player.getWornItems and player:getWornItems() or nil
    if worn and worn.size then
        local okSz, sz = pcall(function() return worn:size() end)
        if okSz and sz then
            for i=0, sz-1 do
                local wi = nil
                if worn.get then
                    local okW, w = pcall(function() return worn:get(i) end)
                    if okW then wi = w end
                elseif worn.getItemByIndex then
                    local okW, w = pcall(function() return worn:getItemByIndex(i) end)
                    if okW then wi = w end
                end
                if wi then
                    local it2 = nil
                    if wi.getItem then
                        local okI, witem = pcall(function() return wi:getItem() end)
                        if okI then it2 = witem end
                    elseif wi.getInventoryItem then
                        local okI, witem = pcall(function() return wi:getInventoryItem() end)
                        if okI then it2 = witem end
                    elseif wi.item then
                        it2 = wi.item
                    end
                    if it2 == item then return true end
                end
            end
        end
    end

    local attached = player.getAttachedItems and player:getAttachedItems() or nil
    if attached and attached.size then
        local okSz, sz = pcall(function() return attached:size() end)
        if okSz and sz then
            for i=0, sz-1 do
                local ai = nil
                if attached.get then
                    local okA, a = pcall(function() return attached:get(i) end)
                    if okA then ai = a end
                elseif attached.getItemByIndex then
                    local okA, a = pcall(function() return attached:getItemByIndex(i) end)
                    if okA then ai = a end
                end
                if ai then
                    local it2 = nil
                    if ai.getItem then
                        local okI, aitem = pcall(function() return ai:getItem() end)
                        if okI then it2 = aitem end
                    elseif ai.getInventoryItem then
                        local okI, aitem = pcall(function() return ai:getInventoryItem() end)
                        if okI then it2 = aitem end
                    elseif ai.item then
                        it2 = ai.item
                    end
                    if it2 == item then return true end
                end
            end
        end
    end

    -- Check for B42 applied medical items (virtual items representing limb dressings)
    if item.getFullType then
        local ft = item:getFullType()
        if ft:find("Bandage_") or ft:find("AlcoholBandage_") or ft:find("DenimStripBandage_") or ft:find("LeatherStripBandage_") or ft:find("Splint_") then
            return true
        end
    end

    return false
end


-- Ban specific item types from being sold (Keyring carries players' keys)
local function isBannedSellType(fullType)
    if not fullType then return false end
    local ft = string.lower(tostring(fullType))
    return ft == "base.keyring"
end



local function countInContainerRecursiveUnequipped(container, fullType, player)
    if not container then return 0 end
    local items = container:getItems()
    local count = 0
    for i=0, items:size()-1 do
        local it = items:get(i)
        if it and it.getFullType and it:getFullType() == fullType then
            if not isEquippedByPlayer(player, it) then
                count = count + 1
            end
        end
        if it and it.getInventory and it:getInventory() then
            count = count + countInContainerRecursiveUnequipped(it:getInventory(), fullType, player)
        end
    end
    return count
end

local function takeItemsRecursiveUnequipped(container, fullType, amount, outList, player)
    if not container or amount <= 0 then return amount end
    local items = container:getItems()
    for i=items:size()-1,0,-1 do
        if amount <= 0 then break end
        local it = items:get(i)
        if it and it.getFullType and it:getFullType() == fullType then
            if not isEquippedByPlayer(player, it) then
                local parent = it.getContainer and it:getContainer() or nil
                if parent and isInCharInv(parent, player) then
                    syncRemove(parent, it) -- IMPORTANT: sync to client
                    table.insert(outList, it)
                    amount = amount - 1
                end
            end
        end
        if it and it.getInventory and it:getInventory() then
            amount = takeItemsRecursiveUnequipped(it:getInventory(), fullType, amount, outList, player)
        end
    end
    return amount
end

local function takeItemsRecursive(container, fullType, amount, outList, player)
    if not container or amount <= 0 then return amount end
    local items = container:getItems()
    for i=items:size()-1,0,-1 do
        if amount <= 0 then break end
        local it = items:get(i)
        if it and it.getFullType and it:getFullType() == fullType then
            local parent = it.getContainer and it:getContainer() or nil
            if parent and isInCharInv(parent, player) then
                syncRemove(parent, it) -- IMPORTANT: sync to client
                table.insert(outList, it)
                amount = amount - 1
            end
        end
        if it and it.getInventory and it:getInventory() then
            amount = takeItemsRecursive(it:getInventory(), fullType, amount, outList, player)
        end
    end
    return amount
end

local function addMoneyToPlayer(player, amount)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then return end
    local inv = player:getInventory()

    -- Add currency items on server and sync to client.
    for i=1,amount do
        local it = inv:AddItem(SurvivorShop.CURRENCY)
        if it then
            syncAdd(inv, it)
        else
            local sq = player:getSquare()
            if sq then sq:AddWorldInventoryItem(SurvivorShop.CURRENCY, 0,0,0) end
        end
    end
end

-- Numeric helpers (B42 Java bridge can be strict about expected types)
local function ss_toFloat(v, default)
    local n = tonumber(v)
    if n == nil then return default end
    return n
end

local function ss_toInt(v, default)
    local n = tonumber(v)
    if n == nil then return default end
    return math.floor(n)
end

local function _ss_hasMeaningfulUsesSnapshot(data)
    local maxUses = tonumber(data and data.maxUses)
    if maxUses and maxUses > 1 then return true end
    return false
end

-- Serialize item state (best-effort, including Food, Drainable, DrainableCombo, etc.)
-- B42 NOTE: DrainableComboItem (Base.Lighter, Base.WeldingRod, etc.) may return false for
-- isDrainable() but still use getCurrentUses/getMaxUses/getUsedDelta/getUseDelta.
-- We always capture ALL use-related fields unconditionally, regardless of isDrainable().
local function serializeItem(it)
    if not it then return nil end
    local data = {
        itemType   = (it.getFullType   and it:getFullType())   or nil,
        condition  = (it.getCondition  and it:getCondition())  or nil,
        conditionMax = (it.getConditionMax and it:getConditionMax()) or nil,
        modData    = SurvivorShop.copyModDataSafe(it),
    }

    -- UnitId (per-unit snapshot id, helps guarantee delivery matches the advertised unit)
    data.unitId = tostring(((it.getID and it:getID()) or "")) .. "-" .. tostring(os.time()) .. "-" .. tostring(ZombRand(1000000))

    -- ---------------------------------------------------------------
    -- Drainable / DrainableCombo detection (B42-safe)
    -- isDrainable() returns false for DrainableComboItem in some B42
    -- patches, so we detect by the presence of getCurrentUses instead.
    -- ---------------------------------------------------------------
    local currentUses = nil
    local maxUses = nil
    local useDelta = nil
    local usedDelta = nil

    if it.getCurrentUses then
        local ok, v = pcall(it.getCurrentUses, it)
        if ok then currentUses = ss_toInt(v, nil) end
    end

    if it.getMaxUses then
        local ok, v = pcall(it.getMaxUses, it)
        if ok then maxUses = ss_toInt(v, nil) end
    end

    if it.getUseDelta then
        local ok, v = pcall(it.getUseDelta, it)
        if ok then useDelta = ss_toFloat(v, nil) end
    end

    if it.getUsedDelta then
        local ok, v = pcall(it.getUsedDelta, it)
        if ok then usedDelta = ss_toFloat(v, nil) end
    end

    if maxUses ~= nil and maxUses > 1 then
        data.isDrainable = true
        data.currentUses = currentUses
        data.maxUses = maxUses
        data.useDelta = useDelta
        data.drainableUses = usedDelta

        -- usedDelta: fraction of consumption (0.0 = full, 1.0 = empty)
        -- Log what we captured (helps trace bugs)
        print(string.format("[SurvivorShop] serialize drainable %s: currentUses=%s maxUses=%s usedDelta=%s useDelta=%s",
            tostring(data.itemType),
            tostring(data.currentUses),
            tostring(data.maxUses),
            tostring(data.drainableUses),
            tostring(data.useDelta)
        ))
    end

    -- FluidContainer (B42): capture current fluid amount/type (empty stays empty)
    if it.getFluidContainer and type(it.getFluidContainer) == "function" then
        local okFC, fc = pcall(it.getFluidContainer, it)
        if okFC and fc then
            data.hasFluid = true
            local amt = nil
            if fc.getAmount then
                local okA, a = pcall(fc.getAmount, fc)
                if okA then amt = a end
            end
            if amt == nil and fc.getAmountLitres then
                local okA, a = pcall(fc.getAmountLitres, fc)
                if okA then amt = a end
            end
            data.fluidAmount = amt or 0

            -- Capacidade máxima (para calcular % no painel)
            local maxAmt = nil
            if fc.getCapacity then
                local okC, c = pcall(fc.getCapacity, fc)
                if okC and c ~= nil then maxAmt = c end
            end
            if maxAmt == nil and fc.getMaxAmount then
                local okC, c = pcall(fc.getMaxAmount, fc)
                if okC and c ~= nil then maxAmt = c end
            end
            data.fluidMaxAmount = maxAmt or 0

            local fluidName = nil
            if fc.getPrimaryFluid then
                local okP, pf = pcall(fc.getPrimaryFluid, fc)
                if okP and pf then
                    if type(pf) == "string" then
                        fluidName = pf
                    elseif pf.getName then
                        local okN, n = pcall(pf.getName, pf)
                        if okN then fluidName = n end
                    end
                    fluidName = fluidName or tostring(pf)
                end
            end
            data.primaryFluid = fluidName
        end
    end

    -- Media (VHS/CD/Recorded Media)
    if it.getMediaIndex and type(it.getMediaIndex) == "function" then
        data.mediaIndex = ss_toInt(it:getMediaIndex(), nil)
    end
    if it.getRecordedMediaIndex and type(it.getRecordedMediaIndex) == "function" then
        data.recordedMediaIndex = ss_toInt(it:getRecordedMediaIndex(), nil)
    end
    if it.getMediaType and type(it.getMediaType) == "function" then
        data.mediaType = it:getMediaType()
    end

    -- Clothing Color only (Blood/Dirt omitidos: getBlood()/getDirt() em B42
    -- exigem BodyPartType como argumento e jogam exceção Java irrecuperável no Kahlua)

    if it.getColor then
        local ok, c = pcall(it.getColor, it)
        if ok and c then
            if type(c.getR) == "function" then
                data.color = { r=c:getR(), g=c:getG(), b=c:getB(), a=(type(c.getA)=="function" and c:getA() or 1) }
            elseif type(c.r) == "number" then
                data.color = { r=c.r, g=c.g, b=c.b, a=(c.a or 1) }
            end
        end
    end

    -- Food detection (B42)
    if it.isFood and type(it.isFood) == "function" and it:isFood() then
        data.isFood = true
        if it.getAge          then data.age          = it:getAge()          end
        if it.getLastAged     then data.lastAged     = it:getLastAged()     end
        if it.isCooked        then data.cooked       = it:isCooked()        end
        if it.isBurnt         then data.burnt        = it:isBurnt()         end
        if it.getHeat         then data.heat         = it:getHeat()         end
        if it.getFreezingTime then data.freezingTime = it:getFreezingTime() end
        if it.getPoisonPower  then data.poisonPower  = it:getPoisonPower()  end
        if it.getHungChange   then data.hungChange   = it:getHungChange()   end
        if it.getBaseHunger   then data.baseHunger   = it:getBaseHunger()   end

        -- Peso atual (indica quanto do alimento resta quando parcialmente consumido)
        if it.getWeight then
            local ok, w = pcall(it.getWeight, it)
            if ok and w ~= nil then data.weight = w end
        end

        -- Peso base (do script do item — valor original sem consumo)
        local scriptItem = nil
        if it.getFullType then
            local ok, ft = pcall(it.getFullType, it)
            if ok and ft then
                local ok2, si = pcall(function() return getScriptManager():FindItem(ft) end)
                if ok2 and si then scriptItem = si end
            end
        end
        if scriptItem then
            if scriptItem.getWeight then
                local ok, bw = pcall(scriptItem.getWeight, scriptItem)
                if ok and bw ~= nil then data.baseWeight = bw end
            end
            -- Dias frescos e dias podre (do script)
            if scriptItem.getDaysFresh then
                local ok, df = pcall(scriptItem.getDaysFresh, scriptItem)
                if ok and df ~= nil then data.daysTotal = df end
            end
            if scriptItem.getDaysTotallyRotten then
                local ok, dr = pcall(scriptItem.getDaysTotallyRotten, scriptItem)
                if ok and dr ~= nil then data.daysBad = dr end
            end
        end

        -- Tristeza e tédio (unhappyChange, boredomChange)
        if it.getUnhappyChange then
            local ok, v = pcall(it.getUnhappyChange, it)
            if ok and v ~= nil then data.unhappyChange = v end
        end
        if it.getBoredomChange then
            local ok, v = pcall(it.getBoredomChange, it)
            if ok and v ~= nil then data.boredomChange = v end
        end
    end

    return data
end

local function applySerialized(item, data)
    if not item or not data then return end

    -- Apply condition
    if data.condition ~= nil and item.setCondition and item.getConditionMax then
        local c = ss_toInt(data.condition, nil)
        if c ~= nil then
            local maxC = item:getConditionMax()
            c = math.max(0, math.min(maxC, c))
            pcall(item.setCondition, item, c)
        end
    end

    -- Apply modData
    if data.modData and item.getModData then
        local md = item:getModData()
        for k,v in pairs(data.modData) do md[k] = v end
    end

    -- Preserve UnitId for audit/debug
    if data.unitId and item.getModData then
        item:getModData().SurvivorShop_UnitId = data.unitId
    end

    -- Media (B42)
    if data.mediaIndex ~= nil and item.setMediaIndex then
        local mi = ss_toInt(data.mediaIndex, nil)
        if mi ~= nil then pcall(item.setMediaIndex, item, mi) end
    end
    if data.mediaType ~= nil and item.setMediaType then
        pcall(item.setMediaType, item, data.mediaType)
    end
    if data.recordedMediaIndex ~= nil then
        local rmi = ss_toInt(data.recordedMediaIndex, nil) or 0
        if item.setRecordedMediaIndexInteger then
            pcall(item.setRecordedMediaIndexInteger, item, rmi)
        elseif item.setRecordedMediaIndex then
            pcall(item.setRecordedMediaIndex, item, rmi)
        end
    end

    -- FluidContainer (B42)
    if data.hasFluid and item.getFluidContainer and type(item.getFluidContainer) == "function" then
        local okFC, fc = pcall(item.getFluidContainer, item)
        if okFC and fc then
            local function _fcGetAmt(_fc)
                if _fc.getAmount then
                    local okA, a = pcall(_fc.getAmount, _fc)
                    if okA and a ~= nil then return a end
                end
                if _fc.getAmountLitres then
                    local okA, a = pcall(_fc.getAmountLitres, _fc)
                    if okA and a ~= nil then return a end
                end
                return nil
            end
            local cur = _fcGetAmt(fc) or 0
            if cur > 0 then
                if fc.removeFluid then pcall(fc.removeFluid, fc, cur)
                elseif fc.setAmount then pcall(fc.setAmount, fc, 0) end
            end
            local amt = tonumber(data.fluidAmount) or 0
            if amt > 0 and fc.addFluid then
                local f = data.primaryFluid
                local okAdd = pcall(fc.addFluid, fc, f, amt)
                if not okAdd and Fluid and type(f) == "string" then
                    local key2 = f:gsub("^Fluid%.", "")
                    local obj = Fluid[key2]
                    if obj then pcall(fc.addFluid, fc, obj, amt) end
                end
            end
        end
    end

    -- ---------------------------------------------------------------
    -- Drainable / DrainableCombo restore (B42-safe)
    -- Apply in this exact order:
    --   1. setUseDelta  (per-use step size)
    --   2. setCurrentUses (integer count — may internally recalc usedDelta)
    --   3. setUsedDelta LAST (fractional override wins, ensures exact state)
    -- ---------------------------------------------------------------
    if data.isDrainable then
        -- 1. Per-use step
        if data.useDelta ~= nil and item.setUseDelta then
            local ud = ss_toFloat(data.useDelta, nil)
            if ud ~= nil then pcall(item.setUseDelta, item, ud) end
        end
        -- 2. Integer use count
        if data.currentUses ~= nil and item.setCurrentUses then
            local cu = ss_toInt(data.currentUses, nil)
            if cu ~= nil then pcall(item.setCurrentUses, item, cu) end
        end
        -- 3. Fractional delta LAST — overrides whatever setCurrentUses computed
        if data.drainableUses ~= nil and item.setUsedDelta then
            local du = ss_toFloat(data.drainableUses, nil)
            if du ~= nil then pcall(item.setUsedDelta, item, du) end
        end

        print(string.format("[SurvivorShop] restore drainable %s: currentUses=%s usedDelta=%s",
            tostring(data.itemType),
            tostring(data.currentUses),
            tostring(data.drainableUses)
        ))
    end

    -- Clothing
    if data.color and item.setColor then
        local r,g,b,a = data.color.r or 1, data.color.g or 1, data.color.b or 1, data.color.a or 1
        local ok, c = pcall(function() return Color.new(r, g, b, a) end)
        if not ok then ok, c = pcall(function() return ImmutableColor.new(r, g, b, a) end) end
        if ok and c then pcall(item.setColor, item, c) end
    end
    -- (Blood/Dirt não são restaurados: getBlood/getDirt B42 requerem BodyPartType)

    -- Food
    if data.isFood then
        if data.age          ~= nil and item.setAge          then item:setAge(data.age)                   end
        if data.lastAged     ~= nil and item.setLastAged     then item:setLastAged(data.lastAged)         end
        if data.cooked       ~= nil and item.setCooked       then item:setCooked(data.cooked)             end
        if data.burnt        ~= nil and item.setBurnt        then item:setBurnt(data.burnt)               end
        if data.heat         ~= nil and item.setHeat         then item:setHeat(data.heat)                 end
        if data.freezingTime ~= nil and item.setFreezingTime then item:setFreezingTime(data.freezingTime) end
        if data.poisonPower  ~= nil and item.setPoisonPower  then item:setPoisonPower(data.poisonPower)   end
        if data.hungChange   ~= nil and item.setHungChange   then item:setHungChange(data.hungChange)     end
    end
end

local function restoreSerializedItem(container, fullType, data)
    local it = ss_addItemSmart(container, fullType)
    if not it then return nil, "AddItem nil" end

    local ok, err = pcall(applySerialized, it, data)
    if not ok then
        print("[SurvivorShop] Warning: applySerialized failed for " .. tostring(fullType) .. ": " .. tostring(err))
    end

    syncAdd(container, it)
    return it
end


-- Helper: Generate item stats summary for listings
-- Retorna tabela com todos os campos necessários para o painel de detalhes da UI.
local function getItemStatsSummary(data)
    if not data then return nil end
    local stats = {}
    local isNew = true

    -- ── Condição ──────────────────────────────────────────────────────────────
    if data.condition ~= nil and data.conditionMax ~= nil and data.conditionMax > 0 then
        local condPct = (data.condition / data.conditionMax) * 100
        stats.conditionPercent = math.floor(condPct)
        if condPct < 99 then isNew = false end
    end

    -- ── Usos drainable / DrainableCombo (isqueiro, vareta, etc.) ─────────────
    if data.isDrainable then
        local usesPct = nil
        if data.drainableUses ~= nil then
            -- drainableUses = usedDelta: 0.0 = cheio, 1.0 = vazio
            usesPct = (1.0 - data.drainableUses) * 100
        elseif data.currentUses ~= nil and data.maxUses ~= nil and data.maxUses > 0 then
            usesPct = (data.currentUses / data.maxUses) * 100
        end
        if usesPct ~= nil then
            stats.usesPercent = math.floor(math.max(0, math.min(100, usesPct)))
            if usesPct < 99 then isNew = false end
        end
    end

    -- ── Líquido (FluidContainer: garrafa, botijão de gás, etc.) ──────────────
    -- fluidAmount em litros, capturado na serialização.
    -- Para calcular %, precisamos do máximo da capacidade.
    -- Usamos fluidAmount diretamente; o label mostra o valor absoluto (L) e %
    -- se soubermos o max, caso contrário só mostra o valor.
    if data.hasFluid then
        local amt = tonumber(data.fluidAmount) or 0
        -- fluidMaxAmount é capturado na serialização (adicionamos abaixo)
        local maxAmt = tonumber(data.fluidMaxAmount) or 0
        if maxAmt > 0 then
            local fluidPct = (amt / maxAmt) * 100
            stats.fluidPercent = math.floor(math.max(0, math.min(100, fluidPct)))
            stats.fluidAmount  = amt
            stats.fluidMax     = maxAmt
            stats.fluidLabel   = data.primaryFluid or "?"
            if fluidPct < 99 then isNew = false end
        elseif amt > 0 then
            -- Temos quantidade mas não máximo; exibe valor absoluto
            stats.fluidPercent = nil
            stats.fluidAmount  = amt
            stats.fluidMax     = nil
            stats.fluidLabel   = data.primaryFluid or "?"
        else
            -- Vazio
            stats.fluidPercent = 0
            stats.fluidAmount  = 0
            stats.fluidMax     = maxAmt > 0 and maxAmt or nil
            stats.fluidLabel   = data.primaryFluid or "?"
            isNew = false
        end
    end

    -- ── Comida (informações completas) ────────────────────────────────────────
    if data.isFood then
        -- Peso atual vs. base (quanto resta do alimento)
        if data.weight ~= nil then stats.weight = data.weight end
        if data.baseWeight ~= nil then stats.baseWeight = data.baseWeight end
        if data.weight ~= nil and data.baseWeight ~= nil and data.baseWeight > 0 then
            local weightPct = (data.weight / data.baseWeight) * 100
            stats.foodWeightPercent = math.floor(math.max(0, math.min(100, weightPct)))
            if weightPct < 99 then isNew = false end
        end

        -- Fome: hungChange é float (ex: -0.2 = -20 de fome na UI do jogo)
        -- Multiplicar por 100 e arredondar para mostrar o valor inteiro da UI
        if data.hungChange ~= nil then
            stats.hunger = math.floor((tonumber(data.hungChange) or 0) * 100 + 0.5)
        end

        -- Tristeza (unhappyChange): já é inteiro na escala do jogo (ex: 10 = +10 tristeza)
        -- NÃO multiplicar por 100
        if data.unhappyChange ~= nil then
            stats.unhappy = math.floor(tonumber(data.unhappyChange) or 0)
        end

        -- Tédio (boredomChange): mesmo padrão — já é inteiro na escala do jogo
        if data.boredomChange ~= nil then
            stats.boredom = math.floor(tonumber(data.boredomChange) or 0)
        end

        -- Dias frescos / dias podre (a partir do script do item, não da instância)
        if data.daysTotal ~= nil then stats.daysTotal = data.daysTotal end
        if data.daysBad   ~= nil then stats.daysBad   = data.daysBad   end

        -- Estado do item: congelado/cozido/podre
        if data.cooked  then stats.cooked  = data.cooked  end
        if data.burnt   then stats.burnt   = data.burnt   end

        -- Marcar como USADO se parcialmente consumido (peso menor que base)
        if stats.foodWeightPercent and stats.foodWeightPercent < 99 then
            isNew = false
        end
    end

    stats.isNew = isNew
    stats.tag   = isNew and "NOVO" or "USADO"
    return stats
end

local function _ss_buildListingItemStatsSafe(units, itemType)
    local ok, result = pcall(function()
        local itemStats = { isNew = true, tag = "NOVO" }
        local allNew           = true
        local minConditionPct  = 100
        local minUsesPct       = 100
        local minFluidPct      = 100
        local minFluidAmt      = nil
        local fluidMax         = nil
        local fluidLabel       = nil
        local foodHunger       = nil
        local foodBaseWeight   = nil
        local foodMinWeightPct = 100
        local foodUnhappy      = nil
        local foodBoredom      = nil
        local foodDaysTotal    = nil
        local foodDaysBad      = nil
        local foodCooked       = nil
        local foodBurnt        = nil

        for i=1,#units do
            local okStats, statsOrErr = pcall(getItemStatsSummary, units[i])
            local stats = okStats and statsOrErr or nil
            if not okStats then
                print("[SurvivorShop] Warning: getItemStatsSummary failed for " .. tostring(itemType) .. ": " .. tostring(statsOrErr))
            end
            if stats then
                if not stats.isNew then allNew = false end
                if stats.conditionPercent ~= nil then
                    minConditionPct = math.min(minConditionPct, tonumber(stats.conditionPercent) or minConditionPct)
                end
                if stats.usesPercent ~= nil then
                    minUsesPct = math.min(minUsesPct, tonumber(stats.usesPercent) or minUsesPct)
                end
                if stats.fluidPercent ~= nil then
                    minFluidPct = math.min(minFluidPct, tonumber(stats.fluidPercent) or minFluidPct)
                end
                if stats.fluidAmount ~= nil then
                    local amt = tonumber(stats.fluidAmount)
                    if amt ~= nil and (minFluidAmt == nil or amt < minFluidAmt) then
                        minFluidAmt = amt
                    end
                end
                if stats.fluidMax ~= nil then fluidMax = tonumber(stats.fluidMax) or stats.fluidMax end
                if stats.fluidLabel ~= nil then fluidLabel = stats.fluidLabel end
                if i == 1 then
                    foodHunger     = stats.hunger
                    foodBaseWeight = stats.baseWeight
                    foodUnhappy    = stats.unhappy
                    foodBoredom    = stats.boredom
                    foodDaysTotal  = stats.daysTotal
                    foodDaysBad    = stats.daysBad
                    foodCooked     = stats.cooked
                    foodBurnt      = stats.burnt
                end
                if stats.foodWeightPercent ~= nil then
                    foodMinWeightPct = math.min(foodMinWeightPct, tonumber(stats.foodWeightPercent) or foodMinWeightPct)
                end
            end
        end

        itemStats.isNew = allNew
        itemStats.tag   = allNew and "NOVO" or "USADO"
        if minConditionPct < 100 then itemStats.minCondition = minConditionPct end
        if minUsesPct < 100 then itemStats.minUses = minUsesPct end
        if minFluidAmt ~= nil then
            itemStats.fluidPercent = (minFluidPct < 100) and minFluidPct or nil
            itemStats.fluidAmount  = minFluidAmt
            itemStats.fluidMax     = fluidMax
            itemStats.fluidLabel   = fluidLabel
            if (minFluidAmt or 0) == 0 then
                itemStats.fluidPercent = 0
                itemStats.isNew = false
                itemStats.tag = "USADO"
            end
        end
        if foodHunger ~= nil then itemStats.foodHunger = foodHunger end
        if foodBaseWeight ~= nil then itemStats.foodBaseWeight = foodBaseWeight end
        if foodMinWeightPct < 100 then itemStats.foodWeightPct = foodMinWeightPct end
        if foodUnhappy ~= nil then itemStats.foodUnhappy = foodUnhappy end
        if foodBoredom ~= nil then itemStats.foodBoredom = foodBoredom end
        if foodDaysTotal ~= nil then itemStats.foodDaysTotal = foodDaysTotal end
        if foodDaysBad ~= nil then itemStats.foodDaysBad = foodDaysBad end
        if foodCooked ~= nil then itemStats.foodCooked = foodCooked end
        if foodBurnt ~= nil then itemStats.foodBurnt = foodBurnt end

        return itemStats
    end)

    if not ok then
        print("[SurvivorShop] Warning: listing stats build failed for " .. tostring(itemType) .. ": " .. tostring(result))
        return { isNew = true, tag = "NOVO" }
    end

    return result or { isNew = true, tag = "NOVO" }
end

local function _ss_sellClampPct(value)
    if value == nil then return nil end
    return math.floor(math.max(0, math.min(100, tonumber(value) or 0)))
end

local function _ss_sellRoundMillis(value)
    return math.floor(((tonumber(value) or 0) * 1000) + 0.5)
end

local function _ss_sellFreshnessPercentFromData(data)
    local age = tonumber(data and data.age)
    local daysBad = tonumber(data and data.daysBad)
    if not age or not daysBad or daysBad <= 0 then return nil end
    return _ss_sellClampPct((1.0 - (age / daysBad)) * 100)
end

local function _ss_buildSellVariantMetaFromSerialized(data)
    local stats = getItemStatsSummary(data) or {}
    local keyParts = { "ft:" .. tostring((data and data.itemType) or "") }
    local hasStableUseVariant = _ss_hasMeaningfulUsesSnapshot(data) and (stats.usesPercent ~= nil)

    local function addKey(name, value)
        keyParts[#keyParts + 1] = tostring(name) .. ":" .. tostring(value)
    end

    if stats.conditionPercent ~= nil and tonumber(stats.conditionPercent) < 100 then
        addKey("cond", stats.conditionPercent)
    end

    if hasStableUseVariant and stats.usesPercent ~= nil and tonumber(stats.usesPercent) < 100 then
        addKey("uses", stats.usesPercent)
    end

    if data and data.hasFluid then
        if stats.fluidPercent ~= nil and tonumber(stats.fluidPercent) < 100 then
            addKey("fluidPct", stats.fluidPercent)
        elseif tonumber(data.fluidAmount) and tonumber(data.fluidAmount) <= 0 then
            addKey("fluidAmt", _ss_sellRoundMillis(data.fluidAmount))
        end
        if data.primaryFluid ~= nil and tostring(data.primaryFluid) ~= "" then
            addKey("fluidType", tostring(data.primaryFluid))
        end
    end

    if data and data.isFood then
        if not hasStableUseVariant and stats.foodWeightPercent ~= nil and tonumber(stats.foodWeightPercent) < 100 then
            addKey("foodWeight", stats.foodWeightPercent ~= nil and stats.foodWeightPercent or 100)
        end
        if data.cooked then addKey("cooked", 1) end
        if data.burnt then addKey("burnt", 1) end
    end

    return {
        key = table.concat(keyParts, "|"),
        stats = stats,
    }
end

local function _ss_collectVariantKeysInContainerRecursiveUnequipped(container, fullType, player, outKeys, limit)
    if not container or not outKeys or (#outKeys >= (limit or 3)) then return end
    local items = container:getItems()
    for i=0, items:size()-1 do
        if #outKeys >= (limit or 3) then break end
        local it = items:get(i)
        if it and it.getFullType and it:getFullType() == fullType and not isEquippedByPlayer(player, it) then
            local parent = it.getContainer and it:getContainer() or nil
            if parent and isInCharInv(parent, player) then
                local meta = _ss_buildSellVariantMetaFromSerialized(serializeItem(it))
                if meta and meta.key then
                    outKeys[#outKeys + 1] = tostring(meta.key)
                end
            end
        end
        if it and it.getInventory and it:getInventory() then
            _ss_collectVariantKeysInContainerRecursiveUnequipped(it:getInventory(), fullType, player, outKeys, limit)
        end
    end
end

local function _ss_countVariantInContainerRecursiveUnequipped(container, fullType, variantKey, player)
    if not container then return 0 end
    local items = container:getItems()
    local count = 0
    for i=0, items:size()-1 do
        local it = items:get(i)
        if it and it.getFullType and it:getFullType() == fullType and not isEquippedByPlayer(player, it) then
            local parent = it.getContainer and it:getContainer() or nil
            if parent and isInCharInv(parent, player) then
                local meta = _ss_buildSellVariantMetaFromSerialized(serializeItem(it))
                if meta.key == variantKey then
                    count = count + 1
                end
            end
        end
        if it and it.getInventory and it:getInventory() then
            count = count + _ss_countVariantInContainerRecursiveUnequipped(it:getInventory(), fullType, variantKey, player)
        end
    end
    return count
end

local function _ss_takeItemsRecursiveUnequippedVariant(container, fullType, variantKey, amount, outList, player)
    if not container or amount <= 0 then return amount end
    local items = container:getItems()
    for i=items:size()-1,0,-1 do
        if amount <= 0 then break end
        local it = items:get(i)
        if it and it.getFullType and it:getFullType() == fullType and not isEquippedByPlayer(player, it) then
            local parent = it.getContainer and it:getContainer() or nil
            if parent and isInCharInv(parent, player) then
                local meta = _ss_buildSellVariantMetaFromSerialized(serializeItem(it))
                if meta.key == variantKey then
                    syncRemove(parent, it)
                    table.insert(outList, it)
                    amount = amount - 1
                end
            end
        end
        if it and it.getInventory and it:getInventory() then
            amount = _ss_takeItemsRecursiveUnequippedVariant(it:getInventory(), fullType, variantKey, amount, outList, player)
        end
    end
    return amount
end

local function getPublicListings(pub) return pub.listings or {} end
local function setPublicListings(pub, arr) pub.listings = arr end

local function findListing(pub, id)
    local list = getPublicListings(pub)
    for i=1,#list do
        if tostring(list[i].id) == tostring(id) then
            return list[i], i
        end
    end
    return nil, nil
end

local function removeListingById(pub, id)
    local list = getPublicListings(pub)
    for i=#list, 1, -1 do
        if tostring(list[i].id) == tostring(id) then
            table.remove(list, i)
            return true
        end
    end
    return false
end


local function nextId(internal)
    internal.nextId = (tonumber(internal.nextId) or 0) + 1
    return tostring(internal.nextId)
end


-- =========================================================
-- Public ModData transmit coalescing (dedicated-friendly)
-- Reduces broadcast spam when many players buy/list/cancel.
-- =========================================================
local PUBLIC_TX_INTERVAL_MS = 750
local _publicDirty = false
local _lastPublicTx = 0

local function _ss_ensureExpiryFieldsOnPublic()
    local pub = getPublic()
    local list = getPublicListings(pub)
    if not list or #list == 0 then return end

    local nowSec = os.time()
    local expSec = getListingExpireSeconds()
    local changed = false

    for i=1,#list do
        local l = list[i]
        if l then
            if l.created == nil then
                l.created = nowSec
                changed = true
            end
            if l.expiresAt == nil then
                l.expiresAt = (tonumber(l.created) or nowSec) + expSec
                changed = true
            end
        end
    end

    if changed then
        setPublicListings(pub, list)
    end
end

local function _ss_buildListingsPayload()
    local pub = getPublic()
    _ss_ensureExpiryFieldsOnPublic()
    return { listings = pub.listings or {}, auctions = pub.auctions or {} }
end

local function _ss_sendListingsToPlayer(player)
    if not player then return end
    sendServerCommand(player, SurvivorShop.MODULE, "listings", _ss_buildListingsPayload())
end

local function _ss_broadcastListings()
    if not getOnlinePlayers then return end
    local ok, players = pcall(getOnlinePlayers)
    if not ok or not players then return end
    local payload = _ss_buildListingsPayload()
    for i = 0, players:size() - 1 do
        local p = players:get(i)
        if p then sendServerCommand(p, SurvivorShop.MODULE, "listings", payload) end
    end
end

local function transmitPublicImmediate()
    _ss_ensureExpiryFieldsOnPublic()
    _publicDirty = false
    _lastPublicTx = nowMs()
    _ss_broadcastListings()
end

local function transmitPublicQueued()
    _publicDirty = true
end

local function _ss_tryTransmitPublic()
    if not _publicDirty then return end
    local n = nowMs()
    if (n - _lastPublicTx) < PUBLIC_TX_INTERVAL_MS then return end
    transmitPublicImmediate()
end

Events.OnTick.Add(_ss_tryTransmitPublic)

local Commands = {}

function Commands.sync(_, _, player, args)
    if not rateLimitOK(player, "sync") then return end
    local payload = _ss_buildListingsPayload()
    print("[SurvivorShop DEBUG] sync from " .. tostring(player and player.getUsername and player:getUsername()) .. " | listings=" .. tostring(#(payload.listings or {})) .. " auctions=" .. tostring(#(payload.auctions or {})))
    _ss_registerPlayerAccount(player)
    sendServerCommand(player, SurvivorShop.MODULE, "listings", payload)
    sendBalance(player)
    _ss_sendLedger(player)
    _ss_sendInvoices(player)
    sendSalesHistory(player)
end

function Commands.getBalance(_, _, player, args)
    if not rateLimitOK(player, "getBalance") then return end
    _ss_registerPlayerAccount(player)
    sendBalance(player)
end

function Commands.getBankSnapshot(_, _, player, args)
    if not rateLimitOK(player, "getBankSnapshot") then return end
    _ss_sendBankSnapshot(player, true)
end

function Commands.getOnlinePlayers(_, _, player, args)
    if not rateLimitOK(player, "getOnlinePlayers") then return end
    _ss_sendOnlinePlayers(player)
end

function Commands.bankTransfer(_, _, player, args)
    if not rateLimitOK(player, "bankTransfer") then return end
    args = args or {}
    _ss_registerPlayerAccount(player)

    local toName = _ss_trimmedName(args.to or "")
    local amount = math.floor(tonumber(args.amount) or 0)

    if toName == "" then return sendErrorK(player, "IGUI_SS_Err_SelectPlayer") end
    if amount <= 0 then return sendErrorK(player, "IGUI_SS_InvalidAmount") end
    if amount > SurvivorShop.MAX_PRICE then return sendErrorK(player, "IGUI_SS_InvalidAmount") end

    local targetInfo = _ss_resolveAccountByName(toName)
    if not targetInfo then return sendErrorK(player, "IGUI_SS_Err_PlayerBankUnknown") end
    if targetInfo.player == player then return sendErrorK(player, "IGUI_SS_Err_CantTransferToSelf") end

    local bal = getBalances()
    local fromKey = SurvivorShop.getAccountKey(player)
    local toKey = tostring(targetInfo.key or "")
    if fromKey == toKey then return sendErrorK(player, "IGUI_SS_Err_CantTransferToSelf") end

    local fromBal = getBalanceForKey(bal, fromKey)
    if fromBal < amount then return sendErrorK(player, "IGUI_SS_Err_InsufficientFunds") end

    local toBal = getBalanceForKey(bal, toKey)
    local targetName = _ss_getKnownNameForKey(toKey, targetInfo.name)

    setBalanceForKey(bal, fromKey, fromBal - amount)
    setBalanceForKey(bal, toKey, toBal + amount)

    _ss_addLedgerEntryForKey(fromKey, {
        kind = "transfer_out",
        amount = amount,
        otherName = targetName,
    })
    _ss_addLedgerEntryForKey(toKey, {
        kind = "transfer_in",
        amount = amount,
        otherName = SurvivorShop.getAccountName(player),
    })

    sendBalance(player, fromBal - amount)
    _ss_sendLedger(player)
    sendToastK(player, "IGUI_SS_Toast_BankTransferOut", { tostring(amount), tostring(targetName) }, { refreshBalance = true })

    if targetInfo.player then
        sendBalance(targetInfo.player, toBal + amount)
        _ss_sendLedger(targetInfo.player)
        sendServerCommand(targetInfo.player, SurvivorShop.MODULE, "bankTransferNotify", { from = SurvivorShop.getAccountName(player), amount = amount })
    end

    ss_log(player, "TRANSFERENCIA_ENVIADA", "Enviou $" .. amount .. " para " .. targetName .. ".")
    ss_log_raw(targetName, toKey, "TRANSFERENCIA_RECEBIDA", "Recebeu $" .. amount .. " de " .. SurvivorShop.getAccountName(player) .. ".")
end

function Commands.deposit(_, _, player, args)
    if not rateLimitOK(player, "deposit") then return end
    _ss_registerPlayerAccount(player)
    local amount = math.floor(tonumber(args.amount) or 0)
    if amount <= 0 then return sendErrorK(player, "IGUI_SS_InvalidAmount") end

    local inv = player:getInventory()
    if countInContainerRecursiveCharacterInventory(inv, SurvivorShop.CURRENCY, player) < amount then
        return sendErrorK(player, "IGUI_SS_Err_NotEnoughMoney")
    end

    local taken = {}
    if takeItemsRecursive(inv, SurvivorShop.CURRENCY, amount, taken, player) > 0 then
        return sendErrorK(player, "IGUI_SS_Err_FailedRemoveMoney")
    end

    local bal = getBalances()
    local key = SurvivorShop.getAccountKey(player)
    local b = getBalanceForKey(bal, key)
    setBalanceForKey(bal, key, b + amount)
    _ss_addLedgerEntryForKey(key, {
        kind = "deposit",
        amount = amount,
    })
    sendBalance(player, b + amount)
    _ss_sendLedger(player)
    sendToastK(player, "IGUI_SS_Toast_Deposited", { tostring(amount) })
    ss_log(player, "DEPOSITO", "Depositou $" .. amount .. " no banco.")
end

function Commands.depositAll(_, _, player, args)
    if not rateLimitOK(player, "depositAll") then return end
    _ss_registerPlayerAccount(player)

    local inv = player:getInventory()
    local amount = countInContainerRecursiveCharacterInventory(inv, SurvivorShop.CURRENCY, player)
    if amount <= 0 then
        return sendErrorK(player, "IGUI_SS_Err_NotEnoughMoney")
    end

    local taken = {}
    local remaining = takeItemsRecursive(inv, SurvivorShop.CURRENCY, amount, taken, player)
    if remaining > 0 then
        return sendErrorK(player, "IGUI_SS_Err_FailedRemoveMoney")
    end

    local bal = getBalances()
    local key = SurvivorShop.getAccountKey(player)
    local b = getBalanceForKey(bal, key)
    setBalanceForKey(bal, key, b + amount)
    _ss_addLedgerEntryForKey(key, {
        kind = "deposit",
        amount = amount,
    })
    sendBalance(player, b + amount)
    _ss_sendLedger(player)
    sendToastK(player, "IGUI_SS_Toast_Deposited", { tostring(amount) })
    ss_log(player, "DEPOSITO_TUDO", "Depositou $" .. amount .. " do inventario no banco.")
end

function Commands.withdraw(_, _, player, args)
    if not rateLimitOK(player, "withdraw") then return end
    _ss_registerPlayerAccount(player)
    local amount = math.floor(tonumber(args.amount) or 0)
    if amount <= 0 then return sendErrorK(player, "IGUI_SS_InvalidAmount") end

    local bal = getBalances()
    local key = SurvivorShop.getAccountKey(player)
    local b = getBalanceForKey(bal, key)
    if b < amount then return sendErrorK(player, "IGUI_SS_Err_InsufficientFunds") end

    setBalanceForKey(bal, key, b - amount)
    addMoneyToPlayer(player, amount)
    _ss_addLedgerEntryForKey(key, {
        kind = "withdraw",
        amount = amount,
    })
    sendBalance(player, b - amount)
    _ss_sendLedger(player)
    sendToastK(player, "IGUI_SS_Toast_Withdrawn", { tostring(amount) })
    ss_log(player, "SAQUE", "Sacou $" .. amount .. " do banco.")
end

function Commands.reserveDeposit(_, _, player, args)
    if not rateLimitOK(player, "reserveDeposit") then return end
    _ss_registerPlayerAccount(player)

    local amount = math.floor(tonumber(args.amount) or 0)
    if amount <= 0 then return sendErrorK(player, "IGUI_SS_InvalidAmount") end

    local bal = getBalances()
    local key = SurvivorShop.getAccountKey(player)
    local available = getBalanceForKey(bal, key)
    local savings = getSavingsForKey(bal, key)
    if available < amount then return sendErrorK(player, "IGUI_SS_Err_InsufficientFunds") end

    setBalanceForKey(bal, key, available - amount)
    setSavingsForKey(bal, key, savings + amount)
    _ss_addLedgerEntryForKey(key, {
        kind = "vault_in",
        amount = amount,
    })

    sendBalance(player, available - amount)
    _ss_sendLedger(player)
    sendToastK(player, "IGUI_SS_Toast_VaultDeposit", { tostring(amount) }, { refreshBalance = true })
end

function Commands.reserveWithdraw(_, _, player, args)
    if not rateLimitOK(player, "reserveWithdraw") then return end
    _ss_registerPlayerAccount(player)

    local amount = math.floor(tonumber(args.amount) or 0)
    if amount <= 0 then return sendErrorK(player, "IGUI_SS_InvalidAmount") end

    local bal = getBalances()
    local key = SurvivorShop.getAccountKey(player)
    local available = getBalanceForKey(bal, key)
    local savings = getSavingsForKey(bal, key)
    if savings < amount then return sendErrorK(player, "IGUI_SS_Err_InsufficientSavings") end

    setSavingsForKey(bal, key, savings - amount)
    setBalanceForKey(bal, key, available + amount)
    _ss_addLedgerEntryForKey(key, {
        kind = "vault_out",
        amount = amount,
    })

    sendBalance(player, available + amount)
    _ss_sendLedger(player)
    sendToastK(player, "IGUI_SS_Toast_VaultWithdraw", { tostring(amount) }, { refreshBalance = true })
end

function Commands.getBankLedger(_, _, player, args)
    if not rateLimitOK(player, "getBankLedger") then return end
    _ss_sendLedger(player)
end

function Commands.getBankInvoices(_, _, player, args)
    if not rateLimitOK(player, "getBankInvoices") then return end
    _ss_sendInvoices(player)
end

function Commands.bankInvoiceCreate(_, _, player, args)
    if not rateLimitOK(player, "bankInvoiceCreate") then return end
    args = args or {}
    _ss_registerPlayerAccount(player)

    local toName = _ss_trimmedName(args.to or "")
    local amount = math.floor(tonumber(args.amount) or 0)
    local note = _ss_trimmedName(args.note or "")
    if #note > 80 then
        note = string.sub(note, 1, 80)
    end

    if toName == "" then return sendErrorK(player, "IGUI_SS_Err_SelectPlayer") end
    if amount <= 0 then return sendErrorK(player, "IGUI_SS_InvalidAmount") end
    if amount > SurvivorShop.MAX_PRICE then return sendErrorK(player, "IGUI_SS_InvalidAmount") end

    local targetInfo = _ss_resolveAccountByName(toName)
    if not targetInfo then return sendErrorK(player, "IGUI_SS_Err_PlayerBankUnknown") end

    local fromKey = SurvivorShop.getAccountKey(player)
    if tostring(targetInfo.key or "") == fromKey then
        return sendErrorK(player, "IGUI_SS_Err_CantTransferToSelf")
    end

    local store = _ss_normalizeInvoiceStore()
    local list = _ss_getInvoicesForRecipient(tostring(targetInfo.key))
    local invoice = {
        id = tostring(store.nextId),
        fromKey = fromKey,
        fromName = SurvivorShop.getAccountName(player),
        toKey = tostring(targetInfo.key),
        toName = _ss_getKnownNameForKey(tostring(targetInfo.key), targetInfo.name),
        amount = amount,
        note = note,
        status = "pending",
        createdAt = os.time(),
        resolvedAt = 0,
    }
    store.nextId = store.nextId + 1
    table.insert(list, 1, invoice)
    _ss_trimInvoicesForRecipient(tostring(targetInfo.key))

    _ss_sendInvoices(player)
    sendToastK(player, "IGUI_SS_Toast_InvoiceCreated", { invoice.toName, tostring(amount) })

    if targetInfo.player then
        _ss_sendInvoices(targetInfo.player)
        sendToastK(targetInfo.player, "IGUI_SS_Toast_InvoiceIncoming", { invoice.fromName, tostring(amount) })
    end
end

function Commands.bankInvoicePay(_, _, player, args)
    if not rateLimitOK(player, "bankInvoicePay") then return end
    args = args or {}
    _ss_registerPlayerAccount(player)

    local invoice = _ss_findInvoiceById(args.id)
    if not invoice then return sendErrorK(player, "IGUI_SS_Err_InvoiceNotFound") end
    if tostring(invoice.status or "pending") ~= "pending" then
        return sendErrorK(player, "IGUI_SS_Err_InvoiceAlreadyResolved")
    end

    local key = SurvivorShop.getAccountKey(player)
    if tostring(invoice.toKey or "") ~= tostring(key) then
        return sendErrorK(player, "IGUI_SS_Err_InvoiceOnlyRecipient")
    end

    local bal = getBalances()
    local payerBal = getBalanceForKey(bal, key)
    local amount = math.max(0, math.floor(tonumber(invoice.amount) or 0))
    if payerBal < amount then return sendErrorK(player, "IGUI_SS_Err_InsufficientFunds") end

    local senderKey = tostring(invoice.fromKey or "")
    local senderBal = getBalanceForKey(bal, senderKey)
    setBalanceForKey(bal, key, payerBal - amount)
    setBalanceForKey(bal, senderKey, senderBal + amount)

    invoice.status = "paid"
    invoice.resolvedAt = os.time()
    invoice.resolvedBy = SurvivorShop.getAccountName(player)

    _ss_addLedgerEntryForKey(key, {
        kind = "invoice_paid_out",
        amount = amount,
        otherName = _ss_getKnownNameForKey(senderKey, invoice.fromName),
        note = invoice.note,
    })
    _ss_addLedgerEntryForKey(senderKey, {
        kind = "invoice_paid_in",
        amount = amount,
        otherName = SurvivorShop.getAccountName(player),
        note = invoice.note,
    })

    sendBalance(player, payerBal - amount)
    _ss_sendLedger(player)
    _ss_sendInvoices(player)
    sendToastK(player, "IGUI_SS_Toast_InvoicePaid", { tostring(amount), _ss_getKnownNameForKey(senderKey, invoice.fromName) }, { refreshBalance = true })

    local senderOnline = _ss_findOnlinePlayerByKey(senderKey)
    if senderOnline then
        sendBalance(senderOnline, senderBal + amount)
        _ss_sendLedger(senderOnline)
        _ss_sendInvoices(senderOnline)
        sendToastK(senderOnline, "IGUI_SS_Toast_InvoicePaidIncoming", { SurvivorShop.getAccountName(player), tostring(amount) }, { refreshBalance = true })
    end
end

function Commands.bankInvoiceDecline(_, _, player, args)
    if not rateLimitOK(player, "bankInvoiceDecline") then return end
    args = args or {}
    _ss_registerPlayerAccount(player)

    local invoice = _ss_findInvoiceById(args.id)
    if not invoice then return sendErrorK(player, "IGUI_SS_Err_InvoiceNotFound") end
    if tostring(invoice.status or "pending") ~= "pending" then
        return sendErrorK(player, "IGUI_SS_Err_InvoiceAlreadyResolved")
    end

    local key = SurvivorShop.getAccountKey(player)
    if tostring(invoice.toKey or "") ~= tostring(key) then
        return sendErrorK(player, "IGUI_SS_Err_InvoiceOnlyRecipient")
    end

    invoice.status = "declined"
    invoice.resolvedAt = os.time()
    invoice.resolvedBy = SurvivorShop.getAccountName(player)

    _ss_sendInvoices(player)
    sendToastK(player, "IGUI_SS_Toast_InvoiceDeclined", { _ss_getKnownNameForKey(tostring(invoice.fromKey or ""), invoice.fromName) })

    local senderOnline = _ss_findOnlinePlayerByKey(tostring(invoice.fromKey or ""))
    if senderOnline then
        _ss_sendInvoices(senderOnline)
        sendToastK(senderOnline, "IGUI_SS_Toast_InvoiceDeclinedIncoming", { SurvivorShop.getAccountName(player) })
    end
end

function Commands.bankInvoiceCancel(_, _, player, args)
    if not rateLimitOK(player, "bankInvoiceCancel") then return end
    args = args or {}
    _ss_registerPlayerAccount(player)

    local invoice = _ss_findInvoiceById(args.id)
    if not invoice then return sendErrorK(player, "IGUI_SS_Err_InvoiceNotFound") end
    if tostring(invoice.status or "pending") ~= "pending" then
        return sendErrorK(player, "IGUI_SS_Err_InvoiceAlreadyResolved")
    end

    local key = SurvivorShop.getAccountKey(player)
    if tostring(invoice.fromKey or "") ~= tostring(key) then
        return sendErrorK(player, "IGUI_SS_Err_InvoiceOnlySender")
    end

    invoice.status = "canceled"
    invoice.resolvedAt = os.time()
    invoice.resolvedBy = SurvivorShop.getAccountName(player)

    _ss_sendInvoices(player)
    sendToastK(player, "IGUI_SS_Toast_InvoiceCanceled", { _ss_getKnownNameForKey(tostring(invoice.toKey or ""), invoice.toName) })

    local targetOnline = _ss_findOnlinePlayerByKey(tostring(invoice.toKey or ""))
    if targetOnline then
        _ss_sendInvoices(targetOnline)
    end
end

function Commands.list(_, _, player, args)
    if not rateLimitOK(player, "list") then return end
    _ss_registerPlayerAccount(player)
    local itemType = tostring(args.itemType or "")
    local variantKey = tostring(args.variantKey or "")
    local qty = math.floor(tonumber(args.quantity) or 0)
    local price = math.floor(tonumber(args.price) or 0)
    local sellerKey = SurvivorShop.getAccountKey(player)
    local sellerName = SurvivorShop.getAccountName(player)

    local function rejectList(key, reason, params, fallback)
        print("[SurvivorShop] list rejected for " .. tostring(sellerName)
            .. " | item=" .. tostring(itemType)
            .. " | variant=" .. tostring(variantKey ~= "" and variantKey or "<none>")
            .. " | qty=" .. tostring(qty)
            .. " | price=" .. tostring(price)
            .. " | reason=" .. tostring(reason))
        return sendErrorK(player, key, params, fallback)
    end

    if itemType == "" then return rejectList("IGUI_SS_Err_InvalidItem", "invalid-item") end
    
    if isBannedSellType(itemType) then return rejectList("IGUI_SS_Err_BannedItem", "banned-item") end
if qty <= 0 or qty > SurvivorShop.MAX_QTY_PER_LISTING then return rejectList("IGUI_SS_Err_InvalidQuantity", "invalid-quantity") end
    if price <= 0 or price > SurvivorShop.MAX_PRICE then return rejectList("IGUI_SS_Err_InvalidPrice", "invalid-price") end

    -- Max listings per player (Sandbox configurable)
    local maxListings = getMaxListingsPerPlayer()
    if maxListings > 0 then
        local internal = getInternal()
        local sellerKey = SurvivorShop.getAccountKey(player)
        local current = countActiveListingsForKey(internal, sellerKey)
        if current >= maxListings then
            return rejectList("IGUI_SS_Err_ListingLimitReached", "listing-limit", { tostring(maxListings) })
        end
    end
    local inv = player:getInventory()
    local totalHave = countInContainerRecursive(inv, itemType)
    local freeHave = nil
    if variantKey ~= "" then
        freeHave = _ss_countVariantInContainerRecursiveUnequipped(inv, itemType, variantKey, player)
    else
        freeHave = countInContainerRecursiveUnequipped(inv, itemType, player)
    end
    if freeHave < qty then
        if variantKey ~= "" then
            local candidateKeys = {}
            _ss_collectVariantKeysInContainerRecursiveUnequipped(inv, itemType, player, candidateKeys, 3)
            print("[SurvivorShop] Variant mismatch while listing " .. tostring(itemType)
                .. " for " .. tostring(SurvivorShop.getAccountName(player))
                .. " | requested=" .. tostring(variantKey)
                .. " | freeHave=" .. tostring(freeHave)
                .. " | totalHave=" .. tostring(totalHave)
                .. " | qty=" .. tostring(qty)
                .. (candidateKeys[1] and (" | candidates=" .. table.concat(candidateKeys, " || ")) or ""))
            return sendErrorK(player, "IGUI_SS_Err_NotEnoughItems")
        end
        if totalHave >= qty then
            return rejectList("IGUI_SS_Err_UnequipBeforeSell", "equipped-item")
        end
        return rejectList("IGUI_SS_Err_NotEnoughItems", "not-enough-items")
    end

    -- Upfront listing fee (charged from bank balance) somente depois de validar o inventário.
    local feePct = getListingFeePercent()
    local listingFee = 0
    if feePct > 0 then
        listingFee = math.floor((qty * price) * (feePct / 100.0))
        if listingFee < 1 then listingFee = 1 end
    end
    if listingFee > 0 then
        local bal = getBalances()
        local b = getBalanceForKey(bal, sellerKey)
        if b < listingFee then
            print("[SurvivorShop] list rejected for " .. tostring(sellerName)
                .. " | item=" .. tostring(itemType)
                .. " | reason=insufficient-listing-fee"
                .. " | balance=" .. tostring(b)
                .. " | listingFee=" .. tostring(listingFee))
            return sendErrorK(player, "IGUI_SS_Err_InsufficientForListingFee", { tostring(listingFee) })
        end
        setBalanceForKey(bal, sellerKey, b - listingFee)
        _ss_addLedgerEntryForKey(sellerKey, {
            kind = "listing_fee",
            amount = listingFee,
            itemName = itemType,
            quantity = qty,
        })
        sendBalance(player, b - listingFee)
        _ss_sendLedger(player)
        sendToastK(player, "IGUI_SS_Toast_ListingFeeCharged", { tostring(listingFee) })
    end
    local function refundListingFee()
        if listingFee <= 0 then return end
        local bal = getBalances()
        local b = getBalanceForKey(bal, sellerKey)
        setBalanceForKey(bal, sellerKey, b + listingFee)
        _ss_addLedgerEntryForKey(sellerKey, {
            kind = "listing_fee_refund",
            amount = listingFee,
            itemName = itemType,
            quantity = qty,
        })
        sendBalance(player, b + listingFee)
        _ss_sendLedger(player)
    end

    local removed = {}
    local remaining = nil
    if variantKey ~= "" then
        remaining = _ss_takeItemsRecursiveUnequippedVariant(inv, itemType, variantKey, qty, removed, player)
    else
        remaining = takeItemsRecursiveUnequipped(inv, itemType, qty, removed, player)
    end
    if remaining > 0 then
        refundListingFee()
        return rejectList("IGUI_SS_Err_FailedRemoveItems", "failed-remove-items")
    end

    local units, anyFood = {}, false
    for i=1,#removed do
        local data = serializeItem(removed[i])
        if data and data.isFood then anyFood = true end
        table.insert(units, data)
    end

    if anyFood and SurvivorShop.ALLOW_FOOD == false then
        local restored = {}
        for i=1,#units do
            local it = restoreSerializedItem(inv, itemType, units[i])
            if not it then
                for j=#restored,1,-1 do
                    syncRemove(inv, restored[j])
                end
                refundListingFee()
                return sendError(player, "Falha ao restaurar item bloqueado pela regra de comida: " .. tostring(itemType) .. ".")
            end
            restored[#restored+1] = it
        end
        refundListingFee()
        return rejectList("IGUI_SS_Err_FoodNotAllowed", "food-not-allowed")
    end

    local internal = getInternal()
    internal.units = internal.units or {}
    internal.sellerById = internal.sellerById or {}

    local pub = getPublic()
    pub.listings = pub.listings or {}

    local id = nextId(internal)
    internal.units[id] = units
    internal.sellerById[id] = { key = sellerKey, name = SurvivorShop.getAccountName(player), expired = false }

    local displayName = itemType
    if removed[1] and removed[1].getDisplayName then displayName = stripUnknownPrefix(removed[1]:getDisplayName()) end

    -- Calculate aggregate stats for all units in this listing
    -- ALWAYS create itemStats table (even for NEW items) so UI can display it
    local itemStats = _ss_buildListingItemStatsSafe(units, itemType)
    if false then
    local itemStats = { isNew = true, tag = "NOVO" }
    local allNew           = true
    local minConditionPct  = 100
    local minUsesPct       = 100
    local minFluidPct      = 100
    local minFluidAmt      = nil   -- litros no item com menos líquido
    local fluidMax         = nil
    local fluidLabel       = nil
    -- Food aggregates (use first unit's values; all units of the same type share script data)
    local foodHunger       = nil
    local foodBaseWeight   = nil
    local foodMinWeightPct = 100
    local foodUnhappy      = nil
    local foodBoredom      = nil
    local foodDaysTotal    = nil
    local foodDaysBad      = nil
    local foodCooked       = nil
    local foodBurnt        = nil

    for i=1,#units do
        local okStats, statsOrErr = pcall(getItemStatsSummary, units[i])
        local stats = okStats and statsOrErr or nil
        if not okStats then
            print("[SurvivorShop] Warning: getItemStatsSummary failed for " .. tostring(itemType) .. ": " .. tostring(statsOrErr))
        end
        if stats then
            if not stats.isNew then allNew = false end
            if stats.conditionPercent then
                minConditionPct = math.min(minConditionPct, stats.conditionPercent)
            end
            if stats.usesPercent ~= nil then
                minUsesPct = math.min(minUsesPct, stats.usesPercent)
            end
            -- Fluido
            if stats.fluidPercent ~= nil then
                minFluidPct = math.min(minFluidPct, stats.fluidPercent)
            end
            if stats.fluidAmount ~= nil then
                if minFluidAmt == nil or stats.fluidAmount < minFluidAmt then
                    minFluidAmt = stats.fluidAmount
                end
            end
            if stats.fluidMax   ~= nil then fluidMax   = stats.fluidMax   end
            if stats.fluidLabel ~= nil then fluidLabel = stats.fluidLabel end
            -- Comida (usa valores do primeiro item; todos os itens do mesmo tipo compartilham)
            if i == 1 then
                foodHunger    = stats.hunger
                foodBaseWeight= stats.baseWeight
                foodUnhappy   = stats.unhappy
                foodBoredom   = stats.boredom
                foodDaysTotal = stats.daysTotal
                foodDaysBad   = stats.daysBad
                foodCooked    = stats.cooked
                foodBurnt     = stats.burnt
            end
            if stats.foodWeightPercent ~= nil then
                foodMinWeightPct = math.min(foodMinWeightPct, stats.foodWeightPercent)
            end
        end
    end

    -- Monta itemStats final
    itemStats.isNew = allNew
    itemStats.tag   = allNew and "NOVO" or "USADO"
    if minConditionPct  < 100  then itemStats.minCondition  = minConditionPct  end
    if minUsesPct       < 100  then itemStats.minUses       = minUsesPct       end
    -- Fluido: sempre inclui se o item tem fluido (inclusive 0% = vazio)
    if minFluidAmt ~= nil then
        itemStats.fluidPercent = (minFluidPct < 100) and minFluidPct or nil
        itemStats.fluidAmount  = minFluidAmt
        itemStats.fluidMax     = fluidMax
        itemStats.fluidLabel   = fluidLabel
        -- 0 litros = vazio → marca como USADO
        if (minFluidAmt or 0) == 0 then
            itemStats.fluidPercent = 0
            itemStats.isNew = false
            itemStats.tag = "USADO"
        end
    end
    -- Comida
    if foodHunger    ~= nil then itemStats.foodHunger    = foodHunger    end
    if foodBaseWeight~= nil then itemStats.foodBaseWeight= foodBaseWeight end
    if foodMinWeightPct < 100 then itemStats.foodWeightPct = foodMinWeightPct end
    if foodUnhappy   ~= nil then itemStats.foodUnhappy   = foodUnhappy   end
    if foodBoredom   ~= nil then itemStats.foodBoredom   = foodBoredom   end
    if foodDaysTotal ~= nil then itemStats.foodDaysTotal = foodDaysTotal end
    if foodDaysBad   ~= nil then itemStats.foodDaysBad   = foodDaysBad   end
    if foodCooked    ~= nil then itemStats.foodCooked    = foodCooked    end
    if foodBurnt     ~= nil then itemStats.foodBurnt     = foodBurnt     end

    end
    local nowSec = os.time()
    local listing = {
        id=id, itemType=itemType, name=displayName,
        quantity=qty, price=price, sellerName=SurvivorShop.getAccountName(player),
        created=nowSec,
        expiresAt=nowSec + getListingExpireSeconds(),
        expired=false,
        isFood=anyFood,
        itemStats=itemStats,  -- NEW: Add stats info to listing
    }

    local list = getPublicListings(pub)
    table.insert(list, listing)
    setPublicListings(pub, list)

    print("[SurvivorShop] Listed " .. tostring(displayName) .. " x" .. tostring(qty) .. " for $" .. tostring(price) .. " each (id=" .. tostring(id) .. ")")
    local okHistory, errHistory = pcall(addSaleRecord, sellerKey, {
        listingId = id,
        itemType = listing.itemType,
        itemName = listing.name or listing.itemType,
        quantity = listing.quantity,
        unitPrice = tonumber(listing.price) or 0,
        totalPayout = 0,
        buyerName = "[ANUNCIADO]",
        soldAt = nowSec,
    })
    if not okHistory then
        print("[SurvivorShop] Warning: failed to record listing history for " .. tostring(displayName) .. ": " .. tostring(errHistory))
    end
    transmitPublicQueued()
    _ss_sendListingsToPlayer(player)
    local okSendHistory, errSendHistory = pcall(sendSalesHistory, player)
    if not okSendHistory then
        print("[SurvivorShop] Warning: failed to send sales history after listing " .. tostring(displayName) .. ": " .. tostring(errSendHistory))
    end
    sendToastK(player, "IGUI_SS_Toast_Listed", { tostring(displayName), tostring(qty), tostring(price) }, { refreshSell = true, refreshMy = true, refreshBrowse = true })
    ss_log(player, "ANUNCIO", "Anunciou " .. qty .. "x " .. displayName .. " por $" .. price .. " cada.")
end

function Commands.buy(_, _, player, args)
    if not rateLimitOK(player, "buy") then return end
    _ss_registerPlayerAccount(player)
    local id = tostring(args.id or "")
    local qty = math.floor(tonumber(args.quantity) or 0)
    if id == "" then return sendErrorK(player, "IGUI_SS_Err_InvalidID") end
    if qty <= 0 then return sendErrorK(player, "IGUI_SS_Err_InvalidQuantity") end

    local pub = getPublic()
    local listing, idx = findListing(pub, id)
    if not listing then return sendErrorK(player, "IGUI_SS_Err_ListingNotFound") end
    if qty > (tonumber(listing.quantity) or 0) then return sendErrorK(player, "IGUI_SS_Err_QuantityUnavailable") end

    -- Expiration (server-authoritative)
    do
        local nowSec = os.time()
        if listing.expiresAt == nil then
            local created = tonumber(listing.created) or nowSec
            listing.created = created
            listing.expiresAt = created + getListingExpireSeconds()
        end

        if listing.expired == true or (tonumber(listing.expiresAt) or 0) <= nowSec then
            -- Mark expired if not already, persist and broadcast
            if listing.expired ~= true then
                listing.expired = true
                listing.expiredAt = nowSec
                local all = getPublicListings(pub)
                all[idx] = listing
                setPublicListings(pub, all)

                local internal2 = getInternal()
                internal2.sellerById = internal2.sellerById or {}
                local s = internal2.sellerById[id]
                if s then s.expired = true end

                transmitPublicQueued()
            end
            return sendErrorK(player, "IGUI_SS_Err_ListingExpired")
        end
    end


    local internal = getInternal()
    internal.units = internal.units or {}
    internal.sellerById = internal.sellerById or {}
    local sellerInfo = internal.sellerById[id]
    if not sellerInfo then return sendErrorK(player, "IGUI_SS_Err_InvalidListingNoSeller") end

    local buyerKey = SurvivorShop.getAccountKey(player)
    if sellerInfo.key == buyerKey then
        return sendErrorK(player, "IGUI_SS_Err_CannotBuyOwnListing")
    end

    local cost = qty * (tonumber(listing.price) or 0)
    local bal = getBalances()
    local buyerBal = getBalanceForKey(bal, buyerKey)
    if buyerBal < cost then return sendErrorK(player, "IGUI_SS_Err_InsufficientFunds") end

    local units = internal.units[id] or {}
    if #units < qty then 
        -- If we have listing but no units, it's corrupt. Remove it to fix the shop state.
        removeListingById(pub, id)
        internal.units[id] = nil
        internal.sellerById[id] = nil
        transmitPublicQueued()
        return sendErrorK(player, "IGUI_SS_Err_CorruptUnitsInsufficient") 
    end


    -- BALANCE DEDUCTION (Server authoritative) - deduct first, refund on failure
    setBalanceForKey(bal, buyerKey, buyerBal - cost)
    sendBalance(player, buyerBal - cost)

    -- ITEM DELIVERY (all-or-nothing, server-authoritative)
    local inv = player:getInventory()
    local createdItems = {}
    for i=1,qty do
        local u = units[i]
        local it = ss_addItemSmart(inv, listing.itemType)
        if not it then
            -- rollback items + refund buyer
            for j=#createdItems,1,-1 do
                syncRemove(inv, createdItems[j])
            end
            setBalanceForKey(bal, buyerKey, buyerBal)
            sendBalance(player, buyerBal)
            sendError(player, "Falha ao entregar item (AddItem nil): " .. tostring(listing.itemType) .. ". Compra cancelada e valor estornado.")
            return
        end

        local ok, err = pcall(applySerialized, it, u)
        if not ok then
            print("[SurvivorShop] Warning: applySerialized failed for " .. tostring(listing.itemType) .. ": " .. tostring(err))
        end
        syncAdd(inv, it)
        createdItems[#createdItems+1] = it
    end

    _ss_addLedgerEntryForKey(buyerKey, {
        kind = "purchase",
        amount = cost,
        otherName = _ss_getKnownNameForKey(sellerInfo.key, sellerInfo.name),
        itemName = listing.name or listing.itemType,
        quantity = qty,
    })
    _ss_sendLedger(player)

    -- PAYOUT seller (only after delivery succeeded)
    local sellerBal = getBalanceForKey(bal, sellerInfo.key)
    local payout = math.floor(cost * (1.0 - getCommissionRate()))
    setBalanceForKey(bal, sellerInfo.key, sellerBal + payout)
    _ss_addLedgerEntryForKey(sellerInfo.key, {
        kind = "sale_payout",
        amount = payout,
        otherName = SurvivorShop.getAccountName(player),
        itemName = listing.name or listing.itemType,
        quantity = qty,
    })

    local sellerOnline = _ss_findOnlinePlayerByName(sellerInfo.name)
    if sellerOnline then
        sendBalance(sellerOnline, sellerBal + payout)
        _ss_sendLedger(sellerOnline)
        sendToastK(sellerOnline, "IGUI_SS_Toast_SoldNet", { tostring(listing.name), tostring(qty), tostring(payout) }, { refreshMy = true, refreshBrowse = true })
        sendServerCommand(sellerOnline, SurvivorShop.MODULE, "announceSold", {
            itemType = listing.itemType,
            itemName = listing.name,
            quantity = qty,
            payout = payout,
        })
    end

    -- Register sale in seller's history
    do
        local saleRecord = {
            listingId = id,
            itemType = listing.itemType,
            itemName = listing.name or listing.itemType,
            quantity = qty,
            unitPrice = tonumber(listing.price) or 0,
            totalPayout = payout,
            buyerName = SurvivorShop.getAccountName(player),
            soldAt = os.time(),
        }
        addSaleRecord(sellerInfo.key, saleRecord)
        if sellerOnline then
            sendSalesHistory(sellerOnline)
        end
    end

    -- Remove delivered units from queue (now it's safe)
    for i=1,qty do table.remove(units, 1) end

    -- UPDATE ModData listing quantity or remove if empty
    -- We re-find the listing to avoid race-condition shifted indices
    local list = getPublicListings(pub)
    local freshListing, freshIdx = findListing(pub, id)
    if freshListing then
        freshListing.quantity = (tonumber(freshListing.quantity) or 0) - qty
        if freshListing.quantity <= 0 then
            table.remove(list, freshIdx)
            internal.units[id] = nil
            internal.sellerById[id] = nil
        else
            list[freshIdx] = freshListing
            internal.units[id] = units
        end
    end

    transmitPublicQueued()
    _ss_sendListingsToPlayer(player)
    sendToastK(player, "IGUI_SS_Toast_PurchaseComplete", { tostring(listing.name), tostring(qty) }, { refreshSell = true, refreshBrowse = true })

    -- LOGGING (Buyer and Seller)
    ss_log(player, "COMPRA", "Comprou " .. qty .. "x " .. tostring(listing.name) .. " por total de $" .. cost .. ".")
    ss_log_raw(sellerInfo.name, sellerInfo.key, "VENDA", "Vendeu " .. qty .. "x " .. tostring(listing.name) .. " para " .. SurvivorShop.getAccountName(player) .. ". Recebeu $" .. payout .. " (pós-taxa).")
end


function Commands.cancel(_, _, player, args)
    if not rateLimitOK(player, "cancel") then return end
    local id = tostring(args.id or "")
    if id == "" then return sendErrorK(player, "IGUI_SS_Err_InvalidID") end

    local pub = getPublic()
    local listing, idx = findListing(pub, id)
    if not listing then return sendErrorK(player, "IGUI_SS_Err_ListingNotFound") end

    local internal = getInternal()
    internal.units = internal.units or {}
    internal.sellerById = internal.sellerById or {}
    local sellerInfo = internal.sellerById[id]
    if not sellerInfo then return sendErrorK(player, "IGUI_SS_Err_InvalidListing") end

    if sellerInfo.key ~= SurvivorShop.getAccountKey(player) then
        return sendErrorK(player, "IGUI_SS_Err_OnlySellerCanCancel")
    end

    local units = internal.units[id] or {}
    local inv = player:getInventory()

    -- Return items (all-or-nothing). If we can't recreate any unit, do NOT remove listing/units.
    local created = {}
    for i=1,#units do
        local u = units[i]
        local it = ss_addItemSmart(inv, listing.itemType)
        if not it then
            for j=#created,1,-1 do
                syncRemove(inv, created[j])
            end
            sendError(player, "Falha ao devolver item (AddItem nil): " .. tostring(listing.itemType) .. ". Cancelamento abortado.")
            return
        end

        local ok, err = pcall(applySerialized, it, u)
        if not ok then
            print("[SurvivorShop] Warning: applySerialized failed during cancel for " .. tostring(listing.itemType) .. ": " .. tostring(err))
        end
        syncAdd(inv, it)
        created[#created+1] = it
    end

    -- Register cancellation in seller's history
    do
        local cancelRecord = {
            listingId = id,
            itemType = listing.itemType,
            itemName = listing.name or listing.itemType,
            quantity = #units,
            unitPrice = tonumber(listing.price) or 0,
            totalPayout = 0,
            buyerName = "[CANCELADO]",
            soldAt = os.time(),
        }
        addSaleRecord(sellerInfo.key, cancelRecord)
        sendSalesHistory(player)
    end

    -- Remove by ID to stay robust against index shifts
    removeListingById(pub, id)

    internal.units[id] = nil
    internal.sellerById[id] = nil

    transmitPublicQueued()
    _ss_sendListingsToPlayer(player)
    sendToastK(player, "IGUI_SS_Toast_ListingCanceledReturned", nil, { refreshSell = true, refreshMy = true, refreshBrowse = true })
    ss_log(player, "CANCELAMENTO", "Cancelou anúncio " .. id .. ": " .. tostring(listing.name or listing.itemType) .. ".")
end



-- Favorites (per-player, stored in player modData)
local function getPlayerFavorites(player)
    if not player or not player.getModData then return {} end
    local md = player:getModData()
    md.SurvivorShopFavorites = md.SurvivorShopFavorites or {}
    return md.SurvivorShopFavorites
end

Commands.favGet = function(module, command, player, args)
    if not rateLimitOK(player, "favGet") then return end
    local favs = getPlayerFavorites(player)
    sendServerCommand(player, SurvivorShop.MODULE, "favorites", { favorites = favs })
end

Commands.favSet = function(module, command, player, args)
    args = args or {}
    local itemType = args.itemType
    if type(itemType) ~= "string" or itemType == "" then
        sendErrorK(player, "IGUI_SS_Err_InvalidItem")
        return
    end
    -- NOTA: getScriptManager():FindItem() falha silenciosamente em B42 dedicado.
    -- A validação foi removida; o itemType vem do inventário real do jogador e
    -- já foi validado pelo Commands.list no momento do anúncio.

    local fav = args.fav == true
    local favs = getPlayerFavorites(player)

    if fav then
        favs[itemType] = true
    else
        favs[itemType] = nil
    end

    -- sendServerCommand("favorites") já atualiza o cliente com os dados corretos.
    -- transmitModData() removido para não sobrescrever ModData de outros mods no cliente.
    sendServerCommand(player, SurvivorShop.MODULE, "favorites", { favorites = favs })
end


-- ===== Expiration sweep (server) =====
local EXPIRE_SWEEP_INTERVAL_MS = 15000
local _lastExpireSweep = 0

local function _ss_expireSweep()
    local n = nowMs()
    if (n - _lastExpireSweep) < EXPIRE_SWEEP_INTERVAL_MS then return end
    _lastExpireSweep = n

    local pub = getPublic()
    local list = getPublicListings(pub)
    if not list or #list == 0 then return end

    local internal = getInternal()
    internal.sellerById = internal.sellerById or {}

    local nowSec = os.time()
    local expireSec = getListingExpireSeconds()
    local changed = false

    for i=1,#list do
        local l = list[i]
        if l then
            if l.created == nil then l.created = nowSec; changed = true end
            if l.expiresAt == nil then
                l.expiresAt = (tonumber(l.created) or nowSec) + expireSec
                changed = true
            end

            local isExpired = (l.expired == true) or ((tonumber(l.expiresAt) or 0) <= nowSec)
            if isExpired and l.expired ~= true then
                l.expired = true
                l.expiredAt = nowSec
                changed = true

                local sid = tostring(l.id)
                local s = internal.sellerById[sid]
                if s then s.expired = true end
            end
        end
    end

    if changed then
        setPublicListings(pub, list)
        transmitPublicQueued()
    end
end

Events.OnTick.Add(_ss_expireSweep)

-- ===== Auction sweep (server) =====
local AUCTION_SWEEP_INTERVAL_MS = 5000
local _lastAuctionSweep = 0

local function _ss_auctionSweep()
    local n = nowMs()
    if (n - _lastAuctionSweep) < AUCTION_SWEEP_INTERVAL_MS then return end
    _lastAuctionSweep = n

    local internal = getInternal()
    local auctions = getInternalAuctions(internal)
    if not auctions or #auctions == 0 then return end

    local bal = getBalances()
    bal.balances = bal.balances or {}

    local nowSec = os.time()
    local changed = false

    for i=1,#auctions do
        local a = auctions[i]
        if a and a.id then
            if a.endAt == nil then
                a.endAt = nowSec + getAuctionDurationSeconds()
                changed = true
            end

            if a.ended ~= true and (tonumber(a.endAt) or 0) <= nowSec then
                a.ended = true
                a.endedAt = nowSec
                changed = true
            end

            -- pay seller once (winner's bid was already deducted/held in balances)
            if a.ended == true and a.sellerPaid ~= true then
                local bid = tonumber(a.currentBid) or 0
                if bid > 0 and a.winnerKey and tostring(a.winnerKey) ~= "" and a.sellerKey and tostring(a.sellerKey) ~= "" then
                    local sk = tostring(a.sellerKey)
                    bal.balances[sk] = (tonumber(bal.balances[sk]) or 0) + bid
                    _ss_addLedgerEntryForKey(sk, {
                        kind = "auction_payout",
                        amount = bid,
                        otherName = _ss_getKnownNameForKey(tostring(a.winnerKey or ""), ""),
                        itemName = tostring(a.itemType or ""),
                        quantity = tonumber(a.quantity) or 0,
                    })
                    local sellerOnline = _ss_pushBalanceAndAuctionClaims(sk)
                    if sellerOnline then
                        sendToastK(sellerOnline, nil, nil, { refreshBalance = true }, "Leilão concluído: saldo do banco atualizado.")
                    end
                end
                a.sellerPaid = true
                changed = true
            end
        end
    end

    if changed then
        _ss_rebuildPublicAuctions()
        transmitPublicQueued()
    end
end

Events.OnTick.Add(_ss_auctionSweep)


-- =========================================================
-- Auction Commands
-- =========================================================
function Commands.auctionHello(_, _, player, args)
    if not rateLimitOK(player, "auctionHello") then return end
    sendServerCommand(player, SurvivorShop.MODULE, "auctionHello", { isAdmin = _ss_isAdmin(player) })
    _ss_sendAuctionClaims(player)
end

function Commands.auctionCreate(_, _, player, args)
    if not rateLimitOK(player, "auctionCreate") then return end
    _ss_registerPlayerAccount(player)
    if not _ss_isAdmin(player) then return sendErrorK(player, "IGUI_SS_Err_AdminOnlyAuctionCreate") end

    local itemType = tostring(args.itemType or "")
    local qty = math.floor(tonumber(args.quantity) or 1)
    local minBid = math.floor(tonumber(args.minBid) or 0)

    if itemType == "" or qty <= 0 then return sendErrorK(player, "IGUI_SS_Err_InvalidItemQuantity") end
    if qty > 9999 then qty = 9999 end
    if minBid < 0 then minBid = 0 end

    -- remove items from admin inventory (server authoritative)
    local inv = player:getInventory()
    if not inv then return sendErrorK(player, "IGUI_SS_Err_InvalidInventory") end

    local removedItems = {}
    local remaining = takeItemsRecursive(inv, itemType, qty, removedItems, player)
    if remaining > 0 then
        -- rollback removed items if partial
        if #removedItems > 0 then
            local restored = {}
            for i=1,#removedItems do
                local snapshot = serializeItem(removedItems[i])
                local it = restoreSerializedItem(inv, itemType, snapshot)
                if not it then
                    for j=#restored,1,-1 do
                        syncRemove(inv, restored[j])
                    end
                    return sendError(player, "Falha ao restaurar item removido durante a criação do leilão: " .. tostring(itemType) .. ".")
                end
                restored[#restored+1] = it
            end
        end
        return sendErrorK(player, "IGUI_SS_Err_NotEnoughItemsToAuction")
    end

    local auctionUnits = {}
    for i=1,#removedItems do
        auctionUnits[i] = serializeItem(removedItems[i])
    end

    local internal = getInternal()
    local auctions = getInternalAuctions(internal)

    local id = tostring(internal.nextAuctionId or 1)
    internal.nextAuctionId = (tonumber(internal.nextAuctionId) or 1) + 1

    local nowSec = os.time()
    local a = {
        id = id,
        itemType = itemType,
        quantity = qty,
        minBid = minBid,
        currentBid = 0,
        bidderKey = nil,
        winnerKey = nil,
        sellerKey = SurvivorShop.getAccountKey(player),
        sellerName = SurvivorShop.getAccountName(player),
        sellerPaid = false,
        createdAt = nowSec,
        endAt = nowSec + getAuctionDurationSeconds(),
        ended = false,
        claimed = false,
        units = auctionUnits,
        bids = {},
    }

    table.insert(auctions, a)
    internal.auctions = auctions

    _ss_rebuildPublicAuctions()
    transmitPublicQueued()
    sendToastK(player, "IGUI_SS_Toast_AuctionCreated")
end

function Commands.auctionBid(_, _, player, args)
    if not rateLimitOK(player, "auctionBid") then return end
    _ss_registerPlayerAccount(player)

    local id = tostring(args.id or "")
    local amount = math.floor(tonumber(args.amount) or 0)
    if id == "" or amount <= 0 then return sendErrorK(player, "IGUI_SS_Err_InvalidBid") end

    local internal = getInternal()
    local a = _ss_getAuctionById(internal, id)
    if not a then return sendErrorK(player, "IGUI_SS_Err_AuctionNotFound") end

    local nowSec = os.time()
    if a.ended == true or (tonumber(a.endAt) or 0) <= nowSec then
        a.ended = true
        _ss_rebuildPublicAuctions()
        transmitPublicQueued()
        _ss_sendAuctionClaims(player)
        return sendErrorK(player, "IGUI_SS_Err_AuctionAlreadyEnded")
    end

    local current = tonumber(a.currentBid) or 0
    local minBid = tonumber(a.minBid) or 0
    local inc = getAuctionMinIncrement()
    local required = (current > 0) and (current + inc) or minBid
    if amount < required then
        return sendErrorK(player, "IGUI_SS_Err_AuctionMinBid", { tostring(required) })
    end

    local feePct = getAuctionBidFeePercent()
    local fee = 0
    if feePct > 0 then
        fee = math.floor(amount * (feePct / 100.0))
        if fee < 1 then fee = 1 end
    end

    local bal = getBalances()
    bal.balances = bal.balances or {}
    local bmap = bal.balances
    local key = SurvivorShop.getAccountKey(player)

    local prevKey = tostring(a.bidderKey or "")
    local prevAmt = tonumber(a.currentBid) or 0

    local have = tonumber(bmap[key]) or 0
    local available = have
    if prevKey ~= "" and prevKey == tostring(key) then
        -- if you are re-bidding, your previous bid is effectively available (it will be refunded then re-charged)
        available = have + prevAmt
    end

    local total = amount + fee
    if available < total then
        return sendErrorK(player, "IGUI_SS_Err_InsufficientBidAndFee")
    end

    -- refund previous highest bidder (bid only; fee is never refunded)
    if prevKey ~= "" and prevAmt > 0 then
        bmap[prevKey] = (tonumber(bmap[prevKey]) or 0) + prevAmt
        if prevKey ~= tostring(key) then
            _ss_pushBalanceAndAuctionClaims(prevKey)
        end
    end

    -- charge new bidder
    bmap[key] = (tonumber(bmap[key]) or 0) - total
    bal.balances = bmap

    a.currentBid = amount
    a.bidderKey = key
    a.winnerKey = key
    a.lastBidAt = nowSec

    -- Record in bid history
    a.bids = a.bids or {}
    table.insert(a.bids, 1, {
        bidderName = SurvivorShop.getAccountName(player),
        amount = amount,
        time = nowSec
    })

    -- Limit history size to prevent ModData bloat
    if #a.bids > 10 then
        table.remove(a.bids, 11)
    end

    _ss_rebuildPublicAuctions()
    transmitPublicQueued()

    sendBalance(player, tonumber(bmap[key]) or 0)
    if fee > 0 then
        sendToastK(player, "IGUI_SS_Toast_AuctionBidAcceptedWithFee", { tostring(amount), tostring(fee) })
    else
        sendToastK(player, "IGUI_SS_Toast_AuctionBidAccepted", { tostring(amount) })
    end
    _ss_sendAuctionClaims(player)
end

function Commands.auctionClaim(_, _, player, args)
    if not rateLimitOK(player, "auctionClaim") then return end
    _ss_registerPlayerAccount(player)
    local id = tostring(args.id or "")
    if id == "" then return sendErrorK(player, "IGUI_SS_Err_InvalidID") end

    local internal = getInternal()
    local a = _ss_getAuctionById(internal, id)
    if not a then return sendErrorK(player, "IGUI_SS_Err_AuctionNotFound") end

    local key = SurvivorShop.getAccountKey(player)
    local nowSec = os.time()

    if (tonumber(a.endAt) or 0) > nowSec and a.ended ~= true then
        return sendErrorK(player, "IGUI_SS_Err_AuctionNotEnded")
    end
    a.ended = true

    if a.claimed == true then return sendErrorK(player, "IGUI_SS_Err_PrizeAlreadyClaimed") end

    local isWinner = (tostring(a.winnerKey or "") ~= "" and tostring(a.winnerKey) == tostring(key))
    local isSellerUnsold = ((a.winnerKey == nil or tostring(a.winnerKey) == "") and tostring(a.sellerKey or "") == tostring(key))
    if not isWinner and not isSellerUnsold then
        return sendErrorK(player, "IGUI_SS_Err_OnlyWinnerCanClaim")
    end

    local inv = player:getInventory()
    if not inv then return sendErrorK(player, "IGUI_SS_Err_InvalidInventory") end

    local qty = math.max(1, math.floor(tonumber(a.quantity) or 1))
    local itemType = tostring(a.itemType or "")
    if itemType == "" then return sendErrorK(player, "IGUI_SS_Err_InvalidItem") end

    local units = type(a.units) == "table" and a.units or {}
    local created = {}
    for i=1,qty do
        local snapshot = units[i]
        local it, err = restoreSerializedItem(inv, itemType, snapshot)
        if not it then
            for j=#created,1,-1 do
                syncRemove(inv, created[j])
            end
            return sendError(player, "Falha ao entregar prêmio do leilão (" .. tostring(itemType) .. "): " .. tostring(err or "unknown") .. ".")
        end
        created[#created+1] = it
    end

    a.claimed = true
    a.claimedAt = nowSec
    a.units = nil

    _ss_rebuildPublicAuctions()
    transmitPublicQueued()
    _ss_sendAuctionClaims(player)

    sendToastK(player, "IGUI_SS_Toast_AuctionPrizeClaimed")
end

function Commands.auctionGetClaims(_, _, player, args)
    if not rateLimitOK(player, "auctionGetClaims") then return end
    _ss_sendAuctionClaims(player)
end

function Commands.getSalesHistory(_, _, player, args)
    print("[SurvivorShop] getSalesHistory command received from " .. tostring(SurvivorShop.getAccountName(player)))
    if not rateLimitOK(player, "getSalesHistory") then
        print("[SurvivorShop] Rate limit hit for getSalesHistory")
        return
    end
    sendSalesHistory(player)
end

function onClientCommand(module, command, player, args)
    if module ~= SurvivorShop.MODULE then return end
    local fn = Commands[command]
    if fn then fn(module, command, player, args or {}) end
end
Events.OnClientCommand.Add(onClientCommand)

Events.OnInitGlobalModData.Add(function()
    getPublic().listings = getPublic().listings or {}
    getPublic().auctions = getPublic().auctions or {}
    local internal = getInternal()
    internal.units = internal.units or {}
    internal.sellerById = internal.sellerById or {}
    _ss_rebuildPublicAuctions()
    getBalances().balances = getBalances().balances or {}
    getBalances().savings = getBalances().savings or {}
    _ss_normalizeLedgerStore()
    _ss_normalizeInvoiceStore()
    _ss_normalizeAccountDirectory()
    normalizeSalesHistoryStore()
    _ss_seedAccountDirectoryFromState()

    -- Migration: Clean up old listing names with "?" prefix
    print("[SurvivorShop] Running migration: cleaning up old listing names...")
    local pub = getPublic()
    local listings = pub.listings or {}
    local cleanedCount = 0
    for i, listing in ipairs(listings) do
        if listing and listing.name then
            local oldName = listing.name
            listing.name = stripUnknownPrefix(listing.name)
            if oldName ~= listing.name then
                cleanedCount = cleanedCount + 1
            end
        end
    end
    if cleanedCount > 0 then
        print("[SurvivorShop] Migration: cleaned " .. tostring(cleanedCount) .. " listing names")
        setPublicListings(pub, listings)
        transmitPublicQueued()
    else
        print("[SurvivorShop] Migration: no listing names needed cleaning")
    end

    -- Migration: Clean up sales history item names with "?" prefix
    print("[SurvivorShop] Running migration: cleaning up sales history...")
    local salesHistoryData = normalizeSalesHistoryStore()
    if salesHistoryData then
        local historyCleanedCount = 0
        for playerKey, playerHistory in pairs(salesHistoryData) do
            if type(playerHistory) == "table" then
                for i, sale in ipairs(playerHistory) do
                    if sale and sale.itemName then
                        local oldName = sale.itemName
                        sale.itemName = stripUnknownPrefix(sale.itemName)
                        if oldName ~= sale.itemName then
                            historyCleanedCount = historyCleanedCount + 1
                        end
                    end
                end
            end
        end
        if historyCleanedCount > 0 then
            print("[SurvivorShop] Migration: cleaned " .. tostring(historyCleanedCount) .. " sales history names")
            ModData.add(SurvivorShop.MODDATA_SALES_HISTORY, salesHistoryData)
        else
            print("[SurvivorShop] Migration: no sales history names needed cleaning")
        end
    end
end)
