-- SurvivorShopContext.lua (B42 / ATM + shop computer)
require "SurvivorShopShared"
require "SurvivorShopUI"

-- ATM sprites (Tile Report)
-- Example provided: location_business_bank_01_65
local ATM_SPRITES = {
    ["location_business_bank_01_65"] = true,
    -- add more variants here if needed
}

-- Shop computer sprite (Tile Report)
local SHOP_COMPUTER_SPRITES = {
    ["appliances_com_01_72"] = true,
    ["appliances_com_01_73"] = true,
}

local function getSandboxBool(key, defaultVal)
    local sv = SandboxVars and SandboxVars.SurvivorShop
    if sv and sv[key] ~= nil then
        return sv[key] == true
    end
    return defaultVal == true
end

local function isATM(obj)
    if not obj then return false end
    local spr = obj.getSprite and obj:getSprite()
    if not spr then return false end
    local name = spr:getName()
    if ATM_SPRITES[name] then return true end
    -- fallback: match family (safer when tiles vary)
    if type(name) == "string" and string.find(name, "location_business_bank_") == 1 then
        return true
    end
    return false
end

local function isComputer(obj)
    if not obj then return false end
    local spr = obj.getSprite and obj:getSprite()
    local name = spr and spr.getName and spr:getName() or nil
    return SHOP_COMPUTER_SPRITES[name] == true
end

local function hasPower(obj)
    local sq = obj and obj.getSquare and obj:getSquare()
    if not sq then return true end
    if sq.haveElectricity then return sq:haveElectricity() end
    if sq.isPowered then return sq:isPowered() end
    local building = sq.getBuilding and sq:getBuilding()
    if building and building.hasPower then return building:hasPower() end
    return true
end

local function addShopOption(context, playerObj)
    if not context or not playerObj then return end

    -- IMPORTANT: UI opens instantly without walking to the ATM.
    -- Any movement/distance checks must be enforced server-side on actions (buy/sell/cancel),
    -- not when opening the UI.
    context:addOption(getText("IGUI_SS_OpenShop") or "Open Survivor Shop", playerObj, function(p)
        if SurvivorShopUI and SurvivorShopUI.open then
            SurvivorShopUI.open(p)
        else
            print("[SurvivorShop] SurvivorShopUI.open not found")
        end
    end)
end

local function onFillWorldObjectContextMenu(playerNum, context, worldobjects, test)
    if test then return true end
    local playerObj = getSpecificPlayer(playerNum)
    if not playerObj then return end

    -- Check clicked objects
    for i=1,#worldobjects do
        local obj = worldobjects[i]
        if getSandboxBool("AllowATMAccess", true) and isATM(obj) then
            addShopOption(context, playerObj, obj)
            return
        end

        if getSandboxBool("AllowComputerAccess", true) and isComputer(obj) then
            addShopOption(context, playerObj, obj)
            return
        end

        -- fallback: scan square objects (some clicks return floor or parent)
        local sq = obj and obj.getSquare and obj:getSquare()
        if sq then
            local objs = sq:getObjects()
            for j=0, objs:size()-1 do
                local o = objs:get(j)
                if getSandboxBool("AllowATMAccess", true) and isATM(o) then
                    addShopOption(context, playerObj, o)
                    return
                end

                if getSandboxBool("AllowComputerAccess", true) and isComputer(o) then
                    addShopOption(context, playerObj, o)
                    return
                end
            end
        end
    end
end

Events.OnFillWorldObjectContextMenu.Add(onFillWorldObjectContextMenu)
