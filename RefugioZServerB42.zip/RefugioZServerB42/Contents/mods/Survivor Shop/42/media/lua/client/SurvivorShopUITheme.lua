-- SurvivorShopUITheme.lua (B42) - UI helpers inspired by BurdJournals_UIShared.lua
SurvivorShopUITheme = SurvivorShopUITheme or {}

SurvivorShopUITheme.Colors = {
    panelBg = {r=0.05, g=0.055, b=0.065, a=0.96},
    panelInset = {r=0.09, g=0.095, b=0.11, a=0.90},
    panelBorder = {r=0.36, g=0.33, b=0.26, a=0.92},
    panelBorderSoft = {r=0.19, g=0.18, b=0.16, a=0.90},
    panelShadow = {r=0, g=0, b=0, a=0.24},
    panelGlow = {r=0.84, g=0.67, b=0.31, a=0.08},

    headerBg = {r=0.11, g=0.09, b=0.07, a=0.98},
    headerAccent = {r=0.84, g=0.67, b=0.31, a=1.00},
    headerAccentSoft = {r=0.47, g=0.37, b=0.15, a=0.75},
    headerLine = {r=0.16, g=0.54, b=0.46, a=1.00},

    titleText = {r=0.98, g=0.96, b=0.92, a=1},
    normalText = {r=0.90, g=0.89, b=0.85, a=1},
    dimText = {r=0.64, g=0.62, b=0.58, a=1},
    accentText = {r=0.94, g=0.79, b=0.40, a=1},
    successText = {r=0.62, g=0.91, b=0.67, a=1},
    dangerText = {r=0.95, g=0.49, b=0.40, a=1},
    infoText = {r=0.62, g=0.83, b=0.98, a=1},

    listBg = {r=0.08, g=0.085, b=0.10, a=0.96},
    listAltBg = {r=0.095, g=0.10, b=0.12, a=0.96},
    listRowEven = {r=0.10, g=0.105, b=0.12, a=0.90},
    listRowAlt = {r=0.12, g=0.125, b=0.145, a=0.92},
    listHover = {r=0.16, g=0.17, b=0.20, a=0.98},
    listSelected = {r=0.18, g=0.23, b=0.20, a=0.99},

    btnDark = {r=0.12, g=0.12, b=0.14},
    btnDefault = {r=0.17, g=0.15, b=0.13},
    btnDefaultOver = {r=0.23, g=0.20, b=0.16},
    btnSuccess = {r=0.17, g=0.38, b=0.28},
    btnSuccessOver = {r=0.22, g=0.48, b=0.35},
    btnSuccessBorder = {r=0.42, g=0.72, b=0.55},
    btnInfo = {r=0.17, g=0.27, b=0.36},
    btnInfoOver = {r=0.22, g=0.34, b=0.46},
    btnDanger = {r=0.45, g=0.18, b=0.15},
    btnDangerOver = {r=0.58, g=0.24, b=0.20},
    btnWarn = {r=0.42, g=0.29, b=0.08},
    btnWarnOver = {r=0.52, g=0.36, b=0.10},
    btnWarnBorder = {r=0.90, g=0.74, b=0.26},

    searchBg = {r=0.07, g=0.07, b=0.08, a=0.97},
    searchBorder = {r=0.26, g=0.24, b=0.22, a=0.90},

    priceBg = {r=0.08, g=0.08, b=0.10},
}

function SurvivorShopUITheme.styleButton(btn, variant)
    if not btn then return end
    local c = SurvivorShopUITheme.Colors

    if variant == "success" then
        btn.backgroundColor = {r=c.btnSuccess.r, g=c.btnSuccess.g, b=c.btnSuccess.b, a=0.90}
        btn.backgroundColorMouseOver = {r=c.btnSuccessOver.r, g=c.btnSuccessOver.g, b=c.btnSuccessOver.b, a=0.95}
        btn.borderColor = {r=c.btnSuccessBorder.r, g=c.btnSuccessBorder.g, b=c.btnSuccessBorder.b, a=0.95}
        btn.textColor = {r=1, g=1, b=1, a=1}
    elseif variant == "warning" then
        btn.backgroundColor = {r=c.btnWarn.r, g=c.btnWarn.g, b=c.btnWarn.b, a=0.90}
        btn.backgroundColorMouseOver = {r=c.btnWarnOver.r, g=c.btnWarnOver.g, b=c.btnWarnOver.b, a=0.95}
        btn.borderColor = {r=c.btnWarnBorder.r, g=c.btnWarnBorder.g, b=c.btnWarnBorder.b, a=0.95}
        btn.textColor = {r=1, g=1, b=1, a=1}
    elseif variant == "info" then
        btn.backgroundColor = {r=c.btnInfo.r, g=c.btnInfo.g, b=c.btnInfo.b, a=0.90}
        btn.backgroundColorMouseOver = {r=c.btnInfoOver.r, g=c.btnInfoOver.g, b=c.btnInfoOver.b, a=0.95}
        btn.borderColor = {r=c.panelBorder.r, g=c.panelBorder.g, b=c.panelBorder.b, a=0.85}
        btn.textColor = {r=1, g=1, b=1, a=1}
    elseif variant == "dangerTiny" then
        btn.backgroundColor = {r=c.btnDefault.r, g=c.btnDefault.g, b=c.btnDefault.b, a=0.85}
        btn.backgroundColorMouseOver = {r=c.btnDangerOver.r, g=c.btnDangerOver.g, b=c.btnDangerOver.b, a=0.95}
        btn.borderColor = {r=c.panelBorder.r, g=c.panelBorder.g, b=c.panelBorder.b, a=0.85}
        btn.textColor = {r=0.9, g=0.85, b=0.85, a=1}
    else
        -- default
        btn.backgroundColor = {r=c.btnDefault.r, g=c.btnDefault.g, b=c.btnDefault.b, a=0.90}
        btn.backgroundColorMouseOver = {r=c.btnDefaultOver.r, g=c.btnDefaultOver.g, b=c.btnDefaultOver.b, a=0.95}
        btn.borderColor = {r=c.panelBorder.r, g=c.panelBorder.g, b=c.panelBorder.b, a=0.85}
        btn.textColor = {r=0.95, g=0.95, b=0.95, a=1}
    end
end

function SurvivorShopUITheme.truncateText(text, maxWidth, font)
    if not text then return "" end
    local tm = getTextManager()
    local f = font or UIFont.Small
    if tm:MeasureStringX(f, text) <= maxWidth then return text end
    local ellipsis = "..."
    local targetWidth = maxWidth - tm:MeasureStringX(f, ellipsis)
    local s = text
    while #s > 0 and tm:MeasureStringX(f, s) > targetWidth do
        s = string.sub(s, 1, -2)
    end
    return s .. ellipsis
end

function SurvivorShopUITheme.normQuery(q)
    if not q then return nil end
    q = tostring(q)
    q = q:gsub("^%s+", ""):gsub("%s+$", "")
    if q == "" then return nil end
    return string.lower(q)
end

function SurvivorShopUITheme.matchesSearch(normQuery, text)
    if not normQuery then return true end
    local name = string.lower(tostring(text or ""))
    return string.find(name, normQuery, 1, true) ~= nil
end


-- ===== Extra UI polish helpers =====
function SurvivorShopUITheme.styleTextEntry(entry)
    if not entry then return end
    local c = SurvivorShopUITheme.Colors
    entry.backgroundColor = {r=c.searchBg.r, g=c.searchBg.g, b=c.searchBg.b, a=c.searchBg.a}
    entry.borderColor = {r=c.searchBorder.r, g=c.searchBorder.g, b=c.searchBorder.b, a=c.searchBorder.a}
    entry.textColor = {r=c.normalText.r, g=c.normalText.g, b=c.normalText.b, a=1}
    -- cursorColor exists in newer builds; guard just in case
    if entry.cursorColor ~= nil then
        entry.cursorColor = {r=c.headerAccent.r, g=c.headerAccent.g, b=c.headerAccent.b, a=1}
    end
end

function SurvivorShopUITheme.styleComboBox(combo)
    if not combo then return end
    local c = SurvivorShopUITheme.Colors
    combo.backgroundColor = {r=c.btnDark.r, g=c.btnDark.g, b=c.btnDark.b, a=0.90}
    combo.borderColor = {r=c.panelBorder.r, g=c.panelBorder.g, b=c.panelBorder.b, a=0.85}
    combo.textColor = {r=c.normalText.r, g=c.normalText.g, b=c.normalText.b, a=1}
end

function SurvivorShopUITheme.styleListBox(list)
    if not list then return end
    local c = SurvivorShopUITheme.Colors
    list.backgroundColor = {r=c.listBg.r, g=c.listBg.g, b=c.listBg.b, a=c.listBg.a}
    list.borderColor = {r=c.panelBorder.r, g=c.panelBorder.g, b=c.panelBorder.b, a=0.75}
end


-- ===== Premium chrome =====
SurvivorShopUITheme.Textures = SurvivorShopUITheme.Textures or {}

function SurvivorShopUITheme.loadTextures()
    if SurvivorShopUITheme.Textures._loaded then return end
    SurvivorShopUITheme.Textures._loaded = true
    SurvivorShopUITheme.Textures.headerGradient = getTexture("media/ui/SS_HeaderGradient.png")
end

function SurvivorShopUITheme.drawPremiumHeader(panel, x, y, w, h, title, iconTex)
    SurvivorShopUITheme.loadTextures()
    local c = SurvivorShopUITheme.Colors
    local gradient = SurvivorShopUITheme.Textures.headerGradient
    panel:drawRect(x + 3, y + h, w - 6, 4, 0.18, 0, 0, 0)
    panel:drawRect(x, y, w, h, c.headerBg.a, c.headerBg.r, c.headerBg.g, c.headerBg.b)
    if gradient and panel.drawTextureScaled then
        panel:drawTextureScaled(gradient, x, y, w, h, 0.22, 1, 1, 1)
    end
    panel:drawRect(x + 12, y + 10, math.min(140, w * 0.22), h - 20, 0.09, c.headerAccent.r, c.headerAccent.g, c.headerAccent.b)
    panel:drawRect(x + 16, y + 8, w - 32, 1, 0.08, 1, 1, 1)

    -- icon (optional)
    local tx = x + 20
    local boxX = tx - 8
    local boxY = y + 8
    local boxW = 34
    local boxH = 34
    panel:drawRect(boxX, boxY, boxW, boxH, 0.12, c.headerAccent.r, c.headerAccent.g, c.headerAccent.b)
    panel:drawRectBorder(boxX, boxY, boxW, boxH, 0.30, c.headerAccent.r, c.headerAccent.g, c.headerAccent.b)
    if iconTex and panel.drawTextureScaled then
        local iconSize = 20
        local iconX = boxX + math.floor((boxW - iconSize) / 2)
        local iconY = boxY + math.floor((boxH - iconSize) / 2)
        panel:drawTextureScaled(iconTex, iconX, iconY, iconSize, iconSize, 1, 1, 1, 1)
    else
        local font = UIFont.Large
        local textY = boxY + math.floor((boxH - getTextManager():getFontHeight(font)) / 2) - 1
        panel:drawTextCentre("$", boxX + math.floor(boxW / 2), textY, c.headerAccent.r, c.headerAccent.g, c.headerAccent.b, 0.85, font)
    end
    tx = boxX + boxW + 10

    -- title with shadow
    panel:drawText(title, tx + 1, y + 10, 0, 0, 0, 0.55, UIFont.Large)
    panel:drawText(title, tx,     y + 9, c.titleText.r, c.titleText.g, c.titleText.b, c.titleText.a, UIFont.Large)
    -- Subtitle removed to avoid overlap with tab strip on smaller UI scales.
end

function SurvivorShopUITheme.drawSoftPanel(panel, x, y, w, h)
    local c = SurvivorShopUITheme.Colors
    panel:drawRect(x + 3, y + 4, w, h, c.panelShadow.a, c.panelShadow.r, c.panelShadow.g, c.panelShadow.b)
    panel:drawRect(x, y, w, h, c.panelInset.a, c.panelInset.r, c.panelInset.g, c.panelInset.b)
    panel:drawRectBorder(x, y, w, h, c.panelBorder.a, c.panelBorder.r, c.panelBorder.g, c.panelBorder.b)
    panel:drawRectBorder(x + 1, y + 1, w - 2, h - 2, 0.25, c.panelBorderSoft.r, c.panelBorderSoft.g, c.panelBorderSoft.b)
    panel:drawRect(x + 1, y + 1, w - 2, 1, 0.06, 1, 1, 1)
end

function SurvivorShopUITheme.drawSectionTitle(panel, x, y, w, label, accent)
    local c = SurvivorShopUITheme.Colors
    local ac = accent or c.headerLine
    panel:drawRect(x, y + 8, w, 1, 0.22, c.panelBorderSoft.r, c.panelBorderSoft.g, c.panelBorderSoft.b)
    panel:drawRect(x, y + 8, math.min(72, w), 2, 0.95, ac.r, ac.g, ac.b)
    panel:drawText(label or "", x, y, c.dimText.r, c.dimText.g, c.dimText.b, 0.95, UIFont.Small)
end

function SurvivorShopUITheme.drawInfoPill(panel, x, y, w, h, label, accent)
    local c = SurvivorShopUITheme.Colors
    local ac = accent or c.headerAccent
    panel:drawRect(x, y, w, h, 0.16, ac.r, ac.g, ac.b)
    panel:drawRectBorder(x, y, w, h, 0.38, ac.r, ac.g, ac.b)
    panel:drawTextCentre(label or "", x + w / 2, y + math.floor((h - getTextManager():getFontHeight(UIFont.Small)) / 2), c.titleText.r, c.titleText.g, c.titleText.b, 0.92, UIFont.Small)
end
